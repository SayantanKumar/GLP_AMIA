50 years old|0
    female|0
    admitted to the hospital|0
    headache|-72
    dizziness|-72
    nausea|-72
    weakness|-72
    chronic obstructive pulmonary disease|0
    hypertension|0
    hyperlipidemia|0
    bipolar disorder|0
    autoimmune hepatitis|0
    cirrhosis|0
    gastroesophageal reflux disease|0
    hypothyroidism|0
    type 2 diabetes mellitus|0
    air conditioner stopped working|-168
    standing close to the freezer door|-168
    eating pieces of ice|-168
    feeling heated|-168
    sweating profusely|-168
    albuterol inhaler|0
    clonidine 0.2 mg twice a day|0
    atorvastatin 40 mg nightly|0
    quetiapine 300 mg nightly|0
    fluoxetine 20 mg daily|0
    benztropine 1 mg twice a day|0
    prednisone 5 mg daily|0
    pantoprazole 40 mg daily|0
    furosemide 20 mg daily|0
    levothyroxine 50 mcg daily|0
    metformin 1000 mg twice a day|0
    insulin degludec 16 units every morning|0
    exenatide 2 mg weekly|0
    not adhering to prescription medication regimen|0
    not adhering to diabetic diet|0
    no recent changes in prescription medications|0
    denied taking over-the-counter medications|0
    blood pressure 150/90 mmHg|0
    temperature 37.4°C|0
    heart rate 105 beats per min|0
    respiratory rate 18 breaths per min|0
    oxygen saturation 99% on room air|0
    lethargic|0
    dry mucus membranes|0
    hyperglycemia|0
    blood glucose 365 mg/dL|0
    severe hypercalcemia|0
    calcium level 17.3 gm/dL|0
    ionized calcium 1.95 mM/L|0
    normal bicarbonate|0
    normal anion gap|0
    hyperglycemia without diabetic ketoacidosis|0
    blood gas not done|0
    electrocardiogram normal sinus rhythm without ST-segment changes|0
    administered 2-liter fluid bolus of normal saline|0
    started continuous infusion of normal saline at 150 mL/h|0
    calcium level gradually improved|24
    intravenous hydration|0
    calcium normalized by the third day|72
    bisphosphonate therapy not needed|0
    parathyroid hormone|0
    parathyroid hormone-related peptide|0
    ​25-hydroxy vitamin D|0
    ​1,25-dihydroxy vitamin D|0
    thyroid-stimulation hormone|0
    cortisol|0
    serum protein electrophoresis|0
    serum-free light chain|0
    intravenous hydration stopped|72
    symptoms resolved|72
    discharged|96
    follow-up visit with primary care physician|264
    mammography bilateral breast|264
    nuclear bone imaging whole body|264
    computed tomography scan chest abdomen pelvis|264
    calcium level within reference range|264
    