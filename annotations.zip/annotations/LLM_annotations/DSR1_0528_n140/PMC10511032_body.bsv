35 years old | 0
    male | 0
    obesity | 0
    no medical conditions | 0
    no history of surgery | 0
    insertion of MedSil IGB | 0
    weight loss | 0
    failed to reach targeted body weight on subcutaneous semaglutide | -168
    intolerance to dose escalation | -168
    balloon filled with 600 mL normal saline | 0
    balloon filled with 10 mL methylene blue | 0
    developed left-sided varicocele | 168
    scrotal ultrasound confirmed varicocele | 168
    abdominal-pelvic CT scan | 168
    balloon compression of splenic vein | 168
    no enhancement of splenic vein distal end | 168
    few collaterals | 168
    acute obstruction | 168
    nonfilling segment thrombosis not excluded | 168
    dilatation of left gonadal vein | 168
    no other abnormality in abdomen | 168
    gastric balloon removed endoscopically | 168
    started on rivaroxaban | 168
    no isolated gastric varices | 168
    improvement in varicocele | 168
    abdominal CT scan repeated | 336
    patent splenic vein | 336
    complete recanalization | 336
    significant reduction in gonadal vein caliber | 336
    advised to continue rivaroxaban for 3 months | 336
    symptoms completely resolved | 336
    no complications | 336
    referred to bariatric surgeon | 336
    <|eot_id|>