39 years old | 0
    male | 0
    White | 0
    presented with obesity | 0
    history of failure of nonpharmacologic strategies for weight reduction | 0
    treated with liraglutide | 0
    liraglutide administered subcutaneously | 0
    initial dose of liraglutide 0.6 mg daily | 0
    dose increased weekly by 0.6 mg | 0
    therapeutic dose of 3 mg daily | 0
    pruritic erythematous patches appeared on the injection sites | 168
    injection sites | 168
    itch was negligible | 168
    continued the drug administration | 168
    clinical examination | 0
    round erythematous plaques on the abdomen | 0
    injection sites of liraglutide | 0
    no allergies | 0
    no previous history of atopy | 0
    no concomitant disease beyond obesity | 0
    obesity class 2 | 0
    body mass index of 39.2 kg/m2 | 0
    patch test | 0
    patch test negative | 48
    skin prick test | 0
    skin prick test negative | 0
    intradermal test | 0
    intradermal test negative at 20th minute | 0
    intradermal test positive at 24-hour reading | 24
    intradermal test in 5 healthy controls negative | 0
    refused skin biopsy | 0
    refused histopathologic examination | 0
    benign course | 0
    complete healing of the skin lesions | 0
    diagnosis of delayed hypersensitivity to liraglutide | 0
    symptomatic treatment | 0
    clobetasol propionate ointment 0.05% twice daily | 0
    mometasone furoate ointment 0.1% once daily | 336
    continued treatment with liraglutide 3 mg daily | 0
    tolerate the drug without any skin reaction | 4320
    end of the treatment | 4320
    6-month follow-up | 4320
    no skin reaction | 4320
    <|eot_id|>
    