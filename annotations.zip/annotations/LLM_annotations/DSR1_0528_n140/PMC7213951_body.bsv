59 years old | 0
    female | 0
    type 2 diabetes mellitus | -43800
    generalized anxiety disorder | -43800
    major depressive disorder | -43800
    hypertension | -43800
    hyperlipidemia | -43800
    heart murmur | -43800
    degenerative arthritis of the knee | -43800
    esophageal reflux disease | -43800
    iron deficiency anemia | -43800
    insomnia | -43800
    vitamin D deficiency | -43800
    tobacco use | -43800
    no alcohol use | -43800
    no illicit drug use | -43800
    insulin glargine | -43800
    metformin extended release | -43800
    dulaglutide | -43800
    venlafaxine extended release | -43800
    aspirin | -43800
    losartan | -43800
    ezetimibe | -43800
    polysaccharide iron complex | -43800
    multivitamin | -43800
    omeprazole-sodium bicarbonate | -43800
    venlafaxine extended release 75 mg daily | -35040
    venlafaxine extended release increased to 225 mg daily | -35040
    anxiousness | -35040
    sadness | -35040
    insomnia | -35040
    desvenlafaxine | -35040
    insurance coverage | -35040
    improved generalized anxiety disorder | -35040
    improved major depressive disorder | -35040
    hemoglobin A1c 7.5% | -2160
    fasting blood glucose 96 mg/dL | -2160
    bedtime blood glucose 175 mg/dL | -2160
    dulaglutide 1.5 mg | -2160
    fasting blood glucose 88 mg/dL | -720
    postprandial blood glucose 165 mg/dL | -720
    hemoglobin A1c 7.2% | 0
    fasting blood glucose 106 mg/dL | 0
    postprandial blood glucose 129 mg/dL | 0
    venlafaxine extended release discontinued | 0
    desvenlafaxine extended release 50 mg daily initiated | 0
    patient health questionnaire-9 score 8 | 0
    fasting blood glucose 136 mg/dL | 720
    postprandial blood glucose 207 mg/dL | 720
    insulin glargine increased to 10 units daily | 720
    fasting blood glucose 129 mg/dL | 1440
    postprandial blood glucose 192 mg/dL | 1440
    insulin glargine increased to 12 units daily | 1440
    fasting blood glucose 118 mg/dL | 1560
    postprandial blood glucose 194 mg/dL | 1560
    insulin lispro 2 units initiated | 1560
    insulin lispro increased to 8 units | 2160
    fasting blood glucose 106 mg/dL | 2160
    postprandial blood glucose 146 mg/dL | 2160
    hemoglobin A1c 7.3% | 2160
    hemoglobin A1c 6.9% | 6480
    weight stable | 0
    patient health questionnaire-9 score 8 | 4320
    improved anxiety in social situations | 4320
    improved energy level | 4320
    no discontinuation of desvenlafaxine | 4320
    hyperglycemia | 720
    