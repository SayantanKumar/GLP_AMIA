51 years old | 0\
    man | 0\
    referred to hospital | 0\
    high hemoglobin A1c | 0\
    hemoglobin A1c 13.5% | 0\
    body height 162.8 cm | 0\
    body weight 63 kg | 0\
    body mass index 24.6 kg/m2 | 0\
    abdominal circumference 83.5 cm | 0\
    type 2 diabetes | 0\
    systolic blood pressure 106 mm Hg | 0\
    diastolic blood pressure 66 mm Hg | 0\
    triglyceride 231 mg/dL | 0\
    high-density lipoprotein-cholesterol 48 mg/dL | 0\
    low-density lipoprotein-cholesterol 141 mg/dL | 0\
    creatinine 0.8 mg/dL | 0\
    eGFR 80.1 mL/min/1.73 m2 | 0\
    urinalysis no proteinuria | 0\
    sitagliptin started | 0\
    metformin started | 0\
    metformin 500 mg/day | 0\
    triglyceride 139 mg/dL | 0\
    high-density lipoprotein-cholesterol 40 mg/dL | 0\
    low-density lipoprotein-cholesterol 124 mg/dL | 0\
    eGFR decreased | -8760\
    eGFR 34.5 mL/min/1.73 m2 | -8760\
    metformin discontinued | -8760\
    systolic blood pressure 120 mm Hg | -8760\
    diastolic blood pressure 74 mm Hg | -8760\
    microalbuminuria not detected | -8760\
    masked hypertension | -8760\
    home systolic blood pressure frequently over 140 mm Hg | -17520\
    home diastolic blood pressure frequently over 90 mm Hg | -17520\
    hypertension diagnosis missed | -8760\
    anti-neutrophil cytoplasmic antibody not detected | -8760\
    drugs inducing renal injury not detected | -8760\
    hypertensive nephrosclerosis | -8760\
    telmisartan started | -8760\
    telmisartan 20 mg | -8760\
    empagliflozin started | -8760\
    empagliflozin 10 mg/day | -8760\
    eGFR decreased to 30.1 mL/min/1.73 m2 | -1440\
    eGFR 32.2 mL/min/1.73 m2 | -2160\
    eGFR 31.7 mL/min/1.73 m2 | -3600\
    empagliflozin increased to 25 mg/day | -3600\
    eGFR decreased to 29.6 mL/min/1.73 m2 | -720\
    eGFR 31.7 mL/min/1.73 m2 | -2160\
    empagliflozin stopped | 0\
    switched to teneligliptin | 0\
    eGFR increased to 38.3 mL/min/1.73 m2 | 0\
    HbA1c decreased | -3600\
    body weight decreased | -3600\
    eGFR decreased to 27.7 mL/min/1.73 m2 | 0\
    oral semaglutide started | 0\
    oral semaglutide 3 mg | 0\
    HbA1c decreased to 7.7% | 720\
    eGFR increased to 33.6 mL/min/1.73 m2 | 720\
    oral semaglutide increased to 14 mg/day | 720\
    HbA1c decreased to 6.8% | 1440\
    eGFR increased to 37 mL/min/1.73 m2 | 1440\
    albuminuria not detected | 0\
    body weight decreased | 1440\
    systolic blood pressure decreased | 1440\
    diastolic blood pressure decreased | 1440\
    postprandial glucose decreased | 1440\
    peak of daily glucose decreased | 1440\
    average value of daily glucose decreased | 1440\
    body weight stable | 7200\
    glucose control stable | 7200\
    eGFR stable around 35 mL/min/1.73 m2 | 7200

    