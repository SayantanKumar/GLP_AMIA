


## Summary of the Case Report

The case report describes a 35-year-old Japanese man with ulcerative colitis (UC) who underwent total colectomy due to severe disease. Following the surgery, he developed new-onset diabetes mellitus. The key findings and clinical course are summarized below:

1. **Clinical Presentation**: 
   - The patient had a history of UC diagnosed at age 25, managed with mesalamine and prednisolone.
   - Due to severe UC exacerbation, he underwent total colectomy with ileostomy at age 31.
   - Four years post-colectomy (age 35), he presented with hyperglycemia (HbA1c 8.4%) without classic diabetes symptoms. His BMI was 20.0 kg/m².
   - Autoantibodies (GAD, IA-2) were negative, and C-peptide levels suggested residual insulin secretion (CPI: 0.7, ΔCPR glucagon test: 0.4 ng/mL).

2. **Incretin Analysis**:
   - Serum active GLP-1 and GIP levels were significantly lower than in non-diabetic controls.
   - Immunohistochemistry of duodenal biopsies showed markedly reduced GLP-1-positive cells (0.2 cells/mm² vs. 8.0 in controls) and GIP-positive cells (0.8 cells/mm² vs. 9.3 in controls).

3. **Treatment and Outcomes**:
   - Initial therapy with DPP-4 inhibitor (sitagliptin) and metformin was ineffective.
   - Switching to GLP-1 receptor agonist (liraglutide) rapidly normalized glucose levels (HbA1c 5.6%).
   - After 3 months, glucose control deteriorated despite liraglutide. Insulin secretion capacity further declined (CPI: 0.4, ΔCPR: 0.3 ng/mL).
   - Intensive insulin therapy was initiated, achieving HbA1c 6.5%.

4. **Gut Microbiota Analysis**:
   - Post-colectomy microbiota showed higher *Bifidobacterium* (25.8% vs. ≤3.7% in controls) but no clear dysbiosis pattern linked to diabetes pathogenesis.
   - No significant differences in Firmicutes/Bacteroidetes ratios compared to controls.

## Key Discussion Points

- **Incretin Deficiency**: Total colectomy likely eliminated colonic L-cells, the primary source of GLP-1. The duodenal biopsy confirmed near-absence of GLP-1 and reduced GIP-producing cells, explaining the profound incretin deficiency.
- **Treatment Implications**: 
  - GLP-1 RA effectively compensated for endogenous GLP-1 loss initially but failed long-term due to progressive β-cell dysfunction.
  - Combined GIP/GLP-1 loss may accelerate β-cell decline, as GIP is crucial for β-cell maintenance.
- **Gut Microbiota**: While altered post-colectomy, microbiota changes did not appear central to diabetes development in this case.
- **Broader Significance**: 
  - Highlights colectomy as a risk factor for diabetes via incretin depletion.
  - Suggests that dual GLP-1/GIP deficiency may warrant earlier insulin therapy in similar cases.
  - Supports exploring GLP-1 RA as initial therapy in post-colectomy diabetes, though long-term β-cell preservation remains challenging.

## Conclusion
This case illustrates that colectomy-induced incretin deficiency can precipitate diabetes. While GLP-1 RA offers short-term glycemic control, concomitant GIP deficiency may contribute to β-cell failure, necessitating insulin. Monitoring incretin axes and β-cell function is critical in post-colectomy diabetes management.
<|eot_id|>
```