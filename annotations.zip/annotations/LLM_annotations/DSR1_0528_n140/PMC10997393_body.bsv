21 years old | 0
    woman | 0
    not known to have diabetes mellitus | 0
    not known to have hypertension | 0
    no significant past medical history | 0
    admitted to the ICU | 0
    admitted to the ER | 0
    abdominal pain | -48
    vomiting | -48
    diarrhoea | -48
    no history of fever | -48
    no history of cough | -48
    no history of dysuria | -48
    no history of headache | -48
    no history of chest pain | -48
    tirzepatide 5 mg | -504
    subcutaneous | -504
    once a week | -504
    weight reduction | -504
    previous three weeks | -504
    taken three times | -504
    over the counter | -504
    diarrhoea | -504
    3–4 times/day | -504
    loss of 5 kg | -504
    3 weeks | -504
    denied ketogenic diet | -504
    took pantoprazole | -504
    epigastric discomfort | -504
    dehydrated | 0
    tachypnea | 0
    air hunger | 0
    heart rate 110 beats per minute | 0
    blood pressure 130/80 mmHg | 0
    oxygen saturation 99% | 0
    room air | 0
    BMI 28.2 kg/m2 | 0
    pH 7.22 | 0
    partial pressure of carbon dioxide 33 mmHg | 0
    partial pressure of oxygen 70 mmHg | 0
    bicarbonate concentration 13.8 mmHg | 0
    anion gap 25 | 0
    blood ketone concentration 5.2 mmol/l | 0
    blood glucose levels 4.9 mmol | 0
    no osmolar difference | 0
    paracetamol undetectable | 0
    salicylate undetectable | 0
    admitted to the hospital | 0
    high anion gap metabolic ketoacidosis | 0
    normal lactate | 0
    blood glucose level not elevated | 0
    ketosis | 0
    vomiting | 0
    starvation | 0
    treated with 0.9 saline | 0
    dextrose 10% | 0
    ondansetron | 0
    pantoprazole IV | 0
    blood glucose levels 7-8 mmol/l | 0
    dextrose infusion | 0
    no insulin required | 0
    anion gap closed | 0
    acidosis corrected | 0
    advised against taking tirzepatide | 0
    Naranjo adverse drug reaction probability scale 6 | 0
    probable adverse events | 0
    follow-up after four weeks | 672
    resolution of all symptoms | 672
    gained one kg | 672
    white blood count 8.5 | 0
    haemoglobin 13.7 | 0
    platelet count 351 | 0
    sodium 137 | 0
    serum potassium 4.0 | 0
    blood urea nitrogen 1.6 | 0
    corrected calcium 2.28 | 0
    phosphorus 1.1 | 0
    magnesium 0.75 | 0
    total bilirubin 8 | 0
    gamma glutamyl transpeptidase 13 | 0
    aspartate amino transferase 18 | 0
    creatinine 54 | 0
    glucose 4.9 | 0
    HbA1c 5.1 | 0
    amylase 44 | 0
    lipase 35 | 0
    C-reactive protein 14 | 0
    lactate 0.9 | 0
    salicylates 3 | 0
    ketoacidosis induced by tirzepatide | 0
    starvation ketoacidosis | 0
    nausea | -504
    diarrhoea | -504
    poor caloric intake | -504
    suppressed appetite | -504
    prolonged gastric emptying | -504
    decreased calorie intake | -504
    insulin resistance | 0
    metabolic unhealthy obesity | 0