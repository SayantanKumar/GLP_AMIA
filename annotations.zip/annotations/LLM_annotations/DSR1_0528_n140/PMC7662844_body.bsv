73 years old | 0
    man | 0
    admitted to the hospital | 0
    type 2 diabetes | -1440
    anorexia | -1440
    weight loss | -1440
    diarrhea | -1440
    attacks of tetany | -1440
    inhibitor of DPP4 | -2160
    metformin | -2160
    glimipiride | -2160
    abasaglar | -2160
    liraglutide | -2160
    abdominal pain | -1440
    diarrhea | -1440
    episodes of tetany attacks | -1440
    conscious | 0
    normocardial | 0
    normotensive | 0
    eupnetic | 0
    apyretic | 0
    weight 84 kg | 0
    height 1.69 m | 0
    BMI 29.13 | 0
    Chvostek sign negative | 0
    Trousseau sign negative | 0
    physical examination without distinction | 0
    initial ECG no signs of hypocalcemia | 0
    parathyroid hormone normal | 0
    vitamin D low | 0
    urinary excretion of magnesium elevated | 0
    sodium 139 mmol/l | 0
    potassium 3.2 mmol/l | 0
    chloride 98 mmol/l | 0
    CO2 24 mmol/l | 0
    glycemia 6.80 mmol/l | 0
    urea 5.20 mmol/l | 0
    creatinine 73 μmol/l | 0
    creatinine clearance 88 ml/min/1.73 m2 | 0
    calcium 1.52 mmol/l | 0
    albumin 37 g/l | 0
    prealbumin 0.17 g/l | 0
    corrected calcium 1.60 mmol/l | 0
    phosphorus 1.22 mmol/l | 0
    magnesium <0.1 mmol/l | 0
    intravenous electrolyte supplementation | 0
    ECG monitoring | 0
    calcium gluconate 8 g | 0
    magnesium sulfate 4 g | 0
    potassium chloride 2 g | 0
    normalization of serum calcium | 48
    normalization of serum magnesium | 48
    normalization of serum potassium | 48
    elevation of PTH | 48
    improvement of glycemic cycle | 48
    oral magnesium intake | 48
    liraglutide therapy discontinued | 48
    improvement in digestive disorders | 48
    stable balance sheet | 48
    absence of hypoparathyroidism | 48
    causal link incriminating liraglutide suspected | 48
    hypomagnesemia | 0
    hypocalcemia | 0
    hypokalemia | 0
    malabsorption syndrome | 0
    chronic diarrhea | 0
    <|eot_id|>
    