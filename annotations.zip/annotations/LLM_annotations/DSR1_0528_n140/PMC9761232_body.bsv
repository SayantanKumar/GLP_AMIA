59 years old | 0
    male | 0
    referred to emergency department | 0
    pain in lower limbs | 0
    tingling | 0
    weakness | 0
    impaired bilateral lower limb movement | 0
    foot drop | 0
    frequent urination | 0
    type 2 DM | -157680
    polydipsia | -157680
    polyuria | -157680
    glibenclamide | -157680
    metformin | -157680
    dietary changes | -157680
    unsuccessful treatment | -157680
    fasting blood glucose 8.5-11 mmol/L | -157680
    oral antidiabetic medication suspended | -17520
    NPH insulin initiated | -17520
    regular insulin | -17520
    poor treatment compliance | -17520
    insulin doses increased to 240 IU | -17520
    metformin resumed | -17520
    liraglutide 2.4 mg/day | -17520
    self-monitoring blood glucose 300-450 mg/dL | -17520
    random glucose 300 mg/dL | 0
    diabetic polyneuropathy | 0
    ischemic heart disease | 0
    human insulin 240 IU/day | 0
    liraglutide 2.4 mg/day | 0
    metformin 2000 mg/day | 0
    aspirin 80 mg/day | 0
    valsartan 80 mg/day | 0
    bisoprolol 2.5 mg/day | 0
    hydrochlorothiazide 25 mg/day | 0
    alert | 0
    vital signs stable | 0
    cardiopulmonary examination unremarkable | 0
    acanthosis nigricans | 0
    skin tags | 0
    body mass index 30 kg/m2 | 0
    no deep tendon reflex in lower limbs | 0
    disturbed sense of position | 0
    paresthesia in socks and gloves distribution | 0
    reduced force in lower limbs 4/5 | 0
    reduced force in upper limbs 5/5 | 0
    Gowers sign positive | 0
    insulin dose increased to 530 IU | 24
    uncontrolled blood glucose | 24
    HbA1c 16.1% | 24
    FBS 400-500 mg/dL | 24
    severe insulin resistance | 24
    potential causes of high blood sugar ruled out | 24
    blood biochemistry profile normal | 24
    autoantibodies against insulin receptor 5.23 U/mL | 48
    TBIRS | 48
    EMG | 48
    NCV test | 48
    chronic axonal sensory-motor polyneuropathy | 48
    CIDP | 48
    neurology consultation | 48
    12 sessions plasmapheresis initiated | 48
    plasmapheresis 1500 L per session | 48
    pain improved | 72
    weakness improved | 72
    movement disorders improved | 72
    blood glucose levels improved | 72
    patient refused plasmapheresis | 168
    oral prednisolone 60 mg/day | 168
    neurological manifestations ameliorated | 192
    significant blood glucose control | 192
    human insulin discontinued | 192
    controlled blood glucose | 192
    discharged | 240
    prednisolone 30 mg/day | 240
    homologous insulin lispro 100 IU/day | 240
    liraglutide 1.8 mg/day | 240
    acarbose 150 mg/day | 240
    metformin 1500 mg/day | 240
    glibenclamide 20 mg/day | 240
    pioglitazone 30 mg/day | 240
    significant improvements in lower limb symptoms | 2160
    mild pain in proximal parts of lower limbs | 2160
    prednisolone decreased to 15 mg/day | 2160
    FBS 120-150 mg/dL | 2160
    HbA1c 7.8% | 2160