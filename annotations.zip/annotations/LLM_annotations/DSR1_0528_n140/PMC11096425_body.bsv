50 years old| 0
    woman| 0
    AF| 0
    AFL| 0
    randomized 7 months prior| -5040
    HFpEF| -5040
    Corvia atrial shunt| -5040
    weekly palpitations| -168
    electrocardiograms documenting AF| -168
    electrocardiograms documenting AFL| -168
    symptoms persisted| 0
    drinks 2 standard drinks once per week| -168
    nonsmoker| 0
    does not exercise| 0
    mother has AF| 0
    father has AF| 0
    reduced weight from 108 kg to 96 kg| -168
    Ozempic| -168
    severe asthma| 0
    sotalol relatively contraindicated| 0
    flecainide not preferred| 0
    sinus rhythm| 0
    general anesthesia| 0
    venous accesses| 0
    decapolar catheter in coronary sinus| 0
    Boston Scientific Farawave sheath for ablation| 0
    no intracardiac echocardiography| 0
    atrial burst pacing| 0
    isoproterenol 4 mcg/min| 0
    induced left-sided atrial ectopy| 0
    short self-terminating AF| 0
    pulmonary vein isolation| 0
    CTI line ablation| 0
    Farapulse ablation catheter| 0
    16F Farawave sheath introduced into right atrium| 0
    Farapulse catheter introduced into right atrium| 0
    CTI line ablation performed| 0
    flower configuration of Farapulse catheter| 0
    intravenous glyceryl trinitrate 200 mcg| 0
    2 pulses at 4 locations| 0
    CTI block confirmed| 0
    pacing across CTI| 0
    Rosen wire placed through Corvia shunt into left atrium| 0
    Farawave sheath guided over wire through Corvia shunt into left atrium| 0
    no resistance| 0
    wire and sheath went easily| 0
    wire and sheath passed within 60 seconds| 0
    heparin given| 0
    target activated clotting time 350-400 seconds| 0
    Farapulse ablation advanced to veins| 0
    catheter and sheath moved easily| 0
    catheter and sheath moved freely| 0
    catheter and sheath through fixed Corvia device to pulmonary veins| 0
    no resistance| 0
    eight pulses per vein applied| 0
    2 × 2 flower| 0
    2 × 2 basket| 0
    catheter retracted into sheath| 0
    sheath pulled back through fixed Corvia device into right atrium| 0
    no resistance| 0
    no complications| 0
    atypical AFL using Corvia could not be ruled out| 0
    ablation would involve left atrium| 0
    concern about Corvia interaction with electrophysiology wires| 0
    concern about Corvia interaction with catheters| 0
    concern about Corvia interaction with sheaths| 0
    concern about Corvia interaction with ablation| 0
    electrophysiology catheters getting caught on exposed part of Corvia| 0
    shunt diameter too narrow to cross with sheath| 0
    Corvia endothelialization| 0
    Corvia 8 mm shunt diameter| 0
    Farawave sheath outer diameter 16.8F (5.6 mm)| 0
    safety of ablating tissue close to Corvia| 0
    safety of ablating tissue on Corvia nitinol material| 0
    transseptal puncture in septum with Corvia in situ| 0
    discussion between electrophysiologist and interventional cardiologists| 0
    transseptal access via Corvia| 0
    no changes made| 0
    not using transseptal needle| 0
    dual antiplatelet therapy for 6 months| 0
    device endothelialization| 0
    left atrial pressure measurement immediately after Corvia implant| 0
    early access to left atrium using low-caliber catheters safe and feasible| 0
    RESPONDER-HF trial| 0
    consultancy fees for Farapulse from Boston Scientific| 0
    <|eot_id|>
    