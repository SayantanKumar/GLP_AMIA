67 years old | 0
    woman | 0
    Chinese origin | 0
    referred to neuro-ophthalmology | 0
    third nerve palsy | 0
    type 2 diabetes | 0
    hypertension | 0
    dyslipidemia | 0
    liver fibrosis | 0
    hemorrhoids | 0
    irbesartan | 0
    simvastatin | 0
    empagliflozin | 0
    semaglutide | 0
    new-onset left-eye ptosis | -168
    double vision | -168
    mild pain around her left eye | -168
    presented to the emergency room | -168
    CTA of the head | -168
    CTA normal | -168
    referred to neurology | -168
    MRI of the brain and orbits with contrast | -168
    abnormal enhancement | -168
    slight thickening | -168
    cisternal segment of the left third cranial nerve | -168
    increased T2 signal | -168
    cisternal portion | -168
    cavernous portion | -168
    referred to neuro-ophthalmology | -168
    visual acuity 20/25 OD | 0
    visual acuity 20/50 OS | 0
    cataract | 0
    left complete ptosis | 0
    complete limitation of elevation | 0
    complete limitation of depression | 0
    complete limitation of adduction | 0
    right ocular ductions full | 0
    cranial nerve function otherwise normal | 0
    pupils equal sizes | 0
    pupils reactive to light | 0
    diagnosed with complete pupil-sparing third nerve palsy | 0
    abnormal enhancement of the optic nerve | 0
    underwent extensive workup | 0
    inflammatory bloodwork | 0
    inflammatory bloodwork normal | 0
    ANA | 0
    ANCA | 0
    ACE | 0
    IgG4 serum levels | 0
    NMO-IgG | 0
    MOG-IgG | 0
    ESR | 0
    CRP | 0
    VDRL | 0
    HIV | 0
    lumbar puncture | 0
    normal cell count | 0
    normal glucose | 0
    normal protein levels | 0
    clinical course monitored | 0
    repeat MRI | 720
    persistent thickening | 720
    persistent enhancement | 720
    third nerve palsy spontaneously resolved | 1440
    no new diabetes medications started | 1440
    no new hypertension medications started | 1440
    repeat MRI | 7200
    significant improvement | 7200
    faint minimal enhancement | 7200
    increased T2 signal persisted | 7200
    cisternal portion | 7200
    cavernous portion | 7200
    superior portion | 7200
    inferior portion | 7200
    no recurrence | 8760
    clinically well | 8760
    started on insulin | 4320
