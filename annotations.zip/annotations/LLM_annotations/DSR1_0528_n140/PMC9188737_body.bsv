26 years old | 0
    male | 0
    presented to emergency department | 0
    agitation | -4
    shortness of breath | -4
    abdominal pain | -4
    fatigue | -100
    malaise | -100
    fever | -100
    sore throat | -100
    diagnosed with T2DM | -61320
    metformin | 0
    no recent travel | 0
    dry oral mucosa | 0
    distress | 0
    febrile | 0
    tachycardia | 0
    tachypnea | 0
    hypotension | 0
    received 2 L normal saline | -4
    morbidly obese | 0
    BMI 41.52 kg/m2 | 0
    non-exudative pharyngitis | 0
    shallow deep breathing | 0
    bilateral vesicular breathing without added sounds | 0
    sinus tachycardia | 0
    mild epigastric tenderness | 0
    hyperglycemia | 0
    metabolic acidosis | 0
    bicarbonate 4 mmol/L | 0
    venous pH 6.84 | 0
    anion gap 34 | 0
    urine ketone high | 0
    lactic acid normal | 0
    leukocytosis | 0
    hemoglobin 16.4 g/L | 0
    platelet count 350 × 109/L | 0
    C-reactive protein elevated | 0
    procalcitonin elevated | 0
    toxicology screen negative | 0
    sodium normal | 0
    potassium normal | 0
    creatinine normal | 0
    urea normal | 0
    no rhabdomyolysis | 0
    serum osmolality elevated | 0
    liver function normal | 0
    thyroid tests normal | 0
    broad-spectrum antibiotic therapy | 0
    diabetic ketoacidosis protocol | 0
    insulin bolus | 0
    insulin infusion | 0
    five liters crystalloid fluid | 0
    sodium bicarbonate infusion | 0
    pH static | 0
    respiratory distress | 0
    assisted ventilation | 0
    renal replacement therapy | 0
    family brought home medications | 18
    gliclazide | 18
    canagliflozin | 18
    pioglitazone | 18
    liraglutide | 18
    metformin/sitagliptin | 18
    uncontrolled diabetes | 0
    refused insulin | 0
    on canagliflozin for three years | 0
    capillary blood ketone measurements | 38
    dextrose | 38
    intravenous potassium | 38
    intermittent hemodialysis | 38
    continuous veno-venous hemodiafiltration | 38
    metabolic acidosis corrected | 62
    anion gap closed | 62
    extubated | 96
    shifted to basal bolus regimen | 120
    eDKA resolved | 120
    ketonemia persistent | 120
    urine organic acid profile | 120
    significant diuresis | 0
    cultures negative | 120
    influenza screen negative | 120
    Strep A negative | 120
    HIV negative | 120
    hepatitis B negative | 120
    hepatitis C negative | 120
    adenovirus positive | 120
    chest x-ray normal | 0
    HbA1C 13.3% | 0
    C-peptide 0.11 nmol/L | 0
    Anti IA2 negative | 0
    GAD antibodies negative | 0
    insulin antibodies negative | 0
    femoral line site deep venous thrombosis | 288
    pulmonary embolism | 288
    anticoagulants | 288
    discharged | 384
    