52 years old | 0
    female | 0
    moderately overweight | 0
    BMI 29 kg/m2 | 0
    severe reflux disease | 0
    laparoscopic Toupet fundoplication | 0
    severe symptomatic late dumping syndrome | 8760
    hypoglycemic symptoms | 8760
    palpitations | 8760
    nausea | 8760
    sweating | 8760
    weakness | 8760
    collapse | 8760
    no history of diabetes | 0
    no hypoglycemic symptoms before operation | 0
    blood tests | 8760
    functional X-ray examination | 8760
    upper endoscopy | 8760
    magnetic resonance imaging of the upper abdomen | 8760
    symptomatic hyperinsulinemic hypoglycemia | 8760
    Sigstad score questionnaire | 8760
    oral glucose tolerance test | 8760
    continuous glucose measurement | 8760
    dietary changes | 8760
    meal frequency 5 to 6 per day | 8760
    meal composition more protein and fiber | 8760
    meal composition less carbohydrates | 8760
    acarbose | 8760
    acarbose 50 mg before each meal | 8760
    acarbose 3 times a day | 8760
    treatment failure | 8760
    liraglutide | 8760
    liraglutide off-label | 8760
    informed consent | 8760
    liraglutide daily subcutaneous injection | 8760
    liraglutide 0.6 mg per day | 8760
    liraglutide increased to 1.2 mg per day | 9120
    OGTT without treatment | 8760
    OGTT with 0.6 mg liraglutide | 9120
    OGTT with 1.2 mg liraglutide | 9360
    CGM without treatment | 8760
    CGM with 0.6 mg liraglutide | 9120
    CGM with 1.2 mg liraglutide | 9360
    clinical examinations normal postoperative findings | 8760
    no evidence of neuroendocrine tumor | 8760
    Sigstad score 15 | 8760
    dietary changes no improvement | 8760
    acarbose insufficient therapeutic effect | 8760
    CGM 59% glucose values hypoglycemic range | 8760
    HOMA-Index 6.6 | 8760
    HbA1c 4.5% | 8760
    OGTT fasting glucose 93 mg/dL | 8760
    fasting insulin 29 μU/mL | 8760
    glucose increased to 206 mg/dL at 30 minutes | 8760
    glucose 180 mg/dL at 60 minutes | 8760
    glucose 146 mg/dL at 90 minutes | 8760
    insulin peak 717 μU/mL at 90 minutes | 8760
    glucose 35 mg/dL at 150 minutes | 8760
    hypoglycemia | 8760
    OGTT with 0.6 mg liraglutide | 9120
    marginal improvement in subjective hypoglycemic symptoms | 9120
    fasting glucose 88 mg/dL | 9120
    fasting insulin 19.3 μU/mL | 9120
    peak insulin 311 μU/mL at 60 minutes | 9120
    peak glucose 155 mg/dL at 30 minutes | 9120
    hypoglycemic glucose level | 9120
    glucose 76 mg/dL at 120 minutes | 9120
    insulin 109 μU/mL at 120 minutes | 9120
    glucose 48 mg/dL at 180 minutes | 9120
    symptoms milder | 9120
    insufficient treatment response | 9120
    liraglutide 1.2 mg/day | 9120
    OGTT with 1.2 mg liraglutide | 9360
    fasting insulin 10.7 μU/mL | 9360
    fasting glucose 83 mg/dL | 9360
    peak insulin 413 μU/mL at 60 minutes | 9360
    glucose level above 66 mg/dL | 9360
    84% glucose values normoglycemia | 9360
    free of symptoms | 9360
    resolution of late dumping symptoms | 9360
    treatment successful | 9360
    discharge | 9360