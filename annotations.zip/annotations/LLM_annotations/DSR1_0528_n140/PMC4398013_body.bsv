14 years old | 0
    boy | 0
    poor socioeconomic background | 0
    disoriented | 0
    confused | 0
    emesis | -48
    no diarrhea | 0
    no abdominal pain | 0
    no convulsions | 0
    no loss of consciousness | 0
    no relevant drug/substance abuse | 0
    osmotic symptoms | -720
    no family history of diabetes | 0
    respiratory frequency 30 breaths/min | 0
    heart rate 120 bpm | 0
    blood pressure 110/60 mmHg | 0
    temperature 101°F | 0
    blood glucose 609 mg/dL | 0
    arterial blood gas pH 7.1 | 0
    serum bicarbonate 9.5 mEq/L | 0
    serum ketones 6 mmol/L | 0
    urinary ketones strongly positive | 0
    electrocardiogram Q waves infero-lateral leads | 0
    DKA | 0
    intravenous fluids | 0
    insulin | 0
    potassium | 0
    antibiotics | 0
    A1C 10.5% | 0
    anti-GAD65 negative | 0
    anti-IA2 negative | 0
    difficulties walking | 0
    difficulties standing | 0
    slurring of speech | 0
    ataxic gait | 0
    hypoactive knee jerks | 0
    hypoactive ankle jerks | 0
    bilateral extensor plantar responses | 0
    impairment position sense | 0
    impairment vibratory sense | 0
    dysmetria | 0
    intentional tremors | 0
    progressive ataxia | -8760
    MRI brain normal | -8760
    nerve conduction velocity axonal sensorimotor neuropathy | 0
    hereditary sensory neuropathy considered | 0
    echocardiogram | 0
    concentric symmetric hypertrophy left ventricle | 0
    asymmetric septal hypertrophy | 0
    genetic analysis | 0
    expanded allele | 0
    homozygous alleles FRDA gene | 0
    FA | 0
    FA-associated insulin-dependent diabetes | 0
    cardiomyopathy | 0
    discharged | 0
    split-mixed insulin regimen | 0
    NPH insulin | 0
    rapid-acting insulin | 0
    satisfactory glycemic control | 1440
    postmeal serum C-peptide 2.1 ng/mL | 1440
    Friedreich’s ataxia | 0
    increased risk developing diabetes | 0
    diabetes | 0
    insulin deficiency | 0
    insulin resistance | 0
    diabetic ketoacidosis | 0
    strictly insulin-dependent | 0
    ketosis-prone | 0
    immune markers absent | 0
    β-cell dysfunction | 0
    peripheral insulin resistance | 0
    GAA trinucleotide repeat expansion | 0
    mitochondrial dysfunction | 0
    metabolic stress | 0
    ER stress-induced apoptosis | 0
    insulin requirement 1 unit/kg | 0
    metformin or thiazolidinedione may improve insulin sensitivity | 0
    exogenous insulin | 0
    GLP-1 analogs | 0
    rapid progression to clinical diabetes | 0
    loss of islet cells | 0
    no autoimmunity | 0
    