57 years old|0
    male|0
    HIV infection|0
    visited the outpatient clinic since 2003|0
    diagnosed in 1995|0
    initial treatment|0
    zidovudine|0
    dual therapy|0
    zidovudine|0
    zalcitabine|0
    zidovudine and lamivudine|0
    zidovudine|0
    lamivudine|0
    triple therapy|0
    efavirenz|0
    didanosine|0
    lamivudine|0
    discontinued because of dizziness|0
    rash|0
    depression|0
    atazanavir|0
    tenofovir|0
    lamivudine|0
    progressive abdominal distention|0
    protease inhibitor atazanavir replaced by raltegravir|0
    integrase inhibitor with a better metabolic profile|0
    weight of 105 kg|0
    15 kg weight gain in 2 years|0
    type 2 diabetes diagnosed|0
    lifestyle consultation|0
    metformin initiated|0
    1000 mg b.i.d.|0
    A1C rose to 8.8%|0
    NPH insulin started|0
    November 2007|0
    body weight increased by 5 kg in 6 months|0
    little glycemic improvement|0
    insulin treatment replaced by glimepiride|0
    up to 6 mg q.i.d.|0
    A1C remained 8.3%|0
    start insulin glargine|0
    September 2010|0
    titrated to 60 U/day|0
    glimepiride discontinued|0
    weight increased by 7 kg in 6 months|0
    without glycemic improvement|0
    weight of 116 kg|0
    BMI 35.1 kg/m2|0
    A1C 8.1%|0
    off-label liraglutide initiated|0
    May 2011|0
    0.6 mg/day|0
    uptitrated to 1.8 mg/day|0
    consulted a dietitian|0
    diabetes educator|0
    advised to lower daily insulin dose by 10 U when self-monitored blood glucose was <5 mmol/L|0
    after 3 weeks of liraglutide therapy|0
    body weight dropped to 110 kg|0
    insulin dose reduced to 30 U/day|0
    discontinued altogether after 6 weeks|0
    fasting glucose decreased from 12.3 to 7.0 mmol/L|0
    no side-effects|0
    no hypoglycemia|0
    less fatigue|0
    overall improved quality of life|0
    self-monitored blood glucose varied between 5.6–8.3 mmol/L|0
    HIV-RNA remained undetectable|0
    four months after liraglutide initiation|0
    A1C decreased to 6.8%|0
    body weight to 102 kg|0
    body weight rose slightly to 108 kg at 7 months|0
    A1C remained 6.8%|0
    previously elevated liver enzymes normalized|0
    lipid profile improved significantly|0
    total cholesterol from 5.6 to 4.9 mmol/L|0
    HDL cholesterol from 0.79 to 1.0 mmol/L|0
    triglycerides from 6.6 to 3.1 mmol/L|0
    <|eot_id|>
    