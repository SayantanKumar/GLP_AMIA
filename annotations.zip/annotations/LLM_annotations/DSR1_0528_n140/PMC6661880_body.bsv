52 years old | 0
    female | 0
    BMI 29 | 0
    admitted to regional hospital | 0
    mushroom poisoning | -175200
    alcoholic liver cirrhosis | -157680
    portal hypertension | -157680
    ascites | -157680
    diabetes mellitus | -175200
    30 years alcohol dependence | -262800
    10 years smoking addiction | -87600
    decompensated stage of liver cirrhosis | -157680
    chronic pancreatitis | -210240
    mushroom intoxication | -210240
    alcoholism | -210240
    external secretory insufficiency of pancreas | -210240
    pancreatogenic diabetes | -210240
    axial hiatal hernia | -210240
    polyarthritis | -210240
    cyclical upper abdominal pain | -4380
    pain radiating to back | -4380
    nausea | -4380
    excessive thirst | -4380
    fatigue | -4380
    weight loss | -4380
    diarrhea | -4380
    clay-colored stools | -4380
    chronic pancreatitis | -4380
    endoscopic retrograde cholangiopancreatography | -4380
    computed tomography scan of abdomen | -4380
    fecal fat test | -4380
    increased serum amylase level | -4380
    increased serum lipase level | -4380
    increased serum trypsinogen | -4380
    treatment: withdraw smoking | -4380
    withdraw alcohol | -4380
    dietary changes | -4380
    pancreatic enzyme supplements | -4380
    insulin therapy | -4380
    glucagon-like peptide 1 | -4380
    nonsteroidal anti-inflammatory drug | -4380
    proton pump inhibitor | -4380
    corticosteroids | -4380
    IV fluid | -4380
    cavernous transformation of portal vein | -4380
    hepatosplenomegaly | -4380
    chronic toxic hepatitis | -4380
    chronic calculous cholecystitis | -4380
    adhesive disease | -4380
    intestinal obstruction | -4380
    resection of segment of colon | -4380
    duodenal ulcer | -4380
    erosive gastritis | -4380
    duodeno-gastric reflux | -4380
    cyst on right kidney | -4380
    right-sided nephrectomy | -4380
    diarrhea | -720
    ascites | 0
    tenderness of liver | 0
    chronic fatigue | 0
    general moodiness | 0
    feelings of despair | 0
    loss of appetite | 0
    nausea | 0
    bloating | 0
    liquid stools | 0
    tarry stools | 0
    vomiting | 0
    fever | 0
    abdominal pain | 0
    stomach upset | 0
    jaundice | 0
    altered personality | 0
    hyperreflexia | 0
    insomnia | 0
    drowsiness | 0
    bruises | 0
    pedal edema | 0
    shortness of breath | 0
    breathlessness | 0
    caput medusa | 0
    blotchy palms | 0
    nosebleeds | 0
    muscle cramps | 0
    abnormal CBC | 0
    abnormal blood chemistry | 0
    abnormal liver enzymes | 0
    fasting HDL level low | 0
    fasting triglyceride level high | 0
    waist circumference large | 0
    fasting plasma glucose high | 0
    hypertension | 0
    viral hepatitis negative | 0
    esophageal varices | 0
    hepatosplenomegaly | 0
    spleen size increased | 0
    vena porta dilated | 0
    splenic vein dilated | 0
    recanalization umbilical vein | 0
    treatment: regimen palatine | 0
    diet N5 and N9 | 0
    insulin short acting | 0
    insulin long acting | 0
    aetropidi | 0
    protafan | 0
    berlitioni | 0
    solution natrium 0.9% | 0
    enterogel | 0
    creonu | 0
    enterogermina | 0
    lacium | 0
    calcemin | 0
    thiotriazolini | 0
    reosirbilact | 0
    calcii | 0
    vitruni | 0
    lactovit | 0
    aevit | 0
    pimafucini | 0
    furamag | 0
    thiogamma | 0
    rheosorbilact | 0
    furosemide 1% | 0
    dibazol 1% | 0
    papaverine | 0
    