56 years old|0
    Caucasian|0
    male|0
    presented to outpatient dermatology clinic|0
    new-onset diffuse intense pruritic symptoms|0
    symptoms gradually progressed over seven weeks|0
    symptoms began at lower extremities| -1176
    symptoms advanced to upper extremities| -1176
    decreased quality of life|0
    inability to work|0
    inability to sleep|0
    itching|0
    condition exacerbated by stress|0
    history and physical exam|0
    excoriations on lower extremities|0
    excoriations on upper extremities|0
    localized to flexor surfaces|0
    physical exam no specific nodules|0
    physical exam positive post-inflammatory hyperpigmentation|0
    physical exam positive pruritic nodules|0
    biopsy not prompted|0
    patient attempted to relieve itch with over-the-counter anti-itch creams| -168
    patient attempted to relieve itch with low-dose steroids| -168
    no improvement| -168
    past medical history positive for possible prediabetes|0
    past medical history positive for joint pain|0
    currently takes Ozempic|0
    non-adherent to Ozempic|0
    review of systems|0
    history of allergic symptoms to environment|0
    symptoms exacerbated by sun exposure|0
    symptoms well-controlled with over-the-counter first-generation antihistamines|0
    bloodwork demonstrated slight elevations in AST/ALT|0
    abdominal ultrasound negative for biliary tree involvement|0
    CT abdomen and pelvis negative for biliary tree involvement|0
    P-ANCA normal|0
    differential diagnosis of unusual presentation of atopic dermatitis|0
    started on trial of topical steroids|0
    started on trial of oral steroids|0
    failed trial of steroids|0
    no relief of pruritic symptoms|0
    follow-up|168
    given trial of gabapentin 1,000 mg|168
    new differential chronic pain presenting as pruritus|168
    progression of disease|168
    titrated down to 500 mg steady state of gabapentin|336
    experienced complete resolution of symptomatology|336
    generalized chronic pruritus|0
    idiopathic generalized pruritus|0
    no noticeable skin lesion|0
    no obvious diagnosis|0
    no shortness of breath|0
    denies chest pain|0
    no specific lesion|0
    no improvement with antihistamines|0
    no improvement with steroids|0
    no relief with typical approaches|0
    no biliary tree involvement|0
    no dermatological diseases|0
    no systemic diseases|0
    no neurological diseases|0
    no psychosocial diseases|0
    no mixed diseases|0
    no other diseases|0
    no failure of gabapentin|336
    no side effects from gabapentin|336
    no recurrence of symptoms|336
    no impact on quality of life after treatment|336
    no need for further treatment|336
    no contraindications to gabapentin|0
    no renal impairment|0
    no abnormal findings on imaging|0
    no abnormal laboratory findings except AST/ALT|0
    no adherence issues with gabapentin|336
    no adverse events|336
    no complications|336
    no need for biopsy|0
    no evidence of atopic dermatitis|0
    no evidence of psoriasis|0
    no evidence of seborrheic dermatitis|0
    no evidence of systemic disease|0
    no evidence of neurological disease|0
    no evidence of psychogenic disease|0
    no evidence of environmental allergy exacerbation|0
    no evidence of solar radiation causing pruritus|0
    no evidence of BRP|0
    no evidence of neuropathic itch|0
    no evidence of pain conduction|0
    no evidence of multifactorial itch|0
    no evidence of unknown etiology after treatment|336
    no evidence of treatment failure|336
    no evidence of symptom recurrence|336
    no evidence of side effects|336
    no evidence of non-adherence|336
    no evidence of contraindications|0
    no evidence of renal impairment|0
    no evidence of abnormal imaging|0
    no evidence of abnormal labs except AST/ALT|0
    no evidence of alternative diagnoses|0
    no evidence of other treatments needed|336