23 years old|0
    male|0
    presented to a weight management program|0
    weight 643 pounds|0
    BMI 84.3 kg/m2|0
    obesity mixed central and peripheral|0
    genetic predisposition|0
    family history of obesity|0
    strong degrees of hunger|0
    food cravings|0
    binge-eating tendencies|0
    depression|0
    prediabetes|0
    hemoglobin A1c 6.4%|0
    concerns for obstructive sleep apnea|0
    previously followed in a pediatric weight management clinic|0
    originally presented at 17 years old| -52560
    weight 364 pounds| -52560
    BMI 48.5 kg/m2| -52560
    started on topiramate 75 mg daily| -52560
    phentermine 15 mg daily added| -52560
    continued on medications for around 6 months| -52560
    lost approximately 25 pounds| -52560
    lost to follow-up| -49680
    not consistently on AOMs| -49680
    briefly restarted on phentermine and topiramate| -49680
    on medications for only a few weeks at a time| -49680
    represented for care| -49680
    weight increased approximately 50 to 75 pounds| -49680
    re-establishing care in the adult weight management clinic|0
    started on phentermine 15 mg|0
    started on topiramate 75 mg|0
    started on metformin 500 mg daily|0
    COVID-19 pandemic|0
    seen virtually via telemedicine|0
    weight and BMI not obtained|0
    phentermine increased to 18.75 mg daily|720
    topiramate increased to 50 mg twice a day|720
    metformin increased to 500 mg twice a day|720
    started bupropion extended release 150 mg daily|720
    bupropion increased to 300 mg daily|720
    return to weight management clinic in person|720
    weight and BMI remained unchanged|720
    continued phentermine|720
    continued topiramate|720
    continued metformin|720
    continued bupropion|720
    started on semaglutide 0.25 mg weekly|720
    started on lower calorie diet|720
    started on regularly scheduled registered dietician visits|720
    significant reduction in hunger|720
    BMI began to decrease|720
    semaglutide increased to 0.5 mg weekly|1080
    lost 209 pounds|1080
    BMI decreased to 66.5 kg/m2|1080
    hemoglobin A1c normalized to 5.0%|1080
    snoring improved|1080
    plateau in weight loss|1080
    semaglutide increased to 1.0 mg weekly|1080
    lost an additional 6 pounds|1080
    gained an additional 11 pounds|1080
    stability on AOM regimen|1080
    