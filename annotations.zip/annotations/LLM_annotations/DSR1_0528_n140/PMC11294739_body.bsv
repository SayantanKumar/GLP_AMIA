40 years old | 0
    Caucasian | 0
    female | 0
    presented for care of T1DM | 0
    diagnosed with T1DM at age 37 | -26280
    presentation of diabetic ketoacidosis | -26280
    hemoglobin A1c 9.3% | -26280
    C-peptide 0.8 ng/mL | -26280
    Glutamic Acid Decarboxylase antibodies positive | -26280
    body mass index 28 kg/m2 | -26280
    treated with multiple daily injections of insulin glargine | -26280
    treated with multiple daily injections of insulin aspart | -26280
    switched to pod insulin pump therapy | -17520
    HbA1c range 5.7% to 7.4% | -17520
    experienced skin reactions at the pod insertion site | -8760
    pruritic and painful erythema | -8760
    wheals | -8760
    developed within 1 to 4 h of pod placement | -8760
    induration | -8760
    subcutaneous nodules | -8760
    surrounding lipodystrophy | -8760
    lasted several days | -8760
    spontaneous resolution in 1 to 2 weeks | -8760
    barrier adhesives ineffective | -8760
    topical antihistamines ineffective | -8760
    oral antihistamines ineffective | -8760
    topical glucocorticoids ineffective | -8760
    denied other past medical history | 0
    nonspecific rash to sulfonamide antibiotic | 0
    not on any medications besides insulin | 0
    maternal grandmother with T2DM | 0
    no known dermatologic conditions | 0
    no known rheumatologic conditions | 0
    treated with insulin aspart | -8760
    treated with insulin lispro | -8760
    treated with insulin regular | -8760
    treated with insulin glulisine | -8760
    similar skin reactions | -8760
    used syringe | -8760
    used pen injectors | -8760
    inhaled human insulin implemented | -8760
    inhaled human insulin discontinued due to cough | -8760
    HbA1c range 5.9% to 6.8% | -8760
    self-titrate insulin | -8760
    used Do-It-Yourself automated insulin delivery system | -8760
    used Pod pump | -8760
    used Continuous Glucose Monitoring | -8760
    referred to drug allergy clinic | -8760
    positive immediate intradermal insulin lispro test | -8760
    negative metacresol skin test | -8760
    serum human insulin-specific IgG antibody testing positive 156 mg/L | -8760
    IgE antibody testing negative <0.1 U/mL | -8760
    skin punch biopsy | -8760
    sublobular panniculitis | -8760
    empirically treated with metformin | -8760
    empirically treated with dapagliflozin | -8760
    empirically treated with liraglutide | -8760
    minimal improvement in skin reaction | -8760
    insulin requirement decreased from 60 units/d to 50 units/d | -8760
    lost 12 pounds in 4 months | -8760
    HbA1c range 5.8% to 6.8% | -8760
    considered investigational approach with rituximab | -8760
    treated with weekly intravenous rituximab infusion | 0
    rituximab dose 375 mg/m2 | 0
    premedicated with diphenhydramine | 0
    premedicated with acetaminophen | 0
    closely monitored | 0
    tolerated treatment well | 0
    skin reactions improved significantly | 0
    repeat serum human insulin-specific antibody testing | 336
    IgG 122 mg/L | 336
    IgE undetectable <0.1 U/mL | 336
    effect lasted 18 months | 0
    injection site reactions recurred | 13140
    deeper punch biopsy | 13140
    sublobular panniculitis | 13140
    treated with second round of rituximab infusion | 13140
    same protocol | 13140
    drastic improvement of skin reactions | 13140
    no recurrent skin reactions | 35040
    up to 4 years afterward | 35040
    