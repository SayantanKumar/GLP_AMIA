60 years old|0
    female|0
    Caucasian|0
    consulted our cardiology outpatient clinic|0
    dyspnea on moderate exertion|0
    New York Heart Association class II|0
    symptoms started a couple of weeks prior to presentation|-336
    increasing frequency in the last couple of days|-48
    denied chest pain|0
    denied palpitations|0
    denied orthopnea|0
    denied lower leg edema|0
    denied paroxysmal nocturnal dyspnea|0
    denied change in weight|0
    denied syncope|0
    nonsmoker|0
    10-year history of type 2 diabetes mellitus|0
    essential arterial hypertension|0
    dyslipidemia|0
    untreated asymptomatic stable pulmonary sarcoidosis|0
    pulmonary sarcoidosis diagnosed 5 years prior|-43800
    mediastinal lymph node biopsy|0
    resected epidermoid carcinoma of the tongue|0
    coronary angiography given 5 years prior|-43800
    40%-50% mid-left anterior descending artery stenosis|0
    bisoprolol|0
    acetylsalicylic acid|0
    atorvastatin|0
    metformin|0
    gliquidone|0
    dulaglutide|0
    no family history of sudden cardiac death|0
    denied recent severe illness|0
    denied respiratory symptoms|0
    abdominal computed tomography scan|0
    thoracic computed tomography scan|0
    infracentimetric mediastinal lymph nodes|0
    infracentimetric hilar lymph nodes|0
    physical examination|0
    no signs of distress|0
    temperature 37.2 °C|0
    blood pressure 130/70 mmHg|0
    heart rate 50 beats/min|0
    oxygen saturation 97%|0
    no jugular vein distention|0
    no carotid bruit|0
    peripheral pulses present and equal|0
    no skin lesions|0
    heart rate regular|0
    occasional premature beat|0
    first heart sound heard|0
    second heart sound heard|0
    no murmurs|0
    no rubs|0
    no gallops|0
    lung exam unremarkable|0
    abdomen exam unremarkable|0
    no lower leg edema|0
    laboratory work-up|0
    elevated glycated hemoglobin|0
    normal potassium|0
    normal cardiac ultrasensitive troponin|0
    normal thyroid findings|0
    normal angiotensin converting enzyme levels|0
    electrocardiogram|0
    regular sinus rhythm|0
    prolonged PR interval|0
    QTc 450 ms|0
    cardiac ultrasound|0
    basal-septal akinesia|0
    globally preserved left ventricular systolic ejection fraction|0
    normal left chamber size|0
    normal right chamber size|0
    normal tricuspid aortic valve|0
    trace aortic insufficiency|0
    ascending aorta 41 mm|0
    submaximal exercise stress test|0
    67% maximal predicted heart rate|0
    stopped due to multifocal ventricular extrasystoles|0
    self-limiting torsades de pointes|0
    no syncope|0
    no chest pain|0
    maximal blood pressure 152/70 mmHg|0
    recovery notable for multiple multifocal ventricular extrasystoles|0
    increase bisoprolol from 2.5 mg to 5 mg|0
    stop dulaglutide|0
    admitted to the hospital|0
    diagnostic coronary angiography|0
    stable 40%-50% mid-left anterior descending plaque|0
    cardiac continuous monitoring|0
    several ectopic supraventricular beats|0
    abundant polymorphic ventricular extrasystoles|0
    intermittent type I second degree atrioventricular block|0
    Mobitz I|0
    cardiac electrophysiology study|0
    induced sustained monomorphic ventricular tachycardia|0
    rate 240 beats/min|0
    terminated by burst|0
    cardiac magnetic resonance imaging|0
    nondilated left ventricle|0
    normotrophic left ventricle|0
    basoseptal dyskinesis|0
    mid-septal dyskinesis|0
    MRI-derived left ventricular ejection fraction 45%|0
    delayed enhancement|0
    patchy transmural fibrosis of the septum|0
    hyperenhancement of the papillary muscles|0
    extensive cardiac involvement of sarcoidosis|0
    whole-body positron emission tomography/CT scan|0
    no myocardial uptake|0
    cardiac sarcoidosis diagnosis|0
    pulmonary sarcoidosis in remission|0
    double-chamber implantable cardiac defibrillator implanted|0
    secondary prevention|0
    ejection fraction 45%|0
    started methylprednisolone|0
    started methotrexate|0
    regular ICD interrogation|0
    episodes of asymptomatic nonsustained ventricular tachycardia|0
    asymptomatic episode of nonsustained ventricular tachycardia|0
    stopped by antitachycardia pacing run|0
    <|eot_id|>