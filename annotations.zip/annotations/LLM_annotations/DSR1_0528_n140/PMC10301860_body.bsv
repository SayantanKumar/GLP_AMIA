40 years old| 0
    transgender woman| 0
    hypertension| 0
    prediabetes| 0
    hemoglobin A1c 6.1%| 0
    mixed hyperlipidemia| 0
    nonalcoholic steatohepatitis| 0
    gastroesophageal reflux| 0
    solitary congenital kidney| 0
    presented to weight management program| 0
    weight 280 pounds| 0
    BMI 39.6 kg/m2| 0
    weight stable at 240 pounds| -8760
    estradiol valerate 10 mg IM weekly| -8760
    spironolactone 50 mg| -8760
    started micronized progesterone 100 mg orally nightly| -8760
    weight gradually increased to 294 pounds| -8760
    lost 14 pounds| -720
    reducing candy and sugary beverages| -720
    no prior weight loss programs| 0
    no prior antiobesity medication| 0
    no prior metabolic and bariatric surgery| 0
    eating mostly at fast food restaurants| 0
    no disordered eating| 0
    sweet cravings| 0
    drinking multiple sugary beverages daily| 0
    instructed lower calorie diet| 0
    avoiding caloric beverages| 0
    encouraged self-monitoring intake| 0
    referred for sleep study| 0
    concerns for obstructive sleep apnea| 0
    primary physical activity walking at work| 0
    not willing to engage in gym exercises| 0
    not willing to engage in outdoor activities| 0
    body dysmorphia| 0
    concerns about discrimination| 0
    counseled on home exercises| 0
    provided online queer-friendly resources| 0
    prescribed semaglutide 0.25 mg weekly| 0
    significant improvements in hunger| 24
    significant improvements in satiety| 24
    dose escalated at monthly appointments| 720
    side effects monitored| 720
    mild abdominal cramping| 720
    reached semaglutide 1.0 mg weekly| 2160
    weighed 241 pounds| 2160
    BMI 34.1 kg/m2| 2160
    13.9% total body weight loss| 2160
    hemoglobin A1c 5.4%| 2160
    creatinine 0.97 mg/dL| 0
    creatinine 1.36 mg/dL| 2160
    decreased water consumption| 2160
    decreased thirst| 2160
    acute kidney injury| 2160
    resolved with increased water consumption| 2160
    estradiol level increased to >500 pg/mL| 2160
    referred to plastic surgeon| 2160
    reduced daily calorie intake| 24
    reduced fast food consumption| 24
    reduced sugary drink consumption| 24
    sleep study moderate obstructive sleep apnea| 0
    referred to sleep medicine| 2160
    did not incorporate resistance activity| 0
    encouraged light resistance activity| 2160
    begin home resistance band training| 2160
    qualified for bilateral breast augmentation| 2160
    weight 294 pounds| -8760
    weight 240 pounds| -105120
    estradiol level 100-200 pg/mL guideline| 0
    dose reduction of estradiol| 2160
    hemoglobin A1c 6.1%| -8760
    hemoglobin A1c 5.4%| 2160
    weight 127 kg| 0
    weight 133 kg| -8760
    weight 109 kg| 2160
    weight 109 kg| -105120
    creatinine 85-120 μmol/L| 0
    creatinine 58-110 μmol/L reference| 0
    creatinine 120 μmol/L| 2160
    estradiol level >1835 pmol/L| 2160
    guideline estradiol level 367-734 pmol/L| 0
    moderate OSA| 0
    weight 133 kg| -8760
    weight 109 kg| -105120
    weight 109 kg| 2160
    