36 years old| 0
    male| 0
    admitted for pneumonia| 0
    admitted for heart failure| 0
    long-standing history of type 2 diabetes| -504
    obesity| 0
    CKD stage 4| 0
    nephrotic syndrome| 0
    diabetic nephropathy| 0
    fever| 0
    tachycardia| 0
    hypoxemia| 0
    tachypnea| 0
    cardiomegaly| 0
    pleural effusion| 0
    consolidation| 0
    systolic blood pressure 168 mm Hg| 0
    diastolic blood pressure 95 mm Hg| 0
    eGFR 14 mL/min/1.73 m2| 0
    serum creatinine 4.7 mg/dL| 0
    daily urinary protein 15.5 g/day| 0
    plasma glucose 254 mg/dL| -504
    HbA1c 8.3%| -504
    liraglutide 0.9 mg/day| 0
    pioglitazone 15 mg/day| 0
    insulin aspart 40 U before breakfast, 20 U before lunch, 24 U before dinner| 0
    insulin glargine 65 U at bedtime| 0
    stopped pioglitazone| 0
    started dapagliflozin 5 mg/day| 96
    body weight loss over 20 kg| 0
    serum creatinine gradually decreased after transient increase| 96
    eGFR gradually increased after transient decrease| 96
    urinary protein decreased significantly| 0
    reduction in urinary protein -10.8 g/day| 0
    plasma BNP 38.6 pg/mL| 0
    plasma BNP increased from 7.9 to 38.6 pg/mL in 3 weeks before admission| -504
    plasma BNP decreased to 5.3 pg/mL| 792
    serum ketone bodies high 557 µmol/L| 120
    serum ketone bodies high 407 µmol/L| 936
    discharged from hospital| 960
    liraglutide 0.9 mg/day| 960
    dapagliflozin 5 mg/day| 960
    insulin aspart 46 U before breakfast, 10 U before lunch, 16 U before dinner| 960
    insulin glargine 41 U at bedtime| 960
    daily insulin dose decreased from 149 to 113 U| 960
    body weight loss| 0
    serum creatinine level decreased| 96
    urinary protein reduced| 0
    eGFR increased| 96
    increased serum ketone bodies| 120
    reduced blood pressure| 96
    amelioration of heart failure| 96
    increased exercise tolerance| 96
    reduced plasma BNP level| 792
    utilization of ketone bodies| 120
    discontinuation of pioglitazone| 0
    reduced daily insulin dose| 960
    improved renal function| 96
    