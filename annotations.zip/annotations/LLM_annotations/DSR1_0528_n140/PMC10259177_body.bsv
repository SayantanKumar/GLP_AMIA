54 years old | 0
    female | 0
    T2DM | -131400
    hypertension | -131400
    worsening central obesity | -131400
    presented to our outpatient endocrine clinic | 0
    poor and deteriorating glycemic control | 0
    difficulty maintaining optimal weight | 0
    strict diet | 0
    intense physical activity | 0
    frustrated by worsening abdominal obesity | 0
    exacerbated by addition of insulin | -17520
    no easy bruising | 0
    no striae | 0
    no muscle weakness | 0
    seen multiple physicians | -26280
    family history of T2DM | 0
    family history of obesity | 0
    nonsmoker | 0
    minimal alcohol use | 0
    no history of glucocorticoid use | 0
    hemoglobin A1c level 11.4% | -2920
    hypertriglyceridemia | -2920
    hypercholesterolemia | -2920
    metformin 1000 mg twice daily | 0
    insulin glargine 18 units once daily | 0
    insulin aspart before meals | 0
    lisinopril 40 mg daily | 0
    hydrochlorothiazide 25 mg daily | 0
    vitals within normal limits | 0
    body mass index 33.4 kg/m2 | 0
    abdominal obesity | 0
    waist circumference 106.8 cm | 0
    muscular extremities | 0
    gluteal region lipoatrophy | 0
    hip circumference 93.7 cm | 0
    father with similar body habitus | 0
    paternal uncle with similar body habitus | 0
    no palmar xanthomas | 0
    no xanthelasma | 0
    no supraclavicular fat pad | 0
    no dorsocervical fat pad | 0
    no moon facies | 0
    no violaceous striae | 0
    no bruising | 0
    no proximal muscle weakness | 0
    no hirsutism | 0
    no acanthosis nigricans | 0
    no skin tags | 0
    no acromegaly | 0
    24-hour urinary free cortisol normal | 0
    1-mg dexamethasone suppression testing normal | 0
    concern for partial lipodystrophy | 0
    fasting leptin level normal | 0
    consent for natural history study | 0
    X-ray densitometry | 0
    increased trunk-to-lower limb fat percent ratio | 0
    FibroScan | 0
    hepatic steatosis | 0
    no cirrhosis | 0
    genetic testing for LMNA negative | 0
    genetic testing for PPARG negative | 0
    whole-exome sequencing pending | 0
    clinical diagnosis of FPLD type 1 | 0
    initiated on dulaglutide 0.75 mg once weekly | 0
    atorvastatin 40 mg daily | 0
    continued on basal-bolus insulin | 0
    continued on metformin | 0
    initiated pioglitazone 15 mg daily | 0
    self-discontinued pioglitazone | 2920
    improvement in hyperglycemia | 0
    improvement in hemoglobin A1c | 0
    discontinuation of insulin | 2920
    lost 35 pounds | 2920
    hyperlipidemia responded to atorvastatin | 0
    triglycerides 155 mg/dL | 2920
    total cholesterol 168 mg/dL | 2920
    