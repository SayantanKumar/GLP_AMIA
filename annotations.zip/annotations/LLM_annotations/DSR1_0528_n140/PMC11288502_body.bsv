54 years old | 0
    male | 0
    history of type 2 diabetes mellitus | 0
    dyslipidemia | 0
    hypertension | 0
    coronary artery disease | 0
    percutaneous coronary intervention | -43800
    recurrent ITP | 0
    metformin 1,000 mg twice daily | 0
    empagliflozin 12.5 mg twice daily | 0
    gliclazide 30 mg once daily | 0
    semaglutide 1 mg once weekly | 0
    atorvastatin 40 mg at bedtime | 0
    amlodipine 5 mg once daily | 0
    losartan 50 mg once daily | 0
    metoprolol 25 mg twice daily | 0
    aspirin 81 mg once daily | 0
    low ferritin levels | -840
    started on ferrous gluconate 300 mg daily | -840
    platelet count decline | -672
    platelet count 223 x 10^9/L | -840
    platelet count 89 x 10^9/L | -672
    asymptomatic | -672
    ITP diagnosis at 21 years old | -289296
    recurrent gum bleeding | -289296
    petechiae | -289296
    bone marrow biopsy | -289296
    corticosteroids | -289296
    annual follow-ups | -289296
    platelet levels averaged 100 x 10^9/L | -289296
    age 39 | -131400
    widespread petechiae | -131400
    persistent epistaxis | -131400
    upper respiratory tract infection | -131400
    vital signs stable | -131400
    low platelet count | -131400
    prednisone | -131400
    intravenous immunoglobulin (IV Ig) | -131400
    tapering course of prednisone | -131400
    ranitidine | -131400
    percutaneous coronary intervention 5 years ago | -43800
    ferritin level 20.7 ug/L | -840
    ferrous gluconate prescribed | -840
    platelet level 86 x 10^9/L | -672
    cessation of ferrous gluconate | -672
    platelet count increased to 144 x 10^9/L | -552
    discontinuing ferrous medication | -672
    