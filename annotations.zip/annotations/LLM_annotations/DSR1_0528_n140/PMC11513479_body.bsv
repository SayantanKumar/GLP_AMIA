50 years old| 0\
    female| 0\
    moved to the United States| -175200\
    establishing care with a new primary care provider| 0\
    inability to lose weight| 0\
    initial work up revealed hypothyroidism| 0\
    treated with levothyroxine| 0\
    vegetarian| 0\
    eating predominantly at home| 0\
    healthy meals| 0\
    small portion size| 0\
    doing regular household chores| 0\
    keeping herself active| 0\
    frustrated with the inability to lose weight| 0\
    interested in pharmacotherapy| 0\
    physical exam revealed normal vital signs| 0\
    normal systemic exam| 0\
    abdominal visceral obesity| 0\
    blood work showed total cholesterol 219 mg/dl| 0\
    triglycerides 93 mg/dl| 0\
    High density lipoprotein cholesterol (HDL-C) 46 mg/dl| 0\
    Low density lipoprotein cholesterol (LDL-C) 154mg/dl| 0\
    Hemoglobin A1c 5.3%| 0\
    Thyroid stimulating hormone (TSH)1.25 mIU/ml| 0\
    free Thyroid 4 hormone 0.93 ng/dl| 0\
    fasting glucose 101mg/dl| 0\
    Anti-nuclear anti-body (ANA) 1:80| 0\
    thyroid ultrasound showed a mildly enlarged gland with two small nodules| 0\
    primary care physician (PCP) prescribed Bupropion| 0\
    referred to an obesity specialist| 0\
    Body Mass Index (BMI) 32.61 kg/m2| 0\
    did not lose weight| 24\
    Bupropion stopped| 24\
    PCP started Topiramate| 24\
    appetite decreased significantly with Topiramate| 168\
    no weight loss| 168\
    phentermine added| 168\
    lost 10 pounds| 336\
    weight loss plateau in 4 months| 2880\
    seen by an obesity specialist| 2880\
    prescribed a custom-tailored Indian Vegetarian meal plan for 1200 calories| 2880\
    SMART goal patient instructions| 2880\
    two visits with the obesity specialist| 2880\
    followed up regularly with PCP| 2880\
    regained the weight| 7200\
    went to India| 7200\
    tried a program with strict all-natural diet| 7200\
    liposuction| 7200\
    exercising regularly| 7200\
    lost 10 pounds| 7200\
    gained all the weight back| 10560\
    returned to PCP| 10560\
    Weight 200 pounds| 10560\
    BMI 34.1 kg/m2| 10560\
    started on weekly injectable Semaglutide| 10560\
    dose titrated up to maximum dose| 10584\
    continued lifestyle interventions| 10560\
    lost a total of 59 pounds| 10584\
    BMI decreased from 34.1 kg/m2 to 23.5 kg/m2| 10584\
    Semaglutide dose slowly decreased| 10584\
    maintained on the optimal dose| 10584\
    patient very happy with the weight loss| 10584\
    can do housework without pain| 10584\
    knee pain much better| 10584\
    walks and bikes a lot| 10584\
    happy that she can maintain her weight| 10584\
    <|eot_id|>
    