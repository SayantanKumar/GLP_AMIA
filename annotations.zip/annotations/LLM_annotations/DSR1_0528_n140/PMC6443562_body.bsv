35 years old | 0
    woman | 0
    diagnosed with diabetes | -157680
    treated with oral hypoglycemic agents | -157680
    insulin treatment | -87600
    SPIDDM | -87600
    obese | 0
    family history: both parents T2D | 0
    family history: grandmother obese | 0
    family history: younger sister obese | 0
    height 152 cm | -131400
    weight 90 kg | -131400
    BMI 39.0 kg/m2 | -131400
    weight 120.8 kg | 0
    BMI 52.3 kg/m2 | 0
    medical therapy ineffective | 0
    introduced to Department of Bariatric Surgery | 0
    metformin | 0
    pioglitazone | 0
    miglitol | 0
    dulaglutide | 0
    insulin | 0
    HbA1c 6.8% | 0
    admitted | 0
    HbA1c 5.7% | 0
    daily insulin dose 35 units | 0
    strict lifestyle modifications | 0
    anti-GAD antibody elevated | 0
    plasma CPR response to glucagon 1.21 ng/mL | 0
    bariatric/metabolic surgery | 0
    sleeve gastrectomy | 0
    blood glucose stabilized | 24
    cessation of all medications except insulin glargine | 24
    insulin glargine 5 units daily | 24
    insulin discontinued | 1440
    HbA1c 5.8% | 4320
    body weight 76.1 kg | 4320
    %EWL 66.6% | 4320
    abdominal fat area 233 cm2 | 4320
    visceral fat area 71 cm2 | 4320
    muscle mass loss 1.7 kg | 4320
    fat mass loss 34.1 kg | 4320
    plasma CPR response to glucagon 2.34 ng/mL | 4320
    no severe adverse events | 4320
    <|eot_id|>
    