32 years old | 0
    woman | 0
    Prader-Willi syndrome | 0
    diabetes | -173328
    strict low-carbohydrate diet | -96408
    poorly-controlled glycemia | -96408
    bodyweight 54 kg | -96408
    bodyweight increased | -96408
    excessive intake of protein | -96408
    excessive intake of lipid | -96408
    glimepiride | -96408
    metformin | -96408
    linagliptin | -96408
    switched to ipragliflozin | -312
    ipragliflozin | -312
    polyuria | -312
    bodyweight decreased 3 kg | -240
    epigastralgia | -48
    water intake decreased | -48
    dietary intake decreased | -48
    tachypnea | -24
    visited emergency room | 0
    severe acidosis | 0
    ketonuria | 0
    ketonemia | 0
    normal lactate | 0
    chest X-ray no abnormalities | 0
    electrocardiogram no abnormalities | 0
    abdominal CT no abnormalities | 0
    urinary sediments no abnormalities | 0
    unlikely infectious diseases | 0
    ketoacidosis | 0
    continuous intravenous insulin | 0
    Ringer's solution infusion | 0
    glucose infusion | 0
    intensive care unit | 0
    ketoacidosis improved | 48
    bodyweight increased 2 kg | 48
    antiglutamic acid decarboxylase antibody negative | 0
    islet antigen-2 antibody negative | 0
    insulin autoantibody negative | 0
    serum C-peptide 0.4 ng/mL | 0
    urinary C-peptide undetectable | 0
    urinary C-peptide 40.2 μg/day | 144
    plasma glucose 191 mg/dL | 0
    HbA1c 9.3% | 0
    glycated albumin 19.6% | 0
    basal-bolus insulin therapy | 48
    discharged | 264
    insulin glargine | 264
    lixisenatide | 264
    metformin | 264
    nutritionist instructed | 264
    1500-kcal diet | 264
    65 g protein | 264
    45 g fat | 264
    210 g carbohydrate | 264
    HbA1c 6.8% | 744
    glycated albumin 13.7% | 744
    bodyweight 67 kg | -312
    BH 150 cm | 0
    BW 63.9 kg | 0
    BMI 28.4 kg/m2 | 0
    RR 32/min | 0
    HR 112/min | 0
    BP 139/77 mmHg | 0
    level of consciousness alert | 0
    WBC 13700/μL | 0
    RBC 501 × 10^4/μL | 0
    Hb 15.2 g/dL | 0
    Ht 45.9% | 0
    Plt 25.7 × 10^4/μL | 0
    urine pH 5.0 | 0
    urine glucose 4+ | 0
    urine ketone body 3+ | 0
    urine occult blood negative | 0
    urine sediments none | 0
    Na 135 mmol/L | 0
    K 3.4 mmol/L | 0
    Cl 104 mmol/L | 0
    TP 7.8 g/dL | 0
    Alb 3.9 g/dL | 0
    BUN 17.5 mg/dL | 0
    Cre 0.4 mg/dL | 0
    UA 6.5 mg/dL | 0
    Amy 51 IU/L | 0
    T-Bil 0.4 mg/dL | 0
    AST 15 IU/L | 0
    ALT 11 IU/L | 0
    γ-GTP 24 IU/L | 0
    ALP 264 IU/L | 0
    T-chol 202 mg/dL | 0
    HDL-chol 28 mg/dL | 0
    LDL-chol 151 mg/dL | 0
    TG 116 mg/dL | 0
    blood gas pH 7.055 | 0
    PaCO2 10.9 mmHg | 0
    PaO2 125.0 mmHg | 0
    HCO3 3.0 mmol/L | 0
    base excess -25.3 mmol/L | 0
    lactate 8.7 mg/dL | 0
    GA 19.6% | 0
    C-peptide 0.4 ng/mL | 0
    anti-GAD Ab <0.3 U/mL | 0
    anti-IA-2 Ab <0.4 U/mL | 0
    insulin Ab <0.4 U/mL | 0
    total ketone body 7473 μmol/L | 15
    acetoacetate 1915 μmol/L | 15
    3-hydroxybutyrate 5558 μmol/L | 15
    eating habits: 1860 kcal/day | -312
    27.4% protein | -312
    55.1% fat | -312
    14.3% carbohydrate | -312
    carbohydrate intake 66 g/day | -312
    dehydration | 0
    no infectious diseases | 0