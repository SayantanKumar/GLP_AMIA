28 years old|0
    female|0
    presented to emergency department|0
    accidental injection of liraglutide 18 mg subcutaneously|0
    epigastric abdominal pain radiating to back|0
    nausea|0
    vomiting|0
    sweating|0
    diabetes mellitus type II|0
    obesity|0
    weight 109 kg|0
    body mass index 40.5 kg/m2|0
    prescribed metformin 500 mg twice daily|0
    daily tablet multivitamin|0
    vital signs within normal|0
    blood glucose 4.6 mmol/L|0
    conscious level normal|0
    abdomen soft|0
    abdomen lax|0
    no focal tenderness|0
    venous blood gas pH 7.40|0
    venous blood gas PCO2 42 mmHg|0
    venous blood gas HCO3 25.2 mEq/L|0
    venous blood gas lactate 0.6 mmol/L|0
    mild hypokalemia 3.2 mmol/L|0
    electrolyte panel within normal|0
    renal panel within normal|0
    lipase normal|0
    amylase normal|0
    C-peptide normal|0
    under observation 16 hours|0
    monitor hourly blood glucose levels|0
    epigastric abdominal pain persisted|0
    persistent vomiting|0
    received dextrose D50% bolus|0
    received dextrose D50% bolus|0
    received dextrose D50% bolus|0
    dextrose 5% infusion|0
    dextrose 10% infusion|0
    abdominal pain improved|16
    blood glucose 7.8 mmol/L|16
    asymptomatic|16
    discharged|16
    good health|10800
    did not continue liraglutide|10800
    no hypoglycemia|10800
    no pancreatitis|10800
    <|eot_id|>
    