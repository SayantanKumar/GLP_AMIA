61-year-old | 0
    woman | 0
    type II diabetes mellitus | 0
    semaglutide | 0
    glimepiride | 0
    presented | 0
    single erythematous, crusted lesion on breast | 0
    hypertension | 0
    hyperlipidemia | 0
    lichen sclerosus | 0
    fibromyalgia | 0
    chronic gingivitis | 0
    rheumatoid arthritis | 0
    cyclobenzaprine | 0
    amitriptyline | 0
    hydroxychloroquine | 0
    oxycodone/paracetamol | 0
    atorvastatin | 0
    losartan | 0
    chlorhexidine oral rinse | 0
    clobetasol 0.05% cream | 0
    initiation of semaglutide | -720
    returned | 720
    new crusted erosions of the breast | 720
    new crusted erosions of the lower back | 720
    worsening erythema of the gingivae | 720
    worsening edema of the gingivae | 720
    applied 2% ketoconazole cream | 0
    applied 2.5% hydrocortisone cream | 0
    previously treated and resolved intertrigo | -unknown
    skin biopsies obtained | 720
    hematoxylin-eosin staining | 720
    immunofluorescence testing | 720
    no mucosal biopsies taken | 720
    subepidermal vesiculation | 720
    brisk mixed dermal infiltrate | 720
    eosinophils | 720
    direct immunofluorescence demonstrated linear IgG reactivity | 720
    n-serrated pattern | 720
    linear C3 staining along the basement membrane | 720
    indirect immunofluorescence positive | 720
    IgG4 epidermal localization | 720
    ELISA elevated anti-BP180 antibodies | 720
    anti-BP230 antibody levels not elevated | 720
    diagnosis of bullous pemphigoid | 720
    discontinued semaglutide | 720
    marked improvement in cutaneous erosions | 720
    reduced inflammation of gingivae | 720
    no additional topical treatments | 720
    follow up | 3600
    mild gingival irritation | 3600
    IIF titers repeated | 3600
    IgG4 epidermal localization | 3600
    elevated anti-BP180 antibodies | 3600
    anti-BP230 antibody negative | 3600
    <|eot_id|>
    