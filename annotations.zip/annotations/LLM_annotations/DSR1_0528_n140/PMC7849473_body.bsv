19 years old| 0
    male| 0
    referred to our clinic| 0
    new-onset diabetes after kidney transplantation| 0
    NODAT| 0
    marked hyperglycemia| 336
    denied catabolic symptoms| 0
    no evidence of ketoacidosis| 0
    normal blood glucose levels through childhood| 0
    fasting blood glucose levels ranging from 4.2 to 5.2 mmol/L| 0
    no trend of deterioration over time| 0
    body weight 55 kg| 0
    BMI 21.5 kg/m²| 0
    kidney disease suspected at 20 weeks’ gestation| -165240
    bilateral hyperechogenic kidneys| -165240
    hyperechogenic kidneys with small cysts after birth| -164640
    plasma creatinine abnormally elevated after birth| -164640
    first child of non-consanguineous healthy parents| 0
    autosomal recessive polycystic kidney disease suspected| -164640
    renal function progressively deteriorated| -164640
    plasma creatinine level 433.2 μmol/L at age 18| -8760
    glomerular filtrate rate 15.9 mL/min/1.73 m² at age 18| -8760
    received living kidney transplant from father at age 19| -8760
    no morphological abnormality on father’s kidney| -8760
    father’s renal function normal| -8760
    procedure complicated by partial graft necrosis| -8760
    plasma creatinine level 185.6 μmol/L at hospital discharge| -8760
    GFR 44.3 mL/min/1.73 m² at hospital discharge| -8760
    immunosuppressive regimen tacrolimus 15 mg/day| -8760
    immunosuppressive regimen mycophenolate mofetil 2000 mg/day| -8760
    immunosuppressive regimen prednisolone 15 mg/day| -8760
    development of NODAT unexpected| 0
    history of diabetes in maternal grandmother| 0
    history of diabetes in maternal uncle| 0
    no other known relevant family history| 0
    no family history of kidney disease| 0
    fasting C-peptide 1.3 nmol/L| 0
    islet autoantibodies negative| 0
    GADA negative| 0
    ICA negative| 0
    IA-2A negative| 0
    ZnT8A negative| 0
    US pancreatic evaluation normal| 0
    raised possibility of MODY type 5| 0
    raised possibility of HNF1B gene defects| 0
    screening for mutations in HNF1B gene| 0
    missense heterozygous mutation p.S148L c.443 C>T in exon 2| 0
    not possible to perform genetic testing on other family members| 0
    family referred for genetic counseling| 0
    no complaints suggestive of exocrine dysfunction| 0
    liver enzymes normal over the years| 0
    alanine aminotransferase persistently below upper limit| 0
    aspartate aminotransferase persistently below upper limit| 0
    no clinical evidence of genital tract malformations| 0
    insulin therapy started with long-acting analog| 0
    insulin dose 0.16 UI/kg/day| 0
    insulin dose progressively reduced| 0
    reductions in tacrolimus and prednisolone doses| 0
    insulin switched to DPP-4 inhibitor at 5 months after NODAT diagnosis| 3600
    tacrolimus 8 mg/day at switch| 3600
    prednisolone 5 mg/day at switch| 3600
    stopped DPP-4 inhibitor due to vomiting| 3624
    glycated hemoglobin below 6.5%| 3624
    kept without medication| 3624
    HbA1c increased to 6.9% at 16 months later| 11664
    sitagliptin 25 mg/day resumed| 11664
    good tolerance to sitagliptin| 11664
    HbA1c progressively increased to 8% in following 8 months| 17064
    renal function slowly deteriorated| 17064
    plasma creatinine level ranging between 185.6 and 229.8 μmol/L| 17064
    GFR range 34–44 mL/min/1.73 m²| 17064
    tacrolimus 6 mg/day| 17064
    prednisolone 5 mg/day| 17064
    therapy switched to liraglutide| 17064
    liraglutide progressively titrated to 1.8 mg/day| 17064
    HbA1c dropped to 6.7% at 2 months after liraglutide introduction| 17688
    glycemic control deteriorated| 17688
    HbA1c increased to 10.9%| 17688
    immunosuppressive therapy doses unchanged| 17688
    less physical activity| 17688
    plasma creatinine level 224.5 μmol/L| 17688
    GFR 35.2 mL/min/1.73 m²| 17688
    liraglutide stopped| 17688
    insulin with long-acting analog resumed| 17688
    insulin dose 0.14 UI/kg/day| 17688
    glycemic control slightly improved at 2 months later| 18216
    insulin therapy maintained| 18216
    treatment management continued| 18216
    