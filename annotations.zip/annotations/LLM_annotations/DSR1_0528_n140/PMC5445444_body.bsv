53 years old| 0
    male| 0
    type 2 diabetes mellitus| -131400
    vertigo| 0
    hypertension| 0
    obstructive sleep apnea| 0
    obesity| 0
    hyperlipidemia| 0
    bilateral carpal tunnel syndrome| 0
    arthralgia| 0
    pituitary macroadenoma| 0
    remodeling of the sella floor| 0
    deviation of the infundibulum to the right| 0
    no suprasellar extension| 0
    IGF-1 level uncontrolled| 0
    GH levels elevated| 0
    acromegaly diagnosis| 0
    FPG elevated| 0
    HbA1c elevated| 0
    metformin| 0
    pioglitazone| 0
    glipizide extended release| 0
    insulin detemir| 0
    refused surgical removal| 0
    enrolled in C2305 study| 0
    assigned to octreotide| 0
    IGF-1 level 487.4 ng/mL| 0
    GH level 1.7 ng/mL| 0
    IGF-1 level 344.1 ng/mL| 2160
    GH level 1.6 ng/mL| 2160
    dose increase of octreotide| 2160
    insulin aspart added| 2160
    HbA1c level elevated| 2160
    IGF-1 level 383.9 ng/mL| 8640
    GH level 1.0 ng/mL| 8640
    HbA1c level 7.3%| 8640
    FPG level 147 mg/dL| 8640
    crossed over to pasireotide| 8640
    IGF-1 level 246.7 ng/mL| 10800
    GH level 0.6 ng/mL| 10800
    dose increase of pasireotide| 10800
    IGF-1 level normalized| 12960
    GH level 0.2 ng/mL| 12960
    IGF-1 level 226.8 ng/mL| 23760
    IGF-1 level 283.5 ng/mL| 25920
    IGF-1 level 288.4 ng/mL| 28080
    IGF-1 level 231.8 ng/mL| 43200
    GH level ≤0.6 ng/mL| 12960
    weight decreased| 43200
    FPG level increased| 8640
    FPG level 162 mg/dL| 8880
    FPG level decreased| 10800
    FPG level 146 mg/dL| 10800
    FPG level 131 mg/dL| 12960
    HbA1c level 7.1%| 12960
    FPG levels variable| 43200
    HbA1c levels stable| 43200
    metformin continued| 43200
    insulin dosing varied| 43200
    sitagliptin added| 23040
    liraglutide replaced sitagliptin| 45360
    biochemical control achieved| 12960
    biochemical control maintained| 43200
    acromegaly controlled| 43200
    discharged| 0
    <|eot_id|>
    