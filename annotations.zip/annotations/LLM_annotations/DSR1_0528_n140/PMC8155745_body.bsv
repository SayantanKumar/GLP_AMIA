26 years old | 0
    female | 0
    referred for evaluation | 0
    persistent fatigue | 0
    unintentional weight gain | 0
    possible hypothyroidism | 0
    right thyroid lobectomy | -52560
    uninodular goiter | -52560
    benign nodule | -52560
    thyroid-stimulating hormone measurements | -52560
    fatigue started | -26280
    poor exertional tolerance | -26280
    unintentional weight gain | -61320
    denied dietary restrictions | 0
    computed tomography of the abdomen | -24
    abdominal pain | -48
    diarrhea | -48
    mild hepatic steatosis | -24
    body mass index 38 kg/m2 | 0
    well healed low neck incision | 0
    absent right thyroid lobe | 0
    absent thyroid isthmus | 0
    unremarkable history and physical examination | 0
    first child positive NBS for PCD | -17520
    repeat serum carnitine level normal | -17496
    second child positive NBS for PCD | -8760
    serum carnitine level low | -8760
    carnitine levels measured | 0
    total carnitine 13 µM | 0
    carnitine esters 2 µM | 0
    genetic testing | 24
    SLC22A5 mutations | 48
    c.34G>A (p.Gly12Ser) | 48
    c.41G>A (p.Trp14Ter) | 48
    compound heterozygote | 72
    buccal swabs obtained | 72
    DNA sequencing | 72
    confirmed compound heterozygote | 96
    mother source c.34G>A | 96
    father source c.41G>A | 96
    electrocardiogram | 0
    no conduction abnormalities | 0
    echocardiogram | 0
    anatomically normal heart | 0
    preserved left ventricular ejection fraction | 0
    carnitine supplementation 20 mg/kg/d | 120
    carnitine supplementation 50 mg/kg/d | 168
    serum total carnitine 21 µM | 120
    serum total carnitine 40 µM | 168
    carnitine esters 5 µM | 120
    improvements in well-being | 168
    improvements in exertional tolerance | 168
    saw dietitian | 168
    began regular aerobic exercise | 168
    Saxenda (liraglutide) | 168
    intentional 15 pound weight loss | 2880
    follow-up appointment | 2880