69 years old| 0
    Japanese man| 0
    visual loss| -8760
    visual field distortion| -8760
    referred to Hokkaido University Hospital| -8760
    residual diabetic CME| -8760
    intravitreal anti-VEGF injections of aflibercept (IVA)| -26280
    intravitreal anti-VEGF injections of aflibercept (IVA)| -26280
    intravitreal anti-VEGF injections of aflibercept (IVA)| -26280
    intravitreal anti-VEGF injections of aflibercept (IVA)| -26280
    intravitreal anti-VEGF injections of aflibercept (IVA)| -26280
    intravitreal anti-VEGF injections of aflibercept (IVA)| -26280
    intravitreal anti-VEGF injections of aflibercept (IVA)| -26280
    intravitreal anti-VEGF injections of aflibercept (IVA)| -26280
    diabetes mellitus| -113880
    dyslipidemia| -113880
    hypertension| -113880
    diagnosed with diabetes| -113880
    subcutaneous injection of dulaglutide| 0
    insulin lispro| 0
    serum HbA1c levels 6.0%| 0
    cataract surgery on right eye| -26280
    best-corrected visual acuity (BCVA) 1.2 OD| 0
    best-corrected visual acuity (BCVA) 0.5 OS| 0
    intraocular pressure normal| 0
    slit-lamp examination| 0
    intraocular lens OD| 0
    mild cataracts OS| 0
    fundus examination| 0
    dot hemorrhages| 0
    hard exudates| 0
    pan-retinal photocoagulation scars| 0
    swept-source optical coherence tomography| 0
    macular edema| 0
    foveal cystoid lesions| 0
    reflectivity slightly higher than vitreous fluids OS| 0
    pars plana vitrectomy of left eye| 0
    cataract surgery| 0
    internal limiting membrane peeling| 0
    removal of cystoid lesion component| 0
    cystoid lesion component translucent soft solid| 0
    fixed in 4% formalin| 0
    embedded in paraffin| 0
    hematoxylin-eosin staining| 0
    fluorescence immunohistochemical staining| 0
    BCVA OS 0.3| 720
    CME subsided| 720
    CME recurred| 720
    sub-Tenon injection of triamcinolone acetonide (STTA)| 8760
    direct photocoagulation for microaneurysms| 8760
    IVA| 8760
    BCVA OS 0.2| 8760
    pathological diagnosis| 0
    immunohistochemical analysis| 0
    dewaxed in xylene| 0
    dehydrated in ethanol| 0
    rinsed in phosphate-buffered saline| 0
    microwave-based antigen retrieval| 0
    incubated with 5.0% normal goat serum| 0
    incubated with primary antibodies| 0
    incubated with secondary antibodies| 0
    visualized with inverted fluorescence-phase contrast microscope| 0
    excised tissue elliptical 0.7x0.4 mm| 0
    homogeneous structure| 0
    eosinophilic material| 0
    no cellular components| 0
    no membranous structure| 0
    erythrocyte aggregates at margin| 0
    immunohistochemical analysis positive for fibrin/fibrinogen| 0
    immunohistochemical analysis weakly positive for AGEs| 0
    no immunoreactivity for GFAP| 0
    no immunoreactivity for RAGE| 0
    no immunoreactivity for type 1 collagen| 0
    immunoreactivity for normal rabbit IgG negative control| 0
    <|eot_id|>
    
