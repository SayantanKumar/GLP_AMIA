37 years old|0
    male|0
    admitted to the hospital|0
    presented with history of LASIK|-120960
    LASIK complication|-120960
    progressive ectasia|-120960
    penetrating keratoplasty (PKP) in left eye|-105120
    type 2 diabetes mellitus|0
    obesity|0
    obstructive sleep apnea|0
    liraglutide|0
    lorcaserin|0
    no prior history of headache syndrome|0
    no anxiety|0
    no depression|0
    presented with acutely elevated intraocular pressure|-105120
    implantation of Baerveldt glaucoma drainage implant in left eye|-104640
    consistently worn scleral contact lens (SCL)|-105120
    no issues with SCL|-105120
    complained SCL uncomfortable and wants to pop out|-105120
    described pronounced left eye pain|0
    dull ache|0
    no associated redness|0
    no light sensitivity|0
    no vision changes|0
    using dorzolamide/timolol|0
    using loteprednol|0
    using artificial tears|0
    pain associated with left-sided headaches|0
    headaches localized to left temple region|0
    characterized pain as waxing and waning retrobulbar ache|2160
    endorsed redness|2160
    endorsed swelling of left eye|2160
    pain refractory to topical proparacaine|2160
    visual acuity 20/20 with contact lens correction|0
    intraocular pressure 20 mm Hg|0
    equal, reactive pupils|0
    no afferent pupillary defect|0
    extraocular motility full|0
    confrontational visual fields full|0
    mild ptosis|0
    well-covered glaucoma drainage implant plate and tube|0
    trace injection of conjunctiva|0
    clear PKP|0
    deep and quiet anterior chamber|0
    funduscopic exam: 0.3 cup-to-disc ratio|0
    sharp foveal light reflex|0
    normal retinal vasculature and periphery|0
    intermittent Meibomian gland dysfunction|0
    blepharitis|0
    no corneal epithelial disruption|0
    intermittent flare in anterior chamber|0
    pain severity increasing|1008
    limiting work functions|1008
    interfering with sleep|1008
    associated burning sensation|1008
    evaluated by cornea subspecialist|1008
    evaluated by uveitis subspecialist|1008
    evaluated by oculoplastics subspecialist|1008
    evaluated by optometric subspecialist|1008
    MRI showed enlarged left lacrimal gland|1008
    no signs of inflammation|1008
    no symptoms of inflammation|1008
    MRI finding clinically incompatible with dacryoadenitis|1008
    tenderness over aqueous shunt bleb|1008
    negative for posterior scleritis|1008
    normal B-scan ultrasonography|1008
    pain refractory to ibuprofen|1008
    discontinued ibuprofen|1008
    pain temporarily alleviated by fluorometholone|1008
    pain temporarily alleviated by oral prednisone|1008
    started on gabapentin 300mg twice daily|5256
    reported pain 0 out of 10|5880
    able to tolerate normal wear of SCL|5880
    discharged|0
    <|eot_id|>
    