51 years old | 0
    female | 0
    homozygous mutation carrier | 0
    MC4R mutation | 0
    type 2 diabetes | -168192
    hypertension | -105120
    hypercholesterolemia | 0
    rheumatic disease | 0
    depression | 0
    borderline personality disorder | 0
    normal birth weight | -446688
    extreme hunger | -446688
    obesity | -446688
    gastric bypass operation | -105120
    weight loss | -105120
    regained weight | -105120
    contacted | -105120
    volunteered | -105120
    liraglutide treatment | 0
    weight 152.2 kg | 0
    height 1.64 m | 0
    BMI 56.6 kg/m2 | 0
    systolic blood pressure 122 mmHg | 0
    diastolic blood pressure 78 mmHg | 0
    pulse 83 beats/min | 0
    fasting plasma glucose 6.3 mmol/L | 0
    fasting HbA1c 54 mmol/mol | 0
    fasting serum insulin 66 pmol/L | 0
    fasting C-peptide 1152 pmol/L | 0
    triglycerides 2.41 mmol/L | 0
    total fat mass 75.5 kg | 0
    total lean mass 76.9 kg | 0
    total fat percentage 49.6% | 0
    liraglutide | 0
    nausea | 672
    stomach pain | 672
    decreased hunger | 1344
    increased satiety | 1344
    weight 142.5 kg | 2688
    height 1.64 m | 2688
    BMI 53.0 kg/m2 | 2688
    systolic blood pressure 112 mmHg | 2688
    diastolic blood pressure 76 mmHg | 2688
    pulse 67 beats/min | 2688
    fasting plasma glucose 5.0 mmol/L | 2688
    fasting HbA1c 49 mmol/mol | 2688
    fasting serum insulin 48 pmol/L | 2688
    fasting C-peptide 1099 pmol/L | 2688
    triglycerides 1.78 mmol/L | 2688
    total fat mass 71.2 kg | 2688
    total lean mass 71.3 kg | 2688
    total fat percentage 49.9% | 2688
    impaired glucose tolerance | 0
    normal glucose tolerance | 2688
    postprandial glucose iAUC 439 mmol/L × min | 0
    postprandial insulin iAUC 6217 pmol/L × min | 0
    postprandial C-peptide iAUC 103623 mmol/mol × min | 0
    postprandial glucose iAUC 428 mmol/L × min | 2688
    postprandial insulin iAUC 12027 pmol/L × min | 2688
    postprandial C-peptide iAUC 130277 mmol/mol × min | 2688
    OGTT 2-hour glucose 8.7 mmol/L | 0
    OGTT 2-hour glucose 6.4 mmol/L | 2688
    weight loss 9.7 kg | 2688
    BMI reduction 3.6 | 2688
    fasting glucose reduction 1.3 mmol/L | 2688
    fasting insulin reduction 18 pmol/L | 2688
    HbA1c reduction 5 mmol/mol | 2688
    triglycerides reduction 0.63 mmol/L | 2688
    fat mass reduction 4.3 kg | 2688
    lean mass reduction 5.6 kg | 2688
    systolic BP reduction 10 mmHg | 2688
    diastolic BP reduction 2 mmHg | 2688
    pulse reduction 16 bpm | 2688
    no change in fat percentage | 2688
    mild gastrointestinal side effects | 672
    no side effects | 1344
    decreased hunger effect reduced | 1344
    satiety effect present | 2688
    discharged | 2688
    