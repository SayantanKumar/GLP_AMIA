35 years old | 0
    female | 0
    type 2 diabetes mellitus | -52560
    clinically severe obesity | 0
    body weight 87 kg | 0
    body mass index 31 kg/m2 | 0
    liraglutide | -8760
    stopped liraglutide | -8760
    metformin 1000 mg bid | -24
    no diabetic ketoacidosis | -24
    admitted to the hospital | 0
    poor blood glucose | 0
    glycated hemoglobin 8.8% | 0
    hypertension | 0
    dyslipidemia | 0
    hyperuricemia | 0
    non-alcoholic fatty liver disease | 0
    delayed insulin secretion | 0
    no insulin deficiency | 0
    pancreatic islet autoantibodies negative | 0
    father type 2 diabetes mellitus | 0
    laparoscopic sleeve gastrectomy | 24
    metformin discontinued | 24
    short-acting recombinant human insulin | 24
    discontinued insulin | 24
    blood glucose 13.4 to 16.8 mmol/L | 24
    degludec insulin 20 IU qn | 24
    metformin 500 mg tid | 24
    dulaglutide 1.5 mg weekly | 24
    sipping water | 24
    enteral nutritional suspension | 24
    bloated | 24
    full | 24
    total daily fluid intake 800-1000 mL | 24
    total daily calorie intake less than 500 kcal | 24
    abdominal CT no abnormal signs | 24
    weight loss 5 kg | 120
    fasting blood glucose 7 to 8 mmol/L | 120
    postprandial blood glucose 8 to 12 mmol/L | 120
    fatigue | 144
    sweating | 144
    nausea | 144
    vomiting 30 times | 144
    blood gas analysis metabolic acidosis | 144
    blood sugar 16.1 mmol/L | 144
    urine ketone over 4+ | 144
    glucose over 4+ | 144
    fluid resuscitation | 144
    glucose | 144
    insulin | 144
    degludec insulin discontinued | 144
    metformin discontinued | 144
    dulaglutide discontinued | 144
    crystalloid fluid plus water intake more than 4000 mL daily | 144
    recombinant human insulin 0.05 units/kg/h | 144
    improved significantly | 168
    no nausea | 168
    no vomiting | 168
    ketones negative | 168
    random blood glucose less than 11.1 mmol/L | 168
    discontinued insulin | 168
    discontinued fluid infusion | 168
    ensure fluid intake | 168
    ensure energy intake | 168
    discharged | 240
    <|eot_id|>