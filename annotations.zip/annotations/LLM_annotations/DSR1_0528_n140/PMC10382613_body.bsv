36 years old | 0
    female | 0
    type 1 diabetes mellitus | 0
    poorly controlled | 0
    closed-loop insulin infusion system | 0
    Tandem t:slim with Control-IQ | 0
    Dexcom G6 continuous glucose monitor | 0
    tirzepatide | 0
    off-label use for weight loss | 0
    weight 192 lbs | -90 days
    body mass index 32.2 kg/m2 | -90 days
    hemoglobin A1c 9.4% | -90 days
    severe nausea | -90 days
    heartburn | -90 days
    lost 50 lbs | -90 days
    weight 142 lbs | -90 days
    body mass index 25.3 kg/m2 | -90 days
    advised to stop or decrease tirzepatide | -90 days
    elected to continue medication | -90 days
    emergency room presentation | 0
    acute worsening of nausea | -4 days
    acute worsening of heartburn | -4 days
    vomiting | -3 days
    inability to keep anything down | -3 days
    positive home urine ketone | -3 days
    t:slim CIQ reported hypoglycemia | -3 days
    suspension of insulin delivery | -3 days
    did not check capillary glucose | -3 days
    treating hypoglycemia with glucose tablets | -3 days
    alert | 0
    mild distress | 0
    appropriately attached CLS | 0
    appropriately attached CGM | 0
    tachycardia 137 beats/min | 0
    tachypnea 35 breaths/min | 0
    elevated blood pressure 155/100 mm Hg | 0
    normal body temperature 98.6 °F | 0
    Kussmaul breathing | 0
    dry oral mucosa | 0
    volume depletion | 0
    CGM readings between 40 and 180 mg/dL | 0
    intermittent hypoglycemia | 0
    t:slim CIQ report intermittent insulin delivery suspension | 0
    correction boluses for hyperglycemia | 0
    total daily dose of insulin 30 units | 0
    prior total daily dose 70 units | -90 days
    point of care glucose 289 mg/dL | 0
    serum glucose 322 mg/dL | 0
    concurrent Dexcom CGM reading 40 mg/dL | 0
    hemoglobin 16.2 g/dL | 0
    hematocrit 45.3% | 0
    hemoglobin A1c 7.4% | 0
    bicarbonate 12 mmol/L | 0
    sodium 131 mmol/L | 0
    potassium 5 mmol/L | 0
    creatinine 1.00 mg/dL | 0
    glomerular filtration rate 75 mL/min/1.73 m2 | 0
    anion gap 21 mmol/L | 0
    high-anion-gap metabolic acidosis | 0
    betahydroxybutyrate level not drawn | 0
    no source of infection | 0
    diagnosed with DKA | 0
    CLS removed | 0
    CGM removed | 0
    continuous regular insulin | 0
    intravenous normal saline infusion | 0
    serum glucose 143 mg/dL | 8
    anion gap 8 mmol/L | 8
    bicarbonate 14 mmol/L | 8
    bicarbonate 16 mmol/L | 24
    bicarbonate 24 mmol/L | 72
    transitioned to subcutaneous insulin | 72
    basal glargine | 72
    prandial lispro | 72
    total daily dose 24 units | 72
    transitioned back to t:slim CIQ | 96
    inserted new Dexcom G6 CGM | 96
    glycemic control within optimal range | 96
    total daily dose 37 units | 96
    outpatient follow-up | 240
    tirzepatide discontinued | 96