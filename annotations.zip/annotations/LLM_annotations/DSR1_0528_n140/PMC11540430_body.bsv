62 years old | 0
    woman | 0
    presented with acute onset abdominal pain | 0
    presented with bloody stools | 0
    history of obesity | 0
    body mass index 40 kg/m2 | 0
    prior venous thromboembolism | 0
    heart failure with preserved ejection fraction | 0
    up to date on colorectal cancer screening | 0
    previous colonoscopies showed benign polyps | 0
    previous colonoscopies showed diverticulosis | 0
    medications included tirzepatide | 0
    tirzepatide 2.5 mg subcutaneous once weekly | 0
    apixaban 5 mg twice daily | 0
    spironolactone 25 mg once daily | 0
    furosemide 20 mg once daily | 0
    atorvastatin 20 mg once daily | 0
    fluoxetine 30 mg once daily | 0
    lisinopril 2.5 mg once daily | 0
    atenolol 37.5 mg once daily | 0
    no over-the-counter supplements | 0
    no laxatives | 0
    started low-dose tirzepatide | -672
    started tirzepatide for weight loss | -672
    noted new-onset constipation | -672
    constipation | -672
    firm bowel movements once every 3 days | -672
    eating smaller, more frequent meals | -672
    no changes to diet | -672
    lower abdominal cramping pain | -24
    urge to defecate | -24
    bloody stools | -24
    duration 1 day | -24
    hypertensive | 0
    blood pressure 155/103 mm Hg | 0
    vital signs otherwise normal | 0
    soft abdomen | 0
    nondistended abdomen | 0
    mild diffuse lower tenderness | 0
    no guarding | 0
    white blood cell count 12.0 | 0
    hemoglobin normal | 0
    platelet count normal | 0
    international normalized ratio 1.6 | 0
    CT scan abdomen and pelvis with contrast | 0
    CT scan showed new wall thickening | 0
    CT scan showed pericolonic fat stranding | 0
    involving splenic flexure | 0
    involving descending colon | 0
    mesenteric vasculature patent | 0
    colonoscopy | 0
    colonoscopy demonstrated inflammatory mucosal changes | 0
    from mid-sigmoid colon through distal transverse colon | 0
    biopsies showed epithelial denudation | 0
    biopsies showed sloughing with necrosis | 0
    biopsies showed crypt withering | 0
    biopsies showed hyalinization of lamina propria | 0
    biopsies showed lamina propria congestion | 0
    biopsies showed lamina propria hemorrhage | 0
    consistent with colonic ischemia | 0
    admitted to hospital | 0
    treated with intravenous fluids | 0
    bowel rest | 0
    broad-spectrum antibiotics | 0
    intravenous ciprofloxacin | 0
    intravenous metronidazole | 0
    analgesics | 0
    apixaban held | 0
    furosemide held | 0
    spironolactone held | 0
    tirzepatide held | 0
    rapid resolution of symptoms | 48
    spontaneous resolution of symptoms | 48
    discharged | 72
    weaned off opioid pain medications | -24
    apixaban resumed | 72
    diuretics held | 72
    discharged with oral ciprofloxacin | 72
    discharged with oral metronidazole | 72
    to complete 5-day antibiotic course | 72
    no recurrence of rectal bleeding at clinic visit | 168
    clinic visit a week after discharge | 168
    intermittent recurrence of bloody bowel movements | 168
    for approximately 2 months after discharge | 168
    repeat colonoscopy | 1800
    repeat colonoscopy 2.5 months after hospitalization | 1800
    found 2 subcentimeter benign polyps | 1800
    in transverse colon | 1800
    otherwise normal mucosa | 1800
    no gross evidence of ischemia | 1800
    no gross evidence of inflammation | 1800
    colonic ischemia | 0
    nonocclusive ischemia | 0
    secondary to tirzepatide-induced constipation | 0
    diuretic use | 0
    heart failure | 0
    onset temporally related to initiation of tirzepatide | 0
    new-onset constipation | 0
    volume depletion | 0
    hypoperfusion | 0
    increased stool burden | 0
    baseline reduced cardiac output | 0
    no mesenteric arterial occlusive disease | 0
    no mesenteric venous occlusive disease | 0
    compliance with home apixaban therapy | 0
    no arterial thrombus | 0
    cardioembolic cause less likely | 0
    advised to avoid GLP-1 RAs | 168
    potential increased risk of recurrent colonic ischemia | 168
    maintain adequate hydration | 168
    review medication list | 168
    dose reduction of medications associated with colonic ischemia | 168
    dose reduction of medications predisposing to hypovolemia | 168
    dose reduction of medications predisposing to hypotension | 168
    counsel patients on preventive measures for constipation | 168
    prescribe laxative agents when appropriate | 168
    patients with congestive heart failure should be medically optimized | 168
    before initiation of GLP-1 RA therapy | 168
    <|eot_id|>
    