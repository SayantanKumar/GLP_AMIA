53 years old | 0
    male | 0
    hypertension | 0
    former tobacco use | 0
    morbid obesity | 0
    type 2 diabetes | 0
    cystinuria | 0
    nephrolithiasis | 0
    lithotripsy | 0
    tiopronin | -5040
    potassium citrate | 0
    semaglutide | 0
    amlodipine | 0
    telmisartan | 0
    chlorthalidone | 0
    blood pressure 128/92 mmHg | 0
    body mass index 41.5 kg/m2 | 0
    no peripheral edema | 0
    serum creatinine 1.1 mg/dl | 0
    estimated glomerular filtration rate 80 ml/min per 1.73 m2 | 0
    urinalysis 3+ protein | 0
    urinalysis negative blood | 0
    urinalysis no leukocyturia | 0
    24-hour urine protein 4.6 g | 0
    serum albumin 4.5 g/dl | 0
    normal serum complement levels | 0
    negative ANA | 0
    negative dsDNA antibody | 0
    negative hepatitis B surface antigen | 0
    negative hepatitis C antibody | 0
    negative MPO-ANCA | 0
    negative PR3-ANCA | 0
    negative anti-PLA2R antibody | 0
    negative anti-glomerular basement membranes antibody | 0
    negative HIV | 0
    no M-spike on SPEP | 0
    no M-spike on UPEP | 0
    normal renal function 7 months prior | -5040
    absence of proteinuria 7 months prior | -5040
    kidney biopsy | 0
    light microscopy: 23 glomeruli | 0
    no global sclerosis | 0
    no segmental sclerosis | 0
    glomeruli normal to mildly enlarged | 0
    unremarkable mesangial areas | 0
    patent glomerular capillary lumina | 0
    normal GBM thickness | 0
    normal GBM contour | 0
    finely vacuolated texture on some capillary loops | 0
    no GBM spikes | 0
    no areas of chain-like thickening | 0
    mild tubular atrophy | 0
    mild interstitial fibrosis | 0
    no significant interstitial inflammation | 0
    intact brush borders in nonatrophic proximal tubules | 0
    unremarkable arteries and arterioles | 0
    immunofluorescence microscopy: 2-3+ granular to semilinear segmental glomerular capillary wall staining for IgG | 0
    immunofluorescence microscopy: trace C3 | 0
    immunofluorescence microscopy: 2+ kappa | 0
    immunofluorescence microscopy: 2+ lambda | 0
    electron microscopy: small segmental subepithelial electron dense deposits | 0
    electron microscopy: deposits involving approximately one-third of examined glomerular capillary surface area | 0
    electron microscopy: no mesangial deposits | 0
    electron microscopy: no subendothelial deposits | 0
    electron microscopy: no extraglomerular deposits | 0
    electron microscopy: no endothelial tubuloreticular inclusions | 0
    podocyte foot process effacement 30%-40% | 0
    negative PLA2R staining | 0
    positive NELL-1 staining | 0
    segmental membranous nephropathy | 0
    NELL-1 positive | 0
    tiopronin-associated | 0
    tiopronin discontinued | 0
    telmisartan started | 0
    dapagliflozin started | 0
    denied use of lipoic acid supplements | 0
    no known occupational risk factors for heavy metal exposure | 0
    no known environmental risk factors for heavy metal exposure | 0
    computed tomography scan of chest negative | 0
    computed tomography scan of abdomen negative | 0
    computed tomography scan of pelvis negative | 0
    screening colonoscopy negative | 0
    prostate-specific antigen testing negative | 0
    immunosuppressive therapies deferred | 0
    anti-NELL-1 antibodies not performed | 0
    serum creatinine 1.0 mg/dl at 6 months | 4320
    urine protein-to-creatinine ratio 2.08 g/g at 6 months | 4320
    serum albumin 4 g/dl at 6 months | 4320
    <|eot_id|>
    