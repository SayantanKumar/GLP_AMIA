53 years old | 0
    female | 0
    diagnosed with asthma | -262800
    mother has asthma | -262800
    daughter has asthma | -262800
    controlled by PRN budesonide/formoterol | -262800
    non-COVID infectious exacerbation | -720
    treated with prednisone | -720
    treated with macrolide antibiotic | -720
    symptoms resolved | -650
    symptoms recurred | -600
    treated with budesonide/formoterol BID and PRN | -600
    COVID infection | -6480
    room oxygen saturation 93% | -6480
    full recovery | -6480
    gained 40 pounds weight | -6480
    adherent to medication | -600
    excellent inhaler technique | -600
    no nasal symptoms | -600
    occasional heartburn | -600
    normal chest X-ray | 0
    spirometry moderate obstruction | 0
    FEV1 reversibility 21% | 0
    air-trapping | 0
    FVC improved 19% with bronchodilator | 0
    treated with indacaterol/mometasone/glycopyrronium | 0
    proton pump inhibitor daily | 0
    subcutaneous semaglutide | 0
    titrated to 1 mg weekly | 0
    conventional weight loss strategies unsuccessful | 0
    lost weight slowly and consistently | 168
    lung function normalized | 336
    symptoms resolved | 336
    allergy testing | 504
    positive for house dust mite | 504
    positive for mold | 504
    negative for dog | 504
    blood eosinophil count 100 | 504
    fractionated exhaled nitric oxide 11 | 504
    repeat spirometry resolution of obstruction | 1008
    no reversibility | 1008
    lost 40 pounds weight | 1008
    PPI discontinued | 1008
    asthma therapy reduced to moderate-dose ICS/LABA | 1008
    subsequently to low-dose ICS/LABA | 1344
    no recurrence asthma symptoms | 1344
    no recurrence gastroesophageal reflux symptoms | 1344
    feels best she has in years | 1008
    <|eot_id|>
    