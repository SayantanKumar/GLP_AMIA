49 years old|0
    overweight|0
    hypertensive|0
    female|0
    type 2 diabetes|0
    diabetic sensory peripheral neuropathy|0
    non-proliferative diabetic retinopathy|0
    triple therapy of oral hypoglycemic agents|0
    oral hypoglycemic agents|0
    insulin introduced|0
    repeated extensive local reactions to various insulin preparations|-26280
    discontinued insulin aspart|-26280
    local erythema|-26280
    edema|-26280
    repeated local erythema|-26280
    repeated edema|-26280
    insulin aspart discontinued|-26280
    introduced insulin glargine|-21900
    extensive local reaction|-21900
    oral hypoglycemic agents|-21900
    exenatide|-21900
    antihistamine premedication|-21900
    delayed extensive local reactions|-21900
    uncontrolled diabetes|0
    introduced insulin lispro|0
    introduced insulin glulisine|0
    recurrence of large local reactions|0
    referred to Allergy clinic|0
    skin prick tests negative|0
    intradermal test positive|0
    patch tests negative|0
    insulin specific-IgE negative|0
    desensitization to insulin glulisine initiated|0
    rapid desensitization protocol|0
    progressive dose-escalation|0
    target dose 8 units|0
    start dose 0.000001 U|0
    escalated every 30 minutes|0
    local reaction|0
    pruritus|0
    erythema|0
    edema|0
    immediate local reactions|0
    same dose repeated|0
    increasing dose twofold|0
    cumulative dose 7.231111 U|0
    injection sites presented local wheal and flare reaction|6
    extensive induration|12
    extensive erythema|12
    premedication with Desloratidine|24
    premedication with Montelukast|24
    changed site of administration|24
    maintenance daily dose 8 UI reached|96
    tolerating insulin glulisine injections|720
    palmar eczema|720
    emollient cream|720
    re-epithelization creams|720
    insulin glulisine not controlling blood glucose|720
    desensitization to insulin glargine initiated|720
    initial dose higher|720
    introduced 12 units insulin glargine|720
    skin testing negative|720
    type-I hypersensitivity reaction suspected|0
    oral hypoglycemic agents|0
    glucagon-like peptide 1 analogs|0
    antihistamines|0
    switching to different insulin preparation|0
    desensitization|0
    daily administration|0
    no shortness of breath|0
    denies chest pain|0
    <|eot_id|>
    