59 years old | 0
    Japanese | 0
    woman | 0
    weight gain | -220800
    age 38 years | -183960
    overeating | -220800
    mental stress | -220800
    retired from work | -96240
    age 48 years | -96240
    disc herniation | -96240
    decreased physical activity | -96240
    weight reached 153 kg | -87600
    height 156.2 cm | -87600
    BMI 62.7 kg/m2 | -87600
    hormonal examinations | -87600
    no endocrinological diseases | -87600
    no Cushing’s disease | -87600
    no hypothyroidism | -87600
    HbA1c 8.8% | -87600
    admitted to the hospital | -87600
    dietary intake 1200 kcal per day | -87600
    weight reduced to 131.2 kg | -87600
    BMI 53.9 kg/m2 | -87600
    HbA1c decreased to 6.5% | -87600
    discharged | -87600
    regained weight to 163.0 kg | -87600
    BMI 66.8 kg/m2 | -87600
    HbA1c increased to 9.3% | -87600
    repeatedly gained and lost weight | -87600
    weight management support | -35040
    age 55 years | -35040
    weight 144.1 kg | -35040
    BMI 59.1 kg/m2 | -35040
    insulin injection 36 units | -35040
    poor glycemic control | -35040
    HbA1c 10.5% | -35040
    weight reduced to 121 kg | -35040
    BMI 49.6 kg/m2 | -35040
    insulin decreased to 28 units | -35040
    weight 114 kg | -35040
    BMI 46.7 kg/m2 | -35040
    HbA1c 6.6% | -35040
    no medication | -35040
    no insulin injections | -35040
    previous weight management strategies | 0
    mazindol | 0
    very low calorie diet 800 kcal/day | 0
    counseling by psychotherapist | 0
    exercise therapy | 0
    restricted to upper body | 0
    knee pain | 0
    weight-induced osteoarthritis | 0
    effective during hospital admission | 0
    no long-term weight loss after discharge | 0
    gastric surgery considered | 0
    no gastric surgery | 0
    inability to cover medical expense | 0
    renal dysfunction | 0
    eGFR 21.8 mL/(min·1.73 m2) | 0
    weight reduction to 112.1 kg | 0
    BMI 45.9 kg/m2 | 0
    regained weight to 133.8 kg | 0
    BMI 54.8 kg/m2 | 0
    HbA1c 8.2% | 0
    exenatide therapy commenced | 0
    exenatide 5 μg injected twice a day | 0
    within 60 min before morning and evening meals | 0
    goals: glycemic control | 0
    goals: weight loss | 0
    weight 96.3 kg | 8760
    BMI 39.5 kg/m2 | 8760
    glucose metabolism assessed | 0
    continuous glucose monitoring system | -17520
    CGMS | -17520
    serum insulin measured | -17520
    plasma glucagon measured | -17520
    blood samples drawn at 0,30,60,120,180 min after breakfast | -17520
    after 14-h overnight fast | -17520
    incretin markers assessed | 0
    baseline active GLP-1 levels | 0
    baseline total GIP levels | 0
    measured at 5 time points after breakfast | 0
    washout period 5 days without exenatide | 8760
    active GLP-1 measured | 8760
    total GIP measured | 8760
    same 5 time points after breakfast | 8760
    blood samples collected into BD™ P800 tubes | 8760
    total caloric intake 1600 kcal per day | 0
    breakfast 365–410 kcal | 0
    resting metabolic rate measured | 0
    FitMate metabolic system | 0
    HOMA-IR | 0
    HOMA-β | 0
    QUICKI | 0
    informed consent obtained | 0
    mild gastrointestinal symptoms | 0
    nausea | 0
    appetite loss | 0
    not serious adverse effects | 0
    no cessation of exenatide therapy | 0
    body weight changes | 0
    BMI changes | 0
    HbA1c changes | 0
    RMR changes | 0
    HOMA-IR changes | 0
    HOMA-β changes | 0
    QUICKI changes | 0
    weight loss | 0
    RMI reduced | 0
    HOMA-IR reduced | 0
    QUICKI increased | 0
    HOMA-β decreased after weight gain | 0
    HOMA-β no change after weight loss | 8760
    glucose fluctuations attenuated | 0
    average CGM glucose 119.7 ± 7 mg/dL | -17520
    average CGM glucose 197 ± 16 mg/dL | 0
    average CGM glucose 117 ± 7 mg/dL | 8760
    time-dependent changes in serum insulin | 0
    plasma glucagon | 0
    active GLP-1 | 0
    total GIP | 0
    insulin levels lower in March 2011 and August 2013 | 0
    insulin AUC values lower in March 2011 and August 2013 | 0
    glucagon levels lower in August 2013 | 8760
    glucagon AUC values lower in August 2013 | 8760
    active GLP-1 levels decreased in August 2013 | 8760
    total GIP levels decreased in August 2013 | 8760
    improvement in glycemic control | 0
    related to weight loss | 0
    related to exenatide therapy | 0
    exenatide ceased for 5 days before assessment | 8760
    weight loss primary reason for changes | 8760
    post-prandial insulin levels related to weight | 0
    insulin resistance decreased | 0
    hyperinsulinemia ameliorated | 0
    glucagon levels decreased after exenatide therapy | 8760
    GLP-1 suppressor of glucagon secretion | 0
    decreased glucose levels | 0
    increased glucagon secretion | 0
    decrease in glucagon secretion | 8760
    GLP-1 secretion impaired in obesity | 0
    circulating GLP-1 levels reduced in obese | 0
    GLP-1 response negatively correlated with BMI | 0
    weight loss associated with increased GLP-1 response | 0
    GLP-1 levels reduced after exenatide treatment | 8760
    due to decreased glucose levels | 8760
    exenatide effect on gastric emptying | 0
    inhibitory feedback for GLP-1 secretion | 0
    total GIP levels decreased after exenatide | 8760
    unclear reason | 0
    reduction in glucose levels | 0
    islet β cell failure | 0
    weight loss improves β cell function | 0
    insulin resistance reduced | 0
    β cell failure progressive | 0
    not recoverable | 0
    hyperglycemia established | 0
    poorly functioning β cells | 0
    de-differentiated β cells | 0
    loss of β cell mass | 0
    apoptosis | 0
    exenatide maintains β cell mass and function | 0
    increases expression of key β cell genes | 0
    stimulates islet cell proliferation | 0
    stimulates islet cell neogenesis | 0
    inhibits islet cell apoptosis | 0
    human β cells less responsive to GLP-1 | 0
    β cell replication diminished in older subjects | 0
    HOMA-β no recovery after exenatide and weight loss | 8760
    ability to secrete insulin not recovered | 8760
    hormones modulating appetite not measured | 0
    peptide YY3–36 | 0
    leptin | 0
    resistin | 0
    ghrelin | 0
    may contribute to weight loss | 0
    exenatide treatment improved β cell function | 0
    decreased body weight | 0
    similar improvements in glycemic control | 0
    beneficial effects not sustained after cessation | 0
    ongoing treatment necessary | 0
    appetite recovered after ceasing exenatide | 8760
    regained 3 kg within 2 months | 14640
    liraglutide led to weight loss | 0
    in overweight or obese | 0
    with or without type 2 diabetes | 0
    liraglutide 3.0 mg per day | 0
    combined with lifestyle modification | 0
    facilitates maintenance of weight loss | 0
    alternative anti-obesity drug | 0
    once-weekly exenatide | 0
    better glycemic control | 0
    sustained weight loss | 0
    alternative option | 0
    exenatide effective for reducing body weight | 8760
    improved glycemic control | 8760
    insulin sensitivity recovered | 8760
    ability to secrete insulin not recovered | 8760
    decreased glucagon | 8760
    decreased active GLP-1 | 8760
    decreased total GIP | 8760
    exenatide affects hormonal reactions | 8760
    informed consent obtained | 0
    compliance with ethics | 0
    open access | 0
    