6-year-old|0
    girl|0
    presented to endocrinology clinic|0
    concerns of abnormal blood glucose values|0
    prematurity|0
    born at 32 weeks' gestational age|0
    gastroschisis|0
    jejunal atresia|0
    small bowel resection|0
    resultant short gut syndrome|0
    liver transplantation at 1 year of age|0
    small bowel transplantation at 1 year of age|0
    pancreas transplantation at 1 year of age|0
    liver failure|0
    total parental nutrition for most of her life|0
    transitioned to gastric feeds through gastrostomy tube at ~5 years of age|0
    celiac disease diagnosed|0
    loose stools with bolus feeds via gastrostomy tube|0
    gluten-free diet|0
    random blood glucose 10.6 mmol/L|0
    hemoglobin A1c 5.8%|0
    endocrine referral|0
    random blood glucose 7.2 mmol/L|0
    insulin level 129.7 µIU/mL|0
    hyperinsulinism|0
    no signs or symptoms concerning for diabetes mellitus|0
    oral glucose tolerance test with 30-mg glucose load (1.75 mg/kg)|0
    fasting blood glucose 3.9 mmol/L|0
    fasting insulin 6.5 µIU/mL|0
    120-minute blood glucose 2.8 mmol/L|0
    120-minute insulin 5.9 µIU/mL|0
    ileostomy bag fully filled twice with loose stools during first 30 minutes after glucose load|0
    gastric emptying study demonstrated 92% gastric content emptied within 1 hour|0
    surgical gastroenteric anastomosis bypassing duodenum|0
    duodenum tortuous with two anastomotic strictures|0
    inability to pass manometry|0
    oral contrast passed preferentially through gastrojejunostomy|0
    feeding tube passed preferentially through gastrojejunostomy|0
    feeds changed to 40% carbohydrates, 40% fat, 20% protein with 2 g fiber|0
    cornstarch added every 6 hours|0
    loperamide started|0
    continued episodes of postprandial hypoglycemia as low as 2.0 mmol/L|0
    symptoms of headaches|0
    symptoms of irritability|0
    symptoms of tremors|0
    symptoms relieved by eating|0
    eating every 2 hours|0
    blood glucose levels decreased if fasted longer|0
    definitive surgical repair recommended|0
    staged duodenal dilatations recommended|0
    failure of first-line therapy for dumping syndrome|0
    persistence of symptomatic hypoglycemia|0
    adding diazoxide to treatment plan discussed|0
    parents gave informed consent|0
    diazoxide started orally at 3 mg/kg/d|0
    diazoxide increased to 5 mg/kg/d divided every 8 hours after 1 month|24
    2-hour postprandial blood glucose levels improved to 3.6 to 5.0 mmol/L|24
    episodes of substantial hypoglycemia resolved|24
    continued diazoxide therapy for total of 3 months|720
    duodenal dilatations ongoing|720
    no hypertrichosis|720
    no fluid retention|720
    no other adverse effects of diazoxide|720
    symptoms of dumping almost resolved at completion of duodenal dilatations|720
    diazoxide slowly weaned|720
    blood glucose levels remained in normal range|720
    dumping syndrome-associated hypoglycemia|0
    postprandial hyperinsulinemic hypoglycemia|0
    postprandial hypoglycemia|0
    hyperglycemia|0
    no shortness of breath|0
    denies chest pain|0
    <|eot_id|>