72 years old | 0
    male | 0
    obese | 0
    body mass index: 34.2 kg/m2 | 0
    type 2 diabetes | 0
    poor glucose control | 0
    HbA1c: 10.8% | 0
    overt proteinuria | 0
    diabetes duration over 20 years | 0
    referred to us | 0
    basal insulin | 0
    dipeptidyl peptidase 4 inhibitor | 0
    glucose control improved | 0
    HbA1c below 7% | 0
    hypertension | 0
    dyslipidemia | 0
    beta-blocker | 0
    carvedilol (5 mg/day) | 0
    ARB | 0
    azilsartan (40 mg/day) | 0
    Ca2+ channel blocker | 0
    nifedipine (40 mg/day) | 0
    alpha-blocker | 0
    doxazosin (8 mg/day) | 0
    rosuvastatin (2.5 mg/day) | 0
    serum creatinine increased to 1.25 mg/dL | 0
    empagliflozin (25 mg/day) started | 0
    elevation in serum creatinine | 0
    overt proteinuria continued | 0
    liraglutide started | 0
    serum creatinine levels decreased | 0
    serum creatinine levels stable | 0
    renal function deteriorated | 0
    serum BUN increased to 40 mg/dL | 0
    serum creatinine increased to 2.43 mg/dL | 0
    eGFR decreased to 22 mL/min/1.73 m2 | 0
    blood gas analysis showed blood pH 7.33 | 0
    metabolic acidosis | 0
    uremia | 0
    sodium bicarbonate started | 0
    spherical carbonaceous adsorbent started | 0
    finerenone started | 0
    hyperuricemia | 0
    serum uric acid (UA) 7.9 mg/dL | 0
    dotinurad started | 0
    BUN decreased | 0
    eGFR increased | 0
    dose-up of finerenone | 0
    dose-up of dotinurad | 0
    UA decreased | 0
    urinary albumin/creatinine ratio decreased | 0
    dose-up of liraglutide | 0
    improvement of CKD stage G4 | 0