67 years old | 0
    Hispanic | 0
    male | 0
    referred by optometrist for evaluation of bilateral RPE detachments | 0
    diabetes mellitus | 0
    insulin | 0
    metformin | 0
    dulaglutide | 0
    chronic interstitial cystitis | 0
    symptoms of interstitial cystitis | 0
    pentosan polysulfate sodium | -227760
    best-corrected visual acuity 20/32 in both eyes | 0
    intraocular pressure 18 mmHg right eye | 0
    intraocular pressure 20 mmHg left eye | 0
    nuclear sclerosis both lenses | 0
    yellow deposits in macula both eyes | 0
    retinal pigment epithelium mottling of the macula both eyes | 0
    fundus pseudocolor imaging highlighted yellow deposits in central macula bilaterally | 0
    fundus autofluorescence central macula hyper-autofluorescence with surrounding spots of hypo-autofluorescence | 0
    near-infrared reflectivity imaging heterogenous reflectance | 0
    macular SD-OCT subretinal vitelliform lesions bilaterally | 0
    intact external limiting membrane | 0
    intact ellipsoid zone | 0
    hyperreflective elevations at level of RPE in parafoveal region | 0
    Bruch's membrane not clear subfoveally | 0
    RPE reflectivity not clear subfoveally | 0
    RPE thickening parafoveally | 0
    hyperreflective nodular elevations parafoveally | 0
    advised to discontinue pentosan polysulfate sodium | 0
    referred to Inherited Retinal Disease clinic | 0
    comprehensive ophthalmologic examination | 24
    best-corrected visual acuity 20/50 in both eyes | 24
    SD-OCT small decrease in peak height of subfoveal deposits | 24
    subfoveal deposits decreased by 38 μm right eye | 24
    subfoveal deposits decreased by 28 μm left eye | 24
    multifocal electroretinogram | 168
    full-field electroretinogram | 168
    microperimetry | 168
    exome IRD testing | 168
    multifocal electroretinogram ring responses slightly reduced in ring 1 right eye | 168
    multifocal electroretinogram within normal limits poor waveform morphology ring 1 left eye | 168
    full-field electroretinogram responses within normal limits cone-dominated responses | 168
    full-field electroretinogram responses within normal limits rod-dominated responses | 168
    genetic testing sequence analysis | 168
    genetic testing deletion/duplication testing | 168
    genetic testing no variants associated with genetic disorder | 168
    comprehensive ophthalmologic examination | 720
    best-corrected visual acuity 20/60 right eye | 720
    best-corrected visual acuity 20/125 left eye | 720
    microperimetry reduced sensitivity at fovea both eyes | 720
    eccentric fixation | 720
    fundus autofluorescence more mottled appearance | 720
    hyper-autofluorescence at fovea | 720
    hypo-autofluorescence at fovea | 720
    SD-OCT resolution of vitelliform deposits bilaterally | 720
    nodular excrescences at level of RPE parafovea right eye | 720
    plaque-like lesion extending from Bruch's membrane-RPE complex left eye | 720
    external limiting membrane intact bilaterally | 720
    ellipsoid zone disrupted left eye | 720
    ellipsoid zone intact right eye subfoveally | 720
    <|eot_id|>
    