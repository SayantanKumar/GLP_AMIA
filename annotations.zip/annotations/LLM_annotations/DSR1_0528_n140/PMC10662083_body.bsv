29-year-old | 0
    woman | 0
    seeking medical and surgical weight loss options | 0
    unsuccessful attempts at weight loss through lifestyle modification | 0
    bigger than other children by age 8 | -175200
    progressive weight gain | -175200
    weight gain accelerated as an adult | -175200
    dyslipidemia | 0
    hypertension | 0
    obstructive sleep apnea | 0
    pre-diabetes | 0
    prescribed carvedilol | 0
    prescribed amlodipine | 0
    prescribed hydrochlorothiazide | 0
    prescribed torsemide | 0
    prescribed valsartan | 0
    prescribed atorvastatin | 0
    prescribed cholestyramine | 0
    weighed 185.3 kg | 0
    blood pressure 132/66 mmHg | 0
    excess abdominal adiposity | 0
    large dorsocervical fat pad | 0
    total cholesterol 182 mg/dL | 0
    LDL 129 mg/dL | 0
    triglyceride 189 mg/dL | 0
    A1c 5.6% | 0
    Binge Eating Severity Scale 16 | 0
    none-to-minimal binge eating behaviors | 0
    workup for secondary causes of obesity normal | 0
    started phentermine 37.5 mg daily | 0
    started topiramate 50 mg daily | 0
    topiramate increased to 50 mg twice daily | 3192
    phentermine maintained 37.5 mg daily | 3192
    lost 8 kg | 3192
    deferred surgical management | 3192
    continued medical therapy | 3192
    exercise | 3192
    dietary improvements | 3192
    trialed semaglutide | 3192
    discontinued semaglutide | 3360
    phentermine/topiramate therapy continued | 3360
    lost 67.3 kg | 9744
    BMI 43.4 | 9744
    weight loss 36.3% | 9744
    BMI reduction 24.7 kg/m2 | 9744
    hyper-responder | 9744
    down-titrate blood pressure medications | 5040
    lost 60 lbs | 5040
    discontinued CPAP | 5760
    discontinued hydrochlorothiazide | 6480
    discontinued valsartan | 8640
    discontinued amlodipine | 8640
    discontinued carvedilol | 8640
    Binge Eating Severity Scale 1 | 9744
    genetic testing | 9744
    PLXNA4 variant | 9744
    discontinued atorvastatin | 9744
    discontinued cholestyramine | 9744
    discontinue blood pressure medications | 9744
    discontinue atorvastatin | 9744
    discontinue cholestyramine | 9744
    discontinue CPAP | 9744
    high satisfaction with medical therapy | 9744
    defer bariatric surgery | 9744
    continued medical and lifestyle intervention | 9744