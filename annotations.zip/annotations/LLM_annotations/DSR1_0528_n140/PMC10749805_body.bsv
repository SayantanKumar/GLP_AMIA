70 years old | 0
    Japanese | 0
    male | 0
    admitted to the hospital | 0
    type 2 diabetes mellitus | 0
    hypertension | 0
    chronic heart failure | 0
    nephrotic syndrome | 0
    bilateral leg swelling | 0
    dermatosclerosis | 0
    height 167.5 cm | 0
    body weight 78.7 kg | 0
    body mass index 28.1 kg/m2 | 0
    blood pressure 134/90 mmHg | 0
    pulse rate 95 beats per minute | 0
    irregular pulse | 0
    atrial fibrillation | 0
    enlarged heart | 0
    cardiothoracic ratio 57% | 0
    right pleural effusion | 0
    serum BNP 390.7 pg/mL | 0
    serum creatinine 0.78 mg/dL | 0
    eGFR 75.2 mL/min/1.73 m2 | 0
    24-hour urine protein 3.8 g | 0
    serum albumin 3.0 g/dL | 0
    diabetic nephropathy | 0
    fasting plasma glucose 141 mg/dL | 0
    hemoglobin A1c 7.8% | 0
    white blood cells 5,100 /µL | 0
    red blood cells 3.4 ×106/µL | 0
    hemoglobin 11.6 g/dL | 0
    platelets 18.0 ×104/µL | 0
    total protein 6.4 g/dL | 0
    albumin 3.0 g/dL | 0
    total bilirubin 0.6 mg/dL | 0
    AST 20 U/L | 0
    ALT 13 U/L | 0
    BUN 16 mg/dL | 0
    creatinine 0.78 mg/dL | 0
    eGFR 75.2 mL/min/1.73 m2 | 0
    uric acid 5.1 mg/dL | 0
    sodium 142 mEq/L | 0
    potassium 4.0 mEq/L | 0
    chloride 105 mEq/L | 0
    calcium 8.6 mg/dL | 0
    LDL-C 80 mg/dL | 0
    HDL-C 55 mg/dL | 0
    triglyceride 105 mg/dL | 0
    BNP 390.7 pg/mL | 0
    glucose 141 mg/dL | 0
    hemoglobin A1c 7.8% | 0
    urinary C-peptide 49 µg/day | 0
    anti-GAD antibody <5.0 U/mL | 0
    urinary pH 7.5 | 0
    urinary protein 2+ | 0
    urinary glucose 4+ | 0
    urinary ketone body negative | 0
    urinary protein 3.8 g/day | 0
    started 1,800-kcal diet | 0
    salt restriction NaCl 6 g/day | 0
    leg swelling improved | 0
    blood pressure improved | 0
    antihypertensive medications reduced | 0
    nifedipine CR 60 mg/day | 0
    azilsartan 40 mg/day | 0
    sacubitril/valsartan 200 mg/day | 216
    blood pressure dropped 86/59 mmHg | 528
    sacubitril/valsartan reduced to 100 mg/day | 480
    sacubitril/valsartan changed to azilsartan 20 mg/day | 576
    azilsartan changed to olmesartan 20 mg/day | 696
    BNP decreased 390.7 pg/mL to 151.2 pg/mL | 384
    BNP decreased to 128.1 pg/mL | 840
    eGFR decreased | 0
    urine protein decreased | 0
    urine volume decreased | 0
    glimepiride 1 mg/day | 0
    dapagliflozin 5 mg/day | 0
    multiple insulin injection therapy | 96
    glimepiride discontinued | 96
    dapagliflozin increased to 10 mg/day | 120
    oral semaglutide 3 mg/day | 336
    insulin requirement maximum 51 units/day | 432
    mitiglinide 30 mg/day | 504
    voglibose 0.9 mg/day | 528
    insulin decreased to 22 units/day | 0
    urinary C-peptide increased to 307 µg/day | 312
    urinary C-peptide decreased to 99 µg/day | 840
    blood glucose normalized | 0
    insulin requirement decreased 51 to 22 units/day | 0
    glucose toxicity attenuated | 0
    insulin secretion capacity restored | 0
    insulin resistance mitigated | 0
    mitiglinide started | 504
    serum C-peptide 2.03 ng/mL | 48
    serum C-peptide 2.71 ng/mL | 384
    serum C-peptide 3.16 ng/mL | 648
    sacubitril/valsartan discontinued | 576
    bilateral leg swelling started | -2160
    diagnosed with type 2 diabetes mellitus | -175200
    started oral hypoglycemic agents | -175200
    diagnosed with hypertension | 0
    diagnosed with chronic heart failure | 0
    diagnosed with nephrotic syndrome | 0
    diagnosed with diabetic nephropathy | 0
    admitted for treatment of type 2 diabetes mellitus | 0
    admitted for treatment of bilateral leg swelling | 0
    became aware of bilateral leg swelling | -2160
    presented with dermatosclerosis | 0
    diet therapy and salt restriction started | 0
    leg swelling improved | 0
    antihypertensive medications changed | 216
    sacubitril/valsartan started | 216
    sacubitril/valsartan dose reduced | 480
    sacubitril/valsartan discontinued | 576
    antihypertensive medications changed to azilsartan | 576
    antihypertensive medications changed to olmesartan | 696
    insulin therapy started | 96
    glimepiride discontinued | 96
    dapagliflozin dose increased | 120
    semaglutide added | 336
    mitiglinide added | 504
    voglibose added | 528
    insulin requirement decreased | 0
    discharged | 840
    urinary C-peptide increased | 312
    urinary C-peptide decreased | 840
    serum C-peptide measured | 48
    serum C-peptide measured | 384
    serum C-peptide measured | 648
    no shortness of breath | 0
    denies chest pain | 0
    retrospective study conducted | 0
    institutional review board approval | 0
    five patients with type 2 diabetes mellitus | 0
    sacubitril/valsartan administered | 0
    urinary C-peptide levels increased | 0
    serum C-peptide levels not elevated | 0
    no conflict of interest | 0
    