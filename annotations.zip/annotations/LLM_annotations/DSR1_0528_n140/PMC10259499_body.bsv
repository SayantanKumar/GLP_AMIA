50 years old | 0
    female | 0
    referred to department | 0
    deranged liver enzyme levels | 0
    type 2 diabetes | -168
    high blood pressure | -168
    hypertension | -168
    obesity | -168
    BMI 39.2 | -168
    metformin 1 g daily | -168
    gliclazide 120 mg daily | -168
    amlodipine 10 mg daily | -168
    general physical examination unremarkable | 0
    no palmar erythema | 0
    no vascular spiders | 0
    palpable liver | 0
    mild splenomegaly | 0
    elevated ALT | 0
    elevated AST | 0
    elevated GGT | 0
    abnormal lipid profile | 0
    high triglycerides | 0
    FIB-4 index elevated | 0
    hepatitis B surface antigen negative | 0
    anti-hepatitis C virus antibodies negative | 0
    autoantibodies negative | 0
    abdominal ultrasound | 0
    bright hepatomegaly | 0
    mild splenomegaly | 0
    portal vein 14 mm | 0
    no ascites | 0
    NASH | 0
    weight reduction | 0
    dyslipidaemia control | 0
    liraglutide 0.6 mg daily | 0
    liraglutide 3 mg daily | 0
    simvastatin 20 mg daily | 0
    silymarin 140 mg three-times daily | 0
    decrease in ALT | 2880
    decrease in AST | 2880
    normalization of liver enzyme levels | 5040
    reduction in GGT | 5040
    improvement in lipid profile | 5040
    reduced triglycerides | 5040
    treatment adherence good | 5040
    no adverse events | 5040
    no drug interactions | 5040
    discharged | 5040
    <|eot_id|>
    