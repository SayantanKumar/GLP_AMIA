57 years old | 0
    Caucasian | 0
    female | 0
    incidentally found bilateral adrenal enlargement | 0
    abdominal imaging | 0
    elevated liver enzymes | 0
    type 2 diabetes mellitus | -87600
    glycemic control progressively worsened | 0
    metformin | -87600
    insulin glargine | -87600
    significant weight gain | 0
    without overt cushingoid features | 0
    incidental adrenal adenomas | 0
    elevated 8:00 h cortisol | 0
    non-suppressible cortisol after 1 mg dexamethasone | 0
    low DHEAS | 0
    low ACTH | 0
    autonomous production of cortisol | 0
    24-h urinary free cortisol normal | 0
    midnight salivary cortisol normal | 0
    adrenal venous sampling | 0
    elevated bilateral cortisol production | 0
    left adrenal vein cortisol significantly higher | 0
    biochemical features without overt Cushing’s syndrome | 0
    AIMAH | 0
    subclinical Cushing’s syndrome | 0
    left adrenalectomy | 0
    nodule on left side 4 cm | 0
    few weeks after surgery | 168
    insulin requirement decreased | 168
    HbA1C decreased from 8.2 to 6.3% | 168
    serum cortisol normalized | 168
    DHEAS normalized | 168
    ACTH normalized | 168
    few months after surgery | 720
    weight gain | 720
    rise in HbA1C | 720
    non-suppressible cortisol after low-dose dexamethasone | 720
    mifepristone started at 300 mg | 720
    escalated to 600 mg daily | 744
    escalated to 900 mg daily | 816
    noncompliance with scheduled follow-up | 816
    few weeks later | 960
    intensive care unit admission | 960
    severe refractory hypokalemia | 960
    fluid overload | 960
    mifepristone toxicity | 960
    improved in a few days | 984
    discontinuation of mifepristone | 984
    diuresis | 984
    dexamethasone | 984
    laboratory results | 960
    WBC 9.0 | 960
    hemoglobin 11.9 | 960
    hematocrit 35.3 | 960
    platelets 161 | 960
    sodium 142 | 960
    potassium 2.6 | 960
    chloride 97 | 960
    bicarbonate 30 | 960
    blood urea nitrogen 9 | 960
    creatinine 0.75 | 960
    blood glucose 153 | 960
    calcium 9.1 | 960
    magnesium 1.3 | 960
    phosphorus 2.1 | 960
    cortisol 190.4 | 960
    TSH 8.62 | 960
    free T4 0.89 | 960
    creatine kinase 224 | 960
    CKMB 1.6 | 960
    troponin <0.030 | 960
    pro-BNP 2067 | 960
    chest x-ray | 960
    question of flash pulmonary edema | 960
    multifocal pneumonia | 960
    trace effusions bilaterally | 960
    chest CT | 960
    no pulmonary embolism | 960
    bilateral predominantly perihilar airspace disease | 960
    infectious/inflammatory process | 960
    cardiogenic pulmonary edema | 960
    congestive heart failure | 960
    symmetrical perihilar distribution | 960
    small bilateral pleural effusions | 960
    echocardiogram | 960
    ejection fraction 60-65% | 960
    mild concentric left ventricular hypertrophy | 960
    transmitral spectral Doppler flow pattern normal | 960
    transmitral E velocity normal | 960
    Doppler E/e’ ratio normal | 960
    left ventricle filling pressures normal | 960
    left ventricular wall motion normal | 960
    cardiac catheterization | 960
    no angiographically evident coronary artery disease | 960
    mifepristone held | 960
    dexamethasone started | 960
    potassium repleted | 960
    symptoms managed with IV diuresis | 960
    volume overload managed with IV diuresis | 960
    volume overload | 960
    hypokalemia | 960
    metabolic alkalosis | 960
    elevated thyrotropin levels | 960
    mifepristone held at discharge | 984
    followed up as outpatient | 1008
    mifepristone discontinued | 1008
    potassium level normal | 1008
    managed for diabetes with dulaglutide | 1008
    managed for diabetes with insulin degludec | 1008
    managed for diabetes with metformin | 1008
    monitored with periodic follow-up visits | 1008
    look for specific signs of Cushing’s syndrome | 1008
    discharge | 984
    <|eot_id|>
    