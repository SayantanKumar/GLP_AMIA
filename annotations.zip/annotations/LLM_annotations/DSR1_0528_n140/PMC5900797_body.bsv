22 years old | 0
    woman | 0
    history of type 2 diabetes mellitus | 0
    panhypopituitarism | 0
    partial resection of craniopharyngioma | 0
    admitted to emergency department | 0
    progressive leg pain | -168
    muscle weakness | -168
    polyuria | -168
    common cold | -168
    medication: hydrocortisone | 0
    thyroxine | 0
    oestradiol/norgestrel | 0
    growth hormone | 0
    nasal desmopressin | 0
    liraglutide | 0
    previous episodes of hyperosmolarity | 0
    decreased feeling of thirst | 0
    malcompliance with desmopressin regimen | 0
    physical examination unremarkable | 0
    normal motor function | 0
    normal level of consciousness | 0
    afebrile | 0
    temperature 36.6°C | 0
    bodyweight 97 kg | 0
    BMI 35 kg/m2 | 0
    blood pressure 105/69 mmHg | 0
    heart rate 79 bpm | 0
    oxygen saturation 98% | 0
    urine output 3880 mL | 24
    serum sodium 161 mmol/L | 0
    hypokalaemia 3.2 mmol/L | 0
    hyperglycaemia 35.4 mmol/L | 0
    serum osmolality 387 mosmol/kg | 0
    free water deficit 8.8 L | 0
    hyperchloraemic metabolic acidosis | 0
    normal anion gap | 0
    haemoglobin 145 g/L | 0
    leukocytes 4.2 × 10^9/L | 0
    platelets 159 × 10^9/L | 0
    haematocrit 0.43 | 0
    INR 1.0 | 0
    chloride 132 mmol/L | 0
    calcium 2.66 mmol/L | 0
    urea nitrogen 6.2 mmol/L | 0
    creatinine 80 µmol/L | 0
    ALT 77 U/L | 0
    LDH 393 U/L | 0
    alkaline phosphatase 140 U/L | 0
    creatine kinase 70 U/L | 0
    CRP 6 mg/L | 0
    HbA1c 8.7% | 0
    venous pH 7.269 | 0
    pCO2 7.35 kPa | 0
    pO2 4.68 kPa | 0
    bicarbonate 25.3 mmol/L | 0
    lactate 1.3 mmol/L | 0
    initial diagnosis HHS | 0
    treatment with IV volume repletion | 0
    D5W 1000 mL | 0
    0.45% saline 1000 mL | 0
    balanced crystalloid 3000 mL | 0
    IV hydrocortisone 200 mg/day | 0
    potassium supplementation | 0
    subcutaneous insulin 14 IU | 0
    nasal desmopressin continued | 0
    BGL decreased to 27.0 mmol/L | 10
    serum sodium increased to 169 mmol/L | 10
    polyuria persisted | 10
    transferred to ICU | 10
    BGL 26.0 mmol/L | 10
    serum sodium 165 mmol/L | 10
    further fluid replacement | 10
    IV insulin infusion increased | 10
    BGL decreased to 14.5 mmol/L | 20
    hypernatraemia persisted | 20
    polyuria persisted | 20
    urine osmolality 773 mosmol/kg | 20
    urine-specific gravity 1.011 | 20
    suspected concurrent CDI | 20
    IV desmopressin 2 μg administered | 20
    serum sodium normalized | 30
    urine output decreased to 650 mL/24h | 30
    hydrocortisone tapered | 30
    BGL normal | 72
    electrolytes normal | 72
    acid-base status normal | 72
    muscle weakness disappeared | 72
    leg pain disappeared | 72
    discharged | 168
    