63 years old | 0
    male | 0
    presented to the emergency department | 0
    progressive ascending weakness of the upper and lower extremities | 0
    hypertension | 0
    dyslipidemia | 0
    insulin-dependent diabetes mellitus | 0
    nephrolithiasis | 0
    obesity | 0
    anxiety | 0
    Guillain–Barré syndrome after vaccination against influenza | -168
    insulin glargine | 0
    metformin | 0
    semaglutide | 0
    gliclazide | 0
    amlodipine | 0
    valsartan | 0
    atorvastatin | 0
    potassium citrate | 0
    received vaccine against seasonal influenza | -672
    acute facial paralysis | -672
    ascending upper and lower extremity weakness | -672
    paresthesias | -672
    flaccid paralysis of all 4 extremities | -672
    generalized areflexia | -672
    computed tomography scan of head normal | -672
    lumbar puncture with elevated CSF protein | -672
    nerve conduction studies not done | -672
    Guillain–Barré syndrome diagnosed | -672
    mechanical ventilation | -672
    tracheostomy | -672
    systemic corticosteroids | -672
    intravenous immune globulin | -672
    near-complete neurologic recovery | -672
    mild residual facial palsy | -672
    received childhood vaccinations without adverse effects | -672
    no further vaccinations until SARS-CoV-2 pandemic | 0
    received first dose of ChAdOx1 nCoV-19 vaccine | -288
    mild chills | -288
    fatigue | -288
    resolved within 3 days | -264
    paresthesias of the lips and fingers | -24
    rapidly progressive ascending weakness | 0
    no preceding symptoms suggesting infection | 0
    mild weakness of both shoulder abductors | 0
    mild weakness of knee flexors | 0
    areflexia | 0
    bilateral loss of pinprick sensation | 0
    loss of vibration sensation up to mid-shin | 0
    no sensory level | 0
    loss of proprioception to ankle joint | 0
    wide gait | 0
    weakness progressed to 1/5 in ankle dorsiflexors | 24
    weakness progressed to 1/5 in extensor hallucus longus | 24
    weakness progressed to 3–4/5 in knee extensors | 24
    weakness progressed to 1–2/5 in hip flexors | 24
    weakness progressed to 4/5 in shoulder abductors | 24
    weakness progressed to 4/5 in elbow flexors | 24
    weakness progressed to 4/5 in elbow extensors | 24
    weakness progressed to 4/5 in wrist extensors | 24
    electrophysiologic studies with sensorimotor peripheral neuropathy | 24
    demyelinating features | 24
    axonal features | 24
    consistent with GBS | 24
    CSF albinocytologic dissociation | 24
    elevated CSF protein | 24
    normal white blood cell count | 24
    elevated CSF glucose | 24
    elevated CSF lactate | 24
    no evidence of infectious cause | 24
    no evidence of metabolic cause | 24
    no evidence of structural cause | 24
    CSF bacterial cultures negative | 24
    CSF nucleic acid testing negative for enterovirus | 24
    CSF nucleic acid testing negative for parechovirus | 24
    CSF nucleic acid testing negative for varicella–zoster virus | 24
    CSF nucleic acid testing negative for herpes simplex virus | 24
    serum negative for hepatitis B | 24
    serum negative for hepatitis C | 24
    serum negative for HIV | 24
    serum negative for syphilis | 24
    blood cultures sterile | 24
    thyroid function normal | 24
    adrenal function normal | 24
    electrolytes normal | 24
    computed tomography scan of head normal | 24
    small vessel ischemic disease | 24
    magnetic resonance imaging of cervical spine normal | 24
    antihuman neuronal ganglioside serology not done | 24
    treated with intravenous immune globulin | 24
    motor weakness deteriorated | 48
    vital capacity deteriorated | 48
    therapeutic plasma exchange | 48
    noninvasive mechanical ventilation | 48
    no invasive mechanical ventilation | 48
    motor function improved substantially | 2160
    persistent mild weakness in hands | 2160
    persistent mild weakness in proximal lower extremities | 2160
    persistent mild weakness in distal lower extremities | 2160
    areflexia | 2160
    abnormal light touch | 2160
    abnormal pinprick sensation | 2160
    abnormal vibration sensation | 2160
    avoid future doses of ChAdOx1 nCoV-19 vaccine | 2160