51 years old | 0
    Gulf War veteran | 0
    diabetes mellitus type II | 0
    alcohol use disorder | 0
    chronic pancreatitis | 0
    presented to the emergency department | 0
    abdominal pain | -336
    abdominal distension | -336
    nausea | -336
    intermittent chills | -336
    constant pressure | -336
    pain rated 10 out of 10 | -336
    abdomen feels about to burst | -336
    changing positions temporarily improved symptoms | -336
    eating meals made pain worse | -336
    acetaminophen did not help | -336
    quit alcohol use 9 years prior | -78840
    former smoker | 0
    denied recent travel | 0
    had 2 dogs | 0
    denied exposure to livestock | 0
    semaglutide | 0
    omeprazole | 0
    acetaminophen | 0
    last colonoscopy 4 years prior | -35040
    tachycardia | 0
    heart rate 134 beats per minute | 0
    temperature 100.4 F | 0
    blood pressure 130/96 mm Hg | 0
    oxygen saturation 100% | 0
    firm abdomen | 0
    distended abdomen | 0
    tenderness to palpation over right upper quadrant | 0
    tenderness to palpation over right lower quadrant | 0
    palpable hepatomegaly | 0
    white blood cell count 13,360 cells/mm3 | 0
    neutrophilic predominance | 0
    thrombocytosis | 0
    platelets 529 per μL | 0
    hemoglobin 8.0 g/dL | 0
    alanine aminotransferase 73 IU/L | 0
    aspartate transaminase 171 IU/L | 0
    alkaline phosphatase 625 IU/L | 0
    total bilirubin 1.9 mg/dL | 0
    direct bilirubin 1.3 mg/dL | 0
    acute kidney injury | 0
    BUN 50 mg/dL | 0
    creatinine 1.2 mg/dL | 0
    lactic acidosis | 0
    lactic acid 5.2 mmol/L | 0
    computed tomography scan of abdomen and pelvis | 0
    multiple masses throughout liver | 0
    partial splenic vein thrombosis | 0
    portal vein thrombosis | 0
    CT scan 6 months prior showed no liver pathology | -4320
    magnetic resonance imaging of abdomen | 0
    no biliary obstruction | 0
    hepatomegaly | 0
    craniocaudal liver span 26 cm | 0
    multiseptated cystic hepatic masses | 0
    largest cystic lesion 9.0 cm × 5.4 cm | 0
    started on intravenous cefepime | 0
    started on oral metronidazole | 0
    started on therapeutic IV heparin | 0
    concern for parasitic infection | 0
    concern for bacterial infection | 0
    bacterial blood cultures negative | 0
    fungal blood cultures negative | 0
    hepatitis A IgM negative | 0
    hepatitis B core antibody IgM negative | 0
    hepatitis B surface antigen negative | 0
    hepatitis C antibody negative | 0
    HIV antibody 1 and 2 negative | 0
    Entamoeba histolytica IgG negative | 0
    Echinococcus IgG antibody negative | 0
    CT-guided liver biopsy | 0
    aspiration of abscess material | 0
    H&E stain showed inflamed liver parenchyma | 0
    degenerating liver parenchyma | 0
    scant identifiable portal tracts | 0
    abundant fibrinopurulent inflammation | 0
    cultures showed no growth | 0
    antibiotics changed to IV ampicillin-sulbactam | 0
    antibiotics changed to oral trimethoprim-sulfamethoxazole | 0
    no clinical improvement | 0
    16S PCR positive for F. nucleatum | 0
    passed away due to cardiac arrest | 0
    etiology not established | 0
    pyogenic liver abscess | 0
    septic pylephlebitis | 0
    Fusobacterium nucleatum | 0
    immunocompetent | 0
    no concomitant oropharyngeal disease | 0
    no GI infection | 0
    fever | 0
    abdominal pain | 0
    chills | 0
    nausea | 0
    vomiting | 0
    headache | 0
    anorexia | 0
    weight loss | 0
    diarrhea | 0
    hypoalbuminemia | 0
    elevated CRP | 0
    elevated gamma-glutamyl transferase | 0
    elevated alkaline phosphatase | 0
    leukocytosis | 0
    elevation in liver tests | 0
    dull pain in right upper quadrant | 0
    fever | 0
    leukocytosis | 0
    ultrasonography | 0
    CT scan | 0
    fine-needle aspiration | 0
    culture | 0
    negative blood cultures | 0
    empiric broad spectrum antibiotic therapy | 0
    needle aspiration | 0
    percutaneous catheter drainage | 0
    selective antimicrobial therapy | 0
    ongoing fever | 0
    abscess size >3 cm | 0
    impending perforation | 0
    abscess rupture | 0
    incomplete percutaneous drainage | 0
    inadequate clinical improvement | 0
    multiloculated abscesses | 0
    parenteral antibiotics | 0
    oral antibiotics | 0
    metronidazole | 0
    ampicillin-sulbactam | 0
    cephalosporins | 0
    carbapenems | 0
    clindamycin | 0
    IV ampicillin-sulbactam | 0
    oral trimethoprim-sulfamethoxazole | 0
    therapeutic IV heparin | 0
    Lemierre syndrome | 0
    portal vein thrombosis | 0
    splenic vein thrombosis | 0
    anticoagulation | 0
    antibiotics | 0
    chronic portal hypertensive symptoms | 0
    resolution of PVT | 0
    death | 0
    cardiac arrest | 0
    <|eot_id|>
    