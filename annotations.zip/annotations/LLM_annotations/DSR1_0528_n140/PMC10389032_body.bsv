58 years old | 0
    female | 0
    referred to hospital | 0
    diabetes | -103248
    semaglutide 0.25 mg sc | -26280
    painful diabetic polyneuropathy | -26280
    tingling | -26280
    numbness | -26280
    burning pain | -26280
    hypoesthesia | -26280
    allodynia | -26280
    severe sharp pain | -26280
    no motor deficits | 0
    no abnormal deep tendon reflexes | 0
    no dysvitaminosis | 0
    no autoimmune disorders | 0
    no rheumatological disorders | 0
    failed conservative therapeutic options | 0
    failed medications of first and second line | 0
    all-in-one SCS implantation | 0
    preoperative MRI | -48
    lower-limb somatosensory evoked potentials | -48
    EMG | -48
    ENG | -48
    reduction of sensory conduction velocity of sural nerve | -48
    HRUS of peripheral nerve CSA | -48
    C7 CSA 0.10 cm2 | -48
    C6 CSA 0.095 cm2 | -48
    ulnar nerve CSA 0.063 cm2 | -48
    median nerve CSA 0.089 cm2 | -48
    superficial radial nerve CSA 0.023 cm2 | -48
    external popliteal nerve CSA left 0.36 cm2 | -48
    external popliteal nerve CSA right 0.38 cm2 | -48
    posterior tibial nerve CSA left 0.19 cm2 | -48
    posterior tibial nerve CSA right 0.19 cm2 | -48
    sural nerve CSA left 0.06 cm2 | -48
    sural nerve CSA right 0.06 cm2 | -48
    NRS 9 | 0
    DN4 7 | 0
    SF36 | 0
    BPI | 0
    PIS | 0
    SCS implantation | 0
    octopolar lead | 0
    FAST stimulation | 0
    frequency 90 Hz | 0
    pulse width 210 ms | 0
    discharged | 48
    NRS 1 | 48
    no complications | 48
    pain relief | 0
    pain relief at 3 months | 2160
    NRS 1 | 720
    BPI improvement | 720
    PIS decreased to 0 | 720
    DN4 0 | 720
    discontinued antalgic pharmacological therapy | 720
    SF36 improvement | 720
    physical component summary increased | 720
    mental component summary increased | 720
    HRUS at 1 month | 720
    reduction of CSA in nerves | 720
    HRUS at 2 months | 1440
    further reduction of CSA | 1440
    ENG at 1 month | 720
    increased sural nerves SCV | 720
    left sural nerve SCV 58.3 m/s | 720
    right sural nerve SCV 64.3 m/s | 720
    pain relief stable at 3 months | 2160
    no changes in stimulation settings | 2160
    <|eot_id|>
    