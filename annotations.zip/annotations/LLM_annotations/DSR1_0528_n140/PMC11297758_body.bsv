50s | 0
    white | 0
    British | 0
    male | 0
    implanted cardiac defibrillator (ICD) | -17520
    congenital heart disease | -17520
    pulmonary stenosis | -17520
    Ventricular Fibrillation (VF) arrest | -17520
    pulmonary valve replacement | -17520
    ICD Implantation | -17520
    Atrial Fibrillation | -17520
    Type 2 Diabetes Mellitus | -17520
    Hypercholesterolemia | -17520
    Gout | -17520
    Amiodarone | -17520
    Apixaban | -17520
    Bisoprolol | -17520
    Lisinopril | -17520
    Furosemide | -17520
    Allopurinol | -17520
    Canagliflozin | -17520
    Lansoprazole | -17520
    Liraglutide | -17520
    Metformin | -17520
    Atorvastatin | -17520
    obstructive sleep apnoea | -17520
    CPAP | -17520
    heart rate dropped | 0
    asystole | 0
    found deceased | 3
    ICD became more active | 0
    device delivering multiple shocks | 0
    Right ventricular intrinsic amplitude out of range | 0
    falling night heart rate | -4320
    deteriorating bradycardia | -4320
    remote clinic appointment | 48
    last device check | -2880
    good battery life | -2880
    stable lead parameters | -2880
    no arrhythmias | -2880
    autopsy | 72
    ICD extracted | 72
    leads pulled out | 72
    scarring | 72
    pathological changes | 72
    ICD not evaluated | 72
    historic transmitted data not interrogated | 72
    cloud-based data not evaluated | 72
    device treated as medical waste | 72
    CPAP mask not collected | 72
    no forensic hardware evaluation | 72
    no software evaluation | 72
    cause of death assigned to underlying heart failure | 72