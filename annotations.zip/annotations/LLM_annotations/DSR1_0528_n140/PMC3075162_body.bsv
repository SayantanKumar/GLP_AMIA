46 years old| 0
    Asian-Indian | 0
    male | 0
    no history of alcohol consumption | 0
    tropical chronic pancreatitis | -87600
    oral pancreatic enzyme therapy | -87600
    exocrine pancreatic insufficiency | -87600
    non-insulin-dependent diabetes mellitus | -78840
    glucotrol (glipizide) 5 mg daily | -78840
    steady midepigastric pain | -6
    pain dull in nature | -6
    pain radiating through back | -6
    pain exacerbated by food intake | -6
    recurrent pain since tropical pancreatitis diagnosis | -6
    pain lasted between 1 and 3 days | -6
    remained completely well in interval phase | -6
    hospitalized for pain control with narcotics | -6
    discharged | -48
    continuing epigastric pain | 0
    pain gradually increased in intensity | 0
    nausea | 0
    vomiting | 0
    no documented fever | 0
    CT scan | 0
    fatty atrophy of pancreatic head | 0
    fatty atrophy of uncinate process | 0
    pancreatic duct filled with large calcifications | 0
    obstruction at level of neck | 0
    marked upstream ductal dilatation 1.5 cm | 0
    admitted for management of pain secondary to chronic pancreatitis | 0
    similar pain | -1440
    fever | -1440
    CT scan of abdomen | -1440
    chronic atrophic calcific pancreatitis | -1440
    dilated pancreatic duct 7 mm | -1440
    intraductal calculi | -1440
    ERCP | -1440
    pancreatography | -1440
    medically managed | -1440
    discharged | -1440
    fever 102°F | 24
    chills | 24
    rigors | 24
    severe sepsis | 24
    septic shock | 24
    transferred to medical intensive care unit | 24
    intubated | 24
    hypoxemic respiratory failure | 24
    acute respiratory distress syndrome | 24
    multiorgan failure | 24
    broad-spectrum antibiotics | 24
    vasopressor support | 24
    activated recombinant human protein C | 24
    ultrasound of abdomen | 24
    markedly dilated pancreatic duct 1.9 cm | 24
    8.7 × 7.6 mm calculus within duct | 24
    pancreas diffusely echogenic | 24
    common bile duct prominent | 24
    no obvious obstructing calculi | 24
    bedside emergency ERCP | 24
    major papilla of Vater visualized spontaneously expelling frank pus | 24
    no evidence of papillitis | 24
    no evidence of tumor | 24
    no evidence of previous sphincterotomy | 24
    evacuation of more than 5 ml yellow pus | 24
    cholangiogram | 24
    normal biliary tree without stones | 24
    pancreatogram | 24
    marked dilatation main pancreatic duct | 24
    single distal calculus | 24
    guide wire introduced | 24
    approximately 20 ml pus evacuated | 24
    selective cannulation | 24
    5-cm-long 5 F stent placed | 24
    no more pus draining | 24
    stent pulled out | 24
    ASPD | 24
    intraductal calculus | 24
    contrast enhanced CT scan abdomen | 48
    inflammatory changes within fat surrounding body and tail of pancreas | 48
    edema | 48
    dilatation pancreatic duct diminished | 48
    calculus showing distal migration towards sphincter of Oddi | 48
    no evidence pancreatic necrosis | 48
    no evidence fluid collection | 48
    bilateral moderate pleural effusions | 48
    dramatic signs clinical improvement | 48
    stabilization hemodynamic parameters | 48
    blood cultures grew Klebsiella ornithinolytica | 48
    sensitive to antibiotics | 48
    extubated | 48
    transferred from intensive care unit | 48
    completed antibiotic course | 264
    discharged home | 264
    follow-up at 1 month | 768
    follow-up at 3 months | 2208
    no further complications | 768
    no further complications | 2208