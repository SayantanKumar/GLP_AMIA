35 years old | 0
    male | 0
    obesity | 0
    dyslipidemia | 0
    T2D for 5 years | -43800
    gliclazide 60 mg/day | -43800
    linagliptin 5 mg/day | -43800
    metformin 2 g/day | -43800
    canagliflozin 300 mg/day | -43800
    rosuvastatin 20 mg/day | -43800
    degludec insulin | -26280
    degludec insulin dose 30 units/day | -26280
    liraglutide 1.8 mg | -87600
    HbA1c 10.1% | -720
    weight 98 kg | 0
    height 180 cm | 0
    BMI 30.2 kg/m2 | 0
    waist circumference 112 cm | 0
    physical examination no significant alterations | 0
    not studied for changes in body composition | 0
    never undergone any treatment for obesity | 0
    heaviest weight of adult life | 0
    initiate VLCKD | 0
    PnK method | 0
    discontinue all medications | 0
    continue rosuvastatin | 0
    use continuous glucose monitoring system | 0
    HbA1c 10.1% | -720
    fasting glucose 132 mg/dL | -720
    creatinine 0.8 G/dL | -720
    uric acid 6.2 mg/dL | -720
    AST 55 U/L | -720
    GGT 90 U/L | -720
    total cholesterol 132 mg/dL | -720
    triglycerides 81 mg/dL | -720
    HDL 43 mg/dL | -720
    LDL 73 mg/dL | -720
    TSH 1.11 mIU/L | -720
    C-peptide 4.83 ng/mL | -720
    microalbuminuria positive 89.6 mg/24 h | -720
    moderate hepatic steatosis | -720
    no tool for screening of fibrosis | -720
    nutritional intervention PnK method | 0
    VLCKD | 0
    step 1 | 0
    step 2 | 0
    step 3 | 0
    active stage | 0
    ketosis | 0
    low calorie diet | 60
    maintenance diet | 90
    weight loss 20 kg | 90
    weight normalization | 90
    diabetes remission | 90
    no change in renal function | 90
    improvement in hepatic function | 90
    microalbuminuria normalization | 90
    remission of steatosis | 90
    weight 90 kg | 30
    BMI 27.8 kg/m2 | 30
    fasting glucose 126 mg/dL | 30
    HbA1c 8.1% | 30
    uric acid 5.4 mg/dL | 30
    creatinine 0.9 G/dL | 30
    AST 37 U/L | 30
    GGT 43 U/L | 30
    weight 82 kg | 60
    BMI 25.3 kg/m2 | 60
    fasting glucose 92 mg/dL | 60
    HbA1c 6.8% | 60
    uric acid 4.4 mg/dL | 60
    creatinine 0.7 G/dL | 60
    AST 37 U/L | 60
    GGT 45 U/L | 60
    weight 78 kg | 90
    BMI 24.1 kg/m2 | 90
    fasting glucose 77 mg/dL | 90
    HbA1c 5.3% | 90
    uric acid 4.3 mg/dL | 90
    creatinine 0.7 G/dL | 90
    AST 32 U/L | 90
    GGT 24 U/L | 90
    total cholesterol 153 mg/dL | 90
    triglycerides 90 mg/dL | 90
    HDL 51 mg/dL | 90
    LDL 84 mg/dL | 90
    microalbuminuria 28.0 mg/24 h | 90
    weight 79 kg | 360
    BMI 24.4 kg/m2 | 360
    fasting glucose 91 mg/dL | 360
    HbA1c 5.4% | 360
    uric acid 4.4 mg/dL | 360
    creatinine 0.9 G/dL | 360
    AST 27 U/L | 360
    GGT 19 U/L | 360
    total cholesterol 145 mg/dL | 360
    triglycerides 130 mg/dL | 360
    HDL 44 mg/dL | 360
    LDL 75 mg/dL | 360
    microalbuminuria 25.2 mg/24 h | 360
    weight 80 kg | 720
    BMI 24.7 kg/m2 | 720
    fasting glucose 86 mg/dL | 720
    HbA1c 5.2% | 720
    uric acid 4.9 mg/dL | 720
    creatinine 1.0 G/dL | 720
    AST 34 U/L | 720
    GGT 12 U/L | 720
    total cholesterol 142 mg/dL | 720
    triglycerides 80 mg/dL | 720
    HDL 44 mg/dL | 720
    LDL 82 mg/dL | 720
    microalbuminuria 22.3 mg/24 h | 720
    follow-up 2 years | 720
    diabetes remission maintained | 720
    remission of steatosis maintained | 720
    patient perspective | 0
    return to desired weight | 90
    blood glucose normalized | 0
    no medication | 0