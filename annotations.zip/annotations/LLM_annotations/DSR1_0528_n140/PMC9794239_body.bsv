51 years old | 0
    Asian | 0
    man | 0
    hypertension | 0
    hyperlipidemia | 0
    T2DM | 0
    nonalcoholic fatty liver disease | 0
    chronic kidney disease stage 3a | 0
    oral semaglutide 3 mg daily | -456
    pitavastatin | 0
    losartan | 0
    insulin | 0
    oral semaglutide 7 mg once daily | -360
    normal or minimally elevated liver tests | -456
    nonalcoholic fatty liver disease | 0
    T2DM | 0
    statin therapy | 0
    increase in alkaline phosphatase (ALP) | -429
    increase in alanine aminotransferase (ALT) | -429
    increase in aspartate aminotransferase (AST) | -429
    normal total bilirubin | -429
    asymptomatic | -429
    abdominal discomfort | 0
    new-onset jaundice | 0
    nausea | 0
    vomiting | 0
    diarrhea | 0
    weakness | 0
    ibuprofen 400 mg twice daily | -1440
    afebrile | 0
    tachycardic | 0
    blood pressures 90s/60s mm Hg | 0
    scleral icterus | 0
    dry oral mucosa | 0
    blood urea nitrogen 58 mg/dL | 0
    creatinine 2.89 mg/dL | 0
    worsening liver tests | 0
    coagulation tests normal | 0
    alpha-fetoprotein normal | 0
    magnetic resonance with cholangiogram no abnormalities | 0
    negative serologies for autoimmune | 0
    negative serologies for viral hepatitis | 0
    COVID-19 negative | 0
    improved | 24
    discharged | 24
    worsening liver tests | 72
    repeat imaging | 72
    endoscopic retrograde cholangiopancreatogram | 72
    unrevealing | 72
    liver biopsy | 168
    marked and diffuse bile duct injury | 168
    patchy ductular reaction | 168
    mild cholestasis | 168
    portal tracts with expanded edema | 168
    marked ductular reaction | 168
    chronic inflammatory infiltrate | 168
    damage to interlobular bile ducts | 168
    no duct loss | 168
    no evidence of steatohepatitis | 168
    no interface hepatitis with plasma cell infiltrate | 168
    cholestatic gene panel | 168
    heterozygosity for ABCC2 NM_000392.5:c:656 G>A (p.R219H) | 168
    heterozygosity for DHCR7 NM_001360.2:2.1168C>T (p.H390Y) | 168
    progressive renal disease | 0
    renal biopsy | 168
    chronic active interstitial nephritis with eosinophils | 168
    patchy acute tubular damage | 168
    moderate tubular atrophy | 168
    interstitial fibrosis | 168
    hemodialysis | 360
    enrolled in DILIN's prospective study | 720
    protocol-specific workup | 720
    exclusion of competing etiologies | 720
    adjudicated causality score 3 (probable) | 720
    severity score 5 (transplantation) | 720
    Roussel-Uclaf Causality Assessment Method score 3 (possible DILI) | 720
    ursodiol | 720
    budesonide | 720
    mycophenolate mofetil | 720
    rapamycin | 720
    no meaningful improvement in liver function | 1080
    no meaningful improvement in kidney function | 1080
    simultaneous liver and kidney transplantation | 1440
    successful recovery | 1680
    liver explant revealed cirrhosis | 1440
    marked ductular reaction | 1440
    cholestasis | 1440
    bile infarcts | 1440
    biliary cirrhosis | 1440
    