79 years old|0
    man|0
    admitted to hospital|0
    treatment of diabetes|0
    orchiectomy| -5760
    prostate cancer| -5760
    T2bN0M0 Stage B| -5760
    Gleason score 8| -5760
    preoperative body weight 81 kg| -5760
    gained 4 kg of body weight| -2160
    not diagnosed with diabetes mellitus| -5760
    preoperative postprandial blood glucose 115 mg/dL| -5760
    preoperative HbA1c 6.6%| -5760
    preoperative prostate-specific antigen concentration 8.334 ng/mL| -5760
    felt thirst| -1440
    polyuria| -1440
    lost 10 kg of body weight| -1440
    visited clinic| -72
    laboratory tests| -72
    postprandial plasma glucose 518 mg/dL| -72
    HbA1c 11.9%| -72
    medication for hypertension|0
    medication for dyslipidemia|0
    medication for paroxysmal atrial fibrillation|0
    no family history of diabetes|0
    ethanol intake under 30 g a day|0
    body temperature 35.6 °C|0
    blood pressure 113/65 mmHg|0
    pulse 88 bpm|0
    body weight 75 kg|0
    body mass index 25.6 kg/m2|0
    glucagon stimulation test|0
    C-peptide immunoreactivity fasting 2.33 ng/mL|0
    C-peptide immunoreactivity 6 min 6.68 ng/mL|0
    endogenous insulin secretion preserved|0
    anti-glutamic acid decarboxylase antibody negative|0
    anti-insulin antibody negative|0
    prostate-specific antigen concentration 0.739 ng/mL|0
    serum free testosterone 1 pg/mL|0
    serum estradiol below detection|0
    thyroid function test normal|0
    adrenal function test normal|0
    abdominal computed tomography|0
    markedly lower liver intensity|0
    liver-to-spleen ratio 0.37|0
    visceral fat area increased 40.8%|0
    subcutaneous fat area increased 15.9%|0
    liver function test normal|0
    viral hepatitis negative|0
    anti-nuclear antibody negative|0
    anti-mitochondrial M2 antibody negative|0
    hypergammaglobulinemia not found|0
    urinalysis glucose 4+|0
    urinalysis ketone negative|0
    urinalysis blood negative|0
    urinalysis protein negative|0
    fasting plasma glucose 210 mg/dL|0
    fasting CPR 1.63 ng/mL|0
    HbA1c 12.3%|0
    lipid profile TG 225 mg/dL|0
    lipid profile TC 145 mg/dL|0
    lipid profile HDL-C 32 mg/dL|0
    lipid profile LDL-C 68 mg/dL|0
    diagnosed with severe diabetes after orchiectomy|0
    rapid deterioration of visceral fat accumulation|0
    fatty liver|0
    administered multiple daily insulin injection therapy|0
    SGLT2 inhibitor canagliflozin 100 mg/day|0
    sitagliptin 50 mg/day|0
    blood glucose well controlled|168
    insulin regimen changed to insulin aspart/insulin degludec combination twice daily|168
    sitagliptin changed to dulaglutide 75 mg once weekly|168
    abdominal computed tomography|336
    improvement in L/S ratio|336
    reduction in visceral fat area|336
    reduction in subcutaneous fat area|336
    discharged| unknown
    