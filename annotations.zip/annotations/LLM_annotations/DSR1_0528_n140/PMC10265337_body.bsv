66 years old|0
    female|0
    referred to endocrinology outpatient service|0
    hirsutism| -8760
    progressively developed after menopause| -8760
    significantly worsened over the past year| -8760
    written informed consent obtained|0
    abdominal obesity|0
    hypertension|0
    atherogenic dyslipidemia|0
    type 2 diabetes|0
    metformin|0
    glucagon-like peptide-1 receptor agonist (semaglutide)|0
    basal insulin|0
    angiotensin-receptor blocker|0
    calcium-channel blocker|0
    furosemide|0
    omega-3-acid ethyl esters|0
    ezetimibe|0
    rosuvastatin|0
    no personal history of infertility|0
    no menstrual irregularity|0
    no hirsutism during reproductive age|0
    three full-term births|0
    one spontaneous miscarriage|0
    gestational diabetes|0
    menopause occurred physiologically at 47| -166440
    alopecia|0
    excess terminal hairs|0
    affecting face, chest, abdomen|0
    no clitoromegaly|0
    no cushingoid features|0
    no overt signs of virilization|0
    Ferriman-Gallwey score 20/36|0
    moderate hirsutism|0
    body mass index 31.9 kg/m2|0
    arterial blood pressure 120/70 mmHg|0
    total testosterone 384.5 ng/dl|0
    dehydroepiandrosterone sulfate 136.2 µg/dl|0
    delta4-androstenedion 6.09 ng/dl|0
    adrenocorticotropic hormone normal|0
    cortisol normal|0
    chromogranin A normal|0
    carcinoembryonic antigen normal|0
    cancer antigen 125 normal|0
    human epididymis protein 4 normal|0
    glycated hemoglobin 8.1%|0
    estimated glomerular filtration rate 44 ml/min/1.73 m2|0
    transvaginal ultrasound|0
    both ovaries within normal size and location|0
    no follicular activity|0
    no vascularization of right ovary|0
    slightly enhanced and localized vascular signal in left ovary|0
    abdominal magnetic resonance imaging|0
    MRI showed regular size left ovary|0
    inhomogeneous signal intensity in T2 sequences|0
    minute central area of signal hyperintensity|0
    intense postcontrast enhancement|0
    not a univocal interpretation|0
    gynecology consultation|0
    laparoscopic bilateral salpingo-oophorectomy proposed|0
    histological diagnosis of luteinized thecoma in left ovary|0
    hirsutism improved|720
    resolution of biochemical hyperandrogenism|2160
    improvement of body weight|2160
    improvement of glucometabolic profile|2160
    follow-up at 3 months|2160
    follow-up at 6 months|4320
    weight 87 kg|0
    weight 85 kg|2160
    weight 83 kg|4320
    height 1.65 m|0
    BMI 31.9 kg/m2|0
    BMI 31.2 kg/m2|2160
    BMI 30.5 kg/m2|4320
    systolic blood pressure 120 mmHg|0
    systolic blood pressure 120 mmHg|2160
    systolic blood pressure 125 mmHg|4320
    diastolic blood pressure 70 mmHg|0
    diastolic blood pressure 70 mmHg|2160
    diastolic blood pressure 70 mmHg|4320
    hemoglobin 10.5 g/dl|0
    hemoglobin 11.1 g/dl|2160
    hemoglobin 11.4 g/dl|4320
    creatinine 1.28 mg/dl|0
    creatinine 1.24 mg/dl|2160
    creatinine 1.22 mg/dl|4320
    glucose 115 mg/dl|0
    glucose 92 mg/dl|2160
    glucose 100 mg/dl|4320
    HbA1c 65 mmol/mol|0
    HbA1c 47 mmol/mol|2160
    HbA1c 49 mmol/mol|4320
    total testosterone 384.5 ng/dl|0
    total testosterone 19.8 ng/dl|2160
    total testosterone 19.9 ng/dl|4320
    SHBG 47.60 nmol/L|0
    SHBG 44.5 nmol/L|2160
    SHBG 41.4 nmol/L|4320
    delta-4-androstenedione 6.1 ng/ml|0
    delta-4-androstenedione 1.5 ng/ml|2160
    delta-4-androstenedione 1.8 ng/ml|4320
    DHEA-S 136.2 µg/dl|0
    DHEA-S 107.5 µg/dl|2160
    DHEA-S 121.3 µg/dl|4320
    ACTH 26.1 pg/ml|0
    LH 42.1 mUI/ml|0
    LH 44.2 mUI/ml|2160
    FSH 68.5 mUI/ml|0
    FSH 85.7 mUI/ml|2160
    total cholesterol 127 mg/dl|0
    total cholesterol 142 mg/dl|4320
    HDL cholesterol 35 mg/dl|0
    HDL cholesterol 39 mg/dl|4320
    LDL cholesterol 58 mg/dl|0
    LDL cholesterol 73 mg/dl|4320
    triglycerides 119 mg/dl|0
    triglycerides 149 mg/dl|4320
    AST 35 U/L|0
    AST 31 U/L|2160
    AST 35 U/L|4320
    ALT 61 U/L|0
    ALT 38 U/L|2160
    ALT 40 U/L|4320
    GGT 87 U/L|0
    metabolic syndrome|0
    hyperandrogenism|0
    improvement of cardiometabolic risk profile|4320
    