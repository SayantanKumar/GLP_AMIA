47 years old | 0
    male | 0
    type 2 diabetes | 0
    heart failure with preserved ejection fraction | 0
    chronic obstructive pulmonary disease | 0
    insulin | 0
    dulaglutide | 0
    evolocumab 140 mg/mL every 2 weeks | 0
    hyperlipidemia | 0
    statin-induced rhabdomyolysis | -unknown
    empagliflozin 25 mg once daily | -168
    hemoglobin A1c 8.42% | -168
    pain in bilateral lower extremities | -144
    constant aching in legs | -144
    constant aching in thighs | -144
    no specific aggravating factors | -144
    no specific alleviating factors | -144
    symptoms similar to statin-induced myopathy | -144
    denied recent trauma | -144
    denied fall | -144
    denied taking new medications | -144
    denied taking herbal supplements | -144
    medication list reviewed | -144
    no common causes of myopathy | -144
    home medications | -144
    insulin lispro | -144
    insulin glargine | -144
    dulaglutide | -144
    evolocumab | -144
    gabapentin | -144
    atenolol | -144
    bupropion | -144
    ziprasidone | -144
    rimegepant | -144
    galcanezumab | -144
    atenolol | -144
    albuterol inhaler | -144
    pain worsened | -144 to -0
    sought care at emergency department | 0
    no complaints of weight loss | 0
    no change in urination | 0
    no feeling thirsty | 0
    vital signs within normal limits | 0
    skin examination no erythema | 0
    no subcutaneous edema | 0
    no lesions | 0
    no evidence of dehydration | 0
    musculoskeletal examination no joint effusions | 0
    range of motion normal | 0
    neurological examination intact strength | 0
    upper extremities strength 5/5 | 0
    lower extremities strength 5/5 | 0
    palpation caused discomfort | 0
    tenderness in bilateral thighs | 0
    tenderness in bilateral legs | 0
    deep tendon reflexes normal | 0
    sensation intact | 0
    physical examination unremarkable | 0
    elevated creatinine kinase 958 U/L | 0
    glucose elevated 206 mg/dL | 0
    creatinine 0.93 mg/dL | 0
    estimated glomerular filtration rate >60 mL/min/1.73 m2 | 0
    magnesium 2.4 mg/dL | 0
    urinalysis negative for blood | 0
    urinalysis negative for red blood cells | 0
    mild elevation of liver enzymes | 0
    aspartate aminotransferase 64 U/L | 0
    alanine aminotransferase 117 U/L | 0
    alkaline phosphatase 138 U/L | 0
    metabolic dysfunction-associated steatotic liver disease | 0
    autoimmune workup unremarkable | 0
    negative antinuclear antibody | 0
    erythrocyte sedimentation rate 21 mm/hr | 0
    myopathy | 0
    elevated creatinine kinase | 0
    empagliflozin discontinued | 0
    intravenous fluids | 0
    discharged home | 0
    follow up with primary care physician | 0
    significant improvement in muscle pain | 168
    significant improvement in weakness | 168
    complete resolution within 2 weeks | 336
    creatinine kinase downtrending | 168
    creatinine kinase 215 U/L | 168
    pain returned to normal | 168
    strength returned to normal | 168
    resolution of symptoms | 168
    negative screening inflammatory testing | 168
    autoimmune causes testing deferred | 168
    <|eot_id|>
    