66 years old|0
    gentleman|0
    presented for cardiovascular evaluation|0
    chest discomfort|0
    right knee pain|0
    intractable hiccups|0
    type 2 diabetes mellitus|0
    hypercholesterolemia|0
    aortic atherosclerosis|0
    ascending aortic aneurysm|0
    family history significant for premature coronary artery disease in father|0
    compliant with medical therapy|0
    subcutaneous 200 units/mL insulin degludec|0
    subcutaneous liraglutide 18 mg/3 mL|0
    daily oral metformin hydrochloride 500 mg|0
    daily oral sitagliptin 100 mg|0
    daily oral zolpidem 12.5 mg|0
    daily oral tadalafil 5 mg|0
    rosuvastatin 20 mg tablet daily|0
    referred for upper gastrointestinal endoscopy|0
    persistent hiccups|0
    no gastrointestinal etiology found|0
    cardiac stress test conducted|-2160
    no significant evidence of ischemia|-2160
    dyspnea|-2160
    unstable angina|-2160
    transthoracic echocardiogram performed|-2160
    preserved ejection fraction|-2160
    no other abnormalities|-2160
    coronary calcium score study taken|-2160
    Agatson calcium score 1185|-2160
    high risk for future cardiovascular events|-2160
    noninvasive cardiovascular workup inconclusive|-2160
    other differentials not suggestive of particular etiology|-2160
    cardiac catheterization|0
    multiple arteries severely calcified|0
    left main artery 10% stenosis|0
    left anterior descending artery 99% stenosis|0
    circumflex artery 20% stenosis|0
    right coronary artery 30% stenosis|0
    successful revascularization|0
    drug eluting stent placed in mid-segment of LAD|0
    discharged same day|0
    followed up in office in same week|168
    compliant with dual antiplatelet therapy|168
    aspirin 81 mg|168
    ticagrelor 90 mg twice a day|168
    post-interventional follow-up after 30 days|720
    post-interventional follow-up after 6 months|4320
    post-interventional follow-up after a year|8640
    no return of intractable hiccups|8640
    persistent hiccups resolved after cardiac catheterization|0
    <|eot_id|>
    