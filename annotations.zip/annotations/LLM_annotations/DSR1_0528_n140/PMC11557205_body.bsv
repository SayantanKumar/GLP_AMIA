79 years old | 0
    male | 0
    Japanese | 0
    type 2 diabetes mellitus | -175320
    hypertension | -175320
    metformin hydrochloride | -175320
    glimepiride | -175320
    dulaglutide | -175320
    nifedipine CR | -175320
    doxazosin mesylate | -175320
    telmisartan | -175320
    hydrochlorothiazide | -175320
    poor glycemic control | -408
    hemoglobin A1c 8.6% | -408
    miglitol 150 mg/day | -408
    leg edema | -396
    general malaise | -396
    appetite loss | -24
    visited hospital | -24
    leg edema | -24
    appetite loss | -24
    admitted to hospital | 0
    acute kidney injury | 0
    serum creatinine 8.12 mg/dL | 0
    elevated serum creatinine | 0
    computed tomography | 0
    no post-renal AKI | 0
    edema | 0
    fractional excretion of sodium 9.43% | 0
    fractional excretion of urea nitrogen 63.76% | 0
    elevated blood pressure 178/100 | 0
    not pre-renal AKI | 0
    blood culture negative | 0
    urine culture negative | 0
    sputum culture negative | 0
    low fever 37.5°C | 0
    elevated C-reactive protein | 0
    urinary β2-microglobulin 31,748 μg/L | 0
    acute interstitial nephritis | 0
    acetaminophen | -216
    general fatigue | -216
    over-the-counter medications | -408
    supplements | -408
    miglitol discontinued | 0
    metformin hydrochloride discontinued | 0
    glimepiride discontinued | 0
    dulaglutide discontinued | 0
    insulin | 0
    drug-induced lymphocyte stimulation test for miglitol positive | 0
    renal biopsy | 264
    subcapsular inflammatory cellular infiltrate | 264
    lymphocytes | 264
    plasma cells | 264
    eosinophils | 264
    acute interstitial nephritis | 264
    glomeruli diffuse mesangial expansion | 264
    polar vasculosis | 264
    hyalinosis of small arteries | 264
    global sclerosis 15/34 glomeruli | 264
    diabetic nephropathy | 264
    nephrosclerosis | 264
    gallium scintigraphy | 384
    diffuse isotope uptake in both kidneys | 384
    urinary β2MG decreased to normal | 312
    serum creatinine gradually decreased | 312
    serum creatinine above 4 mg/dL | 528
    serum creatinine 4.77 mg/dL | 528
    prednisolone 30 mg | 528
    discharged | 600
    serum creatinine above 3 mg/dL | 600
    partial recovery | 600
    serum creatinine 1.50 mg/dL | -408
    white blood cell 8,200/µL | 0
    eosinophil 100/µL | 0
    hemoglobin 9.3 g/dL | 0
    platelet 22.8×104/µL | 0
    HbA1c 8.0% | 0
    total protein 6.8 g/dL | 0
    serum albumin 3.1 g/dL | 0
    blood urea nitrogen 62 mg/dL | 0
    serum creatinine 8.12 mg/dL | 0
    serum sodium 136 mmol/L | 0
    serum potassium 5.0 mmol/L | 0
    serum chloride 100 mmol/L | 0
    serum calcium 8.6 mg/dL | 0
    serum phosphorus 5.2 mg/dL | 0
    blood sugar 145 mg/dL | 0
    eGFR 5.6 mL/min/1.73 m2 | 0
    CRP 10.87 mg/dL | 0
    ASO <20 U/mL | 0
    anti-ds DNA antibody 1.9 U/mL | 0
    rheumatoid factor 8.6 IU/mL | 0
    anti-GBM antibody <2 U/mL | 0
    MPO-ANCA <1.0 U/mL | 0
    PR3-ANCA <1.0 U/mL | 0
    IgG 1,487 U/mL | 0
    IgA 295 mg/dL | 0
    IgM 90 mg/dL | 0
    IgE 14 U/mL | 0
    C3 130 mg/dL | 0
    C4 32 mg/dL | 0
    pH 7.375 | 0
    PCO2 43.6 mmHg | 0
    HCO3- 24.9 mmol/L | 0
    base excess 0.3 mmol/L | 0
    lactate 0.8 mmol/L | 0
    urine specific gravity 1.01 | 0
    urine pH 6.5 | 0
    red blood cell 1-4/HPF | 0
    white blood cell 1-4/HPF | 0
    tubular epithelial cell <1/HPF | 0
    hyaline cast 1-4/WF | 0
    granule cast 1-4/WF | 0
    urinary protein 0.967 g/gCr | 0
    NAG 23.6 IU/gCr | 0
    β2MG 520.5 μg/mgCr | 0
    creatinine 61 mg/dL | 0
    fractional excretion of sodium 9.42% | 0
    fractional excretion of urea 63.76% | 0
    no lactic acidosis | 0
    no adverse events with prednisolone | 528
    incomplete renal recovery | 600
    