54 years old | 0
    female | 0
    type 2 diabetes | -17520
    laparoscopic gastric bypass | -17520
    morbid obesity | -17520
    BMI 42 kg/m2 | -17520
    post-prandial episodes of sweating | 0
    post-prandial episodes of fainting | 0
    hypoglycemia | 0
    capillary blood glucose <50 mg/dl | 0
    stabilized BMI of 30 kg/m2 | 0
    type 2 diabetes in clinical remission | 0
    abdominal ultrasound | 0
    1.8-cm solid mass in the pancreatic head | 0
    abdominal CT scan | 0
    octreotide scan | 0
    focus of abnormal uptake of the radiotracer | 0
    lowest laboratory glucose 65 mg/dl | 0
    parallel insulin 3.3 μUI/ml | 0
    plasma chromogranin A 4.1 ng/ml | 0
    72-h fast test negative for hypoglycemia | 0
    laparoscopic enucleation | 24
    pancreatic nodule | 24
    intraoperative pancreatic ultrasound | 24
    pancreatic nodule >1 cm away from pancreatic duct | 24
    no other nodules | 24
    complete remission of hypoglycemic episodes | 48
    histology | 48
    18×15×14 mm pseudoglandular neuroendocrine neoplasia | 48
    staining positive for CAM 5.2 | 48
    staining positive for chromogranin A | 48
    staining positive for synaptophysin | 48
    staining positive for glucagon | 48
    staining positive for GLP1 | 48
    staining negative for insulin | 48
    low Ki-67 (<2%) | 48
    low mitotic index (<1 mitosis/10c) | 48
    low-grade (G1) well-differentiated neuroendocrine tumor | 48
    PET-68aGa-SRP (DOTANOC) | 72
    no residual disease | 72
    frozen tumor sample | 72
    homogenized in 1% trifluoroacetic acid | 72
    extracts purified | 72
    eluted with 70% ethanol | 72
    reconstituted in TRIS buffer | 72
    peptide hormone levels measured | 72
    high concentration of glucagon (26.707 pmol/g tissue) | 72
    traces of GLP1 (471 pmol/g) | 72
    traces of insulin (139 pmol/g) | 72
    traces of somatostatin (23 pmol/g) | 72
    GLP1/glucagon co-secreting pNET | 72
    written informed consent | 96
    no conflict of interest | 96
    