63 years old | 0
    male | 0
    retired | 0
    Caucasian | 0
    admitted to the hospital | 0
    severe epigastric pain | -120
    dysphagia | -120
    odynophagia | -120
    nausea | -120
    non-bloody emesis | -120
    non-bilious emesis | -120
    anorexia | -120
    no evidence of overt GIB | 0
    hypertension | 0
    type 2 diabetes mellitus | 0
    poor glycemic control | 0
    HbA1c 8.4% | 0
    dyslipidemia | 0
    no known microvascular complications | 0
    attempted to lose weight | -168
    switched from liraglutide to semaglutide | -168
    began ketogenic diet | -168
    became acutely unwell | -144
    manual labour | -144
    no history of reflux disease | 0
    no history of dysphagia | 0
    attempted bed rest | -144
    ceased oral intake | -144
    pain and nausea peaked | -120
    presented to the hospital | 0
    height 1.778 m | 0
    weight 94 kg | 0
    BMI 31.14 kg/m² | 0
    tachycardia 125 bpm | 0
    tachypnea 40/min | 0
    blood pressure 136/81 | 0
    distress | 0
    Kussmaul respirations | 0
    lateral decubitus position | 0
    voluntary abdominal guarding | 0
    frequent painful belching | 0
    hemoglobin 165 g/L | 0
    leukocytes 17.9 × 10^9/L | 0
    anion gap 25 | 0
    bicarbonate 5 mmol/L | 0
    venous blood gas pH 7.02 | 0
    beta-hydroxybutyrate 10.2 mmol/L | 0
    glucose 17 mmol/L | 0
    glucose peaked at 82 mmol/L | 0
    urinalysis negative for leukocytes | 0
    urinalysis negative for nitrites | 0
    abdominal CT | 0
    no bowel obstruction | 0
    no intra-abdominal infection | 0
    no abscess | 0
    circumferential wall thickening of the distal esophagus | 0
    admitted for DKA | 0
    no triggers identified except ketogenic diet and dehydration | 0
    C-peptides within normal limits | 0
    continued epigastric pain | 0
    continued reflux symptoms | 0
    continued dysphagia | 0
    EGD | 0
    severe class D esophagitis | 0
    circumferential black necrotic inflammatory changes | 0
    mid to distal esophagus | 0
    abrupt stop at GEJ | 0
    AEN | 0
    erosions in body and antrum of stomach | 0
    multiple clean based ulcers in duodenum | 0
    biopsies taken | 0
    chronic gastroduodenitis | 0
    no H. pylori | 0
    no infectious organisms | 0
    no neoplasia | 0
    pantoprazole 40 mg IV twice daily | 0
    sucralfate 1 g PO four times daily | 0
    nil per os | 0
    slowly increase to clear fluid diet | 0
    then full fluid diet | 0
    discharged | 0
    liquid diet | 0
    sucralfate 2 g with meals and nightly | 0
    pantoprazole 40 mg twice daily | 0
    metformin discontinued | 0
    GLP-1 RA discontinued | 0
    insulin aspart 5 units TID | 0
    insulin glargine 15 units nightly | 0
    repeat EGD 8 wk post-discharge | 1344
    healed esophagus | 1344
    one polyp | 1344
    biopsies showed healed gastric and duodenal mucosa | 1344
    mild inflammatory changes to polyp | 1344
    follow up arranged | 1344
    HbA1c improved to 7.2 | 1344