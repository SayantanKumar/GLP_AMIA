45 years old|0
    female|0
    Parkinson's disease|0
    clozapine|0
    refractory dyskinesia|0
    gestational diabetes|0
    glycaemic dysfunction|0
    blood glucose 505 mg/dl|0
    HbA1c 12.4%|0
    metformin|0
    clozapine discontinued|0
    insulin|0
    exenatide|0
    empagliflozin|0
    