48 years old|0
    male|0
    African origin|0
    treatment-resistant paranoid schizophrenia|0
    transferred to the National Psychosis Unit|0
    re-titration of clozapine|0
    cessation of clozapine because of side-effects|0
    first known to UK psychiatric services in 1993|-184080
    arrived in UK|-184080
    age 25|-184080
    presented with paranoid delusions|-184080
    presented with grandiose delusions|-184080
    presented with auditory hallucinations|-184080
    symptoms persisted|-184080
    violent behavior|-184080
    involuntary admissions to psychiatric wards|-184080
    olanzapine 15 mg daily|-35040
    risperidone up to 9 mg daily|-43800
    paliperidone palmitate 150 mg monthly|-17520
    flupentixol depot 40 mg three times a week|-87600
    clozapine up to 400 mg a day|-17520
    clozapine stopped on two occasions|-17520
    rapid loss of glycaemic control|-17520
    requiring insulin treatment|-17520
    diabetes improved|-17520
    insulin administration no longer necessary|-17520
    glycaemic control maintained with metformin 1 g twice daily|-17520
    hypertension|0
    average blood pressure 165/101 mmHg|0
    hypercholesterolemia|0
    LDL levels 270 mg/dL|0
    one-pack-per-day smoker|0
    overweight|0
    BMI 28.7|0
    irritable|0
    shouting|0
    intimidating towards staff|0
    paranoid delusions|0
    grandiose delusions|0
    grossly thought-disordered|0
    perceptual abnormalities|0
    responding to unseen stimuli|0
    antipsychotic treatment risperidone on admission|0
    switched to lurasidone|0
    lurasidone not effective|0
    changed to amisulpride|0
    amisulpride produced no improvement|0
    decided to commence clozapine|0
    collaboration with local endocrinologists|0
    fasting blood glucose levels measured before clozapine|0
    baseline fasting blood glucose 4-6 mmol/L|0
    slow-titration approach|144
    glucose levels started to increase|144
    HbA1c increased|0
    HbA1c from 7.3 to 12.1%|1440
    clozapine dose 100 mg|144
    serum clozapine levels 65 ng/ml|144
    glucose levels becoming elevated|144
    elevation associated with increase of clozapine dose|144
    commenced on insulin therapy|0
    initial dose four units of fast-acting insulin once daily|0
    clozapine slowly titrated upwards|0
    increments of 25 mg|0
    blood glucose levels stabilised for 2-3 days|0
    clozapine dose reached 700 mg/day|0
    serum clozapine levels 460 ng/ml|0
    dose of insulin increased slowly|0
    glycaemic control achieved|0
    52 units of medium-acting insulin twice daily|0
    continued taking metformin 1 g twice daily|0
    commenced on 2 mg weekly injection of long-acting exenatide|0
    mental state improved|0
    thought disorder ameliorated|0
    speech disorder ameliorated|0
    perceptual abnormalities no longer noted|0
    continued to experience paranoid delusions|0
    engaged in art activities|0
    calm demeanour|0
    gained partial insight|0
    weight increased slightly|0
    BMI from 28.7 to 28.9|0
    smoking reduced by half|0
    psychotic symptoms significantly reduced|3600
    glycaemic control stable|3600
    discharged from hospital|3600
    care taken over by local mental health team|3600
    diabetes care managed by general practitioner|3600
    specialist input from endocrinologists|3600