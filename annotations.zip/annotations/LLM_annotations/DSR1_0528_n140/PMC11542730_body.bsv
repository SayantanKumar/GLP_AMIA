35 years old|0
    male|0
    admitted to the hospital|0
    mass in the right adrenal gland|0
    dynamic contrast-enhanced CT scan of the lower abdomen|-96
    health check-up|-96
    no dizziness|0
    no fatigue|0
    no nausea|0
    no vomiting|0
    no blurred vision|0
    no general weakness|0
    no profuse sweating|0
    generally good condition|0
    does not smoke|0
    does not drink|0
    denied any history of taking medications|0
    BP 132/85 mmHg|0
    height 178 cm|0
    weight 94 kg|0
    BMI 29.7 kg/m2|0
    no thyroid enlargement|0
    no obvious positive signs on cardiopulmonary examination|0
    no obvious positive signs on abdominal examination|0
    tendon reflexes normal|0
    bowel sounds normal|0
    serum potassium 2.7 mmol/L|0
    serum chloride 94 mmol/L|0
    adrenal cyst|0
    hypokalemia|0
    blood gas PH 7.44|0
    PCO2 41.2 mmhg|0
    actual base excess 3.5 mmol/L|0
    serum potassium 2.8 mmol/L|0
    serum magnesium 0.58 mmol/L|0
    serum chloride 96 mmol/L|0
    ionized calcium 1.07 mmol/L|0
    aldosterone 131.4 pg/ml|0
    renin 8.99 ng/mL/hr|0
    twenty-four-hour urine electrolyte testing|0
    potassium 32.84 mmol/L|0
    output 2900 mL|0
    potassium 3.81 g/24 h|0
    calcium 0.016 g/24 h|0
    creatinine 1.84 g/24 h|0
    phosphorus 0.59 g/24 h|0
    fractional excretion of potassium 14.79%|0
    HbA1c 6.8%|0
    urinary microalbumin/urinary creatinine 38.75 mg/g|0
    urinary microalbumin 34.6 mg/L|0
    anti-human insulin antibody 18.06IU/ml|0
    glutamic acid decarboxylase antibody 1 IU/ml|0
    C-peptide 3.68 ng/mL|0
    INS 16.58 uIU/mL|0
    nodular low-density shadow in the right adrenal region|0
    diameter approximately 37 mm|0
    clear boundaries|0
    no significant enhancement|0
    possibility of a cyst high|0
    no obvious abnormal density in the left adrenal gland|0
    12-channel conventional electrocardiogram showed sinus rhythm|0
    Gitelman syndrome diagnosis|0
    exclude insufficient potassium intake|0
    exclude use of thiazide diuretics|0
    exclude use of laxatives|0
    renal potassium loss|0
    hypokalemia related to increased renal potassium excretion|0
    chronic hypokalemia|0
    inappropriate renal potassium wasting|0
    hypomagnesemia|0
    hypocalciuria|0
    metabolic alkalosis|0
    increased plasma renin levels|0
    genetic testing|0
    SLC12A3 gene mutation|0
    homozygous pathogenic variant c.1456G>A in the SLC12A3 gene|0
    missense mutation|0
    pathogenic|0
    differential diagnosis|0
    Bartter syndrome|0
    fatigue|0
    slow growth|0
    growth retardation absent|0
    blood magnesium levels low|0
    urine calcium levels low|0
    chloride scavenging test not performed|0
    genetic testing performed|0
    exclude adrenal mass diseases|0
    right adrenal mass resection|0
    postoperative pathology showed adrenal cyst|0
    adrenal cyst|0
    GS unrelated to adrenal cyst|0
    potassium chloride 500 mg bid|0
    magnesium chloride 1000 mg bid|0
    spironolactone 20 mg bid|0
    serum potassium 3.63~3.71 mmol/L|0
    male bilateral mammary gland development|0
    adverse effect of spironolactone|0
    spironolactone stopped|0
    serum potassium decreased|0
    potassium chloride 2000 mg tid|0
    magnesium chloride 1000 mg bid|0
    quality of life reduced|0
    serum potassium less than 3 mmol/l|0
    increase in nocturia|0
    finerenone 10 mg bid|0
    potassium chloride 1500 mg bid|0
    magnesium chloride 1000 mg bid|0
    serum potassium 3.48~3.8 mmol/L|0
    serum magnesium 0.53~0.91 mmol/L|0
    no obvious adverse reactions|0
    Semaglutide 1.0 mg qw|0
    dapagliflozin 1 tablet qd|0
    blood glucose levels well-controlled|0
    hypokalemia|0
    hypomagnesemia|0
    hypochloremic metabolic alkalosis|0
    hypocalciuria|0
    renin activity elevated|0
    abnormal glucose metabolism|0
    dry mouth|0
    polydipsia|0
    increased nocturia|0
    discharged|0
    finerenone treatment|0
    reduced drug adverse effects|0
    improved prognosis|0
    