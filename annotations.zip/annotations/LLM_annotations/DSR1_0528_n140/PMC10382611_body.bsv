60 years old| 0
    white| 0
    male| 0
    long-standing type 2 diabetes mellitus| 0
    stable glycemic control| 0
    chylomicronemia| 0
    hypertriglyceridemia| 0
    chief complaint of chylomicronemia| 0
    hypertriglyceridemia with varying triglyceride levels between 1100 and 4000 mg/dL| 0
    adherent to lipid-lowering therapy| 0
    alcohol consumption <1 drink/week| 0
    consistent 20% low fat diet| 0
    exercise with 30 minutes of daily walking| 0
    no history of pancreatitis| 0
    moderate hepatomegaly| 0
    no eruptive xanthomata| 0
    A1C level consistently between 6.0% and 7.0% for at least 2 years before intervention| -17520
    diagnosed with partial lipoprotein lipase deficiency| 0
    variant p.Asn291Ser in lipoprotein lipase| 0
    fenofibrate 145 mg daily| 0
    icosapent ethyl 2 g twice daily| 0
    ezetimibe 10 mg daily| 0
    atorvastatin 40 mg daily| 0
    semaglutide 1.0 mg subcutaneously weekly| 0
    empagliflozin 10 mg/day| 0
    metformin 1000 mg twice daily| 0
    stable for several months| 0
    semaglutide discontinued| 0
    switched to tirzepatide| 0
    tirzepatide titrated up to 15 mg subcutaneously weekly| 0
    stable for 2 months| 1440
    no major side effects| 1440
    lipid-lowering therapy remained consistent and adherent| 1440
    no other changes in clinical care, medications, exercise, or diet| 1440
    triglyceride level decreased approximately 58% from 1404 to 583 mg/dL| 1440
    resolution of chylomicronemia| 1440
    A1C level decreased from 6.9% to 6.3%| 1440
    body weight decreased by 12 lbs| 1440
    after 6 months of tirzepatide| 4320
    triglyceride level decreased to 202 mg/dL| 4320
    lowest triglyceride level ever reported| 4320
    glycemic control improved| 1440
    body weight decreased| 1440
    improvement in chylomicronemia| 1440
    improvement in hypertriglyceridemia| 1440
    gastric inhibitory polypeptide receptor agonism| 1440
    increase in lipoprotein lipase activity| 1440
    decrease in apolipoprotein CIII| 1440
    resolution of chylomicronemia with significant decrease in triglyceride level| 4320
    <|eot_id|>
    