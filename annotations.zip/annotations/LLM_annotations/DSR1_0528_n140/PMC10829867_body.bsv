27 years old | 0
    man | 0
    history of Crohn disease | 0
    obesity | 0
    body mass index 37.1 | 0
    depression | 0
    sleep apnea | 0
    continuous positive airway pressure | 0
    presented to the endocrine clinic | 0
    evaluation of low testosterone levels | 0
    low mood | -6480
    fatigue | -6480
    low testosterone diagnosed | -6480
    physical exam normal hair distribution | 0
    physical exam normal muscle mass | 0
    physical exam normal strength | 0
    testicles soft | 0
    testicles 10 mL | 0
    testicles without palpable nodule | 0
    intramuscular testosterone cypionate | 0
    testosterone cypionate 120 mg weekly | 0
    total testosterone level 2.43 ng/mL | 0
    testosterone replacement therapy discontinued | 0
    assess hypothalamic-pituitary-gonadal axis | 0
    without testosterone treatment | 0
    repeat morning labs total testosterone 0.91 ng/mL | 2160
    repeat morning labs bioavailable testosterone 0.69 ng/mL | 2160
    repeat morning labs sex hormone binding globulin 8 nmol/L | 2160
    repeat morning labs luteinizing hormone 3.1 mIU/mL | 2160
    repeat morning labs follicle stimulating hormone 2.7 mIU/mL | 2160
    repeat morning labs estradiol 23 pg/mL | 2160
    repeat morning labs insulin like growth factor 1 193 ng/mL | 2160
    repeat morning labs prolactin 10 ng/mL | 2160
    repeat morning labs thyroid stimulating hormone 1.03 mIU/L | 2160
    repeat morning labs free thyroxine 1.15 ng/dL | 2160
    repeat morning labs 8 am cortisol 13.5 μg/dL | 2160
    repeat morning labs adrenocorticotropic hormone 37 pg/mL | 2160
    semen analysis | 2160
    semen analysis unremarkable | 2160
    iron studies | 2160
    iron studies normal | 2160
    pituitary magnetic resonance imaging | 2160
    symmetric ectatic cavernous portions of the internal carotid arteries | 2160
    compressing the anterior pituitary gland | 2160
    distorting the normal anatomy of the anterior pituitary gland | 2160
    brain magnetic resonance angiography | 2160
    no aneurysm | 2160
    no malformation of the cavernous internal carotid arteries | 2160
    subcutaneous semaglutide | 2160
    semaglutide 0.25 mg weekly | 2160
    titrated to 1 mg weekly | 2160
    treatment of obesity | 2160
    30 lb weight loss | 2160
    body mass index 33.05 | 2160
    testosterone levels did not improve | 2160
    weight loss | 2160
    sleep apnea treatment | 2160
    testosterone replacement therapy not reinitiated | 2160
    future fertility goals | 2160
    normal semen analysis | 2160
    hypogonadotropic hypogonadism | 2160
    due to intracranial kissing carotid arteries | 2160
    all other etiologies of hypogonadism ruled out | 2160
    hypopituitarism | 2160
    pituitary function evaluation | 2160
    no multiplicity of interest | 2160
    informed consent obtained | 2160