35 years old | 0
    male | 0
    presented for medical weight-loss management | 0
    no medical illness | 0
    taking Liraglutide (Saxenda) | 0
    SC solution multidose pen | 0
    0.6 mg in the first week | 0
    1.2 mg in the second week | 168
    1.8 mg in the third week | 336
    2.4 mg in the fourth week | 504
    3.0 mg in the fifth week | 672
    maintained on low-calorie diet | 0
    not exceeded 1,500 calories/day | 0
    mild exercise | 0
    walking 45 min three times per week | 0
    weight 118 kg | 0
    height 171 cm | 0
    body mass index (BMI) 40.4 | 0
    weight 102 kg | 1080
    BMI 34.9 | 1080
    weight loss 13.55% | 1080
    no remarkable blood analysis | 1080
    no remarkable urine analysis | 1080
    no remarkable lipid profile | 1080
    no remarkable liver function tests | 1080
    WBC 6.62×109/L | 0
    WBC 6.2×109/L | 1080
    Platelets 296×109/L | 0
    Platelets 300×109/L | 1080
    Hb 16.1 g/dL | 0
    Hb 15.8 g/dL | 1080
    Fasting glucose 5.5 mmol/L | 0
    Fasting glucose 5.1 mmol/L | 1080
    Urea 4.5 mmol/L | 0
    Urea 5.5 mmol/L | 1080
    Creatinine 65 µmol/L | 0
    Creatinine 67 µmol/L | 1080
    Uric acid 341 µmol/L | 0
    Uric acid 339 µmol/L | 1080
    Cholesterol 5.2 mmol/L | 0
    Cholesterol 5.1 mmol/L | 1080
    Triglycerides 1.1 mmol/L | 0
    Triglycerides 1 mmol/L | 1080
    Sodium 133 mmol/L | 0
    Sodium 138 mmol/L | 1080
    Potassium 4.5 mmol/L | 0
    Potassium 3.8 mmol/L | 1080
    Chloride 101 mmol/L | 0
    Chloride 105 mmol/L | 1080
    Total bilirubin 26 µmol/L | 0
    Total bilirubin 20 µmol/L | 1080
    AST 36 IU/L | 0
    AST 36 IU/L | 1080
    ALT 51 IU/L | 0
    ALT 40 IU/L | 1080
    ALP 60 IU/L | 0
    ALP 65 IU/L | 1080
    reduction in body weight 5%–10% | 1080
    improves risk factors for cardiovascular disease | 1080
    elevated blood glucose | 0
    blood pressure | 0
    plasma triglyceride concentrations | 0
    Liraglutide maintained weight loss | 1080
    Liraglutide induced further weight loss | 1080
    improvements in CVD risk factors | 1080
    Liraglutide 3 mg/day | 672
    improved maintenance of lost weight | 1080
    compared with placebo | 0
    improved weight maintenance | 1080
    induced additional reductions in CVD risk factors | 1080
    waist circumference | 0
    adding Liraglutide to lifestyle counseling | 0
    average 8.9- to 13.3-lb greater weight loss | 0
    obese | 0
    overweight | 0
    hyperlipidemia | 0
    hypertension | 0
    diabetes | 0
    short-term use 05 weeks | 0
    Liraglutide up to 3-mg dose | 672
    started with 0.6 mg/day | 0
    increased by 0.6 mg in every week | 0
    up to 3 mg | 672
    restricted-calorie diet | 0
    mild exercise | 0
    results in 13.55% weight loss | 1080
    patient consent | 0
    consent for images and clinical information | 0
    names and initials will not be published | 0
    anonymity cannot be guaranteed | 0
    financial support nil | 0
    no conflicts of interest | 0
    acknowledgements | 0
    <|eot_id|>
    