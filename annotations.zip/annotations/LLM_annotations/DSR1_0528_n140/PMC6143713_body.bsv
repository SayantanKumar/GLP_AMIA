60 years old| 0
    man| 0
    presented to the dermatology clinic| 0
    persistent nodules of the abdomen| 0
    persistent nodules of the left thigh| 0
    exenatide extended release weekly injections| -1344
    denied fevers| 0
    denied chills| 0
    denied lymphadenopathy| 0
    denied systemic allergic symptoms| 0
    diabetes mellitus type II| 0
    hypertension| 0
    dyslipidemia| 0
    nonalcoholic steatohepatitis| 0
    metformin| -1344
    liraglutide| -1344
    dulaglutide| -1344
    first nodule occurred| -1344
    no improvement over time| -1344
    nodules extremely pruritic| 0
    nodules mild discomfort| 0
    large firm 5.5-cm × 4-cm subcutaneous nodule on left side of abdomen| 0
    5 other 2.0- to 4.0-cm deep nodules palpated from right abdomen| 0
    5 other 2.0- to 4.0-cm deep nodules palpated from left abdomen| 0
    5 other 2.0- to 4.0-cm deep nodules palpated from left thigh| 0
    slight erythema| 0
    warmth| 0
    exenatide discontinued| -336
    betamethasone 0.5% cream| -336
    Zyrtec| -336
    no improvement| -336
    requested excision| 0
    pruritus no longer bearable| 0
    excisional biopsy taken from nodule on right abdomen| 0
    inject superior right abdominal nodule with intralesional triamcinolone| 0
    lobular and septal panniculitis| 0
    mononuclear cells| 0
    prominent admixed eosinophils| 0
    dermal hypersensitivity reaction| 0
    moderate predominantly perivascular lymphohistiocytic infiltrate| 0
    admixed eosinophils| 0
    occasional plasma cells| 0
    Periodic acid-Schiff stain negative| 0
    acid-fast bacilli stain negative| 0
    telephone call 2 weeks after visit| 168
    worsening erythema surrounding biopsy site| 168
    yellow thickened drainage| 168
    started doxycycline| 168
    started 6-week prednisone course| 168
    addition dapsone| 168
    discontinued both medications after approximately 1 week| 192
    worsening lower extremity edema| 192
    followed up in dermatology clinic 6 weeks after initial evaluation| 1008
    great improvement within nodule treated with intralesional triamcinolone| 1008
    nodule measured 0.8 cm| 1008
    greater than 50% improvement in size| 1008
    remaining nodules similar in size| 1008
    overlying erythema no longer appreciated| 1008
    each nodule injected with triamcinolone| 1008
    returned 6 weeks later| 2016
    significant improvement of all nodules| 2016
    2 subtle less than 0.5 cm persistent nodules on right abdomen| 2016
    2 subtle less than 0.5 cm persistent nodules on left abdomen| 2016
    injected again with triamcinolone| 2016
    pruritus resolved| 2016
    discomfort resolved| 2016
    no skin atrophy| 2016
    well tolerated| 2016
    <|eot_id|>
    