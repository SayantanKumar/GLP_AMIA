7 years old| 0
    Japanese| 0
    boy| 0
    third child| 0
    healthy parents| 0
    non-consanguineous parents| 0
    sister no signs of diabetes| 0
    brother no signs of diabetes| 0
    parents no signs of diabetes| 0
    sister no visual impairment| 0
    brother no visual impairment| 0
    parents no visual impairment| 0
    diagnosed with DM| -35040
    polyuria| -35040
    polydipsia| -35040
    blood glucose level 682 mg/dL| -35040
    hemoglobin A1c level 12.2%| -35040
    serum fasting C-peptide level 0.30 ng/mL| -35040
    serum immunoreactive insulin concentration 0.8 µU/mL| -35040
    anti-GAD antibody negative| -35040
    anti-insulin antibody negative| -35040
    anti-IA-2 antibody negative| -35040
    anti-zinc transporter 8 antibody negative| -35040
    diagnosed with T1BDM| -35040
    treated with subcutaneous insulin injection therapy| -35040
    insulin therapy twice daily| -35040
    transitioned to basal-bolus therapy| -17520
    referred to hospital| -8760
    HbA1c level 6.9%| -8760
    serum fasting C-peptide level 0.24 ng/mL| -8760
    endogenous insulin secretion impaired but preserved| -8760
    anti-GAD antibody negative| -8760
    anti-insulin antibody negative| -8760
    anti-IA-2 antibody negative| -8760
    ophthalmologic screening| -8760
    uncorrected visual acuity 0.15 right eye| -8760
    uncorrected visual acuity 0.2 left eye| -8760
    optic disc pallor| -8760
    critical flicker frequency 23.1 Hz right eye| -8760
    critical flicker frequency 20.8 Hz left eye| -8760
    critical flicker frequency abnormal| -8760
    magnetic resonance imaging no optic nerve atrophy| -8760
    no hearing loss| -8760
    no urinary tract malformations| -8760
    no DI| -8760
    no psychiatric symptoms| -8760
    suspected WS| -8760
    WFS1 gene analysis| 0
    INS gene analysis| 0
    KCNJ11 gene analysis| 0
    ABCC8 gene analysis| 0
    blood samples collected| 0
    genomic DNA obtained| 0
    father refused genetic analysis| 0
    study approved| 0
    informed consent obtained| 0
    direct sequencing| 0
    no variants INS gene| 0
    no variants KCNJ11 gene| 0
    no variants ABCC8 gene| 0
    two heterozygous variants WFS1 gene| 0
    variant c.2483delinsGGA| 0
    variant p.Ile828Arg fs*35| 0
    variant c.1247T>A| 0
    variant p.Ile416Asn| 0
    allele frequency 6.98×10-6 gnomAD| 0
    allele frequency 7.96×10-5 TOPmed| 0
    predicted damaging Polyphen-2| 0
    predicted deleterious PROVEAN| 0
    compound heterozygous variants| 0
    c.2483delinsGGA pathogenic| 0
    c.1247T>A likely pathogenic| 0
    mother c.2483delinsGGA variant| 0
    diagnosed with WS| 0
    