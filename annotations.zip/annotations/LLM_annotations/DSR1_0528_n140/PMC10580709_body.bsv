40 years old | 0
    male | 0
    type 1 diabetes mellitus | 0
    obesity | 0
    hypertension | 0
    dyslipidemia | 0
    nausea | 0
    vomiting | 0
    began Wegovy 1.7 mg | -48
    chills | -48
    nausea | -48
    vomiting | -48
    diarrhea | -48
    presented to ED | -24
    blood glucose 303 mg/dL | -24
    anion gap 16 mEq/L | -24
    beta-hydroxybutyrate 1.4 mmol/L | -24
    nontoxic appearing | -24
    denied abnormal food consumption | -24
    Dexcom 6 continuous glucose monitor | -24
    insulin pump | -24
    10 units insulin after meals | -24
    12 units basal insulin over 24 hours | -24
    insulin pump functional | -24
    conservative management | -24
    discharged home | -24
    nausea control | -24
    presented to ED | 0
    same worsening symptoms | 0
    mild leukocytosis | 0
    blood glucose 171 mg/dL | 0
    anion gap 16 mEq/L | 0
    beta-hydroxybutyrate 1.8 mmol/L | 0
    discharged home | 0
    nausea control | 0
    returned to ED | 24
    worsening symptoms | 24
    unable to keep anything down | 24
    blood glucose levels average 150 mg/dL | 24
    insulin pump received less than 1 unit above basal | 24
    unable to eat without vomiting | 24
    did not give postprandial insulin | 24
    chills | 24
    nausea | 24
    vomiting | 24
    body aches | 24
    diarrhea with eating or drinking | 24
    no prior history of DKA | 24
    tachycardia | 24
    mild hypertension | 24
    normothermia | 24
    history of small bowel obstruction | 0
    electrocardiogram | 24
    troponin testing | 24
    no acute coronary syndrome | 24
    persistent leukocytosis | 24
    afebrile | 24
    anion gap 18 mEq/L | 24
    blood glucose 158 mg/dL | 24
    beta-hydroxybutyrate 2 mmol/L | 24
    lipase normal | 24
    chronic marijuana usage | 0
    venous blood gas pH 7.34 | 24
    PaCO2 42.3 mm Hg | 24
    PaO2 31.2 mm Hg | 24
    HCO3– 22.2 mMol/L | 24
    base excess -3.5 mMol/L | 24
    DKA diagnosis | 24
    received 2 liters IV fluids | 24
    admitted to family medicine service | 24
    insulin drip with 5% dextrose IV fluids | 24
    insulin bolus not used | 24
    anion gap trended every 4 hours | 24
    insulin drip stopped | 48
    insulin pump restarted | 48
    good glucose control | 48
    began eating | 48
    dextrose-containing IV fluid stopped | 48
    tolerate regular diet | 48
    nausea resolved | 48
    feeling well | 48
    discharged home | 72
    follow-up with endocrinologist | 72
    no shortness of breath | 0
    denies chest pain | 0
    