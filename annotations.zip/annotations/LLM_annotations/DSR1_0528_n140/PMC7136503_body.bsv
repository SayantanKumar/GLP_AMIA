18 years old| 0
    female| 0
    dyspnea| -336
    diffuse cellulitis in abdomen| -336
    diffuse cellulitis in both legs| -336
    birth at 40 weeks| -157680
    cesarean section| -157680
    birth weight 1.9 kg| -157680
    hypotonia| -157680
    poor oral intake| -157680
    infancy| -157680
    rapid weight gain| -157680
    childhood| -157680
    intellectual disability| -157680
    Prader-Willi syndrome| -35040
    paternal deletion| -35040
    methylation test| -35040
    fluorescence in situ hybridization for 15q11-q13| -35040
    advanced bone age| -35040
    intelligence quotient 30| -35040
    type 2 diabetes mellitus| -17520
    hypertension| -17520
    metformin| -17520
    calcium channel blocker| -17520
    height 143 cm| -336
    weight 145 kg| -336
    BMI 71 kg/m2| -336
    blood pressure 190/100 mmHg| -336
    heart rate 115 beats/min| -336
    respiratory rate 24 breaths/min| -336
    body temperature 36℃| -336
    unable to walk unaided| -336
    unable to sit unaided| -336
    joint pain| -336
    massive cellulitis in abdomen| -336
    massive cellulitis in legs| -336
    body weight increased 20 kg| -336
    reduced physical activity| -336
    ampicillin/sulbactam| -336
    daily calorie intake 800 kcal/day| -168
    body weight 164 kg| -168
    dyspnea aggravated| -168
    mechanical ventilation| 0
    calorie intake 200 kcal/day| 0
    furosemide 40 mg every 8 hours| 0
    fluid restriction 1000 mL/day| 0
    massive bodyweight reduction| 0
    weight loss 26 kg| 480
    extubation| 480
    electrolytes monitored| 0
    sodium 135–142 mEq/L| 0
    potassium 3.3–4.0 mEq/L| 0
    pituitary function test| 0
    primary amenorrhea| 0
    hypopituitarism| 0
    growth hormone deficiency| 0
    gonadotropin deficiency| 0
    growth hormone 1.33 IU/day| 480
    estrogen 0.125 mg/day| 480
    metformin 1500 mg/day| 480
    liraglutide| 480
    glycosylated hemoglobin 7.3%| 480
    liraglutide 0.6 mg/day| 480
    liraglutide increased to 1.2 mg/day| 480
    physical therapy| 480
    aerobic exercise| 480
    pulmonary rehabilitation| 480
    discharged| 2160
    weight 104 kg| 2160
    BMI 50.8 kg/m2| 2160
    glycosylated hemoglobin 4.8%| 2160
    BMI 48.5 kg/m2| 8760
    diet 1000 kcal/day| 8760
    carbohydrates 100 g| 8760
    proteins 48 g| 8760
    fat 42 g| 8760
    regular mealtimes| 8760
    expected food amounts| 8760
    exercise daily for 1 hour| 8760
    waist circumference reduction 7 cm| 8760
    weight loss 62.7 kg| 8760
    BMI reduction 31.7 kg/m2| 8760
    