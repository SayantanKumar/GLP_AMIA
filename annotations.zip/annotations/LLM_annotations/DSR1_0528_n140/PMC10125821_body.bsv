58 years old | 0
    female | 0
    referred to hospital | 0
    chest pain | 0
    VSD diagnosed | -504
    VSD followed | -504
    VSD closed | -131400
    DCRV detected | -131400
    TTE performed | -131400
    pressure gradient 21 mmHg | -26280
    pressure gradient 57 mmHg | -13140
    pressure gradient 32 mmHg | -4320
    mild dyspnea on exertion | -131400
    hypertension diagnosed | -175200
    diabetes diagnosed | -148920
    dyslipidemia diagnosed | -17520
    candesartan | 0
    nifedipine | 0
    atenolol | 0
    doxazosin mesylate | 0
    atorvastatin | 0
    metformin | 0
    ipragliflozin L-proline | 0
    glimepiride | 0
    semaglutide | 0
    blood pressure 94/55 mmHg | 0
    heart rate 88 bpm | 0
    oxygen saturation 98% | 0
    chest X-ray | 0
    cardiac enlargement | 0
    no lung congestion | 0
    ECG | 0
    ST elevation | 0
    leads II | 0
    leads III | 0
    leads aVF | 0
    TTE | 0
    akinesis | 0
    basal inferior LV myocardium | 0
    DCRV | 0
    no VSD | 0
    troponin I elevated | 0
    CK elevated | 0
    CK-MB elevated | 0
    acute myocardial infarction suspected | 0
    coronary angiography | 0
    LAD stenosis | 0
    RCA occlusion | 0
    PCI performed | 0
    RCA stented | 0
    CK elevated | 48
    CK-MB elevated | 48
    ST elevation right precordial leads | 0
    vital signs stable | 0
    no RV infarction | 0
    TTE | 96
    RV stenosis | 96
    pressure gradient 31 mmHg | 96
    CT | 96
    RV stenosis | 96
    RV hypertrophy | 96
    no other anomalies | 96
    right heart catheterization | 168
    pressure gradient 58 mmHg | 168
    no heart failure | 168
    no atrioventricular block | 168
    cardiac rehabilitation | 168
    discharged | 168
    MRI | 1488
    LGE | 1488
    inferior LV myocardium | 1488
    RV myocardium | 1488
    DCRV repair | 1488
    CABG | 1488
    pressure gradient 5.7 mmHg | 1488
    pressure gradient 5.7 mmHg | 1680
    