59 years old | 0
    African American | 0
    male | 0
    presented to the emergency department | 0
    unilateral left-sided tongue swelling | 0
    difficulty swallowing | 0
    throat tightness | 0
    tongue swelling over the course of an hour | -1
    no dyspnea | 0
    no abdominal pain | 0
    no nausea | 0
    no vomiting | 0
    no syncope | 0
    no cutaneous symptoms | 0
    no rash | 0
    no hives | 0
    no history of angioedema | 0
    no food allergies | 0
    no latex allergies | 0
    no recent insect stings | 0
    no family history of angioedema | 0
    hydrocodone | 0
    rheumatoid arthritis pain | 0
    metformin | 0
    exenatide | 0
    insulin glargine | 0
    diabetes mellitus | 0
    daily aspirin | 0
    Lotrel | 0
    amlodipine besylate | 0
    benazepril | 0
    calcium channel blocker | 0
    ACEI | 0
    hypertension | 0
    daily basis for the past 5 years | -43800
    rapidly evaluated | 0
    intravenous access obtained | 0
    management for histamine-mediated angioedema | 0
    methylprednisolone 125 mg IV | 0
    diphenhydramine 25 mg IV | 0
    epinephrine 1 μg IV | 0
    no improvement | 0.25
    additional 9 μg epinephrine IV | 0.25
    no response | 0.25
    condition decline | 0.58
    airway collapse imminent | 0.58
    ranitidine 150 mg IV | 0.58
    C1-INH | 0.58
    Berinert | 0.58
    3000 U | 0.58
    20 U/kg IV | 0.58
    response noted | 0.83
    reduction of swelling | 0.83
    resolution of dysphagia | 0.83
    admitted to medical intensive care unit | 0.83
    observation overnight | 0.83
    evaluation by otolaryngology specialist | 0.83
    complement levels drawn | 0.83
    C4 level 35 mg/dL | 0.83
    no abnormalities | 0.83
    C1-INH functionality 105% mean normal | 0.83
    diagnosis of ACEI-AAE | 0.83
    discharged | 24
    scheduled follow-up with allergy department | 24
    discontinue ACEIs | 24
    avoid future use of ACEIs | 24
    transitioned to valsartan/hydrochlorothiazide | 24
    160 mg/25 mg | 24
    blood pressure control | 24
    no recurrence of angioedema | 8760
    blood pressure well controlled | 8760
    rheumatoid arthritis | -43800
    diabetes mellitus | -43800
    hypertension | -43800
    ACEI therapy | -43800
    angioedema episode | -43800
    ACEI associated angioedema | -43800
    ACEI induced angioedema | -43800
    ACEI-AAE | -43800
    ACEI discontinuation | 0.83
    conventional therapy failed | 0
    treated with C1-INH | 0.58
    rapid resolution | 0.83
    no institutional review board approval | 0
    PubMed search | 0
    reviewed literature | 0
    discussed pathophysiology | 0
    overview of treatments | 0
    clinical presentation | 0
    risk of ACEI-AAE 0.1 to 0.7% | 0
    leading cause of drug-induced angioedema | 0
    25 to 40% of emergency department visits for angioedema | 0
    time frame varies | 0
    may occur at any time | 0
    after 5 years of ACEI therapy | -43800
    two-thirds within first 3 months | -2190
    asymmetric | 0
    nonpitting swelling | 0
    subcutaneous tissues | 0
    submucosal tissues | 0
    lips | 0
    tongue | 0
    face | 0
    intestines | 0
    episodic abdominal pain | 0
    absence of itching | 0
    absence of urticaria | 0
    episodic | 0
    predictable time course | 0
    swelling developed over several hours | 0
    develops over minutes to hours | 0
    peak in symptoms | 0
    resolution over 24 to 72 hours | 0
    complete resolution unpredictable | 0
    may take days | 0
    duration 2-5 days | 0
    resolves spontaneously | 0
    requires no intervention | 0
    bradykinin role | 0
    inflammatory vasoactive peptide | 0
    increased capillary permeability | 0
    potent vasodilator | 0
    ACEIs block ACE | 0
    block kininase II | 0
    impacts renin-angiotensin-aldosterone pathway | 0
    diminishes degradation of bradykinin | 0
    liver produces angiotensinogen | 0
    converted to angiotensin I | 0
    angiotensin I metabolized to angiotensin II | 0
    angiotensin II causes vasoconstriction | 0
    stimulation of angiotensin I and II receptor | 0
    ACE primary peptidase for bradykinin degradation | 0
    angiotensin II participates in inactivation of bradykinin | 0
    ACEI leads to increased bradykinin | 0
    decreased production of angiotensin II | 0
    elevated bradykinin | 0
    release of nitric oxide | 0
    release of prostaglandins | 0
    vasodilatation | 0
    hypotension | 0
    elevated plasma bradykinin activity | 0
    stimulate vasodilation | 0
    increase vascular permeability | 0
    plasma extravasation | 0
    submucosal tissue | 0
    leads to angioedema | 0
    risk factors | 0
    African American ethnicity | 0
    daily aspirin use | 0
    previous episodes of angioedema | 0
    age >65 years | 0
    nonsteroidal anti-inflammatory use | 0
    female sex | 0
    smoking | 0
    seasonal allergies | 0
    mechanistic target of rapamycin inhibitor use | 0
    transplantation | 0
    underlying C1-inhibitor deficiency | 0
    reduced risk in diabetes | 0
    primary treatment discontinuation of drug | 0
    management of airway | 0
    spontaneously resolves within 24-72 hours | 0
    never resume ACEI | 0
    initial treatment as histamine-mediated | 0
    antihistamines | 0
    glucocorticoids | 0
    epinephrine | 0
    first-line treatment | 0
    ineffective for bradykinin-mediated | 0
    no medication approved | 0
    management debatable | 0
    symptoms progress | 0
    threaten airway | 0
    use of synthetic bradykinin B2-receptor agonists | 0
    kallikrein inhibitors | 0
    fresh frozen plasma | 0
    C1-esterase inhibitors | 0
    icatibant | 0
    synthetic bradykinin B2-receptor antagonist | 0
    approved for HAE | 0
    effective for ACEI-AAE | 0
    efficacious in first few hours | 0
    ecallantide | 0
    recombinant protein | 0
    inhibits plasma kallikrein | 0
    prevents breakdown of high-molecular-weight kininogen | 0
    downregulation of high-molecular-weight kininogen | 0
    FFP | 0
    supplies C1-INH and ACE | 0
    catabolize bradykinin | 0
    C1-INH | 0
    inactivates plasma kallikrein | 0
    inactivates factor XIIa | 0
    modulates vascular permeability | 0
    prevents generation of bradykinin | 0
    counteracts accumulation of bradykinin | 0
    effective in case reports | 0
    resolution 20 minutes to 2 hours | 0
    dosing 20 U/kg | 0
    improvement after infusion | 0
    underdosing | 0
    conclusion | 0
    occurrence accounts for up to 40% of ED visits | 0
    no drug therapy approved | 0
    management ineffective | 0
    drugs for HAE effective | 0
    prevent need for intervention | 0
    icatibant | 0
    ecallantide | 0
    FFP | 0
    C1-INH | 0
    adds to literature | 0
    halts progression | 0
    prevents airway compromise | 0
    rapid resolution | 0
    no conflicts of interest | 0
    no external funding | 0
    private views | 0