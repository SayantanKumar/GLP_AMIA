37 years old | 0
    woman | 0
    presented | 0
    disequilibrium | -336
    unsteadiness | -336
    difficulty closing both eyes | -336
    right lip numbness | -336
    sequential bilateral hearing impairment | -336
    slurred speech | -336
    denied limb weakness | 0
    denied limb numbness | 0
    denied headache | 0
    denied neck stiffness | 0
    denied photophobia | 0
    denied nausea | 0
    denied vomiting | 0
    denied visual changes | 0
    denied fever | 0
    denied rash | 0
    denied lymph node swelling | 0
    denied night sweats | 0
    10 kg weight loss | -720
    type 2 diabetes mellitus | -168
    commenced metformin | -168
    commenced gliclazide | -168
    commenced dulaglutide | -168
    improved diabetic control | -168
    morbid obesity | 0
    weight 96 kg | 0
    body mass index 40 kg/m2 | 0
    asthma | 0
    eczema | 0
    not taking steroids | 0
    not taking immunosuppressant medication | 0
    born in subtropical region | 0
    raised in subtropical region | 0
    denied significant travel history | 0
    engaging in unprotected sex | 0
    denied intravenous drug use | 0
    bilateral cranial neuropathies | 0
    trigeminal nerve involvement | 0
    abducens nerve involvement | 0
    facial nerve involvement | 0
    vestibulocochlear nerve involvement | 0
    hypoglossal nerve involvement | 0
    lateral gaze restricted bilaterally | 0
    bilateral upper facial weakness | 0
    bilateral lower facial weakness | 0
    impaired eyebrow raise | 0
    impaired eye closure | 0
    inability to smile | 0
    Weber’s test lateralised to left ear | 0
    Rinne’s test air conduction greater than bone bilaterally | 0
    tongue weak | 0
    tongue midline on protrusion | 0
    decreased sensation to light touch | 0
    decreased sensation to pinprick | 0
    V2 distribution on right side | 0
    no palpable lymphadenopathy | 0
    no splenomegaly | 0
    mild inflammation | 0
    elevated C reactive protein | 0
    elevated erythrocyte sedimentation rate | 0
    thrombocytosis | 0
    unremarkable full blood examination | 0
    unremarkable renal function | 0
    unremarkable electrolytes | 0
    unremarkable liver function tests | 0
    serum beta human chorionic gonadotropin <1.2 IU/L | 0
    haemoglobin A1c 8.7% | 0
    cerebrospinal fluid examination | 0
    normal opening pressure | 0
    elevated protein | 0
    normoglycaemia | 0
    lymphocyte predominant leucocytosis | 0
    magnetic resonance imaging brain | 0
    enhancement of trigeminal nerve | 0
    enhancement of facial nerve | 0
    enhancement of vestibulocochlear nerve | 0
    no evidence of recent infarct | 0
    no leptomeningeal enhancement | 0
    contrast-enhanced MRI spine unremarkable | 0
    CT neck unremarkable | 0
    CT chest unremarkable | 0
    CT abdomen unremarkable | 0
    CT pelvis unremarkable | 0
    no malignancy | 0
    serum TPPA positive | 0
    serum CMIA IgG positive | 0
    serum CMIA IgM positive | 0
    serum RPR titre 1:32 | 0
    consistent with active syphilis infection | 0
    CSF TPPA positive | 0
    CSF VDRL titre 1:8 | 0
    CSF Treponema pallidum PCR negative | 0
    negative workup for other infectious disorders | 0
    negative workup for autoimmune disorders | 0
    negative workup for neoplastic disorders | 0
    diagnosed with early syphilitic meningitis | 0
    multiple cranial neuropathies | 0
    denied primary syphilitic chancre | 0
    Chlamydia trachomatis detected | 0
    commenced intravenous benzylpenicillin | 0
    treated with benzylpenicillin | 0
    did not treat with steroid medication | 0
    did not develop Jarisch Herxheimer reaction | 0
    cranial neuropathies improved | 192
    treated with doxycycline | 0
    discharged | 360
    scheduled for outpatient review | 360
    serological monitoring RPR titre | 360
    consideration repeat CSF examination | 360
    