48 years old | 0
    postmenopausal | 0
    female | 0
    lateral neck pain | -240
    pain gradual onset | -240
    no radiating | -240
    no aggravating factors | -240
    no relieving factors | -240
    no fever | -240
    no throat pain | -240
    no trauma | -240
    diabetic | 0
    skipped oral hypoglycemic medication | -96
    hypothyroidism | 0
    hypertension | 0
    drinks alcohol socially | 0
    thyroxine 87.5 microgram daily | 0
    liraglutide 5 mg daily | 0
    repaglinide 1 mg thrice daily | 0
    aspirin 75 mg daily | 0
    atorvastatin 10 mg daily | 0
    conscious | 0
    calm | 0
    cooperative | 0
    well-oriented | 0
    vitals stable | 0
    localized ill-defined area | 0
    left neck | 0
    size 3x2 cm | 0
    tender | 0
    local rise in temperature | 0
    crepitations | 0
    distal neurovascular intact | 0
    palpable lymph nodes | 0
    leukocyte count 30330 | 0
    neutrophils 87% | 0
    hemoglobin 12.5 g/dl | 0
    platelets 166000/ml | 0
    random blood sugar 502 mg/dl | 0
    serum urea 63 | 0
    serum creatinine 3.5 | 0
    serum sodium normal | 0
    serum potassium normal | 0
    urine sugar +++ | 0
    urine protein + | 0
    urine acetone positive | 0
    serum protein 6.4 g/dl | 0
    serum albumin 3.3 g/dl | 0
    arterial pH 7.067 | 0
    pCO2 8.7 | 0
    pO2 77% | 0
    serum bicarbonate 12.6 | 0
    diabetic ketoacidosis | 0
    neck abscess | 0
    admitted to medical ICU | 0
    insulin therapy | 0
    IV fluids | 0
    piperacillin | 0
    tazobactam | 0
    ultrasonography neck | 0
    large ill-defined mass | 0
    left neck | 0
    size 3x6 cm | 0
    separate from parotid | 0
    separate from submandibular glands | 0
    neck exploration | 24
    debridement | 24
    general anesthesia | 24
    wound swab | 24
    pseudomonas aeruginosa | 24
    sensitive amikacin | 24
    sensitive ciprofloxacin | 24
    ciprofloxacin 200 mg IV twice daily | 24
    amikacin 500 mg IV thrice daily | 24
    histopathology | 24
    fibrofatty tissue | 24
    inflammatory cells | 24
    neutrophils | 24
    histiocytes | 24
    focal necrosis | 24
    necrotizing fasciitis | 24
    daily dressing | 24
    oral feeding | 168
    leukocyte count normal | 168
    hemoglobin normal | 168
    platelets normal | 168
    renal function normal | 168
    blood sugar 166 mg/dl | 168
    wound healing | 168
    discharged | 168
    wound doing well | 504
    blood sugar doing well | 504
    