36 years old | 0
    woman | 0
    presented | 0
    rash | -1440
    burning pain | -1440
    minimally pruritic | -1440
    no systemic symptoms | 0
    no oral lesions | 0
    obesity | 0
    BMI 36.5 kg/m2 | 0
    nephrolithiasis | 0
    multivitamins | 0
    fish oil | 0
    levonorgestrel IUD | 0
    no recent medication changes | 0
    compounded semaglutide initiated | -2160
    weekly injections | -2160
    visited urgent care | -1440 to 0
    clotrimazole-betamethasone 1%/0.05% cream | -1440 to 0
    ketoconazole 2% cream | -1440 to 0
    hydrocortisone 2.5% cream | -1440 to 0
    fluconazole 150 mg | -1440 to 0
    minimal benefit | 0
    erythematous patches | 0
    minimal fine scale | 0
    no vesicles | 0
    no pustules | 0
    no satellite lesions | 0
    no lymphadenopathy | 0
    no mucosal lesions | 0
    potassium hydroxide examination deferred | 0
    differential diagnosis: contact dermatitis | 0
    differential diagnosis: symmetrical drug-related intertriginous and flexural exanthema | 0
    differential diagnosis: erythema annulare centrifugum | 0
    hydrocortisone 2.5% ointment started | 0
    prednisone 40 mg started | 0
    21-day taper | 0
    rash spread down abdomen | 10
    ongoing burning pain | 10
    treatment stopped | 10
    skin biopsy planned | 10
    returned for biopsy | 504
    missed 2 consecutive doses of semaglutide | 504
    rash resolving | 504
    rash reappeared | 504
    annular erythematous patches | 504
    prominent trailing scale | 504
    punch biopsy | 504
    subcorneal pustular dermatosis | 504
    parakeratosis | 504
    mild acanthosis | 504
    mild spongiosis | 504
    lymphocytic infiltrate | 504
    neutrophilic infiltrate | 504
    periodic acid-Schiff stain negative | 504
    differential diagnosis: AGEP | 504
    differential diagnosis: Sneddon-Wilkinson disease | 504
    differential diagnosis: early evolving pustular psoriasis | 504
    diagnosis: AGEP sine pustules | 504
    Naranjo score 9 | 504
    EuroSCAR score 6 | 504
    semaglutide discontinued | 504
    eruption cleared | 672
    patch testing deferred | 672
    durable clearance | 672
    patient preference | 672
    