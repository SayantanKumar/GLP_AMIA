61 years old|0
    male|0
    type 2 diabetes mellitus|0
    hypertension|0
    hyperlipidemia|0
    amlodipine|0
    valsartan|0
    atorvastatin|0
    pioglitazone|0
    metformin|0
    insulin detemir|0
    liraglutide|0
    dapagliflozin|0
    no calcium supplementation|0
    no vitamin D supplementation|0
    no proton pump inhibitors|0
    no histamine H2-receptor antagonists|0
    no known allergies|0
    properly hydrating|0
    no palpitations|0
    no fatigue|0
    no abdominal pain|0
    no polyuria|0
    no impaired concentration|0
    no constipation|0
    no dysuria|0
    no flank pain|0
    no history of nephrolithiasis|0
    no weight loss|0
    no night sweats|0
    no dyspnea|0
    no cough|0
    no rash|0
    no smoking|0
    no alcohol|0
    no recreational drugs|0
    physical examination unremarkable|0
    vital signs within normal limits|0
    no evidence of dehydration|0
    calcium 11.1 mg/dL|-24
    albumin 4.7 g/dL|-24
    blood urea nitrogen 21 mg/dL|-24
    creatinine 0.91 mg/dL|-24
    chloride 101 mmol/L|-24
    fasting glucose 139 mg/dL|-24
    sudden-onset epigastric burning|-48
    Tums 200 mg calcium (500 mg)|-48
    six chewable tables of Tums|-48
    not taking Tums regularly|-48
    not had any Tums in weeks|-48
    refrain from Tums|0
    refrain from over-the-counter antacids|0
    increase oral hydration|0
    no palpitations|0
    no tachycardia|0
    no electrocardiography ordered|0
    repeat blood work|120
    calcium 9.3 mg/dL|120
    ionized calcium 4.8 mg/dL|120
    parathyroid hormone intact 54 pg/mL|120
    urine protein electrophoresis negative|120
    serum protein electrophoresis negative|120
    no hypercalcemia before|0
    no hypercalcemia after|0
    