38 years old | 0
    female | 0
    presented to the obesity clinic at primary care for weight management | 0
    not complaining of any other medical illness other than obesity | 0
    sister and aunt brought her to the clinic | 0
    partially willing to lose weight | 0
    not gone through a structured weight-loss trial previously | 0
    attempted to lose weight through dietary instructions sourced from different social media platforms | -24
    modest efficacy | -24
    overall dissatisfactory | -24
    first-degree family history of obesity | 0
    no one else in her family had super-super obesity | 0
    resides with her aging parents and a housekeeper | 0
    height 146 cm | 0
    weight 193 kg | 0
    BMI 90.5 kg/m2 | 0
    central obesity | 0
    blood pressure normal | 0
    regular pulse | 0
    prediabetes level of blood sugar | 0
    all laboratory results normal | 0
    elevated risk of obstructive sleep apnea | 0
    STOP-BANG score | 0
    no physical activity | 0
    no muscle-strengthening exercise engagement | 0
    spent most of daytime sitting or reclining at home | 0
    objective evidence of major mobility limitations | 0
    400-m walk test | 0
    climbing one flight of stairs | 0
    daily diet consisted mainly of sugary foods and drinks | 0
    ultra-processed foods | 0
    very little intake of fruits and vegetables | 0
    sleep pattern frequently interrupted | 0
    unrefreshed 4 - 5 h of sleep | 0
    no smoking | 0
    no substance abuse | 0
    limited social connections | 0
    mental health generally stable | 0
    multidisciplinary team formed | 0
    suggested starting a structured lifestyle intervention for 6 months | 0
    adding weight loss medications liraglutide | 0
    going for surgery | 0
    metformin prescribed | 0
    continuous positive airway pressure for obstructive sleep apnea | 0
    lifestyle intervention focused on achieving a negative energy balance | 0
    plant-based diet | 0
    reduced calorie consumption | 0
    gradually increasing physical activity | 0
    patient adheres to Harvard's healthy eating plate | 0
    avoid overeating | 0
    consuming three balanced meals daily | 0
    stop eating snacks | 0
    discouraged from eating sugar-sweetened beverages | 0
    discouraged from eating high-fat foods | 0
    discouraged from eating highly processed foods | 0
    drinking 2 - 3 L of water | 0
    drinking herbal teas | 0
    walking 2 min three times daily at home | 0
    progressed to daily moderate-intensity walking for non-continuous 15 min at home | 720
    resistance training for the upper limb | 0
    10 repetitions three times daily | 0
    resistance training progressed to longer sessions | 720
    encouraged to interrupt sitting with physical activity | 0
    efforts to adjust bedtime and wake-up times | 0
    difficult to extend sleep duration | 0
    implemented incremental approach to advance sleep schedule | 0
    set wake-up time 30 min earlier | 0
    consistent use of CPAP therapy | 0
    uninterrupted sleep | 0
    increased nighttime sleep duration to 6 h | 0
    sister provided support | 0
    spent 5 days a week at sister's home | 0
    sister participated in care | 0
    purchased healthy food options | 0
    prepared nutritious meals | 0
    emphasized portion control | 0
    emphasized balanced diet | 0
    sister engaged in exercise | 0
    walking alongside the patient | 0
    participating in resistance training | 0
    attended hybrid follow-up visits every 2 weeks for first 6 months | 0
    attended monthly visits for next 6 months | 0
    measured weights in clinic monthly | 0
    lost 23 kg | 4320
    percent weight loss of 11.9% | 4320
    came unaccompanied to the clinic | 4320
    willing to continue weight management | 4320
    trusted her ability to lose weight | 4320
    liraglutide introduced | 4320
    lost additional 5 kg | 6480
    total weight loss of 28 kg | 8640
    percent weight loss of 14% | 8640
    BMI decreased to 77.4 kg/m2 | 8640
    regained ability to perform daily activities | 8640
    took care of herself | 8640
    took care of others | 8640
    