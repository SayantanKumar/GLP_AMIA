33 years old|0
    African American woman|0
    G2P0010|0
    admitted to emergency department|0
    general malaise|-72
    altered sensorium|-72
    nausea|-72
    emesis|-72
    history of class III obesity|0
    no preexisting diabetes mellitus|0
    preconception glycosylated hemoglobin level unavailable|0
    gestational diabetes mellitus diagnosed at 15 weeks|-3360
    serum glucose level 266 mg/dL after 1-hour 50-gram glucose challenge test|-3360
    HbA1C level 5.9% at GDM diagnosis|-3360
    insulin therapy initiated at week 20|-1680
    10 units neutral protamine Hagedorn insulin once daily|-1680
    5 units regular insulin 3 times daily with breakfast, lunch, dinner|-1680
    nonadherence to insulin regimen throughout pregnancy|0
    blood pressure 70/40 mmHg|0
    heart rate 150 beats/min|0
    respiratory rate 26 breaths/min|0
    dry mucus membranes|0
    decreased skin turgor|0
    serum glucose level 920 mg/dL|0
    pH 7.02|0
    anion gap level 38 mmol|0
    bicarbonate level 5.0 mEq/L|0
    serum potassium level 3.4 mEq/L|0
    large serum ketones present|0
    white blood cell count 24.13 × 10³/μL|0
    predominance of leukocytes|0
    SARS-CoV-2 polymerase chain reaction negative|0
    intrauterine fetal demise diagnosed|0
    treated with intravenous fluids|0
    continuous insulin|0
    potassium supplementation|0
    bicarbonate supplementation|0
    piperacillin-tazobactam|0
    new HbA1C level 9% obtained|0
    hypokalemia worsened to 2.5 mEq/L|0
    continuous insulin withheld until serum potassium above 3.3 mEq/L|0
    spontaneously delivered nonviable fetus|20
    DKA resolved|20
    managed with basal-bolus insulin therapy|20
    sliding scale insulin therapy|20
    decreased mental status returned to baseline|48
    history negative for diabetes mellitus before pregnancy|48
    transferred to regular medicine ward|48
    basal-bolus insulin dose increased|48
    hyperglycemia between 250-300 mg/dL|48
    glycemia reduced to 180-200 mg/dL|48
    negative antiglutamic acid decarboxylase antibodies|120
    negative islet cell antibodies|120
    negative zinc transporter 8 antibodies|120
    C-peptide level 2.4 ng/dL|120
    discharged|168
    basal insulin 25 units twice daily|168
    preprandial insulin 10 units 3 times daily|168
    metformin 500 mg twice daily|168
    outpatient follow-up visit scheduled at 1 week post discharge|168
    returned to diabetes clinic 2 months later|720
    no evidence of diabetes mellitus|720
    point of care HbA1C level 5.5%|720
    body mass index 48 kg/m²|720
    preprandial insulin discontinued|720
    basal insulin decreased to 25 units daily|720
    metformin dose increased to 1 gram twice daily|720
    glucagon-like peptide 1 receptor agonist initiated|720
    HbA1C level 5.3% at 3-month follow-up|2160
    HbA1C level 5% at 6-month follow-up|4320
    maintained on metformin 500 mg twice daily|4320
    dulaglutide 1.5 mg once a week|4320
    autopsy of nonviable fetus 10 days after discharge|240
    female fetus|240
    macrosomia|240
    bodyweight 1640 g|240
    heart weight 12.7 g|240
    pancreatic islet cell hyperplasia|240
    mild adrenal granulosa layer hyperplasia|240
    no congenital anomalies|240
    placental findings|240
    no evidence of inflammation|240
    no thrombosis of umbilical cord|240
    multiple focal hyperacute ischemic infarction|240
    small intervillous thrombi associated with peripheral parenchymal infarction|240
    mildly increased fibrin deposition on basal plate|240
    <|eot_id|>
    