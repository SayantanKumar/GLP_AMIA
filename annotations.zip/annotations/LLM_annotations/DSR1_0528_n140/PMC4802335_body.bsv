37 years old | 0
    male | 0
    morbid obesity | -26280
    laparoscopic Roux-en-Y gastric bypass | -26280
    bradycardia | 0
    asthma | 0
    gout | 0
    no diabetes | 0
    weight 183 kg | -26280
    height 185 cm | -26280
    BMI 53.5 kg/m2 | -26280
    weight loss 88 kg | -17520
    BMI 27.7 kg/m2 | -17520
    admitted to hospital | -13140
    neuroglycopenic symptoms | -13140
    plasma-glucose 1.6 mmol/l | -13140
    standard nutritional supplements | -13140
    no drugs | -13140
    rarely alcohol | -13140
    serum-cortisol normal | -13140
    thyroid function tests normal | -13140
    cerebral CT scan normal | -13140
    abdominal CT scan normal | -13140
    cardiac evaluation normal | -13140
    plasma-glucose after 72 h fast normal | -13140
    dietary modifications | -13140
    self-monitoring of blood-glucose | -13140
    hypoglycaemic episodes increased | -13140
    hospital admissions increased | -13140
    acarbose attempted | -13140
    acarbose not tolerated | -13140
    gastrointestinal side effects | -13140
    diazoxide up to 600 mg daily | -13140
    little effect | -13140
    discontinued | -13140
    dyspnea | -13140
    verapamil not considered | -13140
    subcutaneous octreotide 50 mcg 3 times daily | -13140
    less severe postprandial hyperinsulinemic hypoglycaemia | -13140
    effect attenuated | -13140
    alanine transaminase increased | -13140
    aspartate transaminase increased | -13140
    severe symptomatic hypoglycaemia daily | -13140
    hospital admission | -13140
    glucose infusions | -13140
    feeding through gastrostomy tube into remnant stomach | -13140
    laparoscopic positioning of gastrostomy tube | -13140
    subileus | -13140
    reoperated | -13140
    mixed meal test peroral | -13140
    mixed meal test via gastrostomy tube at 1 week | -13140
    mixed meal test via gastrostomy tube at 4 weeks | -13140
    recurrent abdominal pain | -13140
    dependent on continuous parenteral glucose infusions | -13140
    hypoglycemia unawareness | -13140
    reduced oral feeding | -13140
    hypoglycaemia | -13140
    increased nutrition through gastric tube | -13140
    partial reversal of Roux-en-Y gastric bypass | 0
    gastrostomy tube removed | 0
    alimentary limb transected | 0
    side-to-side anastomosis | 0
    bilio-pancreatic limb divided | 0
    new entero-entero anastomosis | 0
    mixed meal test peroral after reversal | 672
    no hypoglycaemic symptoms | 1440
    body weight 87.3 kg | 1440
    continuous glucose monitoring | 2160
    plasma-glucose levels around 5 mmol/l | 2160
    no report of hypoglycaemic symptoms | 2160
    weight 94 kg | 7200
    dyspepsia | 7200
    normal upper endoscopy | 7200
    infrequent low blood glucose levels | 7200
    lowest plasma-glucose 2.7 mmol/l | 7200
    no hypoglycaemic symptoms | 7200
    return to work | 1008
    symptoms resolved | 7200
    <|eot_id|>
    