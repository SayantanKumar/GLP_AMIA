72 years old|0
    male|0
    participated as control in clinical study|0
    no liver-related symptoms|0
    exercised regularly|0
    low intake of alcohol|0
    family members no known liver disease|0
    family members no type 2 diabetes|0
    type 2 diabetes|0
    metabolic syndrome|0
    central obesity|0
    waist circumference 100 cm|0
    raised triglycerides 1.8 mmol/L|0
    raised blood pressure|0
    systolic pressure 144 mm Hg|0
    BMI 26.1 kg/m2|0
    continuous glucose monitoring|0
    mean sensor glucose 8.0 mmol/L|0
    glucose levels within target range 96%|0
    ileocecal resection| -17520
    Crohn’s disease| -17520
    post-operative bile acid malabsorption| -17520
    CT abdomen| -17520
    no liver abnormalities| -17520
    referred to hepatologist|0
    no cirrhosis stigmata|0
    alanine aminotransferase elevated 78 U/L|0
    alkaline phosphate elevated 108 U/L|0
    gamma-glutamyl-transferase elevated 159 U/L|0
    aspartate aminotransferase normal|0
    bilirubin normal|0
    platelets normal|0
    albumin normal|0
    transient elastography|0
    liver stiffness 16.1 kPa|0
    Fibrosis 4 score 1.56|0
    fasting FibroScan repeated|0
    liver stiffness 19.8 kPa|0
    percutaneous liver biopsy|0
    mild steatosis|0
    inflammation|0
    ballooning|0
    fibrosis grade 4|0
    alcoholic cirrhosis ruled out|0
    Alcohol Use Disorder Identification Test-Consumption score 3|0
    viral hepatitis B ruled out|0
    viral hepatitis C ruled out|0
    hemochromatosis ruled out|0
    autoimmune liver diseases ruled out|0
    primary biliary cholangitis ruled out|0
    celiac disease ruled out|0
    thyroid disease ruled out|0
    other liver diseases associated with steatosis ruled out|0
    lifestyle intervention|0
    advice regarding diet|0
    advice regarding physical activity|0
    advice regarding alcohol intake|0
    did not smoke|0
    pharmacological treatment type 2 diabetes|0
    semaglutide|0
    atorvastatin|0
    empagliflozin added|0
    BMI decreased to 24.7 kg/m2|15120
    HbA1c decreased to 43 mmol/mol|15120
    total cholesterol decreased to 2.9 mmol/L|15120
    LDL decreased to 0.6 mmol/L|15120
    triglycerides decreased to 1.45 mmol/L|15120
    ALT decreased to 61 U/L|15120
    AST decreased to 37 U/L|15120
    liver stiffness decreased to 12.2 kPa|15120
    no hepatic decompensation|15120
    NASH-cirrhosis diagnosis|0
    no symptoms suggesting liver disease|0
    no clear evidence of cirrhosis|0
    patient consent obtained|0
    