62 years old|0
    male|0
    retired office worker|0
    German origin|0
    portal hypertension|0
    non-alcoholic steatohepatitis liver cirrhosis|0
    esophageal varices progressed|0
    splenic vein thrombosis|0
    stent implantation|0
    anticoagulation therapy initiated|0
    metabolic syndrome|0
    cardiovascular risk factor|0
    liver risk factor|0
    etiology of liver cirrhosis|0
    good general condition|0
    admitted|0
    scheduled revision of transjugular intrahepatic portosystemic shunt (TIPS)|0
    TIPS revision performed|0
    balloon percutaneous transluminal balloon angioplasty of TIPS performed|0
    balloon percutaneous transluminal balloon angioplasty of splenic vein stent performed|0
    post-interventional abdominal pain|0
    metamizole 1 g administered orally|0
    first intake of metamizole|0
    agranulocytosis|24
    elevated indirect bilirubin|24
    no increase of liver enzymes|24
    manual differential blood count|24
    ruled out neoplasia of the bone marrow|24
    no atypical cells|24
    individual protective reverse isolation|24
    antibiotic prophylaxis|24
    filgrastim administered subcutaneously|24
    no change in medication|24
    single application of local anesthetic (prilocaine 1% 10 mL)|0
    application of iodine-based contrast medium (Cacique 300 120 mL)|0
    metformin discontinued|-48
    anticoagulation paused|0
    decreased haptoglobin|24
    increased free hemoglobin|24
    increased lactate dehydrogenase|24
    intraluminal hemolysis|24
    repeated manual differential blood count|24
    no evidence of schistocytes|24
    no previous hematologic disease|0
    intact renal function|24
    stable platelets|24
    no evidence of microangiopathy|24
    no extracorporeal procedures|24
    excluded glucose-6-phosphate dehydrogenase deficiency|24
    excluded paroxysmal nocturnal hemoglobinuria|24
    hemoglobin electrophoresis|24
    no evidence of other hemoglobin disorders|24
    no evidence of corpuscular hemolysis|24
    no blood transfusion|24
    no hint of infectious hemolysis|24
    no evidence of foreign travel|0
    adequately elevated reticulocytes|24
    negative Coombs test|24
    hemoglobin decreased|24
    no symptoms of anemia|24
    no pectanginal symptoms|24
    metamizole-induced agranulocytosis|24
    concomitant simultaneous hemolysis|24
    rapid appropriate increase in granulocytes|48
    decrease in bilirubin to baseline levels|48
    stable cardiac function|24
    stable pulmonary function|24
    no elevated body temperature|24
    no symptoms of infection|24
    discrete increase in systemic inflammation levels|24
    increased C-reactive protein|24
    rapid improvement|48
    normalization of blood count|48
    increasing granulocytes|48
    significantly reduced hemolysis parameters|48
    no administration of intravenous immunoglobulins|48
    no administration of steroids|48
    computed tomography performed|48
    post-interventional imaging of TIPS performed|48
    post-interventional imaging of splenic vein stent performed|48
    good therapeutic success|48
    discharged|120
    no urticaria|24
    no exanthema|24
    no dyspnea|24
    no vomiting|24
    full recovery|120