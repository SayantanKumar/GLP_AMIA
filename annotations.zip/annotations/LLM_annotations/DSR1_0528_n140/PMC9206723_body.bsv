39 years old| 0
    female| 0
    presented to emergency department| 0
    polyuria| -168
    polydipsia| -168
    8 kg weight loss| -168
    usual weight 54 kg| -168
    body mass index 24 kg/m²| -168
    blood glucose 340 mg/dL| 0
    hemoglobin A1c 12.4%| 0
    not ketotic| 0
    aunt had type 2 diabetes| -168
    parents no diabetes| -168
    3 siblings no diabetes| -168
    gastric ulcer disease| -168
    4 miscarriages| -168
    1 daughter born prematurely| -168
    daughter birth weight 1.9 kg| -168
    daughter treated for vesicoureteral reflux| -168
    thyroid-stimulating hormone 0.01 mU/L| 0
    aspartate aminotransferase 114 UI/L| 0
    alanine aminotransferase 117 UI/L| 0
    gamma-glutamyl transferase 445 UI/L| 0
    alkaline phosphatase 420 UI/L| 0
    free triiodothyronine 8.8 pg/mL| 0
    free thyroxine 33 pg/mL| 0
    thyrotropin receptor autoantibodies positive| 0
    antithyroid peroxidase antibodies positive| 0
    heterogeneous hypervascular parenchyma on thyroid ultrasound| 0
    Graves disease| 0
    started carbimazole 60 mg per day| 0
    started propranolol 20 mg three times day| 0
    abdominal ultrasound unremarkable| 0
    viral hepatitis ruled out| 0
    autoimmune hepatitis ruled out| 0
    Wilson disease ruled out| 0
    hemochromatosis ruled out| 0
    coeliac disease ruled out| 0
    liver elastography A0F0| 0
    biochemical liver abnormalities attributed to hyperthyroidism or seronegative autoimmune hepatitis| 0
    type 1 diabetes| 0
    started basal bolus insulin therapy| 0
    no microvascular complications of diabetes| 0
    gained weight back| 720
    hemoglobin A1c 5.7%| 720
    hypoglycemic episodes once daily| 720
    hypoglycemia grade 2| 720
    decrease insulin doses to half| 720
    antiglutamate decarboxylase antibodies negative| 720
    anti-islet antigen 2 antibodies negative| 720
    diagnosis of type 1 diabetes in doubt| 12960
    tight glycemic control| 12960
    very low insulin doses 0.15 U/kg/day| 12960
    antiglutamate decarboxylase D antibodies negative| 12960
    anti-islet antigen 2 antibodies negative| 12960
    anti-zinc transporter 8 autoantibodies negative| 12960
    human leukocyte antigen protective haplotype DRB1*15-DQB1*0602| 12960
    considered type 2 diabetes| 12960
    high-density lipoprotein-cholesterol 0.72 g/L| 12960
    triglycerides 0.56 g/L| 12960
    body mass index 24 kg/m²| 12960
    weaned off insulin| 12960
    started glimepiride| 12960
    hyperglycemia predominantly postprandial| 12960
    thyroid hormones normal| 12960
    thyrotropin receptor antibodies negative| 12960
    carbimazole stopped| 12960
    diabetes well controlled| 12960
    hemoglobin A1c 6.7-7.9%| 12960
    glimepiride 1-3 mg/day| 12960
    hypoglycemia 5/week| 12960
    hypoglycemia grade 2| 12960
    hypoglycemia grade 3| 12960
    thyroid hormones normal| 12960
    cholestatic pattern worsened| 12960
    hepatocellular pattern worsened| 12960
    workup autoimmune hepatitis negative| 86400
    workup coeliac disease negative| 86400
    biliary magnetic resonance imaging unremarkable| 86400
    4 mm hemorrhagic cyst at left kidney| 86400
    liver biopsy normal| 86400
    started ursodeoxycholic acid| 86400
    acute worsening of glycemic control| 87600
    hemoglobin A1c 12.4%| 87600
    resumed insulin glargine| 87600
    hemoglobin A1c 7.7%| 89520
    hypomagnesemia 0.62 mmol/L| 87600
    hypothesis HNF1B-MODY| 87600
    heterozygous deletion HNF1B gene| 89520
    diabetes poorly controlled| 114480
    hemoglobin A1c 9.2%| 114480
    glargine 14 units| 114480
    glimepiride 4 mg| 114480
    serum creatinine 54 µmol/L| 114480
    microalbuminuria physiological range| 114480
    renal morphology normal| 114480
    residual insulin secretion| 114480
    C peptide fasting 0.181 nmol/L| 114480
    C peptide 2 hours 0.654 nmol/L| 114480
    fecal chymotrypsin normal| 114480
    fecal elastase normal| 114480
    pancreatic magnetic resonance imaging unremarkable| 114480
    pelvic ultrasonography normal| 114480
    gamma-glutamyl transferase 8x ULN| 114480
    alkaline phosphatase 2x ULN| 114480
    alanine aminotransferase 2.5x ULN| 114480
    started liraglutide| 114480
    started repaglinide 4-1-2 mg| 114480
    hemoglobin A1c 6.7%| 114720
    recurrent hypoglycemia| 114720
    decrease repaglinide to half| 114720
    hemoglobin A1c 6.6%| 119520
    weight 45 kg| 119520
    liraglutide 1.2 mg| 119520
    repaglinide 1-0-1 mg| 119520