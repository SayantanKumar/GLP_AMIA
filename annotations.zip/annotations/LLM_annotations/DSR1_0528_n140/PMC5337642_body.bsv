65 years old|0
    male|0
    admitted to the hospital|0
    generalised epileptic seizure|0
    increasingly confused in the preceding days|-48
    normal neurological examination|0
    Glasgow Coma scale 15/15|0
    increased C reactive protein|0
    CRP 5.9 mg/L|0
    normal EEG|0
    CT scan of the skull|0
    hypodense lesion in the right frontal lobe|0
    contrast-enhanced lesion in the right frontal lobe|0
    surrounded by oedema|0
    no midline shift|0
    no ventricular anomalies|0
    oncologic screening advised|0
    imaging of the chest|0
    imaging of the abdomen|0
    no primary malignancies|0
    no recurrence|0
    neurosurgical counsel|0
    MRI with diffusion-weighted imaging|0
    brain abscess diagnosed|0
    pachymeningitis diagnosed|0
    transthoracic ultrasound|0
    negative for cardiac vegetations|0
    negative for signs of infection|0
    valproate 1.5 g/day|0
    levetiracetam 1 g/day|0
    vancomycin 2 g/day|0
    ornidazole 1 g/day|0
    ceftriaxone 2 g/day|0
    stereotactic drainage|0
    MALDI-TOF spectrometry|0
    P. gingivalis as causative bacterium|0
    intraoral inspection|0
    partial dentition|0
    parodontitis|0
    apical periodontitis|0
    elements 16, 23, and 34|0
    sinus cavities normal|0
    antibiotic regimen reduced to ornidazole and ceftriaxone|0
    intravenous ornidazole 1 g/day|0
    intravenous ceftriaxone 2 g/day|0
    left hemiparesis|456
    left hemineglect|456
    increase in epileptic seizures|456
    tonic–clonic seizure|456
    deteriorated|456
    intubation|456
    intravenous sedation|456
    intracerebral abscess extending to subdural space|456
    subdural empyema|456
    spreading to occipital–parietal regions|456
    incision and drainage|456
    clinical instability|456
    total extraction of remaining dentition|456
    antibiotic treatment continued|456
    discharged from neurosurgical ward|1416
    referred for inhospital physiotherapy|1416
    prostate carcinoma|0
    radical prostatectomy|0
    adjuvant radiotherapy|0
    type 2 diabetes|0
    hypertension|0
    hypercholesterolaemia|0
    epilepsy of unknown origin during childhood|0
    acetylsalicylic acid|0
    olmesartan medoxomil|0
    rosuvastatin|0
    lixisenatide|0
    metformin|0
    gliclazide|0
    valproate reduced|0
    valproate stopped 6 months earlier|-4320
    seizure free for over 20 years|0
    no intracranial anomalies|0
    full recovery|1416
    