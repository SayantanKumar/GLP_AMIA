33 years old | 0
    female | 0
    end-stage kidney disease | 0
    referred for diabetes management | 0
    diabetes | -26280
    A1C 9.1% | -26280
    body mass index 31 kg/m2 | -26280
    glucose levels normal | -17520
    glucose levels increased moderately | -8760
    negative anti-GAD65 antibodies | 0
    negative antipancreatic islet cell antibodies | 0
    C-peptide 2.9 ng/mL fasting | 0
    C-peptide 5.2 ng/mL random | 0
    denied family history of diabetes | 0
    denied family history of renal disease | 0
    glucose control improved | 0
    diet | 0
    exercise | 0
    glucagon-like peptide-1 agonist | 0
    low doses insulin | 0
    progressive loss of kidney function | -26280
    pretransplant imaging | -70080
    bilateral renal cysts | -70080
    markedly atrophic left kidney | -70080
    imaging | -17520
    scarred native kidneys | -17520
    atrophy of body of pancreas | -17520
    atrophy of tail of pancreas | -17520
    serial sweeping transvaginal ultrasound | 0
    normal uterine body | 0
    uninterrupted endometrial stripe | 0
    abnormal fundal arcuate contour | 0
    interrupted endometrial stripe | 0
    HNF1β-associated disease | 0
    maturity-onset diabetes of the young type 5 | 0
    Renal Cysts and Diabetes Syndrome | 0
    complete deletion of entire coding sequence of gene HNF1β | 0
    congenital kidney disease | -26280
    hyperechoic kidneys | -26280
    cystic kidneys | -26280
    onset diabetes mellitus in young adulthood | -26280
    pancreatic hypoplasia | -26280
    genital tract malformations | 0
    abnormal liver function tests | 0
    hypomagnesemia | 0
    hyperuricemia | 0
    early onset gout | 0
    secondary hyperparathyroidism | 0
    neurologic features | 0
    <|eot_id|>