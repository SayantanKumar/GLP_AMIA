64 years old | 0
    Caucasian | 0
    male | 0
    type 2 diabetes mellitus | 0
    hypertension | 0
    hyperlipidemia | 0
    metabolic dysfunction-associated steatotic liver disease | 0
    Gilbert syndrome | 0
    coronary artery disease | 0
    progressive proximal muscle weakness | -2160
    extreme muscle pain | -2160
    difficulty climbing stairs | -2160
    difficulty rising from a chair | -2160
    atorvastatin | -35040
    elevated liver enzymes | -35040
    discontinued atorvastatin | -35040
    rosuvastatin | -7200
    persistent worsening hyperlipidemia | -7200
    reduced muscle strength | 0
    moderate to significant weakness in biceps | 0
    moderate to significant weakness in triceps | 0
    moderate to significant weakness in shoulder girdles | 0
    good strength in wrists | 0
    good strength in hands | 0
    significant weakness in hip muscles | 0
    good strength at knees | 0
    good strength at ankles | 0
    elevated creatine kinase | 0
    232.48 µkat/L | 0
    elevated aspartate transaminase | 0
    3.88 µkat/L | 0
    elevated alanine transaminase | 0
    9.73 µkat/L | 0
    elevated potassium | 0
    5.5 mmol/L | 0
    discontinued statin | 0
    discontinued dulaglutide | 0
    syncopal episode | 168
    no evidence of neurological event | 168
    no evidence of ischemia | 168
    creatine kinase increasing trend | 168
    275.0167 µkat/L | 168
    alanine transaminase | 168
    9.71 µkat/L | 168
    aspartate transaminase | 168
    5.35 µkat/L | 168
    elevated aldolase | 168
    1.0717 µkat/L | 168
    aggressive intravenous hydration | 168
    creatine kinase improved | 168
    153.333 µkat/L | 168
    normal right upper quadrant ultrasound | 168
    normal renal function tests | 168
    normal thyroid function tests | 168
    electromyography | 168
    diffuse myopathy | 168
    myotonic discharges | 168
    myonecrosis | 168
    vacuolization | 168
    fibrous splitting | 168
    significant spontaneous activity | 168
    fibrillation potentials | 168
    complex repetitive discharges | 168
    sharp waves | 168
    pulmonary function test | 168
    mild decrease in forced expiratory volume | 168
    mild decrease in forced vital capacity | 168
    neuromuscular weakness | 168
    left vastus lateralis muscle biopsy | 168
    scattered necrotic fibers | 168
    scattered regenerating fibers | 168
    compatible with immune-mediated necrotizing myopathy | 168
    anti-HMGCR assay | 168
    strongly positive | 168
    > 200 chemiluminescent units | 168
    Anti Signal Recognition Particle Immunofluorescence screen | 168
    negative | 168
    colonoscopy | 168
    unremarkable | 168
    whole-body fluorodeoxyglucose positron emission tomography/computed tomography | 168
    not completed | 168
    hyperglycemia | 168
    prednisone | 168
    40 mg daily | 168
    creatine kinase lowered | 720
    94.73 µkat/L | 720
    intravenous immunoglobulin | 720
    2 grams/kilogram over 5 days | 720
    monthly for 3 months | 720
    ezetimibe | 720
    10 mg | 720
    evolocumab | 720
    140 mg subcutaneous injections | 720
    proprotein convertase subtilisin/kexin type 9 inhibitor | 720
    re-evaluate lipid panel in 2 to 3 months | 720
    creatine kinase normalized | 2160
    1.05 µkat/L | 2160
    continue intravenous immunoglobulin | 2160
    2 grams/kilogram monthly for 3 months | 2160
    decrease to 1 gram/kilogram monthly | 2160
    prednisone tapered | 2160
    methotrexate | 2160
    poor control of hyperglycemia | 2160
    no history of autoimmune disease | 0
    no preceding history of fevers | 0
    no preceding history of chills | 0
    no preceding history of joint pain | 0
    no preceding history of dysphagia | 0
    no evidence of malignancy | 168
    statin-induced necrotizing autoimmune myopathy | 168
