37-year-old | 0
    woman | 0
    obesity | 0
    hypertension | 0
    hypercholesterolemia | 0
    referred to our clinic for elevated liver enzymes | 0
    denied nausea | 0
    denied vomiting | 0
    denied abdominal distension | 0
    denied jaundice | 0
    denied episodes of confusion | 0
    physical examination normal | 0
    denied supplement use | 0
    denied excessive alcohol use | 0
    denied family history of autoimmune disease | 0
    ethinyl estradiol 0.15 mg/levonorgestrel 30 mg | 0
    tirzepatide | 0
    initiated on tirzepatide | -1800
    birth control medication for more than 10 years | 0
    lost 30 pounds | -1800
    ALT 500 U/L | 0
    AST 261 U/L | 0
    hepatitis serologies unremarkable | 0
    antinuclear antibody level unremarkable | 0
    antimitochondrial antibody level unremarkable | 0
    ceruloplasmin levels unremarkable | 0
    alpha-1 antitrypsin levels unremarkable | 0
    anti-smooth muscle antibody level 37 | 0
    abdominal ultrasound normal | 0
    normal hepatic echotexture | 0
    no evidence of portal hypertension | 0
    tirzepatide discontinued | 0
    ALT decreased to 110 U/L | 504
    AST decreased to 57 U/L | 504
    resumed tirzepatide | 504
    ALT increased to 184 U/L | 1008
    AST increased to 104 U/L | 1008
    liver biopsy performed | 1008
    benign hepatic tissue | 1008
    lymphocytic infiltration within the lobules | 1008
    macrophage infiltration in portal tracts and sinusoidal spaces | 1008
    no evidence of steatosis | 1008
    no bile duct injury | 1008
    no bile duct proliferation | 1008
    no interface hepatitis | 1008
    no steatosis | 1008
    no necrosis | 1008
    RUCAM score 5 | 1008
    DILI from tirzepatide diagnosed | 1008
    not to reinitiate tirzepatide | 1008
    ALT 36 U/L | 2928
    AST 24 U/L | 2928
    switched to semaglutide | 2928
    normal liver enzyme levels | 5112
    <|eot_id|>
    