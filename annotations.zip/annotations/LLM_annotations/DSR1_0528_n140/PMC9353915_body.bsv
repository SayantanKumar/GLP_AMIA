27 years old|0
    male|0
    unemployed|0
    schizophrenia|0
    olanzapine|0
    sodium valproate|0
    schizophrenia diagnosed|-52560
    risperidone|-52560
    aripiprazole|-52560
    ziprasidone|-52560
    weight gain|0
    weight 106.3 kg|0
    BMI 38.58 kg/m2|0
    thirsty|-1344
    polydipsia|-1344
    polyuria|-1344
    fasting blood glucose 20 mmol/L|-1344
    HbA1c 12.3%|-1344
    glargine|-1344
    metformin|-1344
    FBG 10-20 mmol/L|-1344
    PBG 13-24 mmol/L|-1344
    diabetes|0
    obesity|0
    physical examination|0
    no obvious abnormalities|0
    laboratory examinations|0
    metformin discontinued|0
    insulin pump|0
    continuous subcutaneous insulin infusion|0
    liraglutide|72
    liraglutide 0.6 mg/d|72
    liraglutide 1.2 mg/d|120
    insulin decreased|120
    liraglutide 1.8 mg/d|168
    insulin stopped|168
    olanzapine continued|168
    sodium valproate continued|168
    diabetic diet|0
    exercise recommended|0
    blood glucose measured five times per day|0
    FBG 15.0 mmol/L|0
    PBG 13.1 mmol/L|0
    FBG 4.9 mmol/L|264
    PBG 5.1 mmol/L|264
    blood glucose before bedtime 9.9 mmol/L|0
    blood glucose before bedtime 5.2 mmol/L|264
    weight 104 kg|168
    discharged|264
    liraglutide continued|264
    weight loss|17520
    blood glucose controlled|17520
    weight 98.4 kg|17520
    BMI 35.71 kg/m2|17520
    psychiatric status stable|17520
    no hospital admissions|17520