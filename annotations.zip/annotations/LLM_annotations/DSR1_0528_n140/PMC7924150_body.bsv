60-year-old | 0
    man | 0
    referred to hospital for coronary artery bypass graft surgery | 0
    coronary artery disease | 0
    hypercholesterolemia | 0
    type 2 diabetes mellitus diagnosed 15 years previously | 0
    glimepiride | 0
    metformin | 0
    subcutaneous semaglutide | 0
    empagliflozin | 0
    started semaglutide around a year prior to presentation | -8760
    started empagliflozin around a year prior to presentation | -8760
    asymptomatic | 0
    vital signs within normal limits | 0
    white blood cell count 7.6 K/μL | 0
    hemoglobin 14.6 g/dL | 0
    serum glucose 157 mg/dL | 0
    bicarbonate 24 mmol/L | 0
    anion gap 12 mmol/L | 0
    troponin 0.09 ng/mL | 0
    glycated hemoglobin 9.6% | 0
    glucosuria >1000 mg/dL | 0
    ketonuria 15 mg/dL | 0
    oral antihyperglycemic medications withheld | 0
    placed on subcutaneous insulin regimen | 0
    underwent CABG surgery | 42
    developed elevated anion gap metabolic acidosis | 45
    arterial pH 7.275 | 45
    bicarbonate 15 mmol/L | 45
    anion gap 25 mmol/L | 45
    serum glucose 138 mg/dL | 45
    β-hydroxybutyric acid 6.52 mmol/L | 45
    euglycemic diabetic ketoacidosis | 45
    started intravenous insulin drip | 45
    infusion of 5% dextrose in water | 45
    required transient 24-hour intravenous norepinephrine | 45
    ketoacidosis resolved | 117
    transitioned to subcutaneous insulin | 117
    adequate glycemic control | 117
    elevated ketone levels | 45
    history of home SGLT2 inhibitor therapy | 45
    canagliflozin for many years | -26280
    switched to empagliflozin about a year before presentation | -8760
    last dose empagliflozin morning of transfer | -48
    CABG surgery | 42
    hospital stay uneventful | 117
    discharged | 168
    educated on discontinuing SGLT2 inhibitors at least 3 days before procedures | 168
    persistent glycosuria despite normal blood glucose levels | 0
    no history of SGLT2 inhibitor use on admission | 0
    <|eot_id|>
    