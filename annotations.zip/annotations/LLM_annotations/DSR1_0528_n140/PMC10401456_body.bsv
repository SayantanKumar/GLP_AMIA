42 years old | 0
    woman | 0
    presented with xerostomia | -96
    presented with polydipsia | -96
    presented with polyuria | -96
    presented with blurred vision | -96
    consumed substantial amounts of beverages and fruits | -96
    fatigue | -96
    FBG 18.15 mmol/L | -96
    HbA1c 10.3% | -96
    prescribed metformin | -96
    prescribed another oral drug | -96
    symptoms not relieved | 0
    FBG 14.54 mmol/L | 0
    cesarean section | -157680
    uterine fibroids | -105120
    no knowledge of diabetes in her family | 0
    sane | 0
    conscious | 0
    dry lips | 0
    BMI 31.85 kg/m2 | 0
    blood pressure 133/96 mmHg | 0
    no other obvious abnormality | 0
    arterial pH 7.29 | 0
    PO2 93 mmHg | 0
    bicarbonate 14.6 mmol/L | 0
    islet cell antibody 45 times higher than normal | 0
    GAD 200 times higher than normal | 0
    insulin autoantibody two times higher than normal | 0
    urine ketone significantly positive | 0
    liver function slightly abnormal | 0
    blood lipids normal | 0
    albumin/creatinine ratio normal | 0
    thyroid function normal | 0
    fluid replacement | 0
    insulin treatment | 0
    arterial pH normal | 0
    urine ketone levels normal | 0
    mixed protamine zinc recombinant human insulin injection | 0
    lifestyle interventions | 0
    discontinued insulin therapy | 720
    blood glucose normal | 720
    visited outpatient clinic | 0
    capsular blood glucose | 0
    HbA1c 6.2% | 2160
    OGTT fasting 5.96 mmol/L | 2160
    OGTT 30 min 12.44 mmol/L | 2160
    OGTT 1 h 12.64 mmol/L | 2160
    OGTT 2 h 8.33 mmol/L | 2160
    oral glucose-insulin release test fasting 6.82 µU/mL | 2160
    oral glucose-insulin release test 30 min 35.97 µU/mL | 2160
    oral glucose-insulin release test 1 h 44.81 µU/mL | 2160
    oral glucose-insulin release test 2 h 56.74 µU/mL | 2160
    GAD autoantibodies higher than upper limit | 2160
    capsular blood glucose around 7 mmol/L or slightly higher | 6480
    HbA1c 7.3% | 6480
    OGTT fasting 8.88 mmol/L | 6480
    OGTT 30 min 11.26 mmol/L | 6480
    OGTT 1 h 15.72 mmol/L | 6480
    OGTT 2 h 18.17 mmol/L | 6480
    oral glucose-insulin release test fasting 11.93 µU/mL | 6480
    oral glucose-insulin release test 30 min 18.26 µU/mL | 6480
    oral glucose-insulin release test 1 h 30.93 µU/mL | 6480
    oral glucose-insulin release test 2 h 33.13 µU/mL | 6480
    GAD higher than upper limit | 6480
    administered liraglutide | 6480
    FBG 5-6 mmol/L | 6480
    postprandial blood glucose 6-8 mmol/L | 6480
    heterozygous mutation in the PAX4 gene | 0
    diabetic ketoacidosis | 0
    type 1 diabetes mellitus | 0
    latent autoimmune diabetes in adults | 0