34 years old | 0
    female | 0
    presented to outpatient lipid clinic | 0
    abdominal obesity | 0
    diabetes mellitus | 0
    severe hypertriglyceridemia | 0
    height 184 cm | 0
    weight 102 kg | 0
    BMI 30.1 kg/m2 | 0
    increased fat mass around abdomen | 0
    loss of s.c. fat on extremities | 0
    body composition assessed using bioelectrical impedance analysis | 0
    body fat content 33.2% | 0
    fat mass index 8.8 kg/m² | 0
    total muscle mass content 28.9 kg | 0
    bulging musculature | 0
    veins on upper and lower extremities | 0
    no signs of acanthosis nigricans | 0
    no fat accumulation in face | 0
    no fat accumulation in neck | 0
    blood pressure 125/80 mmHg | 0
    no specific medication for blood pressure | 0
    diabetes suboptimally controlled | 0
    HbA1c 73 mmol/mol Hb | 0
    HbA1c 8.8% Hb | 0
    hypertriglyceridemia diagnosed in 2018 | -17520
    blood triglyceride concentrations 47.9 mmol/L | 0
    hepatomegaly | 0
    metabolic steatohepatitis | 0
    stress eating | 0
    sweet eating | 0
    abnormal quantities of eating | 0
    markedly reduced feeling of satiety | 0
    allergy against disinfectants | 0
    family history diabetes mellitus father | 0
    family history myocardial infarction father | 0
    lives in assisted living project | 0
    no contact to parents | 0
    mother athletic phenotype | 0
    mother similar lower extremities | 0
    mother no diabetes | 0
    mother no lipid abnormalities | 0
    metformin 1000 mg twice daily | 0
    insulin glargine once daily 30 IU | 0
    simvastatin 40 mg once daily | 0
    oral contraception | 0
    no i.v. insulin treatment | 0
    no lipid-apheresis | 0
    no acute pancreatitis | 0
    novel PPARG variant c.485T>G (p.(Phe162Cys)) detected | 0
    elevated blood glucose levels 13.5 mmol/L | 0
    insulin level 34.6 mlU/L | 0
    C-peptide level 5.86 μg/L | 0
    thyroid-stimulating hormone within reference range | 0
    insulin-like growth factor 1 within reference range | 0
    cortisol within reference range | 0
    blood cholesterol total 12.6 mmol/L | 0
    HDL cholesterol 0.24 mmol/L | 0
    aspartate aminotransferase 102.2 U/L | 0
    alanine aminotransferase 57.2 U/L | 0
    gamma glutamyl transferase 60 U/L | 0
    C-reactive protein 14.4 mg/L | 0
    no classical infectious diseases | 0
    no immunological diseases | 0
    management intensified | 0
    semaglutide added | 0
    dapagliflozin added | 0
    statin treatment switched to gemfibrozil | 0
    omega-3 fatty acids added | 0
    HbA1c dropped to 54 mmol/mol Hb | 0
    HbA1c dropped to 6.5% Hb | 0
    triglyceride serum concentrations >50 mmol/L | 0
    reduced leptin levels 9.3 ng/mL | 0
    recombinant leptin replacement therapy initiated | 0
    metreleptin 5 mg once daily s.c. injection | 0
    leptin levels 13.0 ng/mL | 336
    triglyceride levels 35.1 mmol/L | 336
    dramatic effect on appetite regulation | 336
    marked improvement feeling of satiety | 336
    alanine aminotransferase decreased | 336
    HbA1c slight increase | 336
    severe allergic reactions at injection sites | 336
    leptin therapy reduced to 5 mg every other day | 336
    anti-histaminic local skin therapy after injection | 336
    improved satiety feeling | 3600
    weight loss 7 kg | 3600
    BMI 26.6 kg/m² | 3600
    triglyceride levels normal | 3600
    insulin glargine stopped | 3600
    leptin concentration 63.0 ng/mL | 3600
    GPT levels increased | 3600
    chronic liver damage | 3600
    <|eot_id|>
    