15 years old | 0
    Caucasian | 0
    teenager | 0
    admitted to the hospital | 0
    inpatient consultation for obesity requested | 0
    in pediatric cardiac intensive care unit | 0
    found gasping for air | -336
    emergency room visit | -336
    vomiting | -336
    diarrhea | -336
    shortness of breath | -336
    malaise | -336
    bilateral lower extremity edema | -336
    tachypnea in the 60s | -336
    BNP level 522 pg/mL | -336
    elevated troponin level 49 ng/mL | -336
    started on furosemide | -336
    started on pressors | -336
    started on continuous positive airway pressure therapy | -336
    started on milrinone drip | -336
    transferred to pediatric cardiac intensive care unit | -336
    palliative care consultation requested | -336
    taken to catheterization laboratory | -336
    intubated briefly | -336
    left ventricular ejection fraction 12-17% | -336
    heart failure diagnosed | -336
    cardiac transplant consultation placed | -336
    unable to be weaned off intravenous cardiac support | -336
    prediabetes | 0
    Hgb A1c 6.1% | 0
    started on metformin XR 1000 mg once daily | 0
    highest weight 365 pounds | 0
    BMI 65 kg/m2 | 0
    Class 3c obesity | 0
    birth weight 7 pounds 1 ounce | 0
    no complications at birth | 0
    no developmental concerns | 0
    weight gain during pre-kindergarten years | 0
    prediabetes diagnosed during hospital stay | 0
    no previous exposure to weight-promoting medications | 0
    non-responder to prior weight loss attempts | 0
    often skipped breakfast | 0
    lunch baked chicken nuggets with vegetables | 0
    dinner lean meat and vegetables | 0
    snacks microwavable popcorn and fruits | 0
    beverages water and unsweetened tea | 0
    foraging behaviors | 0
    distress around food | 0
    cabinets locked | 0
    no known family history of obesity | 0
    shortness of breath | 0
    unable to exercise | 0
    encouraged to walk laps | 0
    sleep apnea diagnosed | 0
    history of snoring | 0
    witnessed apneas | 0
    no previous depression | 0
    no anxiety history | 0
    bullied in school | 0
    attacked twice | 0
    concussions | 0
    transitioned to homeschooling | 0
    no known drug allergies | 0
    extubated | 0
    medications acetaminophen as needed | 0
    medications carvedilol | 0
    medications enoxaparin | 0
    medications furosemide | 0
    medications lisinopril | 0
    medications melatonin | 0
    medications metformin XR | 0
    medications milrinone infusion | 0
    medications spironolactone | 0
    BP 116/85 | 0
    pulse 95 | 0
    weight 400 pounds | 0
    BMI 71.6 kg/m2 | 0
    oxygen 3L via nasal cannula | 0
    oxygen saturations 92-93% | 0
    electrolytes normal | 0
    kidney function normal | 0
    liver function normal | 0
    thyroid function normal | 0
    anemia | 0
    hemoglobin 9.7 g/dL | 0
    lipid profile total 103 mg/dL | 0
    triglycerides 67 mg/dL | 0
    HDL 19 mg/dL | 0
    LDL 71 mg/dL | 0
    public health insurance Medicaid | 0
    blind | 0
    glasses | 0
    round-shaped facies | 0
    stubby hands | 0
    stubby feet | 0
    genetic obesity testing | 0
    negative for genetic obesity | 0
    ophthalmological examination recommended | 0
    in-patient nutrition consultation | 0
    start low calorie protein modified fast | 0
    protein shake breakfast and lunch | 0
    dinner lean meat and vegetables | 0
    medical weight loss dietitian consultation | 0
    reviewed bariatric nutrition guide | 0
    recommend outpatient cardiac rehab | 0
    start liraglutide 3.0 mg | 0
    consider pramlintide 15 mcg pre-meals | 0
    consider empagliflozin 5 mg once daily | 0
    metabolic and bariatric surgery recommended | 0
    genetic testing for obesity | 0
    buccal swab sent | 0
    liraglutide 3.0 mg approved | 0
    empagliflozin started | 0
    pramlintide started | 0
    pramlintide discontinued | 336
    metformin discontinued | 0
    lost 30 pounds | 336
    weaned off milrinone infusion | 336
    weaned off diuretics | 336
    transferred to step-down unit | 336
    discharged home | 336
    lost 101 pounds | 2928
    weight 299 pounds | 2928
    BMI 49.9 kg/m2 | 2928
    LVEF improved to 39% | 2928
    follow up at weight loss center | 2928
    continues on liraglutide 3.0 mg daily | 2928
    continues on empagliflozin | 2928