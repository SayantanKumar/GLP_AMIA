27 years old | 0
    woman | 0
    presented to the hospital | 0
    severe fatigue | 0
    generalized muscle weakness | 0
    progressively worsened | -4320
    multiple falls | 0
    decreased oral intake | 0
    class III obesity | 0
    body mass index 40.0 kg/m2 | 0
    presented to neurology clinic | -3600
    fatigue | -3600
    proximal muscle weakness | -3600
    primarily affecting lower extremities | -3600
    started low carbohydrate, calorie restricted diet | -4320
    severe vomiting | -4320
    stopped diet | -4080
    lost 20 lbs | -4080
    elevated thyroid stimulating hormone | -3600
    TSH 5.45 μIU/mL | -3600
    elevated thyroid peroxidase antibodies | -3600
    elevated creatine kinase | -3600
    CK 588.0 units/L | -3600
    started levothyroxine 25 mcg daily | -3600
    presumed hypothyroid myopathy | -3600
    symptoms worsened | -3600
    TSH 4.17 μIU/mL | -3600
    antibody testing for myositis | -3600
    antibody testing for necrotizing myopathy | -3600
    antibody testing for myasthenia gravis | -3600
    genetic testing for muscular dystrophies | -3600
    normal results | -3600
    electromyography suggested inflammatory, genetic, or metabolic myopathy | -3600
    vastus lateralis biopsy | -3600
    vacuolated muscle fibers | -3600
    lipid droplets | -3600
    suggestive of lipid storage myopathy | -3600
    plasma acylcarnitine profile | -3600
    elevated small-, medium- and long-chain acylcarnitine species | -3600
    suggestive of defect in fatty acid oxidation | -3600
    urine organic acid analysis | -3600
    elevated excretion of orotic acid | -3600
    orotic acid 91 mmol/mol creatinine | -3600
    elevated 2-hydroxy glutaric acid | -3600
    2-hydroxy glutaric acid 270 mmol/mol Cr | -3600
    genetic testing ordered | -3600
    results pending | -3600
    worsening weakness | 0
    multiple falls | 0
    decreased oral intake | 0
    neurological exam | 0
    proximal greater than distal weakness of bilateral upper and lower extremities | 0
    neck weakness | 0
    trace to absent lower extremity reflexes | 0
    pulmonary embolism | 0
    intraluminal filling defects in segmental branches of bilateral lower lobe pulmonary arteries | 0
    severe ketoacidosis | 0
    venous pH 7.00 | 0
    beta hydroxybutyrate 5.67 nmol/L | 0
    rhabdomyolysis | 0
    CK 4656 units/L | 0
    lactate peaking at 6.0 mmol/L | 0
    admission to intensive care unit | 0
    treated with sodium bicarbonate | 0
    normal saline | 0
    thiamine | 0
    dextrose | 0
    heparin infusions | 0
    improved within 24 hours | 24
    venous pH normalized to 7.45 | 24
    CK improved to 245 units/L | 24
    lactate improved to 3.6 mmol/L | 24
    started carnitine | 0
    riboflavin | 0
    cyanocobalamin | 0
    coenzyme Q10 supplementation | 0
    presumptive diagnosis of riboflavin-responsive lipid storage myopathy | 0
    MADD | 0
    objective weakness | 0
    proximal greater than distal weakness of bilateral upper and lower extremities | 0
    genetic testing results expedited | 0
    heterozygous frameshift mutation c.51dup;p.(A18Cfs*5) in ETFDH gene | 0
    likely pathogenic for MADD | 0
    discharged to inpatient rehabilitation | 24
    physical therapy | 24
    occupational therapy | 24
    maintained on carnitine | 24
    riboflavin | 24
    cyanocobalamin | 24
    coenzyme Q10 | 24
    thiamine supplementation | 24
    high carbohydrate, low-fat diet | 24
    discharged home | 24
    adhere to diet with less than 25 g of fat per day | 24
    avoid prolonged fasting | 24
    intermittent nausea | 72
    requiring ondansetron | 72
    neuropathic pain | 72
    requiring pregabalin | 72
    strength improved | 72
    energy improved | 72
    CK normalized to 36 units/L | 504
    intermittent nausea | 72
    neuropathic pain | 72
    gained nearly 30 lbs | 2880
    metformin initiated | 2880
    liraglutide initiated | 2880
    TSH as high as 21.58 μIU/mL | 2880
    levothyroxine increased slowly to 100 mcg daily | 2880
    continues to feel well | 8760
    improved strength | 8760
    improved energy | 8760