19 years old | 0
    female | 0
    South Indian origin | 0
    polycystic ovary syndrome | 0
    fatty liver | 0
    obesity | 0
    hidradenitis suppurativa | 0
    normal growth and development until puberty | -8
    very active lifestyle | -8
    no family history of HS | 0
    no family history of colitis | 0
    no family history of other autoimmune disease | 0
    maternal grandparents had late-onset diabetes | 0
    immigrated to the United States | -96
    begun menstruation | -96
    weight gain | -92
    fever | -92
    perianal pain | -92
    surgery for large perianal abscess | -92
    developed multiple skin lesions consistent with HS | -92
    acne over face | -92
    periods became irregular | -92
    disease became widespread | -86
    up to 20 lesions present at any one time | -86
    intermittent perianal disease | -86
    widespread abdominal scarring | -86
    contracture of entire body | -86
    extensive therapy over total of 8 years | -86
    multiple episodic and continuous regimens of oral antibiotics | -86
    multiple episodic and continuous regimens of intravenous antibiotics | -86
    numerous surgeries | -86
    isotretinoin for acne treatment | -86
    periodic metformin | -86
    oral birth control usage | -86
    no improvement of disease | -86
    menstrual periods caused severe flare-ups | -86
    required increased pain medication | -86
    sleep severely impaired | -86
    physical examination | 0
    HS encompassing most of truncal area anteriorly from inframammary area to groin | 0
    extending to right axilla | 0
    incorporating nearly 40% of body surface | 0
    extensive muscle wasting of extremities | 0
    facial acne without scarring | 0
    hirsutism notably absent | 0
    weight 215 pounds | 0
    BMI 37 | 0
    class II obesity | 0
    profound microcytic anemia | 0
    hemoglobin 6.2 g/dL | 0
    normal iron indices | 0
    anemia of chronic disease | 0
    elevated liver enzymes | 0
    presumed due to fatty liver | 0
    blood sugar 117 mg/dL | 0
    HbA1c 5.7% | 0
    pre-diabetes | 0
    aggressive lifestyle modification program initialed | 0
    low-carbohydrate diet | 0
    physical activity too painful | 0
    oral contraception restarted | 0
    dapsone 100 mg/day | 0
    glucose-6-phosphate dehydrogenase test negative | 0
    initial minimal improvements | 24
    finasteride 5 mg/day | 1440
    metformin 2000 mg/day | 1440
    liraglutide 0.6 mg subcutaneously daily | 1440
    increased to 1.8 mg over 2 months | 2160
    lost approximately 40 pounds | 4320
    19% body weight | 4320
    lowest weight recorded | 4320
    trend of regain subsequently | 4320
    monthly follow-ups | 0
    complete laboratory testing at each visit | 0
    liver enzymes responded first with declines within 6 months | 4320
    resolution within year | 8640
    leukocytosis returned to normal at 2 years | 17280
    anemia returned to normal at 2 years | 17280
    hypoalbuminemia returned to normal at 2 years | 17280
    sedimentation rate reduced from over 120 to 34 mm/h | 17280
    sedimentation rate still above normal | 17280
    total proteins remain slightly above normal | 17280
    HbA1c 5.2% after 2 years | 17280
    HbA1c 4.9% after 3 years | 26280
    average estimated blood sugar 94 mg/dL | 26280
    weight regained | 26280
    blood testing reduced to every 3 months | 17280
    clinical course no improvement in first 3 months | 2160
    new lesions appeared but resolved faster | 4320
    patient began to feel better | 4320
    less intense and frequent flares | 4320
    another large perianal abscess developed | 6480
    required hospitalization | 6480
    required surgery | 6480
    perianal lesion healed completely in 3 weeks | 6480
    avoided extensive debridement | 6480
    not required adjunctive antibiotics | 26280
    risk of pregnancy addressed | 0
    not been concern | 0
    no new lesion for 6 months | 26280
    completed 3 years of regimen | 26280
    remarkable tolerance | 26280
    axillary lesions healed completely | 26280
    groin lesions improved 90% or more | 26280
    thigh lesions improved 90% or more | 26280
    perianal disease improved 90% or more | 26280
    thoraco-abdominal lesions improved 60% | 26280
    4–5 small areas persisting | 26280
    facial acne improved but persisted | 26280
    frequent follow-up visits | 0
    adverse effects asked for routinely | 0
    weight regain noted | 26280
    no physical abnormality detected | 26280
    no biochemical abnormality detected | 26280
    sedimentation rate minimally elevated | 26280
    patient consented to photographs of right axilla | 0
    previous photographs not obtained due to contracture | 0
    remission | 26280
    no significant adverse effects | 26280
    teratogenicity addressed | 0
    contraception advocated | 0
    acne continued to be issue | 26280
    metformin well tolerated | 0
    liraglutide well tolerated | 0
    symptoms suggestive of hypoglycemia absent | 0
    improvement in metabolic profile | 17280
    initial weight loss | 4320
    weight regain ongoing | 26280
    obesity not correlated as long as metabolic parameters controlled | 26280
    clinical remission | 26280
    latency to onset of improvement | 4320
    conundrum remains as to withdrawing one of components | 26280
    regimen use unprecedented | 0
    relapse noted with discontinuation of dapsone or finasteride | -86
    long-term use indicated | 26280
    sedimentation rate may remain elevated due to persistent abdominal lesions | 26280
    weight gain persistent | 26280
    newer formulation of liraglutide could be used | 26280
    resolution of all major concomitant medical abnormalities | 26280
    