72 years old| 0
    male | 0
    board-certified ophthalmologist | 0
    atrial fibrillation | 0
    cataract surgery | -12960
    intraocular lens implantation | -12960
    right eye | -12960
    mild nuclear sclerotic cataract | 0
    left eye | 0
    started oral semaglutide | 0
    weight loss | 0
    noticed right eye round central scotoma | 408
    noticed enlarging square scotoma | 408
    noticed minimal small round scotoma left eye | 456
    discontinued semaglutide | 480
    observed scotomas persist both eyes | 504
    noticed enlarged scotoma right eye | 528
    residual scotomas remain | 552
    scotomas gone | 576
    knee pain | 0
    denied neurologic changes | 0
    denied autoimmune changes | 0
    denied psychiatric changes | 0
    denied other systemic changes | 0
    propranolol | 0
    aspirin | 0
    naproxen | 0
    ibuprofen | 0
    returned from vacation | 0
    formal ophthalmic evaluation | 576
    uncorrected distance visual acuity 20/20 right eye | 576
    uncorrected distance visual acuity 20/25 left eye | 576
    benign anterior segment exam | 576
    well-centered intraocular lens | 576
    clear posterior capsule | 576
    mild nuclear sclerotic cataract | 576
    normal optic nerves | 576
    scattered small drusen | 576
    vitreous opacities | 576
    posterior vitreous detachment | 576
    Humphrey visual field testing | 576
    reliable test | 576
    no visual field loss | 576
    macular optical coherence tomography | 576
    subretinal drusenoid deposits | 576
    poorly defined interdigitation zone | 576
    preserved interdigitation zone | 576
    normal retinal nerve fiber layer | 576
    no diabetes | 0
    no retinopathy | 0
    no prior similar episode | 0
    no subsequent episode | 0
    symptoms observed only under scotopic conditions | 0
    symptoms disappeared with light | 0
    bright white afterimage | 0
    dark brown appearance | 0
    symptoms resolved after discontinuation | 0
    no long-lasting vision problems | 0
    no permanent vision loss | 0
    no comprehensive optic neuropathy workup | 0
    no underlying issue found | 0
    no testing while symptomatic | 0
    no fluorescein angiography | 0
    no OCT angiography | 0
    no ERG | 0
    no wide-field visual field testing | 0
    medication stopped | 480
    symptoms diminished | 504
    symptoms gone | 576
    no re-initiation of semaglutide | 0
    no known competing financial interests | 0
    patient consent obtained | 0
    no funding | 0
    authorship criteria met | 0
    no acknowledgements | 0
    