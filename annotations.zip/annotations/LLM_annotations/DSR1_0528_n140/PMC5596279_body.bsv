36 years old | 0
    male | 0
    type 2 diabetes mellitus | -61320
    liraglutide | -61320
    glycohemoglobin levels 9-13% | -17520
    low-grade fever | -336
    sore throat | -336
    no abdominal pain | 0
    no diarrhea | 0
    chest pain | 0
    respiratory distress | 0
    cardiomegaly | 0
    congestive heart failure suspected | 0
    referred to hospital | 0
    height 174 cm | 0
    weight 88.0 kg | 0
    body mass index 29.1 kg/m2 | 0
    blood pressure 132/77 mmHg | 0
    pulse rate 131/min | 0
    body temperature 36.8℃ | 0
    respiratory rate 14/min | 0
    pulse oximetry 97% | 0
    no heart murmur | 0
    no pericardial friction rub | 0
    no abnormal breath sound | 0
    bilateral pitting edema | 0
    no rashes | 0
    no tattoos | 0
    no cutaneous ulcers | 0
    white-blood-cell count 13,900 /μL | 0
    neutrophils 75.1% | 0
    C-reactive protein 7.3 mg/dL | 0
    plasma glucose 422 mg/dL | 0
    HbA1c 12.2% | 0
    creatine phosphokinase 35 U/L | 0
    N-terminal pro-brain natriuretic peptide 1,939 pg/mL | 0
    liver function unimpaired | 0
    kidney function unimpaired | 0
    thyroid function unimpaired | 0
    electrocardiogram sinus tachycardia | 0
    normal QRS width | 0
    normal axis | 0
    low voltage | 0
    normal ST segment | 0
    echocardiography pericardial effusion | 0
    pericardial thickening | 0
    chest X-ray computed tomography pericardial effusion | 0
    pericardial thickening | 0
    bilateral pleural effusion | 0
    no pulmonary parenchymal involvement | 0
    acute pericarditis diagnosed | 0
    admitted to hospital | 0
    emergency pericardiocentesis | 0
    pericardial fluid drained | 0
    chest pain improved | 0
    dyspnea on exertion improved | 0
    purulent pericarditis considered | 0
    fosfuluconazole | 0
    daptomycin | 0
    doripenem | 0
    colchicine | 0
    bisoprolol fumarate | 0
    pericardial fluid culture Gram-negative bacilli | 24
    no primary source identified | 24
    S. enterica subsp. arizona identified | 96
    blood cultures negative | 96
    ball python received | -5088
    Mexican black kingsnake received | -2928
    Mexican black kingsnake died | -720
    chest pain relieved | 144
    white-blood-cell count normal | 144
    dyspnea on exertion persistent | 144
    pericardial drainage | 144
    cardiac catheterization | 144
    normal coronary artery | 144
    ejection fraction 46.4% | 144
    asynergy | 144
    pulmonary capillary wedge pressure 24 mmHg | 144
    cardiac index 1.29 L/min/m2 | 144
    unstable hemodynamic status | 144
    transferred to cardiovascular surgery | 144
    constrictive pericarditis diagnosed | 144
    pericardial thickness | 144
    fibrinous effusion | 144
    exudative effusion | 144
    pericardiotomy | 168
    recovered well | 192
    discharged | 192
    