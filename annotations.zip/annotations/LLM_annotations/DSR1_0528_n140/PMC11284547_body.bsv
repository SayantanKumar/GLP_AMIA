49-year-old|0
    female|0
    presented|0
    pelvic pain|0
    abnormal uterine bleeding|0
    pelvic ultrasound|0
    6.5 cm complex left adnexal mass|0
    features consistent with dermoid cyst|0
    endometrial biopsy|0
    normal proliferative endometrium|0
    thyroid-stimulating hormone normal|0
    free T4 normal|0
    CA-125 normal|0
    CEA normal|0
    CA 19-9 normal|0
    bHCG normal|0
    inhibin A/B normal|0
    pelvic magnetic resonance imaging|0
    large complex predominantly solid mass|0
    heterogeneous enhancement|0
    concern for malignancy|0
    robotic bilateral salpingectomy|0
    left oophorectomy|0
    9 cm left adnexal mass|0
    grossly consistent with dermoid cyst|0
    removed through midline port site|0
    contained rupture|0
    intra-operative frozen section|0
    struma ovarii|0
    contralateral oophorectomy not performed|0
    hysterectomy not performed|0
    final surgical pathology|0
    struma ovarii|0
    mature thyroid tissue|0
    variable-sized follicles|0
    three microscopic foci of papillary thyroid carcinoma|0
    largest measuring 1.6 mm|0
    papillary architecture|0
    enlarged and overlapping nuclei|0
    cleared chromatin|0
    frequent nuclear grooves|0
    no lymphovascular space invasion|0
    no ovarian capsule involvement|0
    pelvic washings|0
    no evidence of malignant cells|0
    referred to endocrinology|0
    thyroid ultrasound|0
    neck ultrasound|0
    thyroglobulin level normal|0
    thyroid function tests normal|0
    elected for monitoring|0
    thyroglobulin monitoring every 2-4 months|0
    abdominal imaging yearly|0
    thyroglobulin levels normal for 2 years|0
    thyroglobulin increase|504
    thyroid function tests normal|504
    GLP-1 agonist started|408
    thyroglobulin elevated off medication|504
    computed tomography scan chest/abdomen/pelvis|504
    neck ultrasound|504
    no evidence of disease|504
    pelvic ultrasound|504
    hyperechoic right ovarian lesion|504
    measuring 6.4x9x7.5 mm|504
    increased vascularity|504
    re-evaluated by gynecologic oncology|504
    removal of remaining ovary|504
    possible hysterectomy|504
    thyroglobulin level 227 ng/ml|672
    TSH 1.26|672
    diagnostic laparoscopy|672
    peritoneal carcinomatosis|672
    diffuse red cystic nodular lesions|672
    omentum|672
    peritoneal surfaces|672
    sigmoid mesentery|672
    uterine serosa|672
    right ovary enlarged|672
    complex cystic appearance|672
    intraoperative frozen section of omentum|672
    thyroid neoplasm|672
    cytoreduction|672
    robotic-assisted total laparoscopic hysterectomy|672
    right salpingo-oophorectomy|672
    extensive peritoneal resection|672
    omentectomy|672
    no gross residual disease|672
    pathology|672
    resected specimen|672
    right ovary|672
    fallopian tube|672
    omentum|672
    peritoneum|672
    sigmoid mesentery|672
    anterior abdominal wall|672
    variable-sized mature thyroid follicles|672
    strumosis|672
    metastatic lesions|672
    cytologic features consistent with PTC|672
    enlarged elongated nuclei|672
    chromatin clearing|672
    frequent nuclear grooves|672
    PD-L1 testing positive|672
    CPS score 4|672
    comprehensive molecular tumor testing|672
    pathogenic NRAS Q61R mutation|672
    tumor mutational burden 4.2 m/MB|672
    microsatellite stability|672
    inter-disciplinary discussion|672
    gynecologic oncology|672
    pathology|672
    endocrinology|672
    surgical oncology|672
    thyroglobulin 127 ng/ml|1008
    TSH 1.97|1008
    plan for total thyroidectomy|1008
    radioactive iodine therapy|1008
    uncomplicated thyroidectomy|1056
    final pathology benign|1056
    I-131 therapy|1056
    post treatment whole body I-131 scan|1056
    follow up in 3-4 months|1056
    recurrence of malignant struma ovarii|672
    metastatic disease|672
    low-risk disease initially|0
    no history of hyperthyroidism|0
    no lymphovascular invasion|0
    no ovarian capsule involvement|0
    no evidence of malignant cells in washings|0
    normal thyroid function|0
    normal thyroglobulin for 2 years|0
    elevated thyroglobulin at 2 years|504
    recurrence identified|504
    peritoneal metastases|672
    molecular testing with NRAS mutation|672
    planned adjuvant therapy|1008
    benign thyroid gland|1056
    informed consent obtained|0
    no competing interests|0
    <|eot_id|>
    