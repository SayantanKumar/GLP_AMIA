75 years old | 0
    woman | 0
    referred to our hospital | 0
    progressive shortness of breath | -1440
    chest pressure | -1440
    recurrent left pleural effusion | -1440
    recent left atrial appendage closure with Watchman device | -1440
    symptoms started following LAA closure procedure | -1440
    symptoms progressed in severity | -1440
    multiple emergency department visits | -1440
    prior hospitalization | -1440
    2 thoracenteses | -1440
    draining clear fluid | -1440
    subjective fevers | -1440
    20-pound weight loss | -1440
    lack of appetite | -1440
    paroxysmal atrial fibrillation | 0
    hypertension | 0
    dyslipidemia | 0
    well-controlled diabetes mellitus type 2 | 0
    hemoglobin A1c 6.6% | 0
    chronic kidney disease | 0
    aspirin | 0
    bisoprolol | 0
    evolocumab | 0
    ferrous sulfate | 0
    fluoxetine | 0
    gabapentin | 0
    rosuvastatin | 0
    semaglutide | 0
    furosemide | 0
    chest radiograph on admission | 0
    reaccumulation of left pleural effusion | 0
    placement of a chest tube | 0
    drainage of clear yellow exudative pleural fluid | 0
    lymphocyte predominance | 0
    white blood cells 425 cells/μl | 0
    red blood cells 7,123 cells/μl | 0
    neutrophils 12% | 0
    lymphocytes 50% | 0
    eosinophils 1% | 0
    total protein 3.8 g/dl | 0
    glucose 176 mg/dl | 0
    cultures negative | 0
    cytology negative | 0
    chronic anemia | 0
    elevated hs-CRP 63.9 mg/l | 0
    chest CT | 0
    multiple sub-centimeter lung nodules | 0
    not fluorodeoxyglucose avid | 0
    small-size pericardial effusion | 0
    unchanged | 0
    preserved left ventricular ejection fraction | 0
    no signs of restriction or constriction | 0
    transesophageal echocardiogram | 0
    Watchman device seated in LAA | 0
    small 1-mm leak | 0
    cardiac CT with contrast | 0
    occlusive device in LAA | 0
    passage of contrast into distal LAA | 0
    small 1-mm peridevice leak | 0
    no passage of contrast into pericardial or pleural spaces | 0
    chest pain | 0
    stable pericardial effusion | 0
    recurrent pleural effusion | 0
    nonbloody pleural effusion | 0
    elevated hs-CRP | 0
    inflammatory process | 0
    pericarditis | 0
    recurrent left pleural effusion | 0
    microperforation of fixation anchors | 0
    treated conservatively | 0
    nonsteroidal anti-inflammatory drugs | 0
    colchicine | 0
    not treated with anti-inflammatory medications | 0
    symptoms improved | 0
    chest pain improved | 0
    shortness of breath improved | 0
    predischarge chest radiograph | 0
    3 days | 72
    left basilar atelectasis | 72
    no reaccumulation of left pleural effusion | 72
    chest tube removal | 72
    significant improvement in symptoms | 72
    discharged | 72
    resolution of symptoms | 504
    started experiencing intermittent chest pain | 504
    repeat chest CT at 3 weeks | 504
    unchanged small left pleural effusion | 504
    trace pericardial effusion | 504
    advised to take NSAIDs as needed | 504
    relief of chest pain | 504
    complete resolution of symptoms | 1344
    resumed daily activities | 1344
<|eot_id|>