68 years old | 0
    woman | 0
    longstanding type 2 diabetes | 0
    diabetic polyneuropathy | 0
    lower-leg edema | 0
    painful sores | -7300
    pruritic sores | -7300
    sores on the bilateral lower extremities | -7300
    hyperkeratotic papules | -7300
    nodules on the bilateral shins | -7300
    subsequent lesions developed over the calves | -7300
    ulcerated | -7300
    otherwise healthy | 0
    no fever | 0
    no cough | 0
    no lymphadenopathy | 0
    presented to an outside clinic | -7200
    lesions reflect eczematous changes | -7200
    bacterial superinfection | -7200
    topical triamcinolone | -7200
    topical compounded mupirocin/clindamycin/ivermectin/gentamicin | -7200
    oral ciprofloxacin | -7200
    oral fluconazole 150 mg | -7200
    minimal improvement | -7200
    computed tomography angiogram | -7200
    unremarkable | -7200
    duplex ultrasound with Doppler | -7200
    unremarkable | -7200
    biopsy | -7200
    stasis dermatitis | -7200
    extensive fungal hyphae | -7200
    no long-term systemic antifungal therapy | -7200
    lives in middle Tennessee | 0
    spouse | 0
    cat | 0
    avid gardener | 0
    tends to rosebushes | 0
    frequently wears capri pants when gardening | 0
    never used tobacco | 0
    no illicit substances | 0
    rarely drinks alcohol | 0
    denies any recent travel | 0
    medications | 0
    dulaglutide | 0
    omeprazole | 0
    pain medications | 0
    vitamin supplements | 0
    no immunosuppressive medications | 0
    elevates her legs nightly | 0
    ice therapy | 0
    physical exam | 0
    vegetative papules | 0
    hyperkeratotic papules | 0
    plaques | 0
    central ulceration | 0
    background erythema | 0
    stasis changes | 0
    plaques non-tender | 0
    plaques cool to touch | 0
    no nail changes | 0
    no additional skin changes | 0
    hemoglobin A1c 11.8% | 0
    white blood cell count 5600/mm3 | 0
    complete metabolic panel unremarkable | 0
    bacterial cultures no growth | 0
    acid-fast bacilli cultures no growth | 0
    fungal tissue cultures positive | 0
    Paecilomyces lilacinus | 0
    Candida guilliermondii | 0
    no antifungal susceptibility | 0
    histopathologic evaluation | 0
    dermal fibroplasia | 0
    mixed neutrophilic and lymphocytic dermal inflammation | 0
    no abscess | 0
    no granuloma | 0
    Grocott methenamine silver stain | 0
    fungal hyphae within the stratum corneum | 0
    Gram staining failed | 0
    acid-fast bacilli staining failed | 0
    diagnosed with cutaneous Paecilomyces lilacinus and Candida guilliermondii infection | 0
    started on oral voriconazole 200 mg every 12 hours | 0
    topical triamcinolone | 0
    plastic wraps | 0
    marked improvement at 2 months | 720
    planned 6-month course of antifungal therapy | 0
    slow-healing plaques | 0
    crusted over | 0
    healed completely | 0
    scarring | 0
    post-inflammatory hyperpigmentation | 0
    no new development of ulcerative papules | 0
    no new development of plaques | 0
    discharged | 0
    