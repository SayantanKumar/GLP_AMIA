55 years old | 0
    female | 0
    nulliparous | 0
    uterine fibroids | 0
    hypertension | 0
    insulin resistance | 0
    vaginal bleeding | -4320
    BMI 80 kg/m2 | 0
    trans-vaginal pelvic ultrasound | 0
    endometrial thickness 44 mm | 0
    hysteroscopy | 0
    endometrial biopsy | 0
    levonorgestrel IUD insertion | 0
    atypical endometrial hyperplasia | 0
    super-morbid obesity | 0
    total hysterectomy and BSO delayed | 0
    target weight 160 kg | 0
    bariatric surgery declined | 0
    weight loss with dietician and exercise programs | 0
    weight plateaued at 195 kg | 0
    repeat endometrial biopsy | 2880
    grade 1 EAC of the uterus | 2880
    estrogen receptor positive | 2880
    progesterone receptor positive | 2880
    loss of MLH1 | 2880
    loss of PMS2 | 2880
    CT scan chest abdomen pelvis | 2880
    no metastatic disease | 2880
    multidisciplinary discussion | 2880
    medroxyprogesterone 100 mg oral twice daily commenced | 2880
    levonorgestrel IUD continued | 2880
    ongoing plan for weight loss | 2880
    weight decreased to 180 kg | 5760
    Liraglutide | 5760
    Metformin | 5760
    bariatric surgery declined again | 5760
    repeat curettage | 5760
    regression to atypical endometrial hyperplasia | 5760
    medroxyprogesterone increased to 200 mg oral twice daily | 5760
    further weight loss recommended | 5760
    blood-stained fluid discharge from umbilicus | 7200
    CT scan abdomen pelvis | 7200
    umbilical soft tissue mass 32x33x39 mm | 7200
    suspicious for metastasis | 7200
    core biopsy | 7200
    FIGO grade 1 EAC | 7200
    ER positive | 7200
    PR positive | 7200
    loss of MLH1 | 7200
    loss of PMS2 | 7200
    PET scan | 7200
    increased uptake in uterus | 7200
    increased uptake in umbilicus | 7200
    increased uptake in left parametrial lymph node | 7200
    increased uptake in right inguinal node | 7200
    suspicious for metastatic disease | 7200
    CA-125 raised at 420 U/mL | 7200
    diagnostic laparoscopy | 7200
    no widespread peritoneal disease | 7200
    systemic therapy commenced | 7200
    aromatase inhibitor (letrozole) | 7200
    disease progression after three months | 7920
    changed to Carboplatin-Paclitaxel combination chemotherapy | 7920
    immunotherapy with check-point inhibitor considered | 7920
    immunotherapy not affordable | 7920
    after 3 cycles neoadjuvant chemotherapy | 7920
    CA-125 reduced to 50 U/mL | 7920
    weight 157 kg | 7920
    repeat CT scan | 7920
    increase in umbilical soft tissue mass to 72x70x100 mm | 7920
    no new sites of disease | 7920
    surgery delayed | 7920
    asymptomatic pulmonary embolism | 7920
    treated with Apixaban for 12 weeks | 7920
    chemotherapy continued | 7920
    cytoreductive surgery | 8640
    robotic total hysterectomy | 8640
    BSO | 8640
    right inguinal lymph node resection | 8640
    resection of umbilical mass | 8640
    primary abdominal wall closure | 8640
    tumor removed except 1 cm deep nodule in left pararectal peritoneum | 8640
    post-operative recovery complicated | 8640
    infected abdominal wall seroma | 8640
    Clavien Dindo grade 2 adverse event | 8640
    prolonged drainage | 8640
    systemic antibiotics | 8640
    oral antibiotics | 8640
    total ten days antibiotics | 8640
    endometrioid adenocarcinoma FIGO grade 1 in uterus | 8640
    endometrioid adenocarcinoma FIGO grade 2 in right inguinal lymph node | 8640
    dedifferentiated endometrial carcinoma in umbilical lesion | 8640
    loss of MLH1 in all specimens | 8640
    loss of PMS2 in all specimens | 8640
    surgical stage IVB | 8640
    further 3 cycles Carboplatin-Paclitaxel chemotherapy | 8640
    total of 6 cycles | 8640
    external beam radiation to right inguinal region | 8640
    germline testing negative for Lynch syndrome | 8640
    CT scan chest abdomen pelvis | 8640
    progressive disease in peritoneum | 8640
    progressive disease in retroperitoneal lymph nodes | 8640
    referred for clinical trial with immune check-point inhibitor | 8640
    alive at 14 months since diagnosis of umbilical metastatic disease | 8640
    alive at 7 months since cytoreductive surgery | 8640
    