45 years old|0
    woman|0
    presented to the ED|0
    sudden onset of right flank pain|0
    sweating|0
    lightheadedness|0
    fainting|0
    recovered within a minute|0
    brought to the ED by emergency medical services|0
    no history of fever|0
    no history of vomiting|0
    no history of falls|0
    no history of urinary tract symptoms|0
    no jerky movements|0
    no post-event confusion|0
    type 2 diabetes|0
    Semaglutide|0
    pulse 88/min|0
    blood pressure 115/75 mmHg|0
    respiratory rate 18/min|0
    temperature 36.4 C|0
    abdomen soft|0
    mild tenderness in the right flank|0
    mild tenderness in the right costovertebral angle|0
    hemoglobin 13.3 gm/dl|0
    raised total leukocyte count 15.6 ×109/L|0
    neutrophilic shift|0
    urinalysis positive for red blood cells|0
    urinalysis positive for hemoglobinuria|0
    PoCUS performed|0
    hyperechoic heterogeneous mass visualized|0
    anechoic region surrounding the right kidney|0
    urgent CT abdomen ordered|0
    large heterogenous exophytic right renal mass|0
    mass contained fat-density elements|0
    mass contained soft tissue|0
    mass contained prominent vessels|0
    angiomyolipoma|0
    large perinephric hematoma|0
    tumor bleed|0
    consultation sought from urology|0
    consultation sought from interventional radiology|0
    angioembolization conducted|0
    admitted under urology service|0
    monitoring of hemoglobin levels|0
    hemoglobin levels stable|0
    no blood product transfusion|0
    discharged|72
    prescription for oral analgesics|72
    uneventful recovery|72
    rupture leading to hemorrhagic shock|0
    diagnosis of AML|0
    diagnosis of rupture|0
    clinical evaluation|0
    laboratory investigations|0
    imaging modalities|0
    CT scan first imaging modality|0
    PoCUS rapid assessment|0
    real-time visualization|0
    no radiation exposure|0
    presence of masses|0
    presence of free fluid|0
    signs of rupture|0
    patient lying supine|0
    low-frequency curvilinear array transducer selected|0
    abdominal preset|0
    renal preset|0
    transducer placed longitudinally over the posterior axillary line|0
    transducer swept anteriorly and posteriorly|0
    transducer rotated 90 degrees|0
    kidney evaluated in transverse view|0
    typical features of AML|0
    well-defined structure|0
    surrounded by renal parenchyma|0
    variable echogenicity|0
    presence of fat|0
    presence of blood vessels|0
    presence of smooth muscles|0
    hypoechogenicity suggestive of free fluid|0
    hematoma secondary to rupture|0
    limited evidence regarding ultrasound|0
    study by Sapadin et al.|0
    US detected ruptured AML|0
    hemorrhagic shock|0
    study by T. Zhang et al.|0
    spontaneous rupture of renal AML|0
    pregnant woman|0
    PoCUS rapidly identified ruptured AML|0
    rapid referral to interventional radiology|0
    rapid referral to urology|0
    definitive management|0
    emergency physicians expertise|0
    managing patients with syncope|0
    undifferentiated abdominal pain|0
    sudden onset of flank pain|0
    syncope|0
    PoCUS findings revealing ruptured angiomyolipoma|0
    urgent confirmatory imaging|0
    multidisciplinary collaboration|0
    prompt interpretation of imaging findings|0
    coordination with urology|0
    coordination with interventional radiology|0
    timely intervention|0
    angioembolization|0
    acute care|0
    decision-making within emergency medicine|0
    approval for ERC applied|0
    written informed consent to participate obtained|0
    informed consent for publication obtained|0
    no competing interests|0
    <|eot_id|>