30 years old| 0
    female| 0
    obese| 0
    weight 95 kg| 0
    body mass index 36 kg/m2| 0
    type II diabetes| 0
    oral medication| 0
    cesarean section| -17520
    situs inversus totalis| -17520
    failed to lose weight| -168
    dieting| -168
    exercise| -168
    medical treatment| -168
    liraglutide injection| -168
    informed about bariatric surgeries| -24
    preferred laparoscopic sleeve gastrectomy| -24
    multidisciplinary approach| -24
    preoperative workup| -24
    normal laboratory investigations| -24
    complete blood count| -24
    coagulation profile| -24
    renal profile with electrolyte| -24
    liver profile| -24
    lipid profile| -24
    hormones| -24
    chemistry| -24
    vitamins| -24
    electrocardiography| -24
    extreme axis deviation| -24
    northwest axis| -24
    upright P waves in AVR lead| -24
    inverted P waves in leads I and II| -24
    echocardiography| -24
    chest X-ray| -24
    dextrocardia| -24
    barium meal test| -24
    right-sided stomach| -24
    no contrast obstruction| -24
    ultrasound of the abdomen| -24
    normal gall bladder| -24
    evaluated by cardiology| -24
    evaluated by endocrinology| -24
    evaluated by anesthesia| -24
    evaluated by respirology| -24
    fit for surgery| -24
    no associated organic abnormalities| -24
    induction of general anesthesia| 0
    intubation| 0
    positioned in reverse Trendelenburg position| 0
    French method| 0
    surgeon standing between legs| 0
    skin preparation| 0
    draping| 0
    carbon dioxide insufflation| 0
    Veress needle at Palmar's space| 0
    pressure 12 mmHg| 0
    trocar inserted into supra-umbilical region| 0
    10 mm 30 degree scope| 0
    examination of peritoneal cavity| 0
    right-sided stomach| 0
    right-sided spleen| 0
    left-sided liver| 0
    left-sided gallbladder| 0
    monitor at right shoulder| 0
    nursing assistant on left side| 0
    15 mm trocar inserted into left upper quadrant| 0
    12 mm trocar inserted at right upper quadrant| 0
    iron intern laparoscopic liver retractor| 0
    lift hepatic lobe| 0
    dissection| 0
    take down gastrocolic ligament| 0
    from left-sided trocar| 0
    proximal to pylorus| 0
    to base of right diaphragmatic crus| 0
    dissection of gastrosplenic ligament| 0
    stapling| 0
    Endo GIA black articulating reload with tri-staple technology 60 mm| 0
    2 cm proximal to pylorus| 0
    36 Fr calibrating tube inserted orally| 0
    under direct vision| 0
    up to pylorus| 0
    stapling remainder of stomach| 0
    Endo GIA purple articulating reload with tri-staple technology 60 mm| 0
    ended 2 cm lateral to gastroesophageal junction| 0
    staple line reinforced| 0
    Endo clips| 0
    at overlap| 0
    at bleeding spots| 0
    calibrating tube pulled out to GEJ| 0
    methylene blue leak test| 0
    no leak| 0
    calibrating tube removed| 0
    interrupted 2.0 vicryl gastropexy stitches| 0
    between sleeved stomach and prepancreatic fascia| 0
    maintain banana-like shape| 0
    5 mm free gravity surgical drain inserted| 0
    at right upper quadrant| 0
    tip near GEJ| 0
    resected stomach removed| 0
    port sites closed| 0
    skin closed| 0
    surgical duration 28 min| 0
    no surgical complications| 0
    no anesthesia complications| 0
    extubated| 0.5
    transferred to recovery room| 0.5
    oral fluid intake| 6
    gastrografin leak test| 24
    satisfactory contrast flow| 24
    no leak| 24
    drain removed| 24
    discharged| 24
    met with dietitian| 24
    provided written instructions| 24
    followed up at outpatient clinic| 168
    exclude early postoperative complications| 168
    wound care| 168
    followed up at 3 months| 2160
    satisfied| 2160
    weight 83 kg| 2160
    followed up at 6 months| 4320
    satisfied| 4320
    weight 75 kg| 4320
    followed up at 12 months| 8640
    satisfied| 8640
    weight 63 kg| 8640
    no complaints| 8640
    good glycemic control| 8640
    off medications| 8640
    <|eot_id|>