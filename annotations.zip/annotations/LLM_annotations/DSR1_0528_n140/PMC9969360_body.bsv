70 years old | 0
    woman | 0
    enrolled in PACE | 0
    left lower extremity pain | 0
    generalized weakness | 0
    major depressive disorder | 0
    mild depression | 0
    HDL 47 mg/dL | 0
    LDL 97 mg/dL | 0
    total cholesterol 176 mg/dL | 0
    atherosclerotic cardiovascular disease risk 20.3% | 0
    high-intensity statin therapy indicated | 0
    high risk of statin intolerance | 0
    medication safety review requested | 0
    fluoxetine changed to citalopram | 36
    ezetimibe discontinued | 36
    atorvastatin 20 mg changed to pravastatin 40 mg | 36
    time in therapeutic range for warfarin less than 50% | 0
    unstable INR readings | 0
    PGx test ordered | 87
    decreased function of SLCO1B1 | 87
    increased warfarin sensitivity | 87
    drug-drug-gene interaction between warfarin and citalopram | 87
    separate time of administration recommended | 87
    minor left lower extremity pain primarily at night | 180
    improved wellbeing | 180
    HDL 51 mg/dL | 240
    LDL 70 mg/dL | 240
    total cholesterol 134 mg/dL | 240
    wide INR ranges | 240
    INR checked every 3 to 4 days | 240
    INR more stable | 240
    MedWise Risk Score decreased from high to moderate | 240
    improved mental and physical health | 240
    motor vehicle accident | -87600
    statin therapy reduces threshold for muscle pain | -87600
    statin-associated muscular symptoms risk factors present | 0
    preemptive PGx testing would have minimized risk | 0
    pravastatin 40 mg more appropriate than atorvastatin | 36
    diltiazem and warfarin have affinity for CYP3A4 | 0
    atorvastatin may have contributed to left lower extremity pain | 0
    pravastatin not extensively metabolized by CYP system | 36
    SLCO1B1 decreased function decreases statin benefit | 87
    statin alternatives exist | 0
    ezetimibe removal recommendation | 36
    PGx-guided warfarin dosing supported | 0
    atrial fibrillation | 0
    mechanical mitral valve | 0
    warfarin most appropriate anticoagulant | 0
    VKORC1 polymorphism increases warfarin sensitivity | 87
    CYP2C9 polymorphism increases warfarin sensitivity | 87
    CYP4F2 polymorphism decreases warfarin sensitivity | 87
    increased warfarin sensitivity more probable | 87
    PGx testing beneficial early | 0
    decreased SLCO1B1 function increases statin exposure | 87
    statin-induced myalgia | 0
    preemptive PGx testing reduces risk | 0
    medications: atorvastatin 20 mg daily | 0
    ezetimibe 10 mg daily | 0
    carvedilol 12.5 mg twice daily | 0
    furosemide 20 mg daily | 0
    diltiazem 120 mg twice daily | 0
    doxycycline hyclate 100 mg twice daily | 0
    fluoxetine 20 mg daily | 0
    dulaglutide 0.75 mg weekly | 0
    insulin glargine 10 units three times daily | 0
    insulin aspart 5 units daily | 0
    lansoprazole 30 mg daily | 0
    levothyroxine 200 mcg daily | 0
    lorazepam 0.5 mg up to three times daily | 0
    warfarin 17.5 mg weekly | 0
    recommendations: diltiazem discontinuation rejected | 36
    lorazepam discontinuation rejected | 36
    lansoprazole change time to bedtime accepted | 36
    carvedilol monitor symptoms accepted | 87
    lansoprazole discontinue or switch rejected | 87
    pravastatin reduce dose to 20 mg rejected | 87
    warfarin frequent INR assessments accepted | 87
    start lisinopril 2.5 mg accepted | 87
    PGx results: CYP2C9 intermediate metabolizer | 87
    CYP2C19 normal metabolizer | 87
    CYP2D6 intermediate metabolizer | 87
    CYP4F2 reduced activity | 87
    SLCO1B1 decreased function | 87
    VKORC1 low activity | 87
    patient consent obtained | 0
    <|eot_id|>
    
