32 years old | 0
    woman | 0
    referred to our unit | 0
    refractory diarrhea | 0
    diarrhea lasting 10 years | -87600
    recurrent depression | -131400
    primary tonic-myoclonic epilepsy | -131400
    colonic Crohn’s disease | -52560
    75selenium homotaurocholic acid test scintigraphy | -52560
    severe bile acid malabsorption | -52560
    colestyramine | -52560
    colesevelam | -52560
    loperamide | -52560
    codeine phosphate | -52560
    6-mercaptopurine | 0
    levetiracetam | 0
    lamotrigine | 0
    escitalopram | 0
    venlafaxin | 0
    infliximab | 0
    adalimumab | 0
    natalizumab | 0
    vedolizumab | 0
    Crohn’s disease remission | 0
    colonoscopy | 0
    fecal calprotectin measurement | 0
    duodenal biopsies normal | 0
    no bowel surgery | 0
    height 170 cm | 0
    weight 52 kg | 0
    severe electrolyte deficiency | 0
    low plasma potassium | 0
    low plasma magnesium | 0
    normal plasma sodium | 0
    urinary sodium below detection limit | 0
    fecal cultures negative | 0
    PCR toxin test for Clostridium difficile positive | 0
    vancomycin | 0
    transient effect on diarrhea | 0
    repeat fecal tests negative | 0
    MRI of small bowel | 0
    pan-enteric double balloon endoscopy | 0
    endoscopic remission | 0
    duodenal biopsies normal | 0
    jejunal biopsies normal | 0
    ileal biopsies normal | 0
    colonic biopsies normal | 0
    laxative screen normal | 0
    markers of systemic infection normal | 0
    markers of metabolic disease normal | 0
    spironolactone | 0
    octreotide | 0
    liraglutide | 0
    no effect | 0
    unacceptable side effects | 0
    dose of 6-mercaptopurine optimized | 0
    normal TPMT genotype | 0
    normal TPMT phenotype | 0
    E-TGN level 247 nmol/mmol HGB | 0
    E-MeMP level 2354 nmol/mmol HGB | 0
    persistent dehydration | 0
    watery stools up to 5 L per day | 0
    potassium levels normalized | 0
    intravenous potassium | 0
    urinary sodium measurable | 0
    hypertonic NaCl applied | 0
    intravenous supplementation | 0
    type III intestinal failure | 0
    twice weekly infusions | 0
    underweight | 0
    watery diarrhea | 0
    poor quality of life | 0
    obeticholic acid trial | 0
    Intercept Pharmaceuticals collaboration | 0
    National Health Authorities approval | 0
    repeat Clostridium difficile test positive | 0
    fecal transplant | 0
    mean number of bowel passages decreased from 17 to 13 | 0
    obeticholic acid started at 10 mg per day | 0
    obeticholic acid increased to 25 mg per day | 96
    number of bowel movements decreased from 13 to 7 per 24 h | 120
    nightly bowel movements reduced from 3 to 2 | 120
    occasional nights without bowel openings | 120
    weight increased by 2 kg to 54 kg | 120
    weaned off intravenous fluid support | 120
    resumed social activities | 120
    running | 120
    occasional increase in bowel movements | 120
    ibuprofen transiently induced liquid stools | 120
    quality of life improved | 120
    overall wellbeing 35 before treatment | 0
    overall wellbeing 85 after treatment | 336
    treatment pause | 2160
    condition deteriorated | 2184
    number of bowel movements increased to 16 | 2184
    profound hypokalemia | 2184
    obeticholic acid restarted | 2184
    bowel control reestablished | 2184
    6 mo follow-up | 4320
    no adverse effects | 4320
    control of Crohn’s disease unchanged | 4320
    control of epilepsy unchanged | 4320
    control of depression unchanged | 4320
    increased serum pancreatic amylase 266 U/L | 4320
    pause of 6-mercaptopurine | 4320
    ultrasound examination normal | 4320
    p-amylase normalized | 4320
    treatment restarted | 4320
    no further episodes | 4320
    plasma lipids slightly elevated before treatment | 0
    total cholesterol decreased from 7.5 to 5.9 mmol/L | 4320
    LDL-cholesterol decreased from 4.5 to 3.1 mmol/L | 4320
    HDL-cholesterol increased from 2.0 to 2.1 mmol/L | 4320
    fasting serum FGF19 measured | 0
    mean FGF19 increased from 35.7 to 167.0 pg/mL | 4320
    marked fluctuation in serum FGF19 levels | 4320
    serum FGF19 concentrations 21 pg/mL to 728 pg/mL | 4320