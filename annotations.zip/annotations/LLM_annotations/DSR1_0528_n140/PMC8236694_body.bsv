55 years old | 0
    male | 0
    admitted to the hospital | 0
    relapsing-remitting multiple sclerosis | -87600
    methylprednisolone | -87600
    high-dose intravenous methylprednisolone | -87600
    oral methylprednisolone | -87600
    methotrexate | -87600
    Tripterygium wilfordii | -87600
    hiccups | -87600
    numbness in hands | -87600
    fasting blood glucose 8.0 mmol/L | -17520
    fasting blood glucose 13.0 mmol/L | -1440
    HbA1c 12.4% | -1440
    steroid-induced diabetes | -1440
    poor glycemic control | 0
    height 168 cm | 0
    body weight 85 kg | 0
    BMI 30.1 kg/m2 | 0
    body temperature 36.5 °C | 0
    blood pressure 124/75 mmHg | 0
    pulse 75 beats/minute | 0
    hyperinsulinemia | 0
    severe insulin resistance | 0
    abnormal liver function | 0
    ALT 178 U/L | 0
    AST 198 U/L | 0
    γ-GTP 265 U/L | 0
    diammonium glycyrrhizinate enteric-coated capsules | 0
    insulin aspart | 0
    insulin glargine | 0
    insulin allergy | 72
    wheals | 72
    redness | 72
    itching | 72
    hypereosinophilia | 72
    high total IgE level | 72
    eosinophilic infiltration | 72
    insulin aspart plus glargine | 72
    insulin lispro plus glargine | 72
    induration at injection sites | 168
    hypereosinophilia persisted | 168
    hepatic enzyme concentrations normal | 168
    metformin | 168
    unsatisfactory glucose control | 168
    symptoms of insulin allergy | 168
    liraglutide | 168
    insulin glargine | 168
    insulin lispro | 168
    oral metformin | 168
    fasting hyperglycemia decreased | 168
    postprandial hyperglycemia decreased | 168
    blood glucose level 7.1 mmol/L | 240
    insulin lispro reduced | 240
    insulin glargine reduced | 240
    liraglutide increased | 240
    satiety | 240
    no nausea | 240
    no diarrhea | 240
    induration diminished | 240
    insulin lispro discontinued | 336
    liraglutide | 336
    metformin | 336
    insulin glargine | 336
    HbA1c 8.6% | 336
    fasting blood glucose 5.2–6.7 mmol/L | 336
    serum insulin improved | 336
    eosinophil levels improved | 336
    no wheals | 336
    no redness | 336
    no itching | 336
    body weight decreased 6.8 kg | 2880
    