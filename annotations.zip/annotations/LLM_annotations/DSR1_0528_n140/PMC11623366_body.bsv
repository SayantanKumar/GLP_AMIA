60 years old | 0
    female | 0
    metabolic syndrome | 0
    BMI 43 kg/m2 | 0
    elective revision bariatric surgery | 0
    weight gain | -105120
    laparoscopic gastric band | -78840
    laparoscopic gastric sleeve | -52560
    chronic back pain | 0
    weight regain | 0
    blood pressure well treated | 0
    dyslipidaemia | 0
    statin intolerance | 0
    occasional intermittent abdominal pain | 0
    laparoscopic cholecystectomy | -unknown
    surgery abandoned | 0
    extensive mesenteric adhesions | 0
    shortening of the mesentery | 0
    interloop adhesions of the intestines | 0
    biopsy of abnormal mesenteric tissue | 0
    histopathology | 0
    reactive epithelial changes | 0
    diffuse intraepithelial lymphocytes | 0
    consistent with MP | 0
    abdominal CT scan | 0
    mildly prominent lymph nodes | 0
    characteristic central mesenteric fat infiltration | 0
    consistent with MP | 0
    family history negative for MP or FD | 0
    worsening intermittent left-sided facial pain | 8760
    ocular symptoms | 8760
    progressive facial disfigurement | 8760
    difficulty with wearing glasses | 8760
    CT scan of the head | 17520
    left orbital enlargement | 17520
    multiple apparent osteochondromas | 17520
    along left lateral orbit | 17520
    squamosal temporal bone | 17520
    MRI | 26280
    left FD of the zygoma | 26280
    ground glass appearance | 26280
    consistent with FD | 26280
    chronic intermittent abdominal pain | 0
    without bowel disturbances | 0
    obesity | 0
    malignancy ruled out | 0
    cholecystitis ruled out | 0
    bile duct cholecystitis ruled out | 0
    diverticulitis ruled out | 0
    pancreatitis ruled out | 0
    fat masses | 0
    lipomas ruled out | 0
    pseudo-tumours ruled out | 0
    malignant tumours ruled out | 0
    definitive biopsy confirmation of MP | 0
    no specific treatment for MP | 0
    initial treatment tamoxifen | -unknown
    venous thromboembolism | -unknown
    azathioprine not tolerated | -unknown
    linaclotide ineffective | -unknown
    unilateral bony swelling of the face | 8760
    osteosarcoma ruled out | 26280
    osteomyelitis ruled out | 26280
    non-ossifying fibroma ruled out | 26280
    radiological studies confirmatory of FD | 26280
    biopsies not always feasible | 0
    not undergoing active treatment for FD | 0
    under surveillance | 0
    metabolic syndrome | 0
    central obesity | 0
    blood pressure | 0
    blood metabolic markers | 0
    chronic inflammation | 0
    raised inflammatory markers | 0
    sleep apnoea | 0
    tachycardia | 0
    liver failure | 0
    heart failure with preserved-ejection fraction | 0
    abdominal pain | 0
    facial pain with trigeminal distribution | 0
    severity 6 out of 10 at rest | 0
    occasional abdominal swelling | 0
    chronic back pain | 0
    radiculopathy | 0
    constipation | 0
    depression | 0
    poor quality of life | 0
    treatment for sleep apnoea | 0
    new onset hearing loss | 0
    possible auditory nerve involvement | 0
    abdominal CT scan | 26280
    persistent and unchanged MP | 26280
    hepatic steatosis | 26280
    diabetes type 2 | 0
    GLP-1 agonists | 0
    semaglutide | 0
    tirzepatide | 0
    initial weight loss | 0
    highly sensitive C-reactive protein elevated | 0
    elevated since 2017 | 0
    16.1 to 29.7 mg/dl | 0
    latest 24.1 mg/dl in June 2024 | 0
    erythrocyte sedimentation rate increased | 0
    34 to 42 mm/hr | 0
    no leucocytosis | 0
    no anaemia | 0
    HDL cholesterol not greater than 40 mg/dl | 0
    slightly increased triglycerides | 0
    normal LDL cholesterol | 0
    MP | 0
    craniofacial FD | 26280
    persistently elevated inflammatory markers | 0
    previous intra-abdominal surgeries | -unknown
    systemic inflammatory cause | 0
    incidence of MP underestimated | 0
    50% of cases asymptomatic | 0
    found incidentally | 0
    extensive MP | 0
    found incidentally | 0
    frustrating course | 0
    limited treatment options | 0
    FD atypical | 26280
    craniofacial FD more common in children | 0
    usual genetic aetiology | 0
    late and atypical presentation | 0
    genetic causal relationship unclear | 0
    subclinical cases more common | 0
    metabolic syndrome prevalent for decades | 0
    beginning in childhood | -unknown
    progressive | 0
    MP and FD unlikely directly related | 0
    share common elements | 0
    localized cellular proliferation | 0
    inflammation | 0
    systematic influences | 0
    chronic inflammation | 0
    significant contributory factor | 0
    previous case MP with primary Sjogren’s | 0
    previous work up for rheumatological diseases negative | 0
    similar case FD in pelvis with metabolic syndrome | 0
    subsequent diabetes | 0
    decades of raised inflammation | 0
    preceded the two rare diseases | 0
    metabolic syndrome significant underlying factor | 0
    metabolic syndrome significant association with MP | 0
    present in 45% of patients with MP | 0
    compared to 31.8% of controls | 0
    study of 3698 patients with MP | 0
    metabolic syndrome in children and young adults | 0
    comprehensive management | 0
    paradigm shift | 0
    true incidence of MP higher | 0
    asymptomatic | 0
    findings incidental | 0
    radiology testing | 0
    treatment options limited | 0
    clinicians not motivated | 0
    benign condition | 0
    FD incidentally in radiological studies | 0
    no definitive treatment | 0
    asymptomatic | 0
    no active management | 0
    radiological findings should be given greater clinical importance | 0
    increasing awareness | 0
    critical first step | 0
    early diagnosis | 0
    advanced disease less amenable to treatment | 0
    MP | 0
    FD | 26280
    increased awareness | 0
    diagnosis | 0
    research | 0
    early and aggressive management of metabolic syndrome | 0
    critical to long-term metabolic health | 0
    quality of life | 0
    aging | 0
    <|eot_id|>
    