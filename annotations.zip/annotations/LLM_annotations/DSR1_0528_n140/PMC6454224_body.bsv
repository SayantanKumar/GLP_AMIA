45 years old | 0
    white | 0
    male | 0
    carpenter | 0
    referred by GP to bariatric clinic | 0
    assessment | 0
    management | 0
    severe obesity | 0
    poorly controlled type 2 diabetes | 0
    type 2 diabetes duration 10 years | 0
    well-controlled hypertension | 0
    dyslipidaemia | 0
    stable non-alcoholic steatohepatitis | 0
    insulin aspart | 0
    insulin glargine | 0
    metformin | 0
    ramipril | 0
    simvastatin | 0
    aspirin | 0
    does not drink alcohol | 0
    stopped smoking | -4392
    smoking history 26 pack year | 0
    mother had type 2 diabetes | 0
    sister had type 2 diabetes | 0
    single | 0
    lived with two siblings | 0
    persistently elevated glucometer readings | -2928
    thirst | -2928
    polydipsia | -2928
    polyuria | -2928
    nocturia | -2928
    poor glycaemic control | -2928
    weight 113.8 kg | 0
    height 168.2 cm | 0
    BMI 40.2 kg/m2 | 0
    waist 117 cm | 0
    hip 120 cm | 0
    waist-to-hip ratio 0.98 | 0
    BP 105/62 mmHg | 0
    no evidence of retinopathy | 0
    no evidence of neuropathy | 0
    no evidence of cutaneous markers of insulin resistance | 0
    HbA1c 72 mmol/mol (8.7%) | 0
    total cholesterol 3.3 mmol/L | 0
    LDL 0.8 mmol/L | 0
    HDL 1.0 mmol/L | 0
    triglycerides 1.9 mmol/L | 0
    liver profile normal | 0
    iron studies normal | 0
    renal function tests normal | 0
    thyroid function tests normal | 0
    ECG normal | 0
    right bundle branch block | 0
    bariatric treatment options discussed | 0
    declined laparoscopic sleeve gastrectomy | 0
    declined GLP1 agonist therapy | 0
    no evidence of underlying psychiatric disorder | 0
    no evidence of psychological disorder | 0
    assessed by bariatric dietician | 0
    advice on healthy eating | 0
    large intake of sugary snacks | 0
    large intake of starchy carbohydrates | 0
    agreed to trial of milk-based LELD | 0
    basal metabolic rate estimated 1983 kcal | 0
    weight loss phase | 0
    consumed exclusively milk-based liquid diet | 0
    semi-skimmed milk 2.2 L daily | 0
    multivitamin and mineral supplement | 0
    fibre ispaghula husk | 0
    stock cube for sodium replacement | 0
    seen by consultant endocrinologist | 0
    seen by bariatric nurse | 0
    seen by dietitian | 0
    bloods drawn every 2 weeks | 0
    weight stabilisation phase | 1344
    gradual reintroduction of low-calorie meals | 1344
    weight maintenance phase | 2856
    milk-based component stopped | 2856
    balanced diet resumed | 2856
    diet improved | 3624
    glycaemic control improved | 3624
    gained 1.6 kg | 3624
    started LELD | 0
    weight 115.2 kg | 0
    BMI 40.7 kg/m2 | 0
    weight 101.2 kg | 1344
    BMI 35.8 kg/m2 | 1344
    weight 94.6 kg | 4032
    BMI 33.4 kg/m2 | 4032
    weight reduction 20.6 kg | 4032
    insulin titrated downwards | 0
    insulin dose zero | 168
    glucometer readings normalised | 0
    HbA1c normalised | 0
    regained 2.2 kg | 10800
    HbA1c 48 mmol/mol | 10800
    off insulin therapy | 10800
    weight 92.6 kg | 15120
    BMI 32.7 kg/m2 | 15120
    glycaemic control deteriorated | 15120
    HbA1c 104 mmol/mol | 15120
    increased metformin | 15120
    added linagliptin | 15120
    added canagliflozin | 15120
    HbA1c improved | 15120
    HbA1c 50 mmol/mol | 39600
    weight 100.4 kg | 39600
    BMI 35.5 kg/m2 | 39600
    felt well | 39600
    poor glycaemic control | 15120
    weight loss | 15120
    absolute insulin deficiency | 15120
    reversibility without insulin treatment | 15120
    transient beta cell glucotoxicity | 15120
    responded well to oral therapy | 15120
    gained weight | 15120
    glycaemic control improved | 15120
    reversal of glucotoxicity | 15120
    improved beta cell function | 15120
    no measurement of ketones | 0
    written informed consent | 0
    <|eot_id|>
    