84 years old | 0
    woman | 0
    presented to our dermatology clinic | 0
    diffuse bullous rash | 0
    chronic kidney disease | 0
    hyperthyroidism | 0
    hypertension | 0
    type II diabetes mellitus | -175200
    vildagliptin | -175200
    repaglinide | -175200
    acarbose | -175200
    weekly dulaglutide subcutaneous administrations | -168
    dulaglutide discontinued | -24
    mild erythematous rash | -24
    observation | 0
    tense bullous lesions | 0
    serous-hematic content | 0
    spread over the entire skin area | 0
    blister on oral mucosa | 0
    intense itching | 0
    cutaneous biopsy | 0
    histological examination | 0
    eosinophilic papillitis | 0
    arrangement of eosinophils along the free border of the dermal-papillary clefts | 0
    direct immunofluorescence | 0
    IgG deposits on the basement membrane | 0
    C3 deposits on the basement membrane | 0
    neutrophilic leukocytosis | 0
    elevation of inflammatory indices | 0
    increase in total IgE | 0
    BP180 positive >200 U/ml | 0
    BP230 positive 31 U/ml | 0
    diagnosis of bullous pemphigoid | 0
    no recent infections | 0
    no recent vaccinations | 0
    tumor markers negative | 0
    dulaglutide newly introduced drug | 0
    oral prednisone 25 mg/day | 24
    oral doxycycline 100 mg 2/day | 24
    drainage of bullous lesions | 24
    eosin touching | 24
    therapy restored | 24
    subcutaneous injection of insulin glargine | 24
    absence of new lesions | 720
    gradual re-epithelialization of preexisting erosions | 720
    cortisone therapy gradually scaled up to discontinuation | 2160
    antibiotic therapy gradually scaled up to discontinuation | 2160
    <|eot_id|>
    