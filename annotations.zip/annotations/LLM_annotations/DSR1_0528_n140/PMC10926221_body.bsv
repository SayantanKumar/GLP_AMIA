32 years old| 0
    Japanese | 0
    male | 0
    multiple acyl-CoA dehydrogenase deficiency | -277440
    glutaric acidemia type II | -277440
    ETFA gene compound heterozygous pathogenic variants | -277440
    hypoglycemia | -277440
    hyperammonemia | -277440
    metabolic acidosis | -277440
    loss of consciousness | -277440
    urinary organic acid profiles | -277440
    hypoketotic | -277440
    dicarboxylic aciduria | -277440
    increased excretion of ethylmalonic acid | -277440
    increased excretion of 2-hydroxyglutaric acid | -277440
    increased excretion of isovaleric glycine | -277440
    dietary therapy | -277440
    riboflavin | -277440
    levocarnitine | -277440
    avoidance of prolonged fasting | -277440
    frequent meals | -277440
    high-carbohydrate | -277440
    low-fat | -277440
    low-protein | -277440
    episodes of hypoglycemia | -277440
    free of hypoglycemic events | -26280
    polydipsia | -720
    polyuria | -720
    frequent muscle spasms | -720
    fatigue | -720
    decreased appetite | -720
    T2DM | -720
    HbA1c 8.5% | -720
    insulin 13.9 μU/mL | -720
    CPR 2.68 ng/mL | -720
    HOMA-R index 4.5 | -720
    physical labor | -720
    energy intake over 2000 kcal/day | -720
    macronutrient composition 14% protein | -720
    macronutrient composition 20% fat | -720
    macronutrient composition 66% carbohydrate | -720
    consuming 500–1000 mL of soft drinks daily | -166440
    consuming 1500–2000 mL of soft drinks daily | -720
    weight decreased from 90.9 kg to 74.7 kg | -1440
    BMI decreased from 31 to 25 kg/m2 | -1440
    postprandial blood glucose 382 mg/dL | 0
    HbA1c 13.9% | 0
    total ketone bodies 2.5 mmol/L | 0
    3-hydroxybutyrate 1.4 mmol/L | 0
    serum cholinesterase 293 U/L | 0
    creatine kinase 176 U/L | 0
    urea nitrogen 13 mg/dL | 0
    creatinine 0.56 mg/dL | 0
    venous blood gas pH 7.42 | 0
    HCO3− 26.5 mmol/L | 0
    pCO2 42.5 mmHg | 0
    anion gap 4.4 mmol/L | 0
    urinalysis positive for glucose | 0
    urinalysis positive for ketone bodies | 0
    insulin level 3.9 μU/mL | 0
    AST decreased | 0
    ALT decreased | 0
    GGT decreased | 0
    acylcarnitine profile no significant fluctuation | 0
    CT scans fatty liver | 0
    visceral fat area 103.90 cm2 | 0
    subcutaneous fat area 129.36 cm2 | 0
    intravenous saline | 0
    short-acting insulin infusion | 0
    intensive insulin therapy | 264
    insulin lispro | 264
    insulin glargine | 264
    liraglutide | 264
    blood glucose levels stabilized | 264
    once-daily liraglutide injection | 264
    dietary management changed to 1700 kcal/day | 264
    macronutrient composition 17% protein | 264
    macronutrient composition 27% fat | 264
    macronutrient composition 56% carbohydrate | 264
    well-controlled | 264
    diabetic ketoacidosis-like symptoms | 0
    type 2 diabetes mellitus | 0
    non-alcoholic fatty liver disease | 0
    obesity | -1440
    excessive sugar-containing soft drink intake | -720
    improvement in NAFLD | 0
    reduction in liver steatosis | 0
    no significant changes in acylcarnitine profile | 0
    cellular energy insufficiency | 0
    enhanced fatty acid catabolism | 0
    improvement of NAFLD | 0
    regular medical check-ups | 0
    patient education | 0