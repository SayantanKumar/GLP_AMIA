73 years old | 0
    male | 0
    obese | 0
    Caucasian | 0
    T2DM | -126144
    lifestyle modifications | -126144
    metformin 1000 mg twice daily | -126144
    chronic obstructive pulmonary disease | 0
    inhaled long-acting beta-adrenoceptor agonists | 0
    steroids daily | 0
    severe psoriasis | -189216
    consulted many dermatologists | -189216
    adalimumab | -105408
    discontinued adalimumab | -105408
    poor control of diabetes mellitus | 0
    glycated hemoglobin (HbA1c) 7.9% | 0
    fasting glucose level 162 mg/dL | 0
    self-monitoring blood glucose | 0
    height 158 cm | 0
    weight 106.7 kg | 0
    BMI 42.7 kg/m2 | 0
    skin lesions photo-documented | 0
    PASI 33.2 | 0
    severe form of psoriasis | 0
    DLQI 26.0 | 0
    extremely negative effect on the patient’s life | 0
    semaglutide added | 0
    metformin therapy | 0
    semaglutide 0.25 mg per week | 0
    subcutaneous | 0
    first 4 weeks | 0
    semaglutide dose increased to 0.50 mg per week | 672
    maintenance dose of 1 mg once weekly | 2688
    visited by the dermatologist after 4 months | 2688
    PASI 8.0 | 2688
    HbA1c 6.4% | 2688
    fasting glucose level 124 mg/dL | 2688
    BMI 40.3 | 2688
    significant amelioration of quality of life | 2688
    DLQI 3 | 2688
    slightly negative impact | 2688
    HbA1c 5.4% | 7200
    fasting glucose 98 mg/dL | 7200
    BMI 38.3 | 7200
    PASI 2.6 | 7200
    DLQI 0 | 7200
    no effect of psoriasis | 7200
    semaglutide normalized HbA1c | 7200
    semaglutide induced weight loss | 7200
    no significant side effects | 7200
    improvement of severe psoriasis lesions | 2688
    sustained healing response | 7200
    topical medications | -189216
    adalimumab | -105408
    unsatisfactory results | -105408
    adalimumab withdrawn 2 months before | -1440
    psoriasis improvement | 2688
    refused reintroduction of adalimumab | 2688
    high level of patient satisfaction | 7200
    severe psoriasis | 0
    obese | 0
    T2DM | 0
    successfully treated with semaglutide | 7200
    GLP-1 analogs extra-pancreatic effects | 0
    suppression of cell proliferation | 0
    inhibition of macrophage migration | 0
    impairment of inflammation | 0
    activation of adenosine 5’-monophosphate-activated protein kinase | 0
    increase in circulating invariant natural killer T cells | 0
    decrease in dermal γδ T-cell number | 0
    decrease in IL-17 expression | 0
    anti-inflammatory activities | 0
    control of diabetes | 0
    control of obesity | 0
    control of psoriasis lesions | 0
    chronic inflammation | 0
    liraglutide reduces psoriasis | 0
    effect independent of weight loss | 0
    effect independent of glycemic control | 0
    obesity independent risk factor for psoriasis | 0
    weight loss positive impact on psoriasis severity | 0
    semaglutide effective treatment of overweight | 0
    semaglutide effective treatment of obesity | 0
    psoriasis treatment difficult in T2DM | 0
    semaglutide advantages over monoclonal antibodies | 0
    lower cost | 0
    better tolerability | 0
    effective on skin disease | 0
    effective for controlling diabetes | 0
    effective for controlling body weight | 0
    more studies needed | 0
    semaglutide considered as possible treatment | 0
    good efficacy on glycemic control | 0
    good efficacy on body weight control | 0
    single weekly dose | 0
    no conflict of interest | 0
    no specific grant | 0
    written informed consent | 0
    authors directly involved in management | 0
    authors drafted case report | 0
    authors approved final draft | 0
    writing assistance | 0
    editorial assistance | 0
    authors fully responsible | 0
    Novo Nordisk S.p.A. not involved | 0