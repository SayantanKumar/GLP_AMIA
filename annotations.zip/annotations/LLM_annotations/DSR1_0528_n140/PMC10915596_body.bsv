18-year-old male | 0
    admitted to the hospital | 0
    autism spectrum disorder | 0
    intellectual disability | 0
    severe food obsessions | 0
    compulsive overeating | 0
    antipsychotics | -504
    weight gain | -504
    worsening of food-related behaviors | -504
    Liraglutide | 0
    reductions in food obsessions | 2016
    reductions in overeating | 2016
    reductions in aggression | 2016
    reductions in other repetitive behaviors | 2016
    weight loss | 2016
    