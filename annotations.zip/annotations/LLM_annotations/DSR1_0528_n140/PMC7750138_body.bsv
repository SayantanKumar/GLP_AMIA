22 years old | 0
    female | 0
    presented to emergency room | 0
    worsening lower left pelvic pain | 0
    nausea | 0
    vomiting | 0
    vaginal bleeding | 0
    rapid weight gain | -8760
    outpatient evaluation by endocrinologist | -8760
    regular menses | -8760
    denies hirsutism | -8760
    denies acne | -8760
    denies hair loss | -8760
    HgbA1 4.8% | -8760
    testosterone 29.9 | -8760
    LH 8.1 | -8760
    FSH 4.1 | -8760
    TSH 2.41 | -8760
    CMP normal | -8760
    lipid panel normal | -8760
    trial of off-label metformin for weight loss | -8760
    increasing exercise regimen | -8760
    discontinued metformin due to side-effects | -8760
    injections of semaglutide | -8760
    abdominal striae | -8760
    not tested for Cushing's syndrome | -8760
    no hirsutism | -8760
    no acne | -8760
    no buffalo hump | -8760
    no muscle wasting | -8760
    no heat intolerance | -8760
    no hypertension | -8760
    mildly tender over left lower quadrant | 0
    transvaginal ultrasound | 0
    CT scan | 0
    10.6 cm multi-septated left adnexal mass | 0
    suspected dermoid cyst | 0
    pain improved | 0
    arterial and venous blood flow to both ovaries | 0
    outpatient follow-up | 0
    seen in outpatient clinic | 72
    scheduled for laparoscopic ovarian cystectomy | 72
    laparoscopic entry | 168
    left ovary torsed two times | 168
    large dermoid cyst | 168
    dermoid removed | 168
    residual ovarian parenchyma repaired | 168
    mature cystic teratoma | 168
    mature pituitary tissue | 168
    positive pancytokeratin | 168
    positive CAM 5.2 | 168
    positive S100 | 168
    positive synaptophysin | 168
    positive for growth hormone | 168
    positive for prolactin | 168
    positive for ACTH | 168
    seen one month after surgery | 720
    doing well | 720
    modest weight loss | 720
    advised repeat sonogram in 6 months | 720
    not back to endocrinologist | 720