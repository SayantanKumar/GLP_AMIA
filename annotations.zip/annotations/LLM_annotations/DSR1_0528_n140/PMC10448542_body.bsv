50 years old | 0
    Caucasian | 0
    woman | 0
    obesity | -132192
    lifestyle modification | -132192
    never smoked | -132192
    psoriasis | -168192
    consulted many dermatologists | -168192
    ixekizumab 80 mg | -48
    allergic reaction | -48
    secukinumab 75 mg | -48
    lack of response | -24
    guselkumab 100 mg | -24
    discontinued treatment | 0
    glycated hemoglobin (HbA1c) 6.5% | 0
    T2D | 0
    waist circumference 98 cm | 0
    BMI 30.4 kg/m2 | 0
    CCTA | 0
    absence of coronary plaques | 0
    CAC score 0 | 0
    EAT attenuation -80 HU | 0
    PCAT attenuation LAD artery -65 HU | 0
    PCAT attenuation Cx artery -77 HU | 0
    PCAT attenuation RCA -68 HU | 0
    SAT attenuation -94 HU | 0
    EAT volume 198 cm3 | 0
    PASI 12.0 | 0
    erythematous plaques | 0
    DLQI 20 | 0
    DAPSA 31.0 | 0
    negative impact on the patient’s life | 0
    semaglutide | 0
    lifestyle modification | 0
    semaglutide 0.25 mg per week | 0
    semaglutide 0.50 mg per week | 336
    semaglutide 1 mg once weekly | 1344
    PASI 4.0 | 2880
    amelioration of quality of life | 2880
    DLQI 5 | 2880
    DAPSA 8.0 | 2880
    HbA1c 6.1% | 2880
    waist circumference 87 cm | 2880
    EAT attenuation -94 HU | 7200
    PCAT attenuation LAD artery -70 HU | 7200
    PCAT attenuation Cx artery -82 HU | 7200
    PCAT attenuation RCA -72 HU | 7200
    SAT attenuation -95 HU | 7200
    EAT volume 190 cm3 | 7200
    CAC score 0 | 7200
    absence of coronary plaques | 7200
    PASI 0.2 | 7200
    DLQI 1 | 7200
    DAPSA 4.0 | 7200
    HbA1c 5.1% | 7200
    waist circumference 72 cm | 7200