36 years old| 0
    male| 0
    Prader-Willi syndrome| 0
    neonatal hypotonia| -252288
    hyperphagia| 0
    hypogonadism| 0
    obesity| 0
    short stature| 0
    cognitive disabilities| 0
    behavioral disabilities| 0
    born at 36 weeks gestation| -252288
    vaginal breech delivery| -252288
    newborn asphyxia| -252288
    Apgar score 4| -252288
    hypotonia| -252288
    height not measured| -252288
    weight 2150 g| -252288
    diagnosed with Prader-Willi syndrome| -227520
    floppy infant| -227520
    almond shaped eyes| -227520
    scoliosis| -227520
    obesity| -227520
    weight more than 20% of standard| -227520
    mental retardation| -227520
    IQ 61| -227520
    hypogonadism| -227520
    bilateral cryptorchidism| -227520
    referred to pediatric endocrinologist| -218880
    impaired glucose tolerance| -218880
    little reaction of growth hormone| -218880
    GH therapy not done| -218880
    diagnosed with diabetes| -174720
    began oral hypoglycemic agents| -174720
    referred to department of diabetes and endocrinology| -70080
    obesity| -70080
    body weight 90.6 kg| -70080
    height 152.2 cm| -70080
    BMI 39.1 kg/m2| -70080
    no diabetic retinopathy| -70080
    microalbuminuria 13.6 mg/gCr| -70080
    glibenclamide 1.25 mg/day| -70080
    metformin 1000 mg/day| -70080
    pioglitazone 15 mg/day| -70080
    HbA1c 11.2%| -70080
    no neuroleptic drug prescribed| -70080
    genetic testing| -70080
    abnormal DNA methylation| -70080
    uniparental maternal disomy| -70080
    metformin 2.25 g/day| -70080
    NPH insulin 28 U at bedtime| -70080
    miglitol 150 mg/day| -70080
    diet 1600 kcal/day| -70080
    exercise therapy| -70080
    lost 12 kg fat| -70080
    HbA1c 12.2%| -70080
    NPH insulin replaced with exenatide| -70080
    exenatide 20 µg/day| -70080
    HbA1c fluctuated| -70080
    lost 15 kg body weight| -70080
    6 kg fat loss| -70080
    9 kg muscle loss| -70080
    hyperglycemia| -70080
    insufficient insulin| -70080
    body weight 62.5 kg| -26280
    basal insulin glargine 6 U/day| -26280
    lixisenatide| -26280
    exenatide discontinued| -26280
    body weight stabilized| -26280
    HbA1c not improved| -26280
    tofogliflozin 20 mg/day added| -8760
    lixisenatide switched to dulaglutide| -8760
    dulaglutide 0.75 mg/week| -8760
    HbA1c decreased| -8760
    body weight 62.8 kg| -6480
    HbA1c 8.5%| -6480
    total ketone body 781 µM| -6480
    physiological ketosis| -6480
    C-peptide unchanged| -6480
    abdominal CT scan| -6480
    subcutaneous fat area decreased| -6480
    visceral fat area unchanged| -6480
    fatty pancreas| -70080
    fatty pancreas improved| -6480
    liver fat unchanged| -6480
    Hounsfield unit pancreatic head -41.9 to -2.6| -6480
    Hounsfield unit spleen 48.9 to 60.0| -6480
    P/S ratio -0.857 to -0.043| -6480
    followed for 1 year| 0
    effect lasted 1 year| 0