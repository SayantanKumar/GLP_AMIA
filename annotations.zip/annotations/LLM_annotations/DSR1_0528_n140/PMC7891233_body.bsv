80 years old|0
    obese|0
    male|0
    admitted to the hospital|0
    dyspnea|0
    edema|0
    weight gain|0
    smoking|0
    diabetes mellitus|0
    hypertension|0
    colon carcinoma|0
    prostate carcinoma|0
    surgery|0
    radiation therapy|0
    bumetanide|0
    darbepoetin alfa|0
    insulin degludec/liraglutide|0
    irbesartan|0
    nifedipine|0
    omeprazole|0
    pregabalin|0
    tamsulosin|0
    atrial fibrillation|0
    normocytic anemia|0
    elevated D-dimer|0
    elevated gamma-glutamyl transferase|0
    decreased renal function|0
    transthoracic echocardiogram|0
    left ventricle normal dimensions|0
    preserved left heart function|0
    ejection fraction 60%|0
    D-shaped left ventricle|0
    mitral annular calcification|0
    left atrial dilatation|0
    snake thrombus|0
    inferior vena cava|0
    right atrium|0
    computed tomography abdomen|24
    mass in right kidney|24
    renal cell carcinoma|24
    computed tomography thorax|72
    no metastases|72
    T3bN0Mx renal cell carcinoma|72
    anticoagulant therapy|0
    tinzaparin|0
    inadequate factor Xa level|96
    heparin intravenous|96
    progressive dyspnea|0
    progressive edema|0
    kidney failure|168
    palliative care|216
    deceased|288
    