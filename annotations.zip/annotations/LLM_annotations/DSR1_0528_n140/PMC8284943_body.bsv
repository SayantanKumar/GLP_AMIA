36 years old| 0
    female| 0
    referred to outpatient clinic for pregnant women with diabetes| 0
    pregnancy week 12+2| 0
    PCOS| 0
    T2D| 0
    irregular periods| -60480
    significant weight loss| -60480
    spontaneous pregnancy| -60480
    pre-pregnancy BMI 40 kg/m2| -60480
    blood pressure 136/71 mmHg| 0
    treated with metformin| -60480
    treated with liraglutide| -60480
    treated with ACE inhibitor| -60480
    discontinued all medication| -60480
    HbA1c 41 mmol/mol| -60480
    blood pressure normal| -60480
    no medical history| 0
    no lipodystrophy| 0
    no severe acanthosis nigricans| 0
    no hirsutism| 0
    no obstructive sleep apnea| 0
    no Cushing’s syndrome| 0
    no acromegaly| 0
    no hyperthyroidism| 0
    HbA1c 59 mmol/mol| 0
    insulin treatment initiated| 0
    Novomix 30 20 units/day| 0
    insulin doses progressively increased| 0
    insulin regime changed to Insulatard and Novorapid| 0
    insulin requirement 1420 units/day| 0
    week 34+4| 0
    blood samples taken| 0
    insulin requirement 720 units/day| 0
    week 35+0| 0
    no signs of placental insufficiency| 0
    fetal heart rate tracings normal| 0
    fetal ultrasound scans normal| 0
    flow measurements normal| 0
    admitted for observation| 0
    insulin requirements continued to fall| 0
    blood glucose continued to fall| 0
    insulin requirement 0 units/day| 0
    week 35+4| 0
    stable blood glucose around 6 mmol/L| 0
    delivery by cesarean section| 0
    week 36+1| 0
    unsuccessful attempt of induction of labor| 0
    dramatic change in insulin requirements| 0
    healthy baby delivered| 0
    Apgar scores normal| 0
    no abnormalities| 0
    birthweight 3850 g| 0
    large for gestational age| 0
    z-score 3.05| 0
    blood glucose 2.8 mmol/L| 1
    blood glucose 4.3 mmol/L| 4
    no neonatal hypoglycemia| 4
    placental weight 920 g| 0
    discharged from hospital| 120
    advised to continue self-monitoring of glucose| 120
    consult general practitioner for diabetes check-up| 120
    blood glucose normalized after delivery| 120
    plasma insulin normalized after delivery| 120
    C-peptide normalized after delivery| 120
    IGF-1 normalized after delivery| 120
    breastfeeding| 120
    no antidiabetic medication| 120
    insulin increased above reference range| 5040
    C-peptide increased above reference range| 5040
    proinsulin increased above reference range| 5040
    HbA1c 116 mmol/mol| 5040
    insulin resistance returned| 5040
    treatment warranted| 5040
    severe insulin resistance| 0
    non-fasting C-peptide 3294 pmol/L| 0
    proinsulin 302 pmol/L| 0
    leptin high| 0
    MBL high| 0
    IGF-1 401 µg/L| 0
    inflammatory markers comparable to GDM| 0
    FGF-21 low| 0
    CRP mildly elevated| 0
    FFA low| 0
    CD163 unremarkable| 0
    cortisol unremarkable| 0
    biochemical profile unremarkable| 0
    lipid profile unremarkable| 0
    antibodies against insulin undetectable| 0
    no mutations in INSR gene| 0
    weight gain 40 kg| 0
    self-monitoring of glucose seven times a day| 0
    frequent insulin adjustments| 0
    dietary advice| 0
    caloric restriction| 0
    exercise recommendations| 0
    close collaboration with endocrinologists| 0
    aimed at capillary plasma glucose levels 4–6 mmol/L preprandial| 0
    aimed at capillary plasma glucose levels 4–8 mmol/L postprandial| 0
    patient compliant| 0
    weight 115 kg prior to pregnancy| -60480
    weight 155 kg at delivery| 0
    insulin dose per kg 9.66| 0
    insulin dose per kg 0.39| 0
    insulin dose 20 units/day| 0
    insulin dose 28 units/day| 0
    insulin dose 54 units/day| 0
    insulin dose 66 units/day| 0
    insulin dose 192 units/day| 0
    insulin dose 211 units/day| 0
    insulin dose 270 units/day| 0
    insulin dose 290 units/day| 0
    insulin dose 345 units/day| 0
    insulin dose 360 units/day| 0
    insulin dose 580 units/day| 0
    insulin dose 780 units/day| 0
    insulin dose 1420 units/day| 0
    insulin dose 720 units/day| 0
    insulin dose 520 units/day| 0
    insulin dose 480 units/day| 0
    insulin dose 60 units/day| 0
    insulin dose 0 units/day| 0
    HbA1c 59 mmol/mol| 0
    HbA1c 53 mmol/mol| 0
    HbA1c 50 mmol/mol| 0
    HbA1c 58 mmol/mol| 0
    HbA1c 59 mmol/mol| 0
    weight 155 kg| 0
    no hypoglycemia until week 35+0| 0
    induction of labor| 0
    cesarean section| 0
    baby large for gestational age| 0
    no neonatal hypoglycemia| 4
    placental insufficiency not present| 0
    lipohypertrophia not present| 0
    metformin not used| 0
    high concentrate insulin not used| 0
    concentrated insulin not available| 0
    dose-response relationship maintained| 0
    optimal glycemic control not accomplished| 0
    baby large for gestational age| 0
    no hypoglycemia in baby| 4
    no hypoglycemia in mother until week 35+0| 0
    rapid decline in insulin requirement| 0
    reason unclear| 0
    close contact with patient| 0
    insulin pens collection confirmed| 0
    high insulin levels confirmed compliance| 0
    obesity| 0
    PCOS| 0
    T2D| 0
    weight gain| 0
    vicious cycle of weight gain and insulin resistance| 0
    hyperleptinemia| 0
    high IGF-1| 0
    high MBL| 0
    no mutation in INSR gene| 0
    metformin could have spared insulin| 0
    metformin not recommended| 0
    high concentrate insulin not used| 0
    therapeutic challenge| 0
    successful outcome| 0
    written informed consent| 0
    no conflict of interest| 0
    no specific grant| 0
    salary provided| 0
    supported by foundation| 0
    data collected| 0
    manuscript written| 0
    patient treatment managed| 0
    manuscript contributed| 0
    <|eot_id|>
    