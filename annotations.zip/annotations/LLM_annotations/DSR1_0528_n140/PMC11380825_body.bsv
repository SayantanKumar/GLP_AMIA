83 years old | 0
    male | 0
    anxiety | 0
    hyperlipidemia | 0
    type 2 diabetes mellitus | 0
    hypertension | 0
    glaucoma | 0
    headache | 0
    decreased appetite | 0
    semaglutide | 0
    empagliflozin | 0
    brimonidine | 0
    latanoprost | 0
    atorvastatin | 0
    non-contrasted computed tomography of the head | 0
    no acute process | 0
    no acute infection | 0
    no toxic derangements | 0
    no metabolic derangements | 0
    discharged | 0
    analgesics | 0
    worsened mental status | -48
    worsening headache | -48
    nausea | -48
    worsening appetite | -48
    afebrile | -48
    blood pressure 131/99 | -48
    heart rate 81 | -48
    respiratory rate 18 | -48
    fingerstick glucose 260 mg/dL | -48
    insulin aspart | -48
    fentanyl | -48
    ondansetron | -48
    CT abdomen pelvis | -48
    loss of appetite | -48
    nausea | -48
    no acute process | -48
    encephalopathy | -48
    nausea | -48
    repeat non-contrast CT head | -48
    acute left occipital intraparenchymal hemorrhage | -48
    no mass effect | -48
    no interventricular extension | -48
    loaded with levetiracetam | -48
    seizure prophylaxis | -48
    transferred | 0
    neurocritical care unit | 0
    encephalopathic | 0
    not orientated | 0
    visual field testing | 0
    right homonymous hemianopsia | 0
    trouble completing complex commands | 0
    intact strength | 0
    intact sensation | 0
    NIH Stroke Scale 5 | 0
    no dehydration | 0
    no increased skin turgor | 0
    no dry skin | 0
    no dry mucosal membranes | 0
    no polydipsia | 0
    no decreased urine output | 0
    electrocardiogram | 0
    normal sinus rhythm | 0
    complete blood count | 0
    coagulation studies | 0
    complete metabolic panel | 0
    lipid panel | 0
    hemoglobin A1c | 0
    thyroid-stimulating hormone | 0
    hemoglobin A1c 10.2% | 0
    blood urea nitrogen 23 mg/dL | 0
    elevated anion gap 17 mmol/L | 0
    bicarbonate 20 mmol/L | 0
    β-hydroxybutyrate level 3.65 mmol/L | 0
    glucose level 120 mg/dL | 0
    urinalysis | 0
    urine glucose >1000 mg/dL | 0
    urine ketones >80 mg/dL | 0
    no infection | 0
    no reflex culture | 0
    urine toxicology screen negative | 0
    euglycemic diabetic ketoacidosis | 0
    dextrose 10% infusion | 0
    potassium chloride infusion | 0
    insulin drip 1 U/h | 0
    no insulin bolus | 0
    diet | 0
    allowed to eat | 0
    monitor electrolytes | 0
    monitor β-hydroxybutyrate | 0
    correct potassium | 0
    anion gap closed to 10 mmol/L | 24
    β-hydroxybutyrate level 0.93 mmol/L | 24
    transitioned to insulin sliding scale | 24
    encephalopathy resolved | 24
    nausea resolved | 24
    visual field cut | 24
    blood pressure goal systolic <160 mmHg | 0
    repeat CT head stable | 6
    CT angiogram head neck | 0
    prominent arterial branches | 0
    concern for underlying mass | 0
    concern for vascular legion | 0
    MRI brain with contrast | 0
    MRI brain without contrast | 0
    abnormal curvilinear enhancement | 0
    saccular enhancing focus | 0
    arteriovenous malformation | 0
    digital subtraction angiography | 0
    no arteriovenous malformation | 0
    intraparenchymal hemorrhage attributed to uncontrolled hypertension | 0
    started lisinopril | 0
    discharged | 216
    home health | 216
    semaglutide discontinued | 216
    empagliflozin discontinued | 216
    started glargine | 216
    started lispro | 216
    outpatient follow-up endocrinology | 216
    outpatient follow-up vascular neurology | 216
    lost to follow-up | 216