65 years old|0
    woman|0
    obesity|0
    type 2 diabetes mellitus|0
    hypertension|0
    hyperlipidaemia|0
    transient ischaemic attack|0
    left-sided breast cancer|0
    mastectomy|0
    adjuvant docetaxel|0
    adjuvant cyclophosphamide|0
    remission|0
    presented to the emergency room|0
    fever|-168
    cough|-168
    shortness of breath|-168
    progressively worsening fever|0
    progressively worsening cough|0
    progressively worsening shortness of breath|0
    hypoxemic|0
    oxygen saturation 87% on room air|0
    chest computed tomography|0
    bilateral ground-glass opacities|0
    admitted to a specialized COVID-19 unit|0
    treatment with remdesivir|0
    empiric antibiotics|0
    community-acquired pneumonia|0
    decompensated with shock|168
    multiorgan system failure|168
    acute heart failure|168
    acute respiratory distress syndrome|168
    acute kidney injury|168
    estimated glomerular filtration rate 26 mL/min/1.73 m2|168
    ischaemic hepatitis|168
    markedly elevated inflammatory markers|168
    cytokine storm|168
    emergent rapid-sequence intubation|168
    transfer to the medical intensive care unit|168
    severe biventricular failure|168
    left ventricular ejection fraction 25%|168
    TTE|168
    received a 400 mg i.v. dose of tocilizumab|192
    supportive vasoactive medications|192
    shock related to cytokine storm|192
    significant clinical improvement|240
    myocardial recovery|240
    LVEF of 64%|240
    TTE|240
    tracheostomy|0
    discharge from the ICU|0
    discharge from the hospital|0
    prolonged ventilatory wean|0
    long-term acute care facility|0
    temperature 36.1°C|0
    blood pressure 107/62 mmHg|0
    heart rate 83 b.p.m.|0
    diminished breath sounds at lung bases|0
    chest X-ray bilateral infiltrates suggestive of pneumonitis|0
    SARS-CoV-2 positivity|0
    non-contrast chest CT ground-glass opacities|168
    electrocardiogram new-onset T-wave inversions in leads V1–V2|168
    QTc 457 ms|168
    troponin-I 1.058 ng/mL|168
    troponin-I 1.966 ng/mL|168
    troponin-I 0.519 ng/mL|168
    brain natriuretic peptide 401 pg/mL|168
    differential diagnosis sepsis-induced cardiomyopathy|168
    differential diagnosis Takotsubo syndrome|168
    differential diagnosis viral lymphocytic myocarditis|168
    differential diagnosis acute coronary syndrome|168
    norepinephrine|192
    vasopressin|192
    dobutamine|192
    sodium bicarbonate|192
    inhaled epoprostenol|192
    hydrocortisone|192
    propofol|192
    fentanyl|192
    cisatracurium|192
    improvement with down-trending inflammatory markers|216
    titration off norepinephrine|216
    titration off vasopressin|216
    titration off dobutamine|216
    cessation of sodium bicarbonate infusions|216
    cessation of neuromuscular blockade|216
    no significant dysrhythmia|216
    mild RV dysfunction|240
    Grade 2 diastolic dysfunction|240
    small circumferential pericardial effusion|240
    <|eot_id|>