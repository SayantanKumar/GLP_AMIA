58 years old | 0
    woman | 0
    presented to the emergency department | 0
    dyspnea | 0
    bilateral flank pain | 0
    pallor | 0
    clamminess | 0
    blood pressure 170/120 mmHg | 0
    heart rate 120 beats/min | 0
    body temperature 38.2°C | 0
    respiration rate 30 breaths/min | 0
    oxygen saturation 89% | 0
    body mass index 25.1 kg/m2 | 0
    height 148 cm | 0
    weight 55 kg | 0
    no medical history | 0
    no significant family history | 0
    taking phendimetrazine tartrate | -43800
    weight loss | -43800
    crackles in the right lung field | 0
    abdomen soft | 0
    no tenderness | 0
    CRP 29.5 mg/dL | 0
    ESR 120 mm/hr | 0
    leukocytosis 14.82×103/μL | 0
    normocytic anemia | 0
    hemoglobin 9.9 g/dL | 0
    mean corpuscular volume 90.7 fL | 0
    platelet count normal | 0
    acute kidney injury | 0
    blood urea nitrogen 25 mg/dL | 0
    creatinine 1.66 mg/dL | 0
    liver injury | 0
    aspartate aminotransferase 179 IU/L | 0
    alanine aminotransferase 106 IU/L | 0
    arterial blood gas analysis mixed metabolic-respiratory acidosis | 0
    lactate 20 mmol/L | 0
    chest radiography bilateral diffuse infiltrations | 0
    chest CT round mass lesion 3.8 cm | 0
    abdominal CT round mass lesion 3.8 cm | 0
    heterogeneous contrast enhancement | 0
    left paravertebral area | 0
    sepsis of unknown origin | 0
    acute respiratory distress syndrome | 0
    sedated | 0
    intubated | 0
    admitted to the intensive care unit | 0
    broad-spectrum antibiotics | 0
    vancomycin | 0
    meropenem | 0
    azithromycin | 0
    mechanical ventilation | 0
    chest radiography rapid resolution of lung infiltrations | 24
    high fever persisted | 24
    uncontrolled hypertension persisted | 24
    troponin-I 0.841 ng/mL | 24
    creatinine kinase 5.3 ng/mL | 24
    NT-proBNP 35,000 pg/mL | 24
    bedside transthoracic echocardiogram | 24
    hypokinetic mid inferior and apical segments | 24
    left ventricular ejection fraction 38% | 24
    referred to an endocrinologist | 24
    extra-adrenal mass | 24
    pallor | 24
    palpitations | 24
    tachycardia | 24
    urinary metanephrine 2.12 mg/day | 24
    plasma norepinephrine 1,588 pg/mL | 24
    plasma normetanephrine 2.27 nmol/L | 24
    plasma epinephrine normal | 24
    plasma metanephrine normal | 24
    plasma IL-6 16.5 pg/mL | 24
    18F-fluorodeoxyglucose PET/CT | 24
    increased uptake in left paravertebral mass | 24
    no metastases | 24
    functional paraganglioma diagnosis | 48
    paraganglioma | 48
    persistent fever | 48
    elevated inflammatory markers | 48
    suspicion of IL-6 production | 48
    no family history | 48
    SDHB mutation | 48
    alpha-blockers doxazosin | 48
    body temperature normalized 36.5°C | 65
    blood pressure well controlled | 65
    open excision of retroperitoneal mass | 408
    excised tumor 4.3×3.5×3.7 cm3 | 408
    well encapsulated | 408
    histological examination prominent cell-nesting pattern | 408
    round to ovoid nuclei | 408
    abundant basophilic granular cytoplasm | 408
    chromogranin A diffuse positive staining | 408
    doxazosin discontinued | 408
    no postoperative complications | 408
    inflammatory biomarkers improved | 480
    cardiac biomarkers improved | 480
    renal biomarkers improved | 480
    hepatic biomarkers improved | 480
    urinary metanephrine 0.25 mg/day | 480
    diabetes diagnosed | 480
    phendimetrazine tartrate replaced with GLP-1 receptor agonist | 480
    follow-up abdominal CT | 94608
    no evidence of recurrence | 94608
    no distant metastases | 94608
    asymptomatic during follow-up | 94608
    