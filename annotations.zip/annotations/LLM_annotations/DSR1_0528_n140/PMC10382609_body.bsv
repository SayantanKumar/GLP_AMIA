60 years old | 0
    female | 0
    presented to emergency department | 0
    left flank pain | -48
    vomiting | -48
    dizziness | -48
    lightheadedness | -48
    absence of urinary symptoms | 0
    absence of fever | 0
    coronary artery disease | 0
    prior angioplasty | 0
    type 2 diabetes mellitus | 0
    insulin glargine | 0
    insulin lispro | 0
    dulaglutide | 0
    empagliflozin | -2880
    hypertension | 0
    losartan | 0
    hypertriglyceridemia | 0
    icosapent ethyl | 0
    former smoker | 0
    quit smoking | -61320
    strong family history for heart disease | 0
    strong family history for hypertension | 0
    strong family history for diabetes | 0
    strong family history for dyslipidemia | 0
    body mass index 26 kg/m2 | 0
    costovertebral tenderness | 0
    tachycardia | 0
    hypotension | 0
    hypotension did not respond to crystalloids | 0
    required vasopressors | 0
    lactic acidosis | 0
    leukocytosis | 0
    left shift | 0
    thrombocytopenia | 0
    glycosylated hemoglobin A1C 14% | 0
    kidney function compromised | 0
    creatinine 3.5 | 0
    blood urea nitrogen 57 | 0
    shock | 0
    severe sepsis | 0
    hypovolemia | 0
    abnormal liver function tests | 0
    aspartate aminotransaminase 81 | 0
    alanine transaminase 79 | 0
    alkaline phosphatase 160 | 0
    total bilirubin 1.6 | 0
    serum glucose >500 | 0
    urine analysis large amount of glucose | 0
    urine analysis rare bacteria | 0
    urine analysis white blood cells <1/HPC | 0
    emphysematous pyelonephritis | 0
    ischemic colitis | 0
    portal venous gas | 0
    air within branches of superior mesenteric vein | 0
    initial antibiotic treatment | 0
    cefepime | 0
    vancomycin | 0
    metronidazole | 0
    emergent nephrectomy | 0
    bowel viable | 0
    postoperative management intensive care unit | 0
    successful recovery | 0
    pan-susceptible Escherichia coli | 0
    antibiotics de-escalated | 0
    discharged home | 336
    cefpodoxime | 336
    empagliflozin discontinued | 336
    admitted to hospital | 1752
    near-syncope | 1752
    abdominal pain | 1752
    small bowel obstruction | 1752
    decompensated quickly | 1752
    cardiopulmonary arrest | 1752
    massive emesis | 1752
    aspiration of gastric contents | 1752
    full resuscitation | 1752
    ICU stay | 1752
    did not recover | 1752
    anoxic brain injury | 1752
    critical condition | 1752
    cardiopulmonary collapse | 1752
    surgery never performed | 1752
    family decided to withdraw life support | 1752
    patient died | 1752
    