74 years old | 0
    female | 0
    hypertension | 0
    diabetes | 0
    dyslipidemia | 0
    cerebral infarction | 0
    ischemic heart disease | 0
    amlodipine | 0
    atorvastatin | 0
    aspirin | 0
    liraglutide | 0
    Insulin Glargine | 0
    admitted to hospital | 0
    syncope episode | 0
    four doses of COVID-19 vaccinations | 0
    tested positive for SARS-CoV-2 | -24
    staying at home | -24
    unconscious | -24
    weak limbs | -24
    drooling | -24
    regained consciousness spontaneously | -24
    body temperature 37.4°C | 0
    blood pressure 128/70 mmHg | 0
    heart rate 82 bpm | 0
    peripheral oxygen saturation 94% | 0
    lungs clear | 0
    no abnormal heart murmur | 0
    electrocardiogram sinus rhythm | 0
    heart rate 78 bpm | 0
    C-reactive protein elevated 0.35 mg/dL | 0
    white blood cell count 3,800 /μL | 0
    chest computed tomography no pneumonia | 0
    chest computed tomography no heart failure | 0
    hospitalized | 0
    quarantined | 0
    Remdesivir 200 mg | 0
    fainted | 6
    walking | 6
    urinating | 6
    8 second sinus arrest | 6
    regained consciousness | 6
    blood pressure 119/69 mmHg | 6
    temporary transvenous pacemaker inserted | 6
    no syncope | 168
    no bradycardia | 168
    temporary pacemaker removed | 168
    felt urge to defecate | 216
    staggered | 216
    not able to defecate | 216
    standing blankly | 216
    no response | 216
    almost fell | 216
    blood pressure 115/79 mmHg | 216
    heart rate dropped from 80 to 36 bpm | 216
    2.4 second pause | 216
    dual-chamber pacemaker implanted | 216
    dizziness | 240
    passed out | 240
    injured head | 240
    yawning | 240
    face pale | 240
    face sweaty | 240
    blood pressure too low to measure | 240
    telemetry monitor disconnected | 240
    no bradycardia episodes | 240
    sinus rhythm | 240
    heart rate 70-80 bpm | 240
    blood pressure 107/62 mmHg | 240
    heart rate 98 bpm | 240
    head-up tilt test | 264
    blood pressure 140/76 mmHg | 264
    heart rate 80 bpm | 264
    blood pressure decreased to 67/52 mmHg | 264
    heart rate 81 bpm | 264
    cold sensations | 264
    consecutive yawns | 264
    syncope | 264
    vasodepressor reflex syncope | 264
    Metoprolol prescribed | 264
    myocardial scintigraphy | 264
    no myocardial ischemia | 264
    discharged | 4320
    metoprolol | 4320
    no fainting episodes | 4320
    no bradycardia | 4320
    maintains normal pulse | 4320
    no use of pacemaker | 4320