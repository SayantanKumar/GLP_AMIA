62 years old|0
    male|0
    history of type 2 diabetes mellitus|0
    history of coronary artery disease|0
    presented|0
    intermittent fevers| -4320
    fatigue| -4320
    body aches| -4320
    weight loss| -4320
    palpable purpuric lesions| -4320
    metoprolol|0
    ranolazine|0
    prasugrel|0
    atorvastatin|0
    alirocumab|0
    insulin|0
    liraglutide|0
    empagliflozin|0
    cyanocobalamin|0
    physical examination unremarkable|0
    no clinical evidence of inflammatory arthritis|0
    no muscle weakness|0
    hemoglobin 10.1 g/dL|0
    hematocrit 30%|0
    elevated mean corpuscular volume 108.3 fL|0
    elevated ESR 97 mm/h|0
    elevated CRP 6.9 mg/dL|0
    WBC 5,100 cells/µL|0
    normal differential|0
    platelet count 176,000/µL|0
    rheumatoid factor negative|0
    antinuclear antibodies negative|0
    antineutrophil cytoplasmic antibodies negative|0
    cryoglobulins negative|0
    SPEP negative for M-protein|0
    B12 normal|0
    folic acid normal|0
    ferritin elevated 413 ng/mL|0
    no proteinuria|0
    skin biopsy showed leukocytoclastic vasculitis|0
    CT lungs bilateral nodules up to 9 mm|0
    some nodules new|0
    some nodules resolved|0
    nodules indeterminate|0
    bone marrow aspirate consistent with MDS|0
    trilineage dysplasia|0
    hypercellular marrow|0
    greater than 95% cellularity|0
    12% ring sideroblasts|0
    no increase in blasts|0
    cytoplasmic vacuolization in precursors|0
    hypogranular neutrophils|0
    nuclear projections|0
    cytogenetics normal male karyotype|0
    FISH normal|0
    next generation sequencing negative|0
    IPSS low risk score 0|0
    medication-induced vacuolization not supported|0
    genetic testing ordered|0
    UBA1 c.121A>C p.Met41Leu variant|0
    mosaicism|0
    variant allele frequency 57-67%|0
    diagnosis of VEXAS syndrome|0
    clinically stable|5760
    gradual improvement in symptoms|5760
    hemoglobin stable 10.0 - 11.0 g/dL|5760
    not required red blood cell transfusion|5760
    no other cytopenias|5760
    systemic therapy for MDS not warranted|5760
    leukocytoclastic vasculitis rash resolved|5760
    no oral medications|5760
    topical steroid cream for symptomatic relief|5760
    fatigue|5760
    fevers improved|5760
    body aches improved|5760
    ESR improved 60 mm/h|5760
    CRP improved 2.4 mg/dL|5760
    asymptomatic pulmonary nodules|5760
    no lung biopsy recommended|5760
    leucine substitution at codon 41|0
    relatively indolent course|0
    better prognosis|0
    <|eot_id|>
    