54 years old|0
    male|0
    type 2 diabetes|0
    nodule on left thigh|-168
    slowly enlarging nodule|-168
    physical examination|0
    solitary 2-cm skin-colored nodule|0
    no pain|0
    some tenderness|0
    exenatide extended-release injections|-3360
    no side effects|-3360
    injected in thigh once per week|-3360
    excised|0
    histopathologic examination|0
    lobular panniculitis|0
    septal panniculitis|0
    fat necrosis|0
    lymphohistiocytic cells|0
    eosinophils|0
    multinucleate giant cells|0
    vacuoles|0
    spaces|0
    eosinophilic panniculitis|0
    exenatide extended-release injection|0
    no relapse|168
    changed to oral medication|168
    type 2 diabetic for 17 years|0
    received exenatide extended-release injections|0
    injected in thigh once per week over 5 months|0
    period of 5 months|-3360
    biopsy performed|0
    diagnosed as eosinophilic panniculitis|0
    due to exenatide extended-release injection|0
    after changing to oral medication|168
    for the last 2 years|168