66 years old|0
    male|0
    hypertension|0
    type 2 diabetes mellitus|0
    hyperlipidemia|0
    chronic obstructive pulmonary disease|0
    prostate cancer|0
    morbid obesity|0
    glipizide|0
    metformin|0
    liraglutide|0
    carvedilol|0
    simvastatin|0
    levothyroxine|0
    tiotropium|0
    no known allergies|0
    denies tobacco use|0
    denies alcohol use|0
    poor vision at all distances|0
    without any recent worsening of vision|0
    BCVA 20/70 right eye|0
    BCVA 20/200 left eye|0
    corrected to 20/50 with pinhole right eye|0
    corrected to 20/70 with pinhole left eye|0
    near visual acuity J3 bilaterally|0
    manifest refraction −14.00 D + 1.75 × 075 right eye|0
    manifest refraction −16.00 D + 1.00 × 075 left eye|0
    IOP 15 right eye|0
    IOP 18 left eye|0
    2+ nuclear sclerotic cataract right eye|0
    posterior chamber IOL left eye|0
    mild capsular fibrosis left eye|0
    pathologic myopia bilaterally|0
    signs of scleral thinning bilaterally|0
    compound myopic astigmatism bilaterally|0
    axial length 30.5 mm right eye|0
    axial length 33.5 mm left eye|0
    normal corneal thickness and architecture bilaterally|0
    phacoemulsification left eye|-113880
    intraocular lens implantation left eye|-113880
    residual myopia left eye|-113880
    placement of sulcus-located pIOL left eye|0
    refractive power −16.00 D left eye|0
    diameter 13.2 mm left eye|0
    postoperative day 1|24
    denied any new symptoms|24
    UCVA 20/50 left eye|24
    pinhole visual acuity 20/40 left eye|24
    IOP 16 left eye|24
    sutured wound on the temporal limbus left eye|24
    pharmacologically dilated pupil left eye|24
    deep and quiet anterior chamber left eye|24
    pIOL in correct position anterior to prior IOL left eye|24
    space between the two implants left eye|24
    BCVA stable right eye|24
    IOP stable right eye|24
    slit-lamp examination stable right eye|24
    returned 1 week later|168
    subjective improvement in vision|168
    ongoing mild blurriness|168
    UCVA 20/25 left eye|168
    IOP 13 left eye|168
    intact sutured wound on the temporal limbus left eye|168
    deep and quiet anterior chamber left eye|168
    pIOL in correct position anterior to prior IOL left eye|168
    space between the two implants left eye|168
    BCVA stable right eye|168
    IOP stable right eye|168
    slit-lamp examination stable right eye|168
    referred to primary ophthalmologist for cataract right eye|168
    phacoemulsification right eye|later
    intraocular lens implantation right eye|later
    +4.0 D AMO SensAr Lens implant right eye|later
    uncomplicated right eye surgery|later
    UCVA 20/20 right eye|later
    <|eot_id|>
    