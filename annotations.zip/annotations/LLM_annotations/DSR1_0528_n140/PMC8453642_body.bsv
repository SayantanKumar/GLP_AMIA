51 years old | 0
    female | 0
    Hashimoto’s disease | 0
    chronic urticaria | 0
    mast cell activation disorder | 0
    hypertension | 0
    diabetes mellitus type 2 | 0
    metformin | 0
    liraglutide | 0
    recurrent hives | 0
    skin dryness | 0
    fatigue | 0
    weight gain | 0
    intermittent constipation | 0
    intermittent diarrhea | 0
    cold intolerance | 0
    brain fog | 0
    difficulty with word finding | 0
    swelling in lower extremities | 0
    daytime somnolence | 0
    multiple chemical sensitivities | 0
    food allergies | 0
    medication sensitivities | 0
    reactions to food dyes and additives | 0
    temperature 36.6°C | 0
    pulse 92 beats per minute | 0
    blood pressure 136/88 mmHg | 0
    respiratory rate 18 respirations per minute | 0
    O2 saturation 98% | 0
    height 1.57 m | 0
    weight 92 kg | 0
    body mass index 37.3 kg/m2 | 0
    no acute distress | 0
    no palpable thyroid nodules | 0
    no visible urticaria | 0
    hypoactive bowel sounds | 0
    minimal tenderness to palpation in left lower quadrant | 0
    family history of papillary thyroid cancer | 0
    multiple bilateral nodules | 0
    benign nodules | 0
    tried generic L-T4 | -720
    transitioned to L-T4 sodium tablets | 0
    discontinued metformin | -720
    TSH 5.30 mIU/L | 0
    free T4 16.60 pmol/L | 0
    free T3 not evaluated | 0
    increased doses of L-T4 | 0
    transitioned to compounded T4/T3 | 0
    escalating doses | 0
    worsening GI symptoms | 168
    projectile vomiting | 168
    undigested food | 168
    pill capsules | 168
    weight loss | 168
    10–20 bowel movements daily | 168
    discontinued metformin and liraglutide | 168
    upper endoscopy | 168
    gastritis | 168
    hiatal hernia | 168
    gastric emptying examination | 168
    20% gastric retention at 4 hours | 168
    diagnosed with gastroparesis | 168
    high-dose probiotics | 168
    dicyclomine hydrochloride | 168
    gastroparesis diet | 168
    bloating | 168
    abdominal pain | 168
    treated with rifaximin | 168
    diagnosed with SIBO | 168
    GI examination | 168
    SIBO breath test | 168
    switched to L-T4 oral solution | 168
    resolution of thyroid symptoms | 168
    down-titrated L-T4 oral solution | 336
    TSH 1.55 mIU/L | 168
    free T4 27.93 pmol/L | 168
    free T3 4.93 pmol/L | 168
    TSH 0.56 mIU/L | 336
    free T4 29.99 pmol/L | 336
    free T3 5.39 pmol/L | 336
    TSH 1.95 mIU/L | 420
    free T4 20.33 pmol/L | 420
    free T3 4.77 pmol/L | 420
    no side effects | 168
    no reaction to medication | 168
    TSH control sustained | 420