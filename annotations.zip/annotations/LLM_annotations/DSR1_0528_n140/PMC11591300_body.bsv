53 years old | 0
    female | 0
    weight 50 kg | -744
    childbirth | -744
    weight gain | -744
    weight 80 kg | -744
    52 years old | -744
    hypothyroidism | -744
    radiotherapy for hyperthyroidism | -744
    thyroid hormone supplementation | -744
    weight increased | -744
    weight 100 kg | -744
    53 years old | 0
    edema | -24
    weight gain | -24
    severe hypercapnic respiratory failure | -24
    type-2 respiratory failure | -24
    hospitalization | -24
    treatment for edema | -24
    edema not improved | -24
    dyspnea | -24
    referral to local hospital | -24
    NPPV | -24
    diuretics | -24
    ventilatory failure worsened | -24
    transferred to our hospital | -24
    admission to our hospital | 0
    height 149 cm | 0
    weight 109 kg | 0
    BMI 49.0 kg/m² | 0
    blood pressure 108/69 mmHg | 0
    pulse rate 83 beats/min | 0
    SpO2 40-60% | 0
    body temperature 38.0°C | 0
    decreased bilateral breath sounds | 0
    systemic edema | 0
    D-dimer 5.1 μg/mL | 0
    BNP 108 pg/mL | 0
    PaO2 31 mmHg | 0
    PaCO2 75 mmHg | 0
    chest radiography decreased permeability | 0
    echocardiography decreased ejection fraction | 0
    no pulmonary hypertension | 0
    chest CT bilateral lung congestion | 0
    no other lung diseases | 0
    no remarkable cardiac enlargement | 0
    suspected OHS | 0
    congestive heart failure | 0
    upper airway infection | 0
    intubation | 0
    mechanical ventilation | 0
    treatment for right heart failure | 0
    diuretics | 0
    extubated | 96
    PaCO2 retention resolved | 96
    NPPV | 96
    IPAP/EPAP 14/7 cmH₂O | 96
    hospitalization days 4 to 9 | 96
    switched to NPPV at night | 216
    oxygen therapy during day | 216
    oxygen 3 L/min | 216
    pulmonary function test | 504
    VC 1.59 L | 504
    FEV1 1.46 L | 504
    restricted ventilation failure | 504
    discharged | 504
    NPPV at night | 504
    IPAP/EPAP 12/7 cmH₂O | 504
    home oxygen therapy | 504
    oxygen 2 L/min at rest | 504
    oxygen 3 L/min during sleep | 504
    weight loss | 504
    weight not below 90 kg | 35064
    glucagon-like peptide 1 receptor agonist | 35064
    weight loss 30 kg | 35064
    BMI 33.3 kg/m² | 35064
    readmitted | 35064
    withdrawal of NPPV considered | 35064
    withdrawal of oxygen therapy considered | 35064
    chest radiography no heart failure | 35064
    chest CT no abnormalities | 35064
    respiratory function test | 35064
    VC 1.96 L | 35064
    arterial blood gas analysis | 35064
    PaO2 improved | 35064
    PaCO2 improved | 35064
    A-aDO2 elevated 25.8 Torr | 35064
    evaluated NPPV settings | 35064
    evaluated oxygen doses | 35064
    setting 1: IPAP/EPAP 12/7 cmH₂O, frequency 15/min, O₂ 3.0 L/min | 35064
    SpO2 acceptable | 35064
    high PtcCO₂ duration long | 35064
    setting 2: increased IPAP | 35064
    setting 3: decreased respiratory frequency | 35064
    setting 4: reduced oxygen dose | 35064
    IPAP 16 cmH₂O | 35064
    difficulty falling asleep | 35064
    waking up at night | 35064
    high-concentration PtcCO₂ exposure prolonged | 35064
    setting 5: IPAP/EPAP 14/7 cmH₂O, frequency 12/min, O₂ 0 L/min | 35064
    PtcCO₂ ≥55 mmHg duration <10 min | 35064
    SpO₂ acceptable | 35064
    PtcCO₂ ≥50 mmHg duration too long | 35064
    weaned off oxygen therapy | 35064
    duration SpO₂ <90% short | 35064
    discharged | 35064
    NPPV IPAP/EPAP 14/7 | 35064
    no worsening respiratory condition | 35064
    plan to lose more weight | 35064