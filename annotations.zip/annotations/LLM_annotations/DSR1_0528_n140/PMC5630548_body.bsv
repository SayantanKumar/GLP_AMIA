62 years old | 0
    male | 0
    type 2 diabetes | 0
    vildagliptin | 0
    dilated cardiomyopathy | 0
    left ventricular assist device | 0
    admitted to hospital | 0
    glycated hemoglobin level 7.4% | 0
    cerebral hemorrhage | -8760
    craniotomy | -8760
    left-side hemiparesis | -8760
    glargine | 0
    insulin aspart | 0
    multi-insulin injection therapy | 0
    poor glycemic control | 0
    fasting plasma glucose level 120 mg/dL | 0
    postprandial plasma glucose level 180-230 mg/dL | 0
    skin reactions | 0
    redness | 0
    itching | 0
    swelling | 0
    insulin aspart 30 mix | 0
    insulin degludec | 0
    local skin reactions | 0
    no family history of diabetes | 0
    no past medical history including collagenous diseases | 0
    insulin allergy suspected | 0
    anti-insulin antibodies >50 U/mL | 0
    anti-insulin-specific immunoglobulin E 27 UA/mL | 0
    anti-insulin receptor antibodies 25.2% | 0
    hyperinsulinemia | 0
    fasting plasma glucose level 160 mg/dL | 0
    C-peptide level 7.22 ng/mL | 0
    immunoreactive insulin level 1150 μU/mL | 0
    type B insulin resistance syndrome | 0
    insulin allergy | 0
    no acanthosis nigricans | 0
    no history of Helicobacter pylori infection | 0
    no renal impairment | 0
    glutamic acid decarboxylase antibody negative | 0
    low complement levels | 0
    serum C4 7 mg/dL | 0
    CH50 27 U/mL | 0
    urinary tract infection | 0
    switch to liraglutide | 0
    liraglutide 0.3 mg/day | 0
    liraglutide dose increased | 0
    liraglutide 0.9 mg/day | 0
    no allergic skin reactions | 0
    no liraglutide-related side effects | 0
    no hypoglycemic event | 0
    glycemic control improved | 720
    fasting plasma glucose level 90-110 mg/dL | 720
    postprandial plasma glucose level <160 mg/dL | 720
    fasting plasma glucose level 101 mg/dL | 720
    C-peptide level 4.1 ng/mL | 720
    immunoreactive insulin level 732 μU/mL | 720
    anti-insulin antibody level >50 U/mL | 720
    anti-insulin receptor antibody level 17.9% | 720
    glycemic control good | 17520
    fasting plasma glucose level 100 mg/dL | 17520
    HbA1c 6.4% | 17520
    <|eot_id|>
    