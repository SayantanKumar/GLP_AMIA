36 years old|0
    female|0
    presented|0
    abdominal pain|-1440
    abdominal swelling|-1440
    fevers|-1440
    weight loss of 10 kg|-1440
    living in Ireland for 16 years|0
    moved from the Philippines|0
    last visited the Philippines|-8760
    severe psoriasis|0
    psoriatic arthritis|0
    ustekinumab|-13920
    ustekinumab increased to every 8 weeks|-13920
    good control of psoriasis|-13920
    narrow-band ultraviolet B phototherapy|0
    cyclosporine|0
    methotrexate|0
    etanercept|0
    adalimumab|0
    investigated for TB|-57600
    chest radiograph normal|-57600
    tuberculin purified protein derivative skin test positive|-57600
    treated for latent TB|-57600
    isoniazid 300 mg daily|-57600
    pyridoxine 20 mg daily|-57600
    ulcerated hyperkeratotic plaque on abdomen|-5760
    multiple biopsies|-5760
    histopathologic examination noncaseating granulomas|-5760
    skin biopsy for culture normal|-5760
    polymerase chain reaction negative for M tuberculosis|-5760
    deterioration in renal function|-5760
    renal biopsy interstitial nephritis with eosinophilia|-5760
    oral corticosteroids for 6 months|-5760
    adalimumab discontinued|-5760
    plaque resolved|-5760
    psoriasis flared|-5760
    ustekinumab considered|-5760
    serum QuantiFERON-TB Gold normal|-5760
    chest radiograph normal|-5760
    ustekinumab initiated|-5760
    abdominal pain|0
    abdominal swelling|0
    fevers|0
    weight loss|0
    urine β human chorionic gonadotrophin positive|0
    ultrasound abdomen fluid|0
    ectopic pregnancy considered|0
    laparotomy chronic inflammatory bowel deposits|0
    omental caking|0
    abdominal adhesions|0
    pelvic adhesions|0
    peritoneal tuberculosis|0
    serum β human chorionic gonadotrophin negative|0
    acid-fast bacilli present ascitic fluid|0
    acid-fast bacilli present omental biopsy|0
    chest radiograph no TB|0
    human immunodeficiency virus negative|0
    ustekinumab discontinued|0
    empiric treatment for M tuberculosis|0
    Rifater|0
    rifampacin 720 mg daily|0
    isoniazid 300 mg daily|0
    pyrazinamide 1800 mg daily|0
    ethambutol 1600 mg daily|0
    pyridoxine 20 mg daily|0
    polymerase chain reaction M tuberculosis complex rifampacin sensitive|0
    ethambutol discontinued|0
    mycobacterial culture confirmed M tuberculosis|0
    abdominal pain settled|0
    treatment for peritoneal TB for 12 months|0
    psoriasis flare|4320
    narrow-band ultraviolet B phototherapy failed|4320
    PsA flare on right ankle|4320
    intralesional corticosteroid injection|4320
    prednisolone 15 mg daily titrating to zero over 2 weeks|4320
    psoriasis unstable|0
    admitted to hospital|0
    liraglutide|0
    intensive topical therapy|0
    white soft paraffin/liquid paraffin|0
    coal tar paste|0
    erythrodermic|0
    hypotensive|0
    admission to high-dependency unit|0
    cyclosporine initiated|0
    cyclosporine 5 mg/kg|0
    improvement|0
    psoriasis extensive|0
    secukinumab|0
    psoriasis cleared|0
    joint pain settled|0
    cyclosporine withdrawn|0
    discharged|1008
    psoriasis under control|0
    PsA under control|0
    no adverse effects|0
    9 months|0