35 years old | 0
    man | 0
    presented | 0
    significant weight loss | -4320
    30 kg weight loss | -4320
    newly diagnosed diabetes | 0
    uncontrolled skin itching | 0
    erythema | 0
    patches of erythematous areas | 0
    irregular borders | 0
    vesicles | 0
    crust formation | 0
    visible on skin | 0
    lower limbs | 0
    abdomen | 0
    thighs | 0
    routine laboratory tests | 0
    complete blood count | 0
    blood chemistry | 0
    normal | 0
    renal function | 0
    normal | 0
    liver function | 0
    normal | 0
    serum glucose | 0
    6.4 mmol/L | 0
    CT scan | 0
    chest | 0
    abdomen | 0
    pelvis | 0
    hypervascular mass | 0
    replacing most of pancreas | 0
    severe diffuse pancreatic enlargement | 0
    multiple liver lesions | 0
    right lobe | 0
    left para-aortic lymph nodes | 0
    FDG PET/CT | 0
    mild to moderate heterogeneous activity | 0
    pancreatic mass | 0
    mild FDG uptake | 0
    liver lesions | 0
    pattern suggestive of metastasis | 0
    biopsy | 0
    liver lesion | 0
    metastatic grade 2 neuroendocrine tumor | 0
    mitotic index 1 | 0
    Ki-67 index 10% | 0
    serum glucagon level | 0
    2500 pg/ml | 0
    elevated chromogranin level | 0
    4600 ng/ml | 0
    68Ga-DOTATATE | 0
    intense Ga-avid large pancreatic mass | 0
    replacing pancreatic head, body, tail | 0
    consistent with glucagonoma | 0
    multiple Ga-avid lesions | 0
    liver | 0
    per-pancreatic foci | 0
    consistent with liver metastasis | 0
    nodal metastasis | 0
    no additional distant metastases | 0
    prescribed short-acting subcutaneous octreotide | 0
    shifted to long-acting intramuscular octreotide | 0
    multiple antidiabetic medications | 0
    liraglutide | 0
    gliclazide | 0
    metformin | 0
    good control of blood glucose | 0
    octreotide therapy | 672
    erythematous skin changes resolved | 672
    weight gain | 672
    3 kg weight gain | 672
    surgical consultation | 672
    recommended tumor-shrinking therapy | 672
    locoregional peptide receptor radionuclide therapy | 672
    before surgical excision | 672
    pancreatic metastases | 672
    liver metastases | 672
    