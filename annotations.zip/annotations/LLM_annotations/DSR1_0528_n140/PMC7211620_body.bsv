70 years old|0
    male|0
    diagnosed with COVID-19|0
    chronic obstructive pulmonary disease|0
    COPD GOLD grade 2|0
    obstructive sleep apnea syndrome|0
    insulin-dependent type 2 diabetes|0
    retinopathy|0
    nephropathy|0
    CKD 3b|0
    polyneuropathy|0
    arterial hypertension|0
    coronary heart disease|0
    obesity|0
    body mass index 38 kg/m2|0
    proximal deep vein thrombosis|-2928
    long-acting beta agonist|0
    long-acting muscarinic antagonist|0
    inhaled glucocorticoid|0
    budesonide 400 μg per day|0
    valsartan|0
    spironolactone|0
    ivabradine|0
    atorvastatin|0
    metformin|0
    liraglutide|0
    insulin glargine|0
    enoxaparin|0
    productive cough|-168
    dyspnea|-168
    intermittent fever|-168
    fever >38.5 °C|-168
    arterial pO2 67 mmHg|0
    white blood cell count within normal limits|0
    C-reactive protein elevated|0
    CRP 33 mg/dl|0
    D-dimer within normal range|0
    chest X-ray bilateral basal coarse reticular opacities|0
    real-time polymerase chain reaction positive for SARS-CoV-2|0
    refused hospitalization|0
    discharged home|0
    oral doxycycline 200 mg q.d.|0
    returned to emergency department|-96
    clinical deterioration|-96
    hypoxemia|-96
    arterial pO2 46 mmHg|-96
    chest CT-scan|-96
    multiple bilateral ground-glass opacities|-96
    crazy paving appearance|-96
    reversed halo sign|-96
    white blood-cell count elevated|-96
    WBC 11.65 × 10^9 per L|-96
    neutrophils elevated|-96
    neutrophils 9.7 × 10^9 per L|-96
    CRP level 144 mg/dl|-96
    interleukin-6 396 pg/ml|-96
    ferritin 465 ng/ml|-96
    creatinine increased|-96
    creatinine 3.26 mg/dl|-96
    lymphocytes within normal range|-96
    admitted to ICU|0
    moderate ARDS|0
    oxygenation index 154|0
    meropenem 1 g b.i.d.|0
    azithromycin 500mg q.d.|0
    hydroxychloroquine 200mg b.i.d.|0
    intubated|0
    mechanically ventilated|0
    chest X-ray progression bilateral infiltrates|48
    pulmonary deterioration|48
    oxygenation index <100|48
    endotracheal aspiration|72
    Aspergillus fumigatus culture positive|72
    voriconazole MIC 0.125 mg/L|72
    no bacterial growth|72
    Aspergillus lateral-flow device positive|72
    galactomannan not performed|72
    serum galactomannan negative|72
    serum 1,3-ß-D-glucan negative|72
    progression of pulmonary infiltrates|72
    recovery of Aspergillus fumigatus|72
    positive LFD in endotracheal aspirate|72
    diagnosed with putative invasive pulmonary aspergillosis|96
    intravenous voriconazole initiated|96
    voriconazole 6 mg/kg b.i.d.|96
    voriconazole 4 mg/kg b.i.d.|96
    treatment of ICU|0
    deceases|168
    multiorgan failure|168
    autopsy not performed|168
    <|eot_id|>
    