 35 years old | 0
     female | 0
     diagnosed with diabetes | -6480
     treated with oral hypoglycemic agents | -6480
     insulin treatment introduced | -6240
     obese from childhood | -6480
     family history of T2D | 0
     family history of obesity | 0
     height 152 cm | -6840
     weight 90 kg | -6840
     BMI 39.0 kg/m2 | -6840
     body weight increased | -6240
     weight 120.8 kg | 0
     BMI 52.3 kg/m2 | 0
     medical therapy ineffective | 0
     introduced to Department of Bariatric Surgery | 0
     treated with metformin | 0
     treated with pioglitazone | 0
     treated with miglitol | 0
     treated with dulaglutide | 0
     treated with insulin | 0
     HbA1c level 6.8% | -168
     HbA1c level 5.7% | 0
     daily insulin dose decreased | 0
     antibody titer against GAD elevated | 0
     plasma C-peptide immunoreactivity 1.21 ng/mL | 0
     bariatric/metabolic surgery performed | 0
     sleeve gastrectomy with duodenojejunal bypass | 0
     blood glucose level stabilized | 24
     cessation of all medications except insulin glargine | 24
     insulin discontinued | 144
     HbA1c level 5.8% | 432
     body weight decreased | 432
     percentage of excess weight loss 66.6% | 432
     abdominal fat area decreased | 432
     visceral fat area decreased | 432
     muscle mass loss 1.7 kg | 432
     fat mass loss 34.1 kg | 432
     plasma CPR response to glucagon increased | 432
     no severe adverse events | 432