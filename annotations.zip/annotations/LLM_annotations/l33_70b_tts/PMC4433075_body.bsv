 type 2 diabetes | 0\
     diet and lifestyle modifications | 0\
     oral antihyperglycemic medications | 0\
     insulin resistance | 0\
     progressive decline in β-cell function | 0\
     increased hepatic glucose output | 0\
     glucagon dysregulation | 0\
     poor glycemic control | 0\
     microvascular complications | 0\
     macrovascular complications | 0\
     basal insulin | 0\
     premixed insulin | 0\
     prandial insulin | 0\
     intensive insulin therapy | 0\
     weight gain | 0\
     hypoglycemia | 0\
     GLP-1 receptor agonists | 0\
     DPP-4 inhibitors | 0\
     exenatide | 0\
     liraglutide | 0\
     lixisenatide | 0\
     albiglutide | 0\
     dulaglutide | 0\
     L.T. | -156 weeks\
     female | -156 weeks\
     27 years old | -156 weeks\
     type 2 diabetes | -156 weeks\
     family history of diabetes | -156 weeks\
     high blood pressure | -156 weeks\
     elevated cholesterol | -156 weeks\
     nonsmoker | -156 weeks\
     no children | -156 weeks\
     works at a fast-food chain | -156 weeks\
     NPH insulin | -156 weeks\
     regular insulin | -156 weeks\
     atorvastatin | -156 weeks\
     warfarin | -156 weeks\
     ergocalciferol | -156 weeks\
     lisinopril/hydrochlorothiazide | -156 weeks\
     poor compliance with medications | -156 weeks\
     poor diet | -156 weeks\
     morbid obesity | -156 weeks\
     sedentary lifestyle | -156 weeks\
     depression | -156 weeks\
     visual disturbances | -156 weeks\
     burning and tingling in feet and legs | -156 weeks\
     alterations in appetite | -156 weeks\
     weight gain | -156 weeks\
     edema | -156 weeks\
     nausea | -156 weeks\
     irritability | -156 weeks\
     A1C 8.9% | -156 weeks\
     weight 265 lb | -156 weeks\
     meal plan | -156 weeks\
     exercise program | -156 weeks\
     personal health poor | -156 weeks\
     missed appointments | -104 weeks\
     inconsistent insulin regimen | -104 weeks\
     A1C 11.1% | -104 weeks\
     albuminuria | -104 weeks\
     insulin glargine | -52 weeks\
     insulin aspart | -52 weeks\
     A1C 10.8% | -52 weeks\
     weight 297 lb | -52 weeks\
     insulin aspart 70/30 mix | -4 weeks\
     liraglutide | 0\
     liraglutide 0.6 mg daily | 0\
     liraglutide 1.2 mg daily | 1 week\
     decreased insulin dose | 12 weeks\
     weight loss 20 lb | 24 weeks\
     BMI decrease 3 kg/m2 | 24 weeks\
     average glucose readings 133 mg/dL | 24 weeks\
     hypoglycemic readings | 24 weeks\
     no hospitalization | 24 weeks\
     blood pressure controlled | 24 weeks\
     lipid panel | 24 weeks\
     glycemic targets | 24 weeks\
     intensive insulin regimens | 24 weeks\
     hypoglycemia | 24 weeks\
     weight gain | 24 weeks\
     GLP-1 receptor agonist therapy | 24 weeks\
     FDA approval | 24 weeks\
     gastrointestinal side effects | 24 weeks\
     pancreatitis | 24 weeks\
     thyroid C-cell tumor formation | 24 weeks\
     quality of life | 24 weeks\
     glycemic goals | 24 weeks\
     diabetes specialist | 24 weeks\
     L.T. denied side effects | 4 weeks\
     L.T. pleased with weight loss | 4 weeks\
     L.T. checked blood glucose more often | 4 weeks\
     L.T. had lower readings | 4 weeks\
     A1C 7.6% | 12 weeks\
     hypoglycemic readings 34 | 12 weeks\
     hypoglycemic readings <70 mg/dL | 12 weeks\
     hypoglycemic readings >50 mg/dL | 12 weeks\
     glucose tablets | 12 weeks\
     fruit juice | 12 weeks\
     nondiet soda | 12 weeks\
     skim milk | 12 weeks\
     insulin dose decreased | 12 weeks\
     weight loss | 24 weeks\
     BMI decrease | 24 weeks\
     average glucose readings | 24 weeks\
     blood pressure controlled | 24 weeks\
     lipid panel | 24 weeks\
     glycemic targets | 24 weeks\
     intensive insulin regimens | 24 weeks\
     hypoglycemia | 24 weeks\
     weight gain | 24 weeks\
     GLP-1 receptor agonist therapy | 24 weeks\
     FDA approval | 24 weeks\
     gastrointestinal side effects | 24 weeks\
     pancreatitis | 24 weeks\
     thyroid C-cell tumor formation | 24 weeks\
     quality of life | 24 weeks\
     glycemic goals | 24 weeks\
     diabetes specialist | 24 weeks\
     L.T. presented with uncontrolled type 2 diabetes | -156 weeks\
     complex comorbidities | -156 weeks\
     poor diet | -156 weeks\
     morbid obesity | -156 weeks\
     sedentary lifestyle | -156 weeks\
     noncompliance with medications | -156 weeks\
     depression | -156 weeks\
     visual disturbances | -156 weeks\
     burning and tingling in feet and legs | -156 weeks\
     alterations in appetite | -156 weeks\
     weight gain | -156 weeks\
     edema | -156 weeks\
     nausea | -156 weeks\
     irritability | -156 weeks\
     A1C 8.9% | -156 weeks\
     weight 265 lb | -156 weeks\
     meal plan | -156 weeks\
     exercise program | -156 weeks\
     personal health poor | -156 weeks\
     L.T. tried several different insulin regimens | -104 weeks\
     none resulted in optimal blood glucose control | -104 weeks\
     L.T. had many additional factors exacerbating her diabetes diagnosis | -104 weeks\
     poor compliance with medications | -104 weeks\
     L.T. did not check her blood glucose consistently | -104 weeks\
     L.T. had difficult decisions when adjusting her medications | -104 weeks\
     L.T. was given liraglutide | 0\
     L.T. reported performing more self-monitoring of blood glucose | 24 weeks\
     L.T. had lower readings | 24 weeks\
     L.T. had more hypoglycemic readings on liraglutide | 24 weeks\
     none resulted in a hospital visit | 24 weeks\
     L.T. lost 20 lb | 24 weeks\
     L.T.'s BMI decreased by 3 kg/m2 | 24 weeks\
     L.T.'s average glucose readings were 133 mg/dL | 24 weeks\
     L.T.'s blood pressure remained controlled | 24 weeks\
     L.T.'s lipid panel has not been ordered since she started liraglutide | 24 weeks\
     L.T.'s glycemic targets | 24 weeks\
     L.T.'s intensive insulin regimens | 24 weeks\
     L.T.'s hypoglycemia | 24 weeks\
     L.T.'s weight gain | 24 weeks\
     L.T.'s GLP-1 receptor agonist therapy | 24 weeks\
     L.T.'s FDA approval | 24 weeks\
     L.T.'s gastrointestinal side effects | 24 weeks\
     L.T.'s pancreatitis | 24 weeks\
     L.T.'s thyroid C-cell tumor formation | 24 weeks\
     L.T.'s quality of life | 24 weeks\
     L.T.'s glycemic goals | 24 weeks\
     L.T.'s diabetes specialist | 24 weeks\
     L.T. presented with uncontrolled type 2 diabetes | -156 weeks\
     L.T. had complex comorbidities | -156 weeks\
     L.T. had poor diet | -156 weeks\
     L.T. had morbid obesity | -156 weeks\
     L.T. had sedentary lifestyle | -156 weeks\
     L.T. had noncompliance with medications | -156 weeks\
     L.T. had depression | -156 weeks\
     L.T. had visual disturbances | -156 weeks\
     L.T. had burning and tingling in feet and legs | -156 weeks\
     L.T. had alterations in appetite | -156 weeks\
     L.T. had weight gain | -156 weeks\
     L.T. had edema | -156 weeks\
     L.T. had nausea | -156 weeks\
     L.T. had irritability | -156 weeks\
     L.T.'s A1C was 8.9% | -156 weeks\
     L.T.'s weight was 265 lb | -156 weeks\
     L.T. was given a meal plan | -156 weeks\
     L.T. had an exercise program | -156 weeks\
     L.T.'s personal health was poor | -156 weeks\
     L.T. tried several different insulin regimens | -104 weeks\
     none resulted in optimal blood glucose control | -104 weeks\
     L.T. had many additional factors exacerbating her diabetes diagnosis | -104 weeks\
     L.T. had poor compliance with medications | -104 weeks\
     L.T. did not check her blood glucose consistently | -104 weeks\
     L.T. had difficult decisions when adjusting her medications | -104 weeks\
     L.T. was given liraglutide | 0\
     L.T. reported performing more self-monitoring of blood glucose | 24 weeks\
     L.T. had lower readings | 24 weeks\
     L.T. had more hypoglycemic readings on liraglutide | 24 weeks\
     none resulted in a hospital visit | 24 weeks\
     L.T. lost 20 lb | 24 weeks\
     L.T.'s BMI decreased by 3 kg/m2 | 24 weeks\
     L.T.'s average glucose readings were 133 mg/dL | 24 weeks\
     L.T.'s blood pressure remained controlled | 24 weeks\
     L.T.'s lipid panel has not been ordered since she started liraglutide | 24 weeks\
     L.T.'s glycemic targets | 24 weeks\
     L.T.'s intensive insulin regimens | 24 weeks\
     L.T.'s hypoglycemia | 24 weeks\
     L.T.'s weight gain | 24 weeks\
     L.T.'s GLP-1 receptor agonist therapy | 24 weeks\
     L.T.'s FDA approval | 24 weeks\
     L.T.'s gastrointestinal side effects | 24 weeks\
     L.T.'s pancreatitis | 24 weeks\
     L.T.'s thyroid C-cell tumor formation | 24 weeks\
     L.T.'s quality of life | 24 weeks\
     L.T.'s glycemic goals | 24 weeks\
     L.T.'s diabetes specialist | 24 weeks\
     L.T. presented with uncontrolled type 2 diabetes | -156 weeks\
     L.T. had complex comorbidities | -156 weeks\
     L.T. had poor diet | -156 weeks\
     L.T. had morbid obesity | -156 weeks\
     L.T. had sedentary lifestyle | -156 weeks\
     L.T. had noncompliance with medications | -156 weeks\
     L.T. had depression | -156 weeks\
     L.T. had visual disturbances | -156 weeks\
     L.T. had burning and tingling in feet and legs | -156 weeks\
     L.T. had alterations in appetite | -156 weeks\
     L.T. had weight gain | -156 weeks\
     L.T. had edema | -156 weeks\
     L.T. had nausea | -156 weeks\
     L.T. had irritability | -156 weeks\
     L.T.'s A1C was 8.9% | -156 weeks\
     L.T.'s weight was 265 lb | -156 weeks\
     L.T. was given a meal plan | -156 weeks\
     L.T. had an exercise program | -156 weeks\
     L.T.'s personal health was poor | -156 weeks\
     L.T. tried several different insulin regimens | -104 weeks\
     none resulted in optimal blood glucose control | -104 weeks\
     L.T. had many additional factors exacerbating her diabetes diagnosis | -104 weeks\
     L.T. had poor compliance with medications | -104 weeks\
     L.T. did not check her blood glucose consistently | -104 weeks\
     L.T. had difficult decisions when adjusting her medications | -104 weeks\
     L.T. was given liraglutide | 0\
     L.T. reported performing more self-monitoring of blood glucose | 24 weeks\
     L.T. had lower readings | 24 weeks\
     L.T. had more hypoglycemic readings on liraglutide | 24 weeks\
     none resulted in a hospital visit | 24 weeks\
     L.T. lost 20 lb | 24 weeks\
     L.T.'s BMI decreased by 3 kg/m2 | 24 weeks\
     L.T.'s average glucose readings were 133 mg/dL | 24 weeks\
     L.T.'s blood pressure remained controlled | 24 weeks\
     L.T.'s lipid panel has not been ordered since she started liraglutide | 24 weeks\
     L.T.'s glycemic targets | 24 weeks\
     L.T.'s intensive insulin regimens | 24 weeks\
     L.T.'s hypoglycemia | 24 weeks\
     L.T.'s weight gain | 24 weeks\
     L.T.'s GLP-1 receptor agonist therapy | 24 weeks\
     L.T.'s FDA approval | 24 weeks\
     L.T.'s gastrointestinal side effects | 24 weeks\
     L.T.'s pancreatitis | 24 weeks\
     L.T.'s thyroid C-cell tumor formation | 24 weeks\
     L.T.'s quality of life | 24 weeks\
     L.T.'s glycemic goals | 24 weeks\
     L.T.'s diabetes specialist | 24 weeks\
     L.T. presented with uncontrolled type 2 diabetes | -156 weeks\
     L.T. had complex comorbidities | -156 weeks\
     L.T. had poor diet | -156 weeks\
     L.T. had morbid obesity | -156 weeks\
     L.T. had sedentary lifestyle | -156 weeks\
     L.T. had noncompliance with medications | -156 weeks\
     L.T. had depression | -156 weeks\
     L.T. had visual disturbances | -156 weeks\
     L.T. had burning and tingling in feet and legs | -156 weeks\
     L.T. had alterations in appetite | -156 weeks\
     L.T. had weight gain | -156 weeks\
     L.T. had edema | -156 weeks\
     L.T. had nausea | -156 weeks\
     L.T. had irritability | -156 weeks\
     L.T.'s A1C was 8.9% | -156 weeks\
     L.T.'s weight was 265 lb | -156 weeks\
     L.T. was given a meal plan | -156 weeks\
     L.T. had an exercise program | -156 weeks\
     L.T.'s personal health was poor | -156 weeks\
     L.T. tried several different insulin regimens | -104 weeks\
     none resulted in optimal blood glucose control | -104 weeks\
     L.T. had many additional factors exacerbating her diabetes diagnosis | -104 weeks\
     L.T. had poor compliance with medications | -104 weeks\
     L.T. did not check her blood glucose consistently | -104 weeks\
     L.T. had difficult decisions when adjusting her medications | -104 weeks\
     L.T. was given liraglutide | 0\
     L.T. reported performing more self-monitoring of blood glucose | 24 weeks\
     L.T. had lower readings | 24 weeks\
     L.T. had more hypoglycemic readings on liraglutide | 24 weeks\
     none resulted in a hospital visit | 24 weeks\
     L.T. lost 20 lb | 24 weeks\
     L.T.'s BMI decreased by 3 kg/m2 | 24 weeks\
     L.T.'s average glucose readings were 133 mg/dL | 24 weeks\
     L.T.'s blood pressure remained controlled | 24 weeks\
     L.T.'s lipid panel has not been ordered since she started liraglutide | 24 weeks\
     L.T.'s glycemic targets | 24 weeks\
     L.T.'s intensive insulin regimens | 24 weeks\
     L.T.'s hypoglycemia | 24 weeks\
     L.T.'s weight gain | 24 weeks\
     L.T.'s GLP-1 receptor agonist therapy | 24 weeks\
     L.T.'s FDA approval | 24 weeks\
     L.T.'s gastrointestinal side effects | 24 weeks\
     L.T.'s pancreatitis | 24 weeks\
     L.T.'s thyroid C-cell tumor formation | 24 weeks\
     L.T.'s quality of life | 24 weeks\
     L.T.'s glycemic goals | 24 weeks\
     L.T.'s diabetes specialist | 24 weeks\
     L.T. presented with uncontrolled type 2 diabetes | -156 weeks\
     L.T. had complex comorbidities | -156 weeks\
     L.T. had poor diet | -156 weeks\
     L.T. had morbid obesity | -156 weeks\
     L.T. had sedentary lifestyle | -156 weeks\
     L.T. had noncompliance with medications | -156 weeks\
     L.T. had depression | -156 weeks\
     L.T. had visual disturbances | -156 weeks\
     L.T. had burning and tingling in feet and legs | -156 weeks\
     L.T. had alterations in appetite | -156 weeks\
     L.T. had weight gain | -156 weeks\
     L.T. had edema | -156 weeks\
     L.T. had nausea | -156 weeks\
     L.T. had irritability | -156 weeks\
     L.T.'s A1C was 8.9% | -156 weeks\
     L.T.'s weight was 265 lb | -156 weeks\
     L.T. was given a meal plan | -156 weeks\
     L.T. had an exercise program | -156 weeks\
     L.T.'s personal health was poor | -156 weeks\
     L.T. tried several different insulin regimens | -104 weeks\
     none resulted in optimal blood glucose control | -104 weeks\
     L.T. had many additional factors exacerbating her diabetes diagnosis | -104 weeks\
     L.T. had poor compliance with medications | -104 weeks\
     L.T. did not check her blood glucose consistently | -104 weeks\
     L.T. had difficult decisions when adjusting her medications | -104 weeks\
     L.T. was given liraglutide | 0\
     L.T. reported performing more self-monitoring of blood glucose | 24 weeks\
     L.T. had lower readings | 24 weeks\
     L.T. had more hypoglycemic readings on liraglutide | 24 weeks\
     none resulted in a hospital visit | 24 weeks\
     L.T. lost 20 lb | 24 weeks\
     L.T.'s BMI decreased by 3 kg/m2 | 24 weeks\
     L.T.'s average glucose readings were 133 mg/dL | 24 weeks\
     L.T.'s blood pressure remained controlled | 24 weeks\
     L.T.'s lipid panel has not been ordered since she started liraglutide | 24 weeks\
     L.T.'s glycemic targets | 24 weeks\
     L.T.'s intensive insulin regimens | 24 weeks\
     L.T.'s hypoglycemia | 24 weeks\
     L.T.'s weight gain | 24 weeks\
     L.T.'s GLP-1 receptor agonist therapy | 24 weeks\
     L.T.'s FDA approval | 24 weeks\
     L.T.'s gastrointestinal side effects | 24 weeks\
     L.T.'s pancreatitis | 24 weeks\
     L.T.'s thyroid C-cell tumor formation | 24 weeks\
     L.T.'s quality of life | 24 weeks\
     L.T.'s glycemic goals | 24 weeks\
     L.T.'s diabetes specialist | 24 weeks\
     L.T. presented with uncontrolled type 2 diabetes | -156 weeks\
     L.T. had complex comorbidities | -156 weeks\
     L.T. had poor diet | -156 weeks\
     L.T. had morbid obesity | -156 weeks\
     L.T. had sedentary lifestyle | -156 weeks\
     L.T. had noncompliance with medications | -156 weeks\
     L.T. had depression | -156 weeks\
     L.T. had visual disturbances | -156 weeks\
     L.T. had burning and tingling in feet and legs | -156 weeks\
     L.T. had alterations in appetite | -156 weeks\
     L.T. had weight gain | -156 weeks\
     L.T. had edema | -156 weeks\
     L.T. had nausea | -156 weeks\
     L.T. had irritability | -156 weeks\
     L.T.'s A1C was 8.9% | -156 weeks\
     L.T.'s weight was 265 lb | -156 weeks\
     L.T. was given a meal plan | -156 weeks\
     L.T. had an exercise program | -156 weeks\
     L.T.'s personal health was poor | -156 weeks\
     L.T. tried several different insulin regimens | -104 weeks\
     none resulted in optimal blood glucose control | -104 weeks\
     L.T. had many additional factors exacerbating her diabetes diagnosis | -104 weeks\
     L.T. had poor compliance with medications | -104 weeks\
     L.T. did not check her blood glucose consistently | -104 weeks\
     L.T. had difficult decisions when adjusting her medications | -104 weeks\
     L.T. was given liraglutide | 0\
     L.T. reported performing more self-monitoring of blood glucose | 24 weeks\
     L.T. had lower readings | 24 weeks\
     L.T. had more hypoglycemic readings on liraglutide | 24 weeks\
     none resulted in a hospital visit | 24 weeks\
     L.T. lost 20 lb | 24 weeks\
     L.T.'s BMI decreased by 3 kg/m2 | 24 weeks\
     L.T.'s average glucose readings were 133 mg/dL | 24 weeks\
     L.T.'s blood pressure remained controlled | 24 weeks\
     L.T.'s lipid panel has not been ordered since she started liraglutide | 24 weeks\
     L.T.'s glycemic targets | 24 weeks\
     L.T.'s intensive insulin regimens | 24 weeks\
     L.T.'s hypoglycemia | 24 weeks\
     L.T.'s weight gain | 24 weeks\
     L.T.'s GLP-1 receptor agonist therapy | 24 weeks\
     L.T.'s FDA approval | 24 weeks\
     L.T.'s gastrointestinal side effects | 24 weeks\
     L.T.'s pancreatitis | 24 weeks\
     L.T.'s thyroid C-cell tumor formation | 24 weeks\
     L.T.'s quality of life | 24 weeks\
     L.T.'s glycemic goals | 24 weeks\
     L.T.'s diabetes specialist | 24 weeks\
     L.T. presented with uncontrolled type 2 diabetes | -156 weeks\
     L.T. had complex comorbidities | -156 weeks\
     L.T. had poor diet | -156 weeks\
     L.T. had morbid obesity | -156 weeks\
     L.T. had sedentary lifestyle | -156 weeks\
     L.T. had noncompliance with medications | -156 weeks\
     L.T. had depression | -156 weeks\
     L.T. had visual disturbances | -156 weeks\
     L.T. had burning and tingling in feet and legs | -156 weeks\
     L.T. had alterations in appetite | -156 weeks\
     L.T. had weight gain | -156 weeks\
     L.T. had edema | -156 weeks\
     L.T. had nausea | -156 weeks\
     L.T. had irritability | -156 weeks\
     L.T.'s A1C was 8.9% | -156 weeks\
     L.T.'s weight was 265 lb | -156 weeks\
     L.T. was given a meal plan | -156 weeks\
     L.T. had an exercise program | -156 weeks\
     L.T.'s personal health was poor | -156 weeks\
     L.T. tried several different insulin regimens | -104 weeks\
     none resulted in optimal blood glucose control | -104 weeks\
     L.T. had many additional factors exacerbating her diabetes diagnosis | -104 weeks\
     L.T. had poor compliance with medications | -104 weeks\
     L.T. did not check her blood glucose consistently | -104 weeks\
     L.T. had difficult decisions when adjusting her medications | -104 weeks\
     L.T. was given liraglutide | 0\
     L.T. reported performing more self-monitoring of blood glucose | 24 weeks\
     L.T. had lower readings | 24 weeks\
     L.T. had more hypoglycemic readings on liraglutide | 24 weeks\
     none resulted in a hospital visit | 24 weeks\
     L.T. lost 20 lb | 24 weeks\
     L.T.'s BMI decreased by 3 kg/m2 | 24 weeks\
     L.T.'s average glucose readings were 133 mg/dL | 24 weeks\
     L.T.'s blood pressure remained controlled | 24 weeks\
     L.T.'s lipid panel has not been ordered since she started liraglutide | 24 weeks\
     L.T.'s glycemic targets | 24 weeks\
     L.T.'s intensive insulin regimens | 24 weeks\
     L.T.'s hypoglycemia | 24 weeks\
     L.T.'s weight gain | 24 weeks\
     L.T.'s GLP-1 receptor agonist therapy | 24 weeks\
     L.T.'s FDA approval | 24 weeks\
     L.T.'s gastrointestinal side effects | 24 weeks\
     L.T.'s pancreatitis | 24 weeks\
     L.T.'s thyroid C-cell tumor formation | 24 weeks\
     L.T.'s quality of life | 24 weeks\
     L.T.'s glycemic goals | 24 weeks\
     L.T.'s diabetes specialist | 24 weeks\
     L.T. presented with uncontrolled type 2 diabetes | -156 weeks\
     L.T. had complex comorbidities | -156 weeks\
     L.T. had poor diet | -156 weeks\
     L.T. had morbid obesity | -156 weeks\
     L.T. had sedentary lifestyle | -156 weeks\
     L.T. had noncompliance with medications | -156 weeks\
     L.T. had depression | -156 weeks\
     L.T. had visual disturbances | -156 weeks\
     L.T. had burning and tingling in feet and legs | -156 weeks\
     L.T. had alterations in appetite | -156 weeks\
     L.T. had weight gain | -156 weeks\
     L.T. had edema | -156 weeks\
     L.T. had nausea | -156 weeks\
     L.T. had irritability | -156 weeks\
     L.T.'s A1C was 8.9% | -156 weeks\
     L.T.'s weight was 265 lb | -156 weeks\
     L.T. was given a meal plan | -156 weeks\
     L.T. had an exercise program | -156 weeks\
     L.T.'s personal health was poor | -156 weeks\
     L.T. tried several different insulin regimens | -104 weeks\
     none resulted in optimal blood glucose control | -104 weeks\
     L.T. had many additional factors exacerbating her diabetes diagnosis | -104 weeks\
     L.T. had poor compliance with medications | -104 weeks\
     L.T. did not check her blood glucose consistently | -104 weeks\
     L.T. had difficult decisions when adjusting her medications | -104 weeks\
     L.T. was given liraglutide | 0\
     L.T. reported performing more self-monitoring of blood glucose | 24 weeks\
     L.T. had lower readings | 24 weeks\
     L.T. had more hypoglycemic readings on liraglutide | 24 weeks\
     none resulted in a hospital visit | 24 weeks\
     L.T. lost 20 lb | 24 weeks\
     L.T.'s BMI decreased by 3 kg/m2 | 24 weeks\
     L.T.'s average glucose readings were 133 mg/dL | 24 weeks\
     L.T.'s blood pressure remained controlled | 24 weeks\
     L.T.'s lipid panel has not been ordered since she started liraglutide | 24 weeks\
     L.T.'s glycemic targets | 24 weeks\
     L.T.'s intensive insulin regimens | 24 weeks\
     L.T.'s hypoglycemia | 24 weeks\
     L.T.'s weight gain | 24 weeks\
     L.T.'s GLP-1 receptor agonist therapy | 24 weeks\
     L.T.'s FDA approval | 24 weeks\
     L.T.'s gastrointestinal side effects | 24 weeks\
     L.T.'s pancreatitis | 24 weeks\
     L.T.'s thyroid C-cell tumor formation | 24 weeks\
     L.T.'s quality of life | 24 weeks\
     L.T.'s glycemic goals | 24 weeks\
     L.T.'s diabetes specialist | 24 weeks\
     L.T. presented with uncontrolled type 2 diabetes | -156 weeks\
     L.T. had complex comorbidities | -156 weeks\
     L.T. had poor diet | -156 weeks\
     L.T. had morbid obesity | -156 weeks\
     L.T. had sedentary lifestyle | -156 weeks\
     L.T. had noncompliance with medications | -156 weeks\
     L.T. had depression | -156 weeks\
     L.T. had visual disturbances | -156 weeks\
     L.T. had burning and tingling in feet and legs | -156 weeks\
     L.T. had alterations in appetite | -156 weeks\
     L.T. had weight gain | -156 weeks\
     L.T. had edema | -156 weeks\
     L.T. had nausea | -156 weeks\
     L.T. had irritability | -156 weeks\
     L.T.'s A1C was 8.9% | -156 weeks\
     L.T.'s weight was 265 lb | -156 weeks\
     L.T. was given a meal plan | -156 weeks\
     L.T. had an exercise program | -156 weeks\
     L.T.'s personal health was poor | -156 weeks\
     L.T. tried several different insulin regimens | -104 weeks\
     none resulted in optimal blood glucose control | -104 weeks\
     L.T. had many additional factors exacerbating her diabetes diagnosis | -104 weeks\
     L.T. had poor compliance with medications | -104 weeks\
     L.T. did not check her blood glucose consistently | -104 weeks\
     L.T. had difficult decisions when adjusting her medications | -104 weeks\
     L.T. was given liraglutide | 0\
     L.T. reported performing more self-monitoring of blood glucose | 24 weeks\
     L.T. had lower readings | 24 weeks\
     L.T. had more hypoglycemic readings on liraglutide | 24 weeks\
     none resulted in a hospital visit | 24 weeks\
     L.T. lost 20 lb | 24 weeks\
     L.T.'s BMI decreased by 3 kg/m2 | 24 weeks\
     L.T.'s average glucose readings were 133 mg/dL | 24 weeks\
     L.T.'s blood pressure remained controlled | 24 weeks\
     L.T.'s lipid panel has not been ordered since she started liraglutide | 24 weeks\
     L.T.'s glycemic targets | 24 weeks\
     L.T.'s intensive insulin regimens | 24 weeks\
     L.T.'s hypoglycemia | 24 weeks\
     L.T.'s weight gain | 24 weeks\
     L.T.'s GLP-1 receptor agonist therapy | 24 weeks\
     L.T.'s FDA approval | 24 weeks\
     L.T.'s gastrointestinal side effects | 24 weeks\
     L.T.'s pancreatitis | 24 weeks\
     L.T.'s thyroid C-cell tumor formation | 24 weeks\
     L.T.'s quality of life | 24 weeks\
     L.T.'s glycemic goals | 24 weeks\
     L.T.'s diabetes specialist | 24 weeks\
     L.T. presented with uncontrolled type 2 diabetes | -156 weeks\
     L.T. had complex comorbidities | -156 weeks\
     L.T. had poor diet | -156 weeks\
     L.T. had morbid obesity | -156 weeks\
     L.T. had sedentary lifestyle | -156 weeks\
     L.T. had noncompliance with medications | -156 weeks\
     L.T. had depression | -156 weeks\
     L.T. had visual disturbances | -156 weeks\
     L.T. had burning and tingling in feet and legs | -156 weeks\
     L.T. had alterations in appetite | -156 weeks\
     L.T. had weight gain | -156 weeks\
     L.T. had edema | -156 weeks\
     L.T. had nausea | -156 weeks\
     L.T. had irritability | -156 weeks\
     L.T.'s A1C was 8.9% | -156 weeks\
     L.T.'s weight was 265 lb | -156 weeks\
     L.T. was given a meal plan | -156 weeks\
     L.T. had an exercise program | -156 weeks\
     L.T.'s personal health was poor | -156 weeks\
     L.T. tried several different insulin regimens | -104 weeks\
     none resulted in optimal blood glucose control | -104 weeks\
     L.T. had many additional factors exacerbating her diabetes diagnosis | -104 weeks\
     L.T. had poor compliance with medications | -104 weeks\
     L.T. did not check her blood glucose consistently | -104 weeks\
     L.T. had difficult decisions when adjusting her medications | -104 weeks\
     L.T. was given liraglutide | 0\
     L.T. reported performing more self-monitoring of blood glucose | 24 weeks\
     L.T. had lower readings | 24 weeks\
     L.T. had more hypoglycemic readings on liraglutide | 24 weeks\
     none resulted in a hospital visit | 24 weeks\
     L.T. lost 20 lb | 24 weeks\
     L.T.'s BMI decreased by 3 kg/m2 | 24 weeks\
     L.T.'s average glucose readings were 133 mg/dL | 24 weeks\
     L.T.'s blood pressure remained controlled | 24 weeks\
     L.T.'s lipid panel has not been ordered since she started liraglutide | 24 weeks\
     L.T.'s glycemic targets | 24 weeks\
     L.T.'s intensive insulin regimens | 24 weeks\
     L.T.'s hypoglycemia | 24 weeks\
     L.T.'s weight gain | 24 weeks\
     L.T.'s GLP-1 receptor agonist therapy | 24 weeks\
     L.T.'s FDA approval | 24 weeks\
     L.T.'s gastrointestinal side effects | 24 weeks\
     L.T.'s pancreatitis | 24 weeks\
     L.T.'s thyroid C-cell tumor formation | 24 weeks\
     L.T.'s quality of life | 24 weeks\
     L.T.'s glycemic goals | 24 weeks\
     L.T.'s diabetes specialist | 24 weeks\
     L.T. presented with uncontrolled type 2 diabetes | -156 weeks\
     L.T. had complex comorbidities | -156 weeks\
     L.T. had poor diet | -156 weeks\
     L.T. had morbid obesity | -156 weeks\
     L.T. had sedentary lifestyle | -156 weeks\
     L.T. had noncompliance with medications | -156 weeks\
     L.T. had depression | -156 weeks\
     L.T. had visual disturbances | -156 weeks\
     L.T. had burning and tingling in feet and legs | -156 weeks\
     L.T. had alterations in appetite | -156 weeks\
     L.T. had weight gain | -156 weeks\
     L.T. had edema | -156