 61 years old | 0
     male | 0
     type 2 diabetes mellitus | 0
     hypertension | 0
     hyperlipidemia | 0
     presented to the office | 0
     blood pressure 124/72 mmHg | 0
     heart rate 78 bpm | 0
     respiratory rate 12 bpm | 0
     temperature 98.3 F | 0
     asymptomatic | 0
     family history of type 2 diabetes mellitus | 0
     family history of cardiovascular disease | 0
     denied smoking | 0
     denied alcohol abuse | 0
     denied illicit drug intake | 0
     amlodipine | 0
     valsartan | 0
     atorvastatin | 0
     pioglitazone | 0
     metformin | 0
     insulin detemir | 0
     liraglutide | 0
     dapagliflozin | 0
     no calcium supplementation | 0
     no vitamin D supplementation | 0
     no proton pump inhibitors | 0
     no histamine H2-receptor antagonists | 0
     no known allergies to medications | 0
     properly hydrating | 0
     denied palpitations | 0
     denied fatigue | 0
     denied abdominal pain | 0
     denied polyuria | 0
     denied impaired concentration | 0
     denied constipation | 0
     denied dysuria | 0
     denied flank pain | 0
     denied nephrolithiasis | 0
     denied weight loss | 0
     denied night sweats | 0
     denied dyspnea | 0
     denied cough | 0
     denied rash | 0
     physical examination unremarkable | 0
     vital signs within normal levels | 0
     no evidence of dehydration | 0
     laboratory testing | -24
     calcium 11.1 mg/dL | -24
     albumin 4.7 g/dL | -24
     blood urea nitrogen 21 mg/dL | -24
     creatinine 0.91 mg/dL | -24
     chloride 101 mmol/L | -24
     fasting glucose 139 mg/dL | -24
     epigastric burning | -24
     took six chewable tablets of Tums | -24
     Tums 200 mg calcium | -24
     denied taking Tums regularly | -24
     refrained from ingesting Tums | 0
     increased oral hydration | 0
     electrocardiography not ordered | 0
     repeat blood work | 120
     calcium normalized to 9.3 mg/dL | 120
     ionized calcium 4.8 mg/dL | 120
     parathyroid hormone intact 54 pg/mL | 120
     urine protein electrophoresis | 120
     serum protein electrophoresis | 120
     no monoclonal proteins detected | 120
     no history of hypercalcemia | 0