 42 years old | 0
     male | 0
     Hispanic | 0
     HIV positive | -72
     diabetes mellitus type II | -72
     hypertension | -72
     hyperlipidemia | -72
     admitted to John H Stroger Hospital | 0
     right foot pain | 0
     swelling | 0
     atorvastatin | 0
     amlodipine/benazepril | 0
     bictegravir/emtricitabine/tenofovir alafenamide | 0
     fenofibrate | 0
     dulaglutide | 0
     linagliptin | 0
     metformin | 0
     insulin | 0
     visited a naturalist | -336
     recommended zinc tablets | -336
     recommended zinc solution | -336
     took zinc tablets | -336
     took zinc solution | -336
     stopped taking zinc tablets | 0
     stopped taking zinc solution | 0
     HIV viral load = 371,691 copies/ml | -72
     CD4 + T-lymphocyte count = 279 cells/ml | -72
     antiretroviral therapy started | -72
     HIV viral load < 200 copies/ml | -60
     HIV viral load < 40 copies/ml | -24
     CD4 + T-lymphocytes = 463-830 cells/ml | -24
     HIV viral load = 56,477 copies/ml | 0
     CD4 + T-lymphocytes = 537 cells/ml | 0
     educated about possible drug interaction | 0
     discontinued zinc supplements | 0
     continued bictegravir/emtricitabine/tenofovir alafenamide | 0
     HIV viral load < 40 copies/ml | 720
     discharged | 24