 65 years old | 0
     male | 0
     prostate carcinoma | -8760
     radical prostatectomy | -8760
     adjuvant radiotherapy | -8760
     type 2 diabetes | 0
     hypertension | 0
     hypercholesterolaemia | 0
     epilepsy | 0
     acetylsalicylic acid | 0
     olmesartan medoxomil | 0
     rosuvastatin | 0
     lixisenatide | 0
     metformin | 0
     gliclazide | 0
     valproate | -4320
     valproate stopped | -144
     generalised epileptic seizure | 0
     confused | -72
     Glasgow Coma scale 15/15 | 0
     C reactive protein 5.9 mg/L | 0
     EEG normal | 0
     CT scan of the skull | 0
     hypodense lesion | 0
     oedema | 0
     oncologic screening | 0
     MRI with diffusion-weighted imaging | 24
     brain abscess | 24
     pachymeningitis | 24
     transthoracic ultrasound | 24
     valproate 1.5 g/day | 24
     levetiracetam 1 g/day | 24
     vancomycin 2 g/day | 24
     ornidazole 1 g/day | 24
     ceftriaxone 2 g/day | 24
     stereotactic drainage | 48
     Porphyromonas gingivalis | 48
     intraoral inspection | 48
     parodontitis | 48
     apical periodontitis | 48
     antibiotic regimen reduced | 72
     left hemiparesis | 456
     left hemineglect | 456
     increase in epileptic seizures | 456
     intubation | 456
     intravenous sedation | 456
     subdural empyema | 456
     incision and drainage | 480
     total extraction of the remaining dentition | 480
     antibiotic treatment continued | 480
     clinical improvement | 1032
     radiological improvement | 1032
     discharged | 1416
     physiotherapy | 1416