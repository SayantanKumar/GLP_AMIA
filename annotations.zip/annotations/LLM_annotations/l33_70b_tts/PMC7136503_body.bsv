 18 years old | 0\
     female | 0\
     admitted to the hospital | 0\
     dyspnea | 0\
     diffuse cellulitis in the abdomen and both legs | 0\
     birth weight of 1.9 kg | -6300\
     hypotonia | -6300\
     poor oral intake | -6300\
     rapid weight gain | -6300\
     intellectual disability | -6300\
     diagnosis of PWS | -3360\
     paternal deletion | -3360\
     type 2 DM | -720\
     hypertension | -720\
     metformin | -720\
     calcium channel blocker | -720\
     limited food intake | -720\
     daily calorie intake of 1,600 kcal | -720\
     height of 143 cm | 0\
     weight of 145 kg | 0\
     BMI of 71 kg/m2 | 0\
     vital signs | 0\
     joint pain | 0\
     massive cellulitis | 0\
     ampicillin/sulbactam | 0\
     calorie intake restricted to 800 kcal/day | 0\
     body weight increased to 164 kg | 168\
     dyspnea aggravated | 168\
     mechanical ventilation | 168\
     calorie intake restricted to 200 kcal/day | 168\
     furosemide | 168\
     fluid restriction | 168\
     weight reduction | 168\
     extubation | 408\
     pituitary function test | 408\
     hypopituitarism | 408\
     GH and gonadotropin deficiencies | 408\
     GH | 408\
     estrogen | 408\
     metformin | 408\
     liraglutide | 408\
     physical therapy | 408\
     aerobic exercise | 408\
     pulmonary rehabilitation | 408\
     able to walk independently | 720\
     weight decreased to 104 kg | 720\
     BMI decreased to 50.8 kg/m2 | 720\
     HbA1c level reduced | 720\
     diet of 1,000 kcal/day | 8760\
     regular mealtimes | 8760\
     expected food amounts | 8760\
     daily exercise | 8760\
     waist circumference reduction | 8760\
     weight loss | 8760\
     BMI reduction | 8760