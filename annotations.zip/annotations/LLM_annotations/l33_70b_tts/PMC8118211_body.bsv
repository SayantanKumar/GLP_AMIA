 49 years old | 0
     female | 0
     overweight | 0
     hypertensive | 0
     type 2 diabetes | 0
     diabetic sensory peripheral neuropathy | 0
     non-proliferative diabetic retinopathy | 0
     triple therapy of oral hypoglycemic agents | -672
     uncontrolled glycemia | -672
     insulin aspart | -504
     local erythema | -504
     edema | -504
     discontinued insulin aspart | -504
     insulin glargine | -336
     local reaction | -336
     discontinued insulin glargine | -336
     GLP1 analog exenatide | -336
     delayed extensive local reactions | -336
     antihistamine premedication | -336
     insulin lispro | -168
     local reactions | -168
     insulin glulisine | -168
     local reactions | -168
     referred to Allergy clinic | -168
     skin prick tests | 0
     intradermal test | 0
     patch tests | 0
     insulin specific-IgE | 0
     desensitization to insulin glulisine | 0
     rapid desensitization protocol | 0
     start dose 0.000001 U | 0
     dose escalation | 0
     local reaction | 0.5
     pruritus | 0.5
     erythema | 0.5
     edema | 0.5
     repeated dose | 1
     increased dose | 1
     local wheal and flare reaction | 6
     induration and erythema | 12
     premedication with Desloratidine | 24
     premedication with Montelukast | 24
     changed site of administration | 24
     reached 8 UI maintenance daily dose | 72
     palmar eczema | 720
     emollient and re-epithelization creams | 720
     desensitization protocol to insulin glargine | 720
     skin testing to insulin glargine | 720
     introduced 12 units of insulin glargine | 720
     type-I hypersensitivity reaction | 0
     type III hypersensitivity reactions | 0
     type IV hypersensitivity reactions | 0
     sensitization to exenatide | 0
     sensitization to additives | 0
     cresol | 0
     desensitization | 0
     immunological tolerance | 0
     anergy | 0
     daily administration | 0