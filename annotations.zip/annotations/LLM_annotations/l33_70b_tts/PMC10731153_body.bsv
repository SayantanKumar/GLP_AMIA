 69 years old | 0\
     male | 0\
     Japanese | 0\
     visual loss | -72\
     visual field distortion | -72\
     diabetes mellitus | -9360\
     dyslipidemia | -9360\
     hypertension | -9360\
     subcutaneous injection of dulaglutide | -9360\
     insulin lispro | -9360\
     cataract surgery | -1096\
     best-corrected visual acuity 1.2 | 0\
     best-corrected visual acuity 0.5 | 0\
     intraocular lens | 0\
     mild cataracts | 0\
     dot hemorrhages | 0\
     hard exudates | 0\
     pan-retinal photocoagulation scars | 0\
     macular edema | 0\
     foveal cystoid lesions | 0\
     pars plana vitrectomy | 72\
     cataract surgery | 72\
     internal limiting membrane peeling | 72\
     removal of the cystoid lesion component | 72\
     cystoid lesion component excised | 72\
     BCVA 0.3 | 168\
     CME subsided | 168\
     CME recurred | 168\
     STTA | 720\
     direct photocoagulation for microaneurysms | 720\
     IVA | 720\
     BCVA 0.2 | 8760\
     histopathological analysis | 72\
     immunohistochemical analysis | 72\
     fibrin/fibrinogen positive | 72\
     AGEs weakly positive | 72\
     GFAP negative | 72\
     RAGE negative | 72\
     type 1 collagen negative | 72\
     erythrocyte aggregates | 72\
     fibrin clot | 72\
     post-translational modifications | 72\
     glycation | 72\
     AGEs modification | 72\
     fibrinolysis | 72\
     retinal damage | 72\
     written informed consent | 0