 65 years old | 0
     female | 0
     obesity | 0
     type 2 diabetes mellitus | 0
     hypertension | 0
     hyperlipidaemia | 0
     transient ischaemic attack | 0
     left-sided breast cancer | 0
     mastectomy | 0
     adjuvant docetaxel and cyclophosphamide | 0
     aspirin | 0
     losartan-hydrochlorothiazide | 0
     simvastatin | 0
     levothyroxine | 0
     omeprazole | 0
     metformin | 0
     liraglutide | 0
     fever | -168
     dry cough | -168
     exertional dyspnoea | -168
     hypoxia | -3
     bilateral lung ground-glass opacities | -3
     SARS-CoV-2 positivity | -3
     remdesivir | 0
     ceftriaxone | 0
     azithromycin | 0
     community-acquired pneumonia | 0
     shock | 168
     multiorgan system failure | 168
     acute heart failure | 168
     rapid sequence intubation | 168
     transfer to medical intensive care unit | 168
     severe biventricular failure | 168
     left ventricular ejection fraction 25% | 168
     tocilizumab | 192
     norepinephrine | 192
     vasopressin | 192
     dobutamine | 192
     sodium bicarbonate | 192
     inhaled epoprostenol | 192
     hydrocortisone | 192
     clinical improvement | 216
     titration off norepinephrine | 216
     titration off vasopressin | 216
     titration off dobutamine | 216
     titration off sodium bicarbonate | 216
     cessation of neuromuscular blockade | 216
     myocardial recovery | 240
     left ventricular ejection fraction 64% | 240
     mild right ventricular dysfunction | 240
     grade 2 diastolic dysfunction | 240
     small circumferential pericardial effusion | 240
     tracheostomy | 360
     discharge from ICU | 360
     discharge from hospital | 720