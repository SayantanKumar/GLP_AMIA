 51 years old | 0
     male | 0
     referred to hospital | 0
     high hemoglobin A1c | 0
     type 2 diabetes | 0
     body height 162.8 cm | 0
     body weight 63 kg | 0
     body mass index 24.6 kg/m2 | 0
     abdominal circumference 83.5 cm | 0
     systolic blood pressure 106 mm Hg | 0
     diastolic blood pressure 66 mm Hg | 0
     serum triglyceride 231 mg/dL | 0
     serum HDL-cholesterol 48 mg/dL | 0
     serum LDL-cholesterol 141 mg/dL | 0
     serum creatinine 0.8 mg/dL | 0
     eGFR 80.1 mL/min/1.73 m2 | 0
     no proteinuria | 0
     sitagliptin started | 0
     metformin started | -24
     serum triglyceride 139 mg/dL | -24
     serum HDL-cholesterol 40 mg/dL | -24
     serum LDL-cholesterol 124 mg/dL | -24
     eGFR decreased | -12
     metformin discontinued | -12
     systolic blood pressure 120 mm Hg | -12
     diastolic blood pressure 74 mm Hg | -12
     microalbuminuria not detected | -12
     masked hypertension diagnosed | -12
     telmisartan started | -12
     empagliflozin started | -8
     eGFR decreased | -6
     empagliflozin dose increased | -4
     eGFR decreased | -2
     empagliflozin stopped | 0
     teneligliptin started | 0
     eGFR increased | 24
     semaglutide started | 72
     HbA1c decreased | 72
     eGFR increased | 72
     body weight decreased | 72
     systolic blood pressure decreased | 72
     postprandial glucose decreased | 72
     peak daily glucose decreased | 72
     average daily glucose decreased | 72
     semaglutide dose increased | 80
     HbA1c decreased | 80
     eGFR increased | 80
     body weight stable | 120
     glucose control stable | 120
     eGFR stable | 120