 39 years old | 0
     male | 0
     White | 0
     obesity | 0
     failure of nonpharmacologic strategies for weight reduction | 0
     liraglutide administered subcutaneously | 0
     initial dose of liraglutide 0.6 mg daily | 0
     increased weekly by 0.6 mg | 0
     therapeutic dose of 3 mg daily | 0
     pruritic erythematous patches appeared on the injection sites | -24
     round erythematous plaques on the abdomen at the injection sites of liraglutide | 0
     no allergies | 0
     no previous history of atopy | 0
     no concomitant disease beyond obesity | 0
     class 2 | 0
     body mass index of 39.2 kg/m2 | 0
     patch test with European baseline series | 0
     propylene glycol test | 0
     liraglutide patch test | 0
     skin prick test with liraglutide | 0
     intradermal test with liraglutide | 0
     positive delayed reaction of the intradermal test to liraglutide | 24
     skin biopsy refused | 0
     histopathologic examination refused | 0
     diagnosis of delayed hypersensitivity to liraglutide | 0
     symptomatic treatment with clobetasol propionate ointment | 0
     mometasone furoate ointment | 336
     continued treatment with liraglutide 3 mg/daily | 0
     able to tolerate the drug without any skin reaction | 720
     6-month follow-up | 1440