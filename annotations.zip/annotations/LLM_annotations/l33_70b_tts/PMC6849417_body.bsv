 35 years old | 0
     male | 0
     weight loss | -4320
     diabetes | -4320
     skin itching | -4320
     erythema | -4320
     erythematous areas | 0
     vesicles | 0
     crust formation | 0
     normal complete blood count | 0
     normal blood chemistry | 0
     normal renal function | 0
     normal liver function | 0
     serum glucose 6.4 mmol/L | 0
     hypervascular mass | 0
     pancreatic enlargement | 0
     liver lesions | 0
     lymph nodes | 0
     FDG PET/CT | 0
     mild FDG uptake | 0
     liver lesions | 0
     metastasis | 0
     biopsy | 0
     metastatic grade 2 neuroendocrine tumor | 0
     mitotic index = 1 | 0
     Ki-67 index of 10% | 0
     elevated serum glucagon level | 0
     elevated chromogranin level | 0
     68Ga-DOTATATE | 0
     intense Ga-avid large pancreatic mass | 0
     liver metastasis | 0
     nodal metastasis | 0
     no additional distant metastases | 0
     short-acting subcutaneous octreotide | 0
     long-acting intramuscular octreotide | 0
     antidiabetic medications | 0
     liraglutide | 0
     gliclazide | 0
     metformin | 0
     good control of blood glucose | 96
     erythematous skin changes resolved | 96
     weight gain | 96
     surgical consultation | 96
     tumor-shrinking therapy | 96
     locoregional peptide receptor radionuclide therapy | 96
     surgical excision | 96