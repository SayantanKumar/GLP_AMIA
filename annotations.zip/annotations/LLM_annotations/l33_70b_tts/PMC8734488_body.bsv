 62 years old | 0
     male | 0
     type 2 diabetes mellitus | -8760
     coronary artery disease | -8760
     metoprolol | -8760
     ranolazine | -8760
     prasugrel | -8760
     atorvastatin | -8760
     alirocumab | -8760
     insulin | -8760
     liraglutide | -8760
     empagliflozin | -8760
     cyanocobalamin | -8760
     intermittent fevers | -432
     fatigue | -432
     body aches | -432
     weight loss | -432
     palpable purpuric lesions | -432
     low hemoglobin | 0
     low hematocrit | 0
     elevated mean corpuscular volume | 0
     elevated erythrocyte sedimentation rate | 0
     elevated C-reactive protein | 0
     normal white blood cell count | 0
     normal differential | 0
     normal platelet count | 0
     negative rheumatoid factor | 0
     negative antinuclear antibodies | 0
     negative antineutrophil cytoplasmic antibodies | 0
     negative cryoglobulins | 0
     negative serum protein electrophoresis | 0
     normal B12 | 0
     normal folic acid | 0
     elevated ferritin | 0
     no proteinuria | 0
     leukocytoclastic vasculitis | 0
     bilateral nodules in lungs | 0
     myelodysplastic syndrome | 0
     multilineage dysplasia | 0
     trilineage dysplasia | 0
     ring sideroblasts | 0
     cytoplasmic vacuolization | 0
     hypogranular neutrophils | 0
     normal male karyotype | 0
     normal fluorescent in situ hybridization | 0
     no pathogenic mutations | 0
     low risk International Prognostic Scoring System | 0
     UBA1 gene mutation | 0
     VEXAS syndrome | 0
     clinically stable | 192
     improvement in symptoms | 192
     stable hemoglobin | 192
     no red blood cell transfusion | 192
     no cytopenias | 192
     resolved leukocytoclastic vasculitis rash | 192
     improved fatigue | 192
     improved fevers | 192
     improved body aches | 192
     improved ESR | 192
     improved CRP | 192
     no lung biopsy | 192