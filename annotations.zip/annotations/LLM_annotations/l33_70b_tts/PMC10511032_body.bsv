 35 years old | 0
     male | 0
     obesity | 0
     insertion of MedSil IGB | 0
     filled with 600 mL of normal saline | 0
     filled with 10 mL of methylene blue | 0
     failed to reach targeted body weight on semaglutide | -168
     intolerance to dose escalation of semaglutide | -168
     developed left-sided varicocele | 168
     scrotal ultrasound | 168
     abdominal-pelvic CT scan | 168
     balloon compression of the splenic vein | 168
     no enhancement at distal end of splenic vein | 168
     dilatation in the left gonadal vein | 168
     removal of gastric balloon | 168
     started on rivaroxaban | 168
     no isolated gastric varices | 168
     significant improvement in varicocele | 168
     repeated abdominal CT | 336
     patent splenic vein | 336
     recanalization of splenic vein | 336
     reduction in gonadal vein caliber | 336
     advised to continue taking rivaroxaban | 336
     symptoms completely resolved | 744
     referred to bariatric surgeon | 744