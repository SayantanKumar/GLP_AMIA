 Fifty-year-old female | 0
     originally from Western India | 0
     moved to the United States | -24000
     inability to lose weight | 0
     hypothyroidism | -24000
     treated with levothyroxine | -24000
     vegetarian | 0
     eating predominantly at home | 0
     healthy meals | 0
     small portion size | 0
     regular household chores | 0
     keeping herself active | 0
     frustrated with the inability to lose weight | 0
     interested in pharmacotherapy | 0
     normal vital signs | 0
     normal systemic exam | 0
     abdominal visceral obesity | 0
     total cholesterol 219 mg/dl | 0
     triglycerides 93 mg/dl | 0
     High density lipoprotein cholesterol (HDL-C) 46 mg/dl | 0
     Low density lipoprotein cholesterol (LDL-C) 154mg/dl | 0
     Hemoglobin A1c 5.3% | 0
     Thyroid stimulating hormone (TSH)1.25 mIU/ml | 0
     free Thyroid 4 hormone 0.93 ng/dl | 0
     fasting glucose 101mg/dl | 0
     Anti-nuclear anti-body (ANA) 1:80 | 0
     thyroid ultrasound showed a mildly enlarged gland with two small nodules | 0
     prescribed Bupropion | 0
     referred to an obesity specialist | 0
     Body Mass Index (BMI) was 32.61 kg/m2 | 0
     Bupropion was stopped | 24
     started on Topiramate | 24
     appetite decreased significantly | 24
     phentermine was added | 48
     lost 10 pounds | 96
     weight loss plateau | 96
     custom-tailored Indian Vegetarian meal plan | 96
     SMART goal patient instructions | 96
     regained weight | 720
     went to India | 720
     tried a program with strict all-natural diet | 720
     liposuction | 720
     exercising regularly | 720
     lost 10 pounds | 720
     gained all the weight back | 8760
     Weight of 200 pounds | 8760
     BMI of 34.1 kg/m2 | 8760
     started on weekly injectable Semaglutide | 8760
     dose was titrated up to maximum dose | 8760
     continued lifestyle interventions | 8760
     lost a total of 59 pounds | 9360
     BMI decreased from 34.1 kg/m2 to 23.5 kg/m2 | 9360
     Semaglutide dose was slowly decreased | 10080
     maintained on the optimal dose | 10080