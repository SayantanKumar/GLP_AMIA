 63 years old | 0
     male | 0
     Caucasian | 0
     admitted to the hospital | 0
     epigastric pain | 0
     dysphagia | 0
     odynophagia | 0
     nausea | 0
     non-bloody, non-bilious emesis | 0
     anorexia | -120
     hypertension | -8760
     type 2 diabetes mellitus | -8760
     liraglutide | -168
     semaglutide | -168
     ketogenic diet | -120
     manual labour | -120
     acute unwell | -120
     bed rest | -120
     ceasing oral intake | -120
     peak pain and nausea | -24
     presented to the hospital | 0
     tachycardia | 0
     tachypnea | 0
     Kussmaul respirations | 0
     abdominal guarding | 0
     painful belching | 0
     hemoglobin of 165 g/L | 0
     leukocytes of 17.9 × 10^9 /L | 0
     anion gap of 25 | 0
     bicarbonate of 5 mmol/L | 0
     acidemia | 0
     B-hydroxybutyrate level of 10.2 mmol/L | 0
     glucose of 17 mmol/L | 0
     glucose peaked at 82 mmol/L | 0
     urinalysis negative for leukocytes or nitrites | 0
     abdominal CT | 0
     circumferential wall thickening of the distal esophagus | 0
     diabetic ketoacidosis | 0
     dehydration | 0
     C-peptides within normal limits | 0
     esophagogastroduodenoscopy | 24
     severe class D esophagitis | 24
     circumferential black, necrotic inflammatory changes | 24
     erosions in the body and antrum of the stomach | 24
     multiple clean based ulcers in the duodenum | 24
     chronic gastroduodenitis | 24
     no sign of H. pylori or infectious organisms | 24
     no evidence of neoplasia | 24
     pantoprazole | 24
     sucralfate suspension | 24
     liquid diet | 24
     discharged home | 48
     metformin discontinued | 48
     GLP-1 RA discontinued | 48
     insulin aspart | 48
     insulin glargine | 48
     repeat EGD | 576
     healed esophagus | 576
     one polyp | 576
     healed gastric and duodenal mucosa | 576
     mild inflammatory changes to the removed polyp | 576
     follow up HbA1c improved | 576