 59 years old | 0
     male | 0
     Iranian | 0
     admitted to the hospital | 0
     pain in lower limbs | 0
     tingling | 0
     weakness | 0
     impaired bilateral lower limb movement | 0
     foot drop | 0
     frequent urination | 0
     type 2 DM | -6480
     polydipsia | -6480
     polyuria | -6480
     glibenclamide | -6480
     metformin | -6480
     dietary changes | -6480
     fasting blood glucose concentration | -6480
     NPH insulin | -730
     regular insulin | -730
     poor treatment compliance | -730
     increased insulin doses | -730
     resumption of metformin | -730
     liraglutide | -730
     self-monitoring blood glucose | -730
     random glucose measurement | 0
     diabetic polyneuropathy | 0
     ischemic heart disease | 0
     human insulin | 0
     liraglutide | 0
     metformin | 0
     aspirin | 0
     valsartan | 0
     bisoprolol | 0
     hydrochlorothiazide | 0
     acanthosis nigricans | 0
     skin tags | 0
     body mass index | 0
     neurological examinations | 0
     no deep tendon reflex in lower limbs | 0
     disturbed sense of position | 0
     paresthesia | 0
     reduced force in lower limbs | 0
     Gowers’ sign | 0
     increased insulin dose | 0
     uncontrolled blood glucose levels | 0
     HbA1c | 0
     fasting blood sugar | 0
     severe insulin resistance | 0
     autoantibodies against the insulin receptor | 0
     radioimmunoassay | 0
     EMG | 0
     NCV test | 0
     chronic axonal sensory-motor polyneuropathy | 0
     CIDP | 0
     plasmapheresis | 0
     oral prednisolone | 0
     amelioration of neurological manifestations | 0
     blood glucose control | 0
     discharge | 720
     prednisolone tablets | 720
     homologous insulin | 720
     liraglutide | 720
     acarbose | 720
     metformin | 720
     glibenclamide | 720
     pioglitazone | 720
     follow-up | 2160
     improvements in lower limb symptoms | 2160
     mild pain in proximal parts of lower limbs | 2160
     decreased prednisolone dose | 2160
     FBS | 2160
     HbA1c | 2160