 46 years old | 0
     Asian-Indian | 0
     male | 0
     tropical chronic pancreatitis | -8760
     oral pancreatic enzyme therapy | -8760
     non-insulin-dependent diabetes mellitus | -4380
     glucotrol | -4380
     midepigastric pain | -6
     pain control with narcotics | -6
     hospitalized | -6
     discharged | -48
     epigastric pain | 0
     nausea | 0
     vomiting | 0
     CT scan | 0
     fatty atrophy of pancreatic head and uncinate process | 0
     pancreatic duct filled with large calcifications | 0
     possible obstruction at the level of the neck | 0
     marked upstream ductal dilatation | 0
     admitted for management of pain | 0
     CT scan of the abdomen | -144
     chronic atrophic calcific pancreatitis | -144
     dilated pancreatic duct | -144
     intraductal calculi | -144
     ERCP | -144
     pancreatography | -144
     medically managed | -144
     discharged | -144
     fever | 48
     chills | 48
     rigors | 48
     severe sepsis | 48
     septic shock | 48
     transferred to medical intensive care unit | 48
     intubated | 48
     hypoxemic respiratory failure | 48
     acute respiratory distress syndrome | 48
     multiorgan failure | 48
     broad-spectrum antibiotics | 48
     vasopressor support | 48
     activated recombinant human protein C | 48
     ultrasound of the abdomen | 48
     markedly dilated pancreatic duct | 48
     calculus within the duct | 48
     diffusely echogenic pancreas | 48
     prominent common bile duct | 48
     bedside emergency ERCP | 72
     frank pus expelling spontaneously | 72
     evacuation of pus | 72
     cholangiogram | 72
     pancreatogram | 72
     guide wire introduced into pancreatic duct | 72
     pus evacuated | 72
     stent placed into pancreatic duct | 72
     stent failed to show pus draining | 72
     stent pulled out | 72
     contrast enhanced CT scan | 96
     inflammatory changes within fat surrounding pancreas | 96
     diminished ductal dilatation | 96
     distal migration of calculus | 96
     bilateral moderate pleural effusions | 96
     clinical improvement | 120
     stabilization of hemodynamic parameters | 120
     blood cultures grew Klebsiella ornithinolytica | 120
     extubated | 120
     transferred from intensive care unit | 120
     completed antibiotic course | 240
     discharged home | 240
     follow-up examinations | 720
     follow-up examinations | 2160
     no further complications | 720
     no further complications | 2160