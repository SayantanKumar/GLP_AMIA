 60 years old | 0
     female | 0
     coronary artery disease | -2520
     prior angioplasty | -2520
     type 2 diabetes mellitus | -2520
     insulin glargine | -672
     insulin lispro | -672
     dulaglutide | -672
     empagliflozin | -336
     hypertension | -2520
     losartan | -2520
     hypertriglyceridemia | -2520
     icosapent ethyl | -2520
     former smoker | -5040
     quit smoking | -5040
     family history for heart disease | 0
     family history for hypertension | 0
     family history for diabetes | 0
     family history for dyslipidemia | 0
     left flank pain | -48
     radiating to the groin | -48
     vomiting | -48
     dizziness | -48
     lightheadedness | -48
     absence of urinary symptoms | -48
     absence of fever | -48
     costovertebral tenderness | 0
     tachycardia | 0
     hypotension | 0
     lactic acidosis | 0
     leukocytosis | 0
     left shift | 0
     thrombocytopenia | 0
     elevated glycosylated hemoglobin A1C | -672
     acute kidney injury | 0
     elevated creatinine | 0
     elevated blood urea nitrogen | 0
     abnormal liver function tests | 0
     elevated serum glucose | 0
     glucose in urine | 0
     rare bacteria in urine | 0
     white blood cells in urine | 0
     emphysematous pyelonephritis | 0
     ischemic colitis | 0
     portal venous gas | 0
     air within branches of the superior mesenteric vein | 0
     cefepime | 0
     vancomycin | 0
     metronidazole | 0
     nephrectomy | 24
     viable bowel | 24
     pan-susceptible Escherichia coli | 24
     de-escalation of antibiotics | 24
     cefpodoxime | 336
     discontinuation of empagliflozin | 336
     near-syncope episode | 1440
     abdominal pain | 1440
     small bowel obstruction | 1440
     cardiopulmonary arrest | 1440
     massive emesis | 1440
     aspiration of gastric contents | 1440
     anoxic brain injury | 1440
     withdrawal of life support | 1440
     death | 1440