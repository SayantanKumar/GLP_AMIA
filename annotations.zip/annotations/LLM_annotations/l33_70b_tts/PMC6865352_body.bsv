 57 years old | 0
     female | 0
     Caucasian | 0
     admitted to the hospital | 0
     bilateral adrenal enlargement | -672
     type 2 diabetes mellitus | -8760
     elevated liver enzymes | -672
     worsening glycemic control | -672
     significant weight gain | -672
     no overt cushingoid features | -672
     incidental adrenal adenomas | -672
     elevated 8:00 h cortisol | -672
     non-suppressible cortisol after 1 mg of dexamethasone | -672
     low DHEAS | -672
     low ACTH levels | -672
     autonomous production of cortisol | -672
     normal 24-h urinary free cortisol | -672
     normal midnight salivary cortisol | -672
     adrenal venous sampling | -672
     elevated bilateral cortisol production | -672
     left adrenalectomy | 0
     decreased insulin requirement | 168
     decreased HbA1C | 168
     normalized serum cortisol | 168
     normalized DHEAS | 168
     normalized ACTH | 168
     weight gain | 672
     rise in HbA1C | 672
     non-suppressible cortisol | 672
     mifepristone started | 672
     mifepristone dose escalation | 840
     mifepristone toxicity | 1344
     severe refractory hypokalemia | 1344
     fluid overload | 1344
     intensive care unit admission | 1344
     mifepristone held | 1344
     dexamethasone started | 1344
     potassium repletion | 1344
     IV diuresis | 1344
     symptoms managed | 1344
     volume overload managed | 1344
     mifepristone discontinued | 1680
     dulaglutide started | 1680
     insulin degludec started | 1680
     metformin continued | 1680
     periodic follow-up visits | 1680
     monitoring for Cushing’s syndrome | 1680