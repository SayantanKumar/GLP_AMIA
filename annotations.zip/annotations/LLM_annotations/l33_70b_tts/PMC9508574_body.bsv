 33 years old | 0
     African American | 0
     female | 0
     G2P0010 | 0
     admitted to the hospital | 0
     general malaise | -72
     altered sensorium | -72
     nausea | -72
     emesis | -72
     class III obesity | 0
     no preexisting DM | 0
     GDM diagnosed | -840
     serum glucose level of 266 mg/dL | -840
     HbA1C level of 5.9% | -840
     insulin therapy initiated | -560
     nonadherence to insulin regimen | -560
     blood pressure of 70/40 mm Hg | 0
     heart rate of 150 beats/min | 0
     respiratory rate of 26 breaths/min | 0
     dry mucus membranes | 0
     decreased skin turgor | 0
     serum glucose level of 920 mg/dL | 0
     pH of 7.02 | 0
     anion gap level of 38 mmol | 0
     bicarbonate level of 5.0 mEq/L | 0
     serum potassium level of 3.4 mEq/L | 0
     large serum ketones | 0
     white blood cell count of 24.13 × 10^3/μL | 0
     SARS-CoV-2 polymerase chain reaction negative | 0
     IUFD diagnosed | 0
     treated with intravenous fluids | 0
     treated with continuous insulin | 0
     treated with potassium | 0
     treated with bicarbonate | 0
     treated with piperacillin-tazobactam | 0
     new HbA1C level of 9% | 0
     hypokalemia worsened to 2.5 mEq/L | 12
     continuous insulin withheld | 12
     serum potassium level reached above 3.3 mEq/L | 12
     spontaneously delivered a nonviable fetus | 20
     DKA resolved | 20
     managed with basal-bolus and sliding scale insulin therapies | 20
     decreased mental status returned to baseline | 48
     negative antiglutamic acid decarboxylase antibodies | 120
     negative islet cell antibodies | 120
     negative zinc transporter 8 antibodies | 120
     C-peptide level of 2.4 ng/dL | 120
     discharged | 168
     outpatient follow-up visit scheduled | 168
     returned to diabetes clinic 2 months later | 744
     HbA1C level of 5.5% | 744
     body mass index of 48 kg/m2 | 744
     preprandial insulin discontinued | 744
     basal insulin decreased to 25 units daily | 744
     metformin dose increased to 1 gram twice daily | 744
     glucagon-like peptide 1 receptor agonist initiated | 744
     HbA1C level of 5.3% | 936
     HbA1C level of 5% | 1296
     maintained on metformin and dulaglutide | 1296
     autopsy of the nonviable fetus | 168
     female fetus | 168
     macrosomia | 168
     pancreatic islet cell hyperplasia | 168
     mild adrenal granulosa layer hyperplasia | 168
     no congenital anomalies | 168
     placental findings showed no evidence of inflammation | 168
     multiple focal hyperacute ischemic infarction | 168
     small intervillous thrombi | 168
     mildly increased fibrin deposition | 168