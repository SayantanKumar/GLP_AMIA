 54 years old | 0
     female | 0
     admitted to the hospital | 0
     T2DM | -18000
     hypertension | -18000
     central obesity | -18000
     worsening central obesity | -720
     difficulty maintaining optimal weight | -720
     strict diet | -720
     intense physical activity | -720
     abdominal obesity | 0
     muscular extremities | 0
     gluteal region lipoatrophy | 0
     family history of T2DM | 0
     family history of obesity | 0
     nonsmoker | 0
     minimal alcohol use | 0
     no history of glucocorticoid use | 0
     hemoglobin A1c 11.4% | -336
     hypertriglyceridemia | -336
     hypercholesterolemia | -336
     metformin 1000 mg twice daily | -720
     basal-bolus insulin | -720
     lisinopril 40 mg daily | -720
     hydrochlorothiazide 25 mg daily | -720
     normal vitals | 0
     body mass index 33.4 kg/m2 | 0
     waist circumference 106.8 cm | 0
     hip circumference 93.7 cm | 0
     no signs of severe dyslipidemia | 0
     no signs of Cushing syndrome | 0
     no acanthosis nigricans | 0
     no skin tags | 0
     no acromegaly | 0
     24-hour urinary free cortisol | 0
     1-mg dexamethasone suppression testing | 0
     fasting leptin level 56.6 ng/mL | 0
     X-ray densitometry | 0
     trunk-to-lower limb fat percent ratio 1.74 | 0
     FibroScan | 0
     hepatic steatosis | 0
     no evidence of cirrhosis | 0
     genetic testing for LMNA and PPARG mutations | 0
     whole-exome sequencing | 0
     clinical diagnosis of FPLD type 1 | 0
     dulaglutide 0.75 mg once weekly | 0
     atorvastatin 40 mg daily | 0
     pioglitazone 15 mg daily | 0
     self-discontinued pioglitazone | 96
     significant improvement in hyperglycemia | 168
     hemoglobin A1c improvement | 168
     weight loss 35 pounds | 168
     hyperlipidemia improvement | 168
     discontinued insulin | 168
     weight loss after insulin discontinuation | 168