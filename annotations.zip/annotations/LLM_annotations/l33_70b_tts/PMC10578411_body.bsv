 23 years old | 0
     male | 0
     presented to a weight management program | 0
     weight of 643 pounds | 0
     BMI of 84.3 kg/m2 | 0
     obesity mixed central and peripheral | 0
     genetic predisposition | 0
     strong degrees of hunger | 0
     food cravings | 0
     binge-eating tendencies | 0
     depression | 0
     prediabetes | 0
     hemoglobin A1c of 6.4% | 0
     concerns for obstructive sleep apnea | 0
     initially started on topiramate 75 mg daily | -2190
     phentermine 15 mg daily | -2190
     lost approximately 25 pounds | -2190
     lost to follow-up | -1300
     weight increased approximately 50 to 75 pounds | -1300
     re-established care in the adult weight management clinic | 0
     started on multiple medications | 0
     phentermine 15 mg | 0
     topiramate 75 mg | 0
     metformin 500 mg daily | 0
     COVID-19 pandemic | 0
     phentermine increased to 18.75 mg daily | 24
     topiramate increased to 50 mg twice a day | 24
     metformin increased to 500 mg twice a day | 24
     bupropion extended release 150 mg daily | 24
     bupropion increased to 300 mg daily | 168
     started on semaglutide 0.25 mg weekly | 168
     lower calorie diet | 168
     regularly scheduled registered dietician visits | 168
     significant reduction in hunger | 168
     BMI began to decrease | 168
     semaglutide increased to 0.5 mg weekly | 720
     lost 209 pounds | 876
     BMI decreased to 66.5 kg/m2 | 876
     hemoglobin A1c normalized to 5.0% | 876
     snoring improved | 876
     semaglutide increased to 1.0 mg weekly | 1200
     lost an additional 6 pounds | 1224
     gained an additional 11 pounds | 1300
     weight stabilization | 1300