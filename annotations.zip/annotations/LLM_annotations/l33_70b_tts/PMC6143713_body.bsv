 60 years old | 0
     male | 0
     presented to the dermatology clinic | 0
     6 large, persistent nodules of the abdomen and left thigh | 0
     denied fevers | 0
     denied chills | 0
     denied lymphadenopathy | 0
     denied systemic allergic symptoms | 0
     diabetes mellitus type II | -672
     hypertension | -672
     dyslipidemia | -672
     nonalcoholic steatohepatitis (NASH) | -672
     metformin | -672
     liraglutide | -672
     dulaglutide | -672
     exenatide extended release weekly injections | -56
     first nodule occurred | -56
     pruritic | -56
     mild discomfort | -56
     large, firm 5.5-cm × 4-cm subcutaneous nodule on the left side of the abdomen | 0
     5 other 2.0- to 4.0-cm deep nodules | 0
     slight erythema | 0
     warmth | 0
     exenatide discontinued | -14
     betamethasone 0.5% cream | -14
     Zyrtec | -14
     excisional biopsy | 0
     intralesional triamcinolone | 0
     lobular and septal panniculitis | 0
     mononuclear cells | 0
     prominent admixed eosinophils | 0
     dermal hypersensitivity reaction | 0
     moderate predominantly perivascular lymphohistiocytic infiltrate | 0
     admixed eosinophils | 0
     occasional plasma cells | 0
     worsening erythema surrounding the biopsy site | 14
     yellow, thickened drainage | 14
     doxycycline | 14
     prednisone | 21
     dapsone | 21
     worsening of his lower extremity edema | 21
     great improvement within the nodule on the right side of the abdomen | 42
     intralesional triamcinolone injections | 42
     significant improvement of all of his nodules | 84
     2 subtle, less than 0.5 cm persistent nodules | 84
     intralesional triamcinolone injections | 84
     pruritus resolved | 84
     discomfort resolved | 84
     no skin atrophy | 84