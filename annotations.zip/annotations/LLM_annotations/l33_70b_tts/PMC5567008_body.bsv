 19 years old | 0
     female | 0
     South Indian origin | 0
     polycystic ovary syndrome (PCOS) | -96
     fatty liver | -96
     normal growth and development | -228
     active lifestyle | -228
     no family history of HS | 0
     no family history of colitis | 0
     no family history of autoimmune disease | 0
     maternal grandparents had late-onset diabetes | 0
     immigrated to the United States | -96
     begun menstruation | -96
     45-pound weight gain | -94
     fever | -94
     perianal pain | -94
     surgery for perianal abscess | -94
     developed multiple skin lesions consistent with HS | -94
     acne | -94
     irregular periods | -94
     widespread abdominal scarring | -84
     contracture of the entire body | -84
     extensive therapy | -96
     oral and intravenous antibiotics | -96
     numerous surgeries | -96
     isotretinoin for acne treatment | -96
     periodic metformin | -96
     oral birth control usage | -96
     menstrual periods caused severe flare-ups | -96
     increased pain medication | -96
     sleep severely impaired | -96
     HS encompassing most of the truncal area | 0
     extensive muscle wasting of the extremities | 0
     facial acne without scarring | 0
     hirsutism | 0
     weight 215 pounds | 0
     BMI of 37 | 0
     class II obesity | 0
     microcytic anemia | 0
     hemoglobin of 6.2 g/dL | 0
     normal iron indices | 0
     anemia of chronic disease | 0
     elevated liver enzymes | 0
     fatty liver | 0
     blood sugar 117 mg/dL | 0
     HbA1c of 5.7% | 0
     pre-diabetes | 0
     low-carbohydrate diet | 0
     oral contraception | 0
     dapsone 100 mg/day | 0
     glucose-6-phosphate dehydrogenase test | 0
     initial minimal improvements | 1
     finasteride 5 mg/day | 3
     metformin 2,000 mg/day | 3
     liraglutide 0.6 mg subcutaneously daily | 3
     increased to 1.8 mg over 2 months | 5
     lost approximately 40 pounds | 6
     lowest weight recorded | 6
     trend of regain subsequently | 6
     monthly follow-ups | 6
     complete laboratory testing | 6
     liver enzymes responded | 6
     declines within 6 months | 6
     resolution within a year | 12
     leukocytosis returned to normalcy | 24
     anemia returned to normalcy | 24
     hypoalbuminemia returned to normalcy | 24
     sedimentation rate reduced | 24
     total proteins remain slightly above normal | 24
     HbA1c 5.2% | 24
     average estimated blood sugar 94 mg/dL | 24
     weight regained | 24
     clinical course did not respond initially | 0
     new lesions appeared | 3
     resolved faster | 3
     patient felt better | 6
     less intense and frequent flares | 6
     large perianal abscess developed | 9
     hospitalization | 9
     surgery | 9
     perianal lesion healed completely | 12
     no adjunctive antibiotics | 12
     risk of pregnancy addressed | 12
     no new lesion for 6 months | 36
     completed 3 years of the regimen | 36
     remarkable tolerance | 36
     axillary lesions healed completely | 36
     groin, thigh, and perianal disease improved 90% or more | 36
     thoraco-abdominal lesions improved 60% | 36
     facial acne improved but persisted | 36
     weight regain noted | 36
     no physical or biochemical abnormality detected | 36
     sedimentation rate minimally elevated | 36