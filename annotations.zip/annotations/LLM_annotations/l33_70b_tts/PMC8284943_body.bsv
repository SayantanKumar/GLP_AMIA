 36 years old | 0
     female | 0
     admitted to the hospital | 0
     diagnosed with PCOS | -6048
     diagnosed with T2D | -6048
     irregular periods | -6048
     weight loss of 30 kg | -6048
     spontaneous pregnancy | -672
     pre-pregnancy BMI 40 kg/m2 | -672
     blood pressure 136/71 mmHg | -672
     treated with metformin | -672
     treated with liraglutide | -672
     treated with ACE inhibitor | -672
     medication discontinued | -672
     HbA1c 41 mmol/mol | -672
     referred to the outpatient clinic | 0
     HbA1c 59 mmol/mol | 0
     insulin treatment initiated | 0
     Novomix 30 20 units/day | 0
     insulin doses increased | 24
     Insulatard and Novorapid initiated | 120
     insulin requirements 1420 units/day | 120
     blood samples taken | 120
     non-fasting C-peptide concentration 3294 pmol/L | 120
     proinsulin level 302 pmol/L | 120
     leptin and MBL levels high | 120
     IGF-1 level 401 µg/L | 120
     inflammatory markers comparable to GDM | 120
     CRP mildly elevated | 120
     free fatty acids low | 120
     CD 163, cortisol and biochemical profile unremarkable | 120
     antibodies against insulin undetectable | 120
     no mutations in the INSR gene | 120
     insulin requirements decreased to 720 units/day | 168
     admitted for observation | 168
     insulin requirements and blood glucose continued to fall | 168
     no insulin requirements | 192
     stable blood glucose at around 6 mmol/L | 192
     delivery by cesarean section | 216
     baby born with birthweight 3850 g | 216
     Apgar scores normal | 216
     no neonatal hypoglycemia | 216
     placental weight 920 g | 216
     mother and baby discharged from the hospital | 240
     patient advised to continue self-monitoring of glucose | 240
     patient advised to consult general practitioner for diabetes check-up | 240
     blood glucose, plasma insulin, C-peptide and IGF-1 normalized | 240
     patient breastfeeding | 240
     no antidiabetic medication | 240
     insulin resistance returned 7 months post-partum | 6048
     HbA1c 116 mmol/mol | 6048
     treatment warranted | 6048