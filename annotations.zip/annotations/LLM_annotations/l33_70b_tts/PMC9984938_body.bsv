 67 years old | 0
     female | 0
     type 2 diabetes | -13140
     hypertension | -13140
     dyslipidemia | -13140
     liver fibrosis | -13140
     hemorrhoids | -13140
     irbesartan | -13140
     simvastatin | -13140
     empagliflozin | -13140
     semaglutide | -13140
     left-eye ptosis | -168
     double vision | -168
     mild pain around left eye | -168
     CTA of the head | -168
     normal CTA | -168
     MRI of the brain and orbits with contrast | -168
     abnormal enhancement of the left third cranial nerve | -168
     thickening of the cisternal segment of the left third cranial nerve | -168
     increased T2 signal in the cisternal and cavernous portions of the third nerve | -168
     referred to neuro-ophthalmology | -168
     visual acuity 20/25 OD | 0
     visual acuity 20/50 OS | 0
     cataract | 0
     left complete ptosis | 0
     complete limitation of elevation, depression, and adduction | 0
     full right ocular ductions | 0
     normal cranial nerve function | 0
     equal pupil sizes | 0
     pupils reactive to light | 0
     diagnosed with complete, pupil-sparing 3NP | 0
     inflammatory bloodwork | 0
     normal ANA | 0
     normal ANCA | 0
     normal ACE | 0
     normal IgG4 serum levels | 0
     normal NMO-IgG | 0
     normal MOG-IgG | 0
     normal ESR | 0
     normal CRP | 0
     normal VDRL | 0
     normal HIV | 0
     lumbar puncture | 0
     normal cell count | 0
     normal glucose | 0
     normal protein levels | 0
     repeat MRI | 744
     persistent thickening and enhancement of the third nerve | 744
     3NP spontaneously resolved | 1488
     started on insulin | 4320
     repeat MRI | 8640
     significant improvement | 8640
     minimal enhancement | 8640
     persistently increased T2 signal | 8640
     no recurrence | 8760
     clinically well | 8760