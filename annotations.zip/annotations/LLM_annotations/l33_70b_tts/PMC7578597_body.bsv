 79 years old | 0
     male | 0
     admitted to the hospital | 0
     prostate cancer | -1920
     orchiectomy | -1920
     body weight 81 kg | -1920
     gained 4 kg of body weight | -432
     diabetes mellitus | -72
     thirst | -72
     polyuria | -72
     lost 10 kg of body weight | -72
     postprandial blood glucose 115 mg/dL | -1920
     HbA1c 6.6% | -1920
     PSA 8.334 ng/mL | -1920
     postprandial plasma glucose 518 mg/dL | -72
     HbA1c 11.9% | -72
     medication for hypertension | 0
     medication for dyslipidemia | 0
     medication for paroxysmal atrial fibrillation | 0
     no family history of diabetes | 0
     ethanol intake under 30 g a day | 0
     body temperature 35.6 °C | 0
     blood pressure 113/65 mmHg | 0
     pulse 88 bpm | 0
     body weight 75 kg | 0
     BMI 25.6 kg/m2 | 0
     C-peptide immunoreactivity 2.33 ng/mL | 0
     C-peptide immunoreactivity 6.68 ng/mL | 0
     anti-glutamic acid decarboxylase antibody negative | 0
     anti-insulin antibody negative | 0
     PSA 0.739 ng/mL | 0
     postoperative serum free testosterone 1 pg/mL | 0
     serum level of estradiol below detection | 0
     thyroid and adrenal function test normal | 0
     abdominal CT showed fatty liver | 0
     liver-to-spleen ratio 0.37 | 0
     visceral fat area 233.50 cm2 | 0
     subcutaneous fat area 242.54 cm2 | 0
     liver function test normal | 0
     tests for viral hepatitis negative | 0
     anti-nuclear antibody negative | 0
     anti-mitochondrial M2 antibody negative | 0
     hypergammaglobulinemia not found | 0
     diagnosed with severe diabetes | 0
     rapid deterioration of visceral fat accumulation | 0
     fatty liver | 0
     MDI therapy with canagliflozin 100 mg/day | 0
     sitagliptin 50 mg/day | 0
     blood glucose well controlled | 168
     insulin regimen changed to insulin aspart/insulin degludec | 168
     sitagliptin changed to dulaglutide injection 75 mg | 168
     CT showed improvement in L/S ratio | 336
     reduction in visceral and subcutaneous fat area | 336
     discharged | 720