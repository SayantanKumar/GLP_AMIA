 83 years old | 0
     male | 0
     anxiety | -672
     hyperlipidemia | -672
     type 2 diabetes mellitus | -672
     hypertension | -672
     glaucoma | -672
     semaglutide | -672
     empagliflozin | -672
     brimonidine | -672
     latanoprost | -672
     atorvastatin | -672
     headache | -48
     decreased appetite | -48
     non-contrasted computed tomography of the head | -48
     serologic workup | -48
     discharged | -46
     worsened mental status | -24
     worsening headache | -24
     nausea | -24
     worsening appetite | -24
     afebrile | 0
     blood pressure 131/99 | 0
     heart rate 81 | 0
     respiratory rate 18 | 0
     fingerstick glucose 260 mg/dL | 0
     insulin aspart | 0
     fentanyl | 0
     ondansetron | 0
     CT of the abdomen and pelvis | 0
     encephalopathy | 0
     repeat non-contrast CT of the head | 0
     acute left occipital IPH | 0
     levetiracetam | 0
     transferred to neurocritical care unit | 0
     encephalopathic | 0
     not orientated to the date or place | 0
     right homonymous hemianopsia | 0
     trouble completing complex commands | 0
     intact strength and sensation | 0
     National Institutes of Health Stroke Scale 5 | 0
     electrocardiogram | 0
     normal sinus rhythm | 0
     complete blood count with differential | 0
     coagulation studies | 0
     complete metabolic panel | 0
     lipid panel | 0
     hemoglobin A1c 10.2% | 0
     elevated blood urea nitrogen 23 | 0
     elevated anion gap 17 | 0
     low bicarbonate level 20 | 0
     β-hydroxybutyrate level 3.65 | 0
     urinalysis | 0
     urine glucose >1000 mg/dL | 0
     urine ketones >80 mg/dL | 0
     euglycemic DKA | 0
     dextrose 10% + potassium chloride infusion | 0
     insulin drip | 0
     goal glucose level 90-200 mg/dL | 0
     diet | 0
     monitoring of electrolyte status and BOHB | 0
     correction of potassium level | 0
     anion gap closed to 10 mmol/L | 4
     BOHB level decreased to 0.93 mmol/L | 4
     transitioned to insulin sliding scale | 4
     blood pressure goal systolic <160 mmHg | 0
     CT head stable | 6
     CT angiogram of the head and neck | 0
     prominent arterial branches | 0
     concern for underlying mass or vascular legion | 0
     MRI of the brain with and without contrast | 0
     abnormal curvilinear enhancement | 0
     saccular enhancing focus | 0
     digital subtraction angiography | 0
     no evidence of arteriovenous malformation | 0
     attributed IPH to uncontrolled hypertension | 0
     lisinopril | 0
     discharged home | 216
     home health | 216
     semaglutide discontinued | 216
     empagliflozin discontinued | 216
     glargine | 216
     lispro | 216
     outpatient follow-up with endocrinology | 216
     outpatient follow-up with vascular neurology | 216
     lost to follow-up | 216