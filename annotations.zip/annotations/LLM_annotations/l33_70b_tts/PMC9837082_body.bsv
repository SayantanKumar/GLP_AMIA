 27 years old | 0
     female | 0
     class III obesity | 0
     fatigue | -1560
     generalized muscle weakness | -1560
     multiple falls | -1560
     decreased oral intake | -1560
     low carbohydrate, calorie restricted diet | -1560
     severe vomiting | -1300
     stopped diet | -1290
     elevated thyroid stimulating hormone | -1300
     elevated thyroid peroxidase antibodies | -1300
     elevated creatine kinase | -1300
     Levothyroxine 25 mcg daily | -1300
     worsening symptoms | -780
     high TSH | -780
     antibody testing for myositis | -780
     necrotizing myopathy | -780
     myasthenia gravis | -780
     panel-based genetic testing for muscular dystrophies | -780
     electromyography | -780
     inflammatory, genetic, or metabolic myopathy | -780
     vastus lateralis biopsy | -780
     vacuolated muscle fibers with lipid droplets | -780
     lipid storage myopathy | -780
     plasma acylcarnitine profile | -780
     elevated small-, medium- and long-chain acylcarnitine species | -780
     urine organic acid analysis | -780
     elevated excretion of orotic acid | -780
     elevated excretion of 2-hydroxy glutaric acid | -780
     genetic testing | -780
     presented to the hospital | 0
     worsening weakness | 0
     multiple falls | 0
     decreased oral intake | 0
     neurological exam | 0
     proximal greater than distal weakness | 0
     neck weakness | 0
     trace to absent lower extremity reflexes | 0
     pulmonary embolism | 0
     severe ketoacidosis | 0
     venous pH 7.00 | 0
     beta hydroxybutyrate 5.67 nmol/L | 0
     rhabdomyolysis | 0
     CK 4656 units/L | 0
     lactate peaking at 6.0 mmol/L | 0
     admission to the intensive care unit | 0
     sodium bicarbonate | 0
     normal saline | 0
     thiamine | 0
     dextrose | 0
     heparin infusions | 0
     improved within 24 hours | 24
     venous pH normalized | 24
     CK improved | 24
     lactate improved | 24
     carnitine | 24
     riboflavin | 24
     cyanocobalamin | 24
     coenzyme Q10 | 24
     presumptive diagnosis of a riboflavin-responsive lipid storage myopathy | 24
     genetic testing results | 24
     heterozygous frameshift mutation | 24
     c.51dup;p.(A18Cfs*5) | 24
     ETFDH gene | 24
     likely pathogenic for MADD | 24
     discharged to inpatient rehabilitation | 48
     physical and occupational therapy | 48
     maintained on carnitine, riboflavin, cyanocobalamin, coenzyme Q10, and thiamine supplementation | 48
     high carbohydrate, low-fat diet | 48
     discharged home | 168
     adhere to a diet with less than 25 g of fat per day | 168
     avoid prolonged fasting | 168
     intermittent nausea | 168
     ondansetron | 168
     neuropathic pain | 168
     pregabalin | 168
     strength and energy started to improve | 168
     CK normalized | 504
     metformin | 1008
     liraglutide | 1008
     weight loss | 1008
     TSH | 1008
     levothyroxine increased | 1008
     feels well | 4032
     improved strength and energy | 4032