 29 years old | 0
     female | 0
     admitted to the hospital | 0
     bigger than other children | -2400
     progressive weight gain | -2400
     dyslipidemia | 0
     hypertension | 0
     obstructive sleep apnea | 0
     pre-diabetes | 0
     carvedilol | 0
     amlodipine | 0
     hydrochlorothiazide | 0
     torsemide | 0
     valsartan | 0
     atorvastatin | 0
     cholestyramine | 0
     weight 185.3 kg | 0
     blood pressure 132/66 mmHg | 0
     excess abdominal adiposity | 0
     large dorsocervical fat pad | 0
     total cholesterol 182 mg/dL | 0
     LDL 129 mg/dL | 0
     triglyceride 189 mg/dL | 0
     A1c 5.6% | 0
     Binge Eating Severity Scale 16 | 0
     phentermine 37.5 mg daily | 0
     topiramate 50 mg daily | 0
     weight loss 8 kg | 133
     topiramate dose increased to 50 mg twice daily | 133
     phentermine dose maintained | 133
     semaglutide trialed | 133
     semaglutide discontinued | 140
     weight loss 67.3 kg | 1044
     BMI 43.4 | 1044
     down-titrate blood pressure medications | 504
     discontinued CPAP | 576
     thiazide diuretic discontinued | 648
     angiotensin-receptor blocker discontinued | 876
     calcium channel blocker discontinued | 876
     beta-blocker discontinued | 876
     Binge Eating Severity Scale 1 | 1044
     genetic testing performed | 1044
     PLXNA4 variant noted | 1044
     deferred bariatric surgery | 1044