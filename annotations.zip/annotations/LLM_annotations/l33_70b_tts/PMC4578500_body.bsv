 32 years old | 0
     female | 0
     Prader–Willi syndrome | 0
     diabetes | -7980
     low-carbohydrate diet | -3972
     glimepiride | -3972
     metformin | -3972
     linagliptin | -3972
     ipragliflozin | -312
     polyuria | -312
     bodyweight decreased | -312
     epigastralgia | -48
     water intake decreased | -48
     dietary intake decreased | -48
     tachypnea | -24
     admitted to the hospital | 0
     severe acidosis | 0
     ketonuria | 0
     ketonemia | 0
     normal lactate level | 0
     chest X-ray | 0
     electrocardiogram | 0
     abdominal computed tomography | 0
     urinary sediments | 0
     ketoacidosis | 0
     continuous intravenous insulin | 0
     Ringer's solution | 0
     glucose infusion | 0
     antiglutamic acid decarboxylase antibody negative | 0
     islet antigen-2 antibody negative | 0
     insulin autoantibody negative | 0
     serum C-peptide | 0
     urinary C-peptide undetectable | 0
     plasma glucose | 0
     glycated hemoglobin | 0
     glycated albumin | 0
     basal–bolus insulin therapy | 24
     insulin glargine | 168
     lixisenatide | 168
     metformin | 168
     1,500-kcal diet | 168
     bodyweight increased | 48
     HbA1c improved | 720
     glycated albumin improved | 720