 60 years old | 0
     male | 0
     coronary artery disease | 0
     hypercholesterolemia | 0
     type 2 DM | 0
     glimepiride | -720
     metformin | -720
     semaglutide | -720
     empagliflozin | -720
     referred to hospital | -72
     cardiac catheterization | -72
     triple-vessel disease | -72
     asymptomatic | 0
     vital signs within normal limits | 0
     white blood cell count of 7.6 K/μL | 0
     hemoglobin of 14.6 g/dL | 0
     serum glucose of 157 mg/dL | 0
     bicarbonate of 24 mmol/L | 0
     anion gap of 12 mmol/L | 0
     troponin of 0.09 ng/mL | 0
     glycated hemoglobin of 9.6% | 0
     glucosuria of >1000 mg/dL | 0
     ketonuria of 15 mg/dL | 0
     oral antihyperglycemic medications withheld | 0
     subcutaneous insulin regimen | 0
     CABG surgery | 42
     elevated anion gap metabolic acidosis | 46
     arterial pH of 7.275 | 46
     reduced bicarbonate level of 15 mmol/L | 46
     increased anion gap of 25 mmol/L | 46
     serum glucose level of 138 mg/dL | 46
     β-hydroxybutyric acid level of 6.52 mmol/L | 46
     euglycemic DKA | 46
     intravenous insulin drip | 46
     5% dextrose in water infusion | 46
     intravenous norepinephrine | 46
     hypotension | 46
     ketoacidosis resolved | 70
     subcutaneous insulin | 70
     adequate glycemic control | 70
     Invokana | -8760
     Jardiance | -720
     last dose of Jardiance | -48
     educated on discontinuing SGLT2 inhibitors | 120
     discharged | 120