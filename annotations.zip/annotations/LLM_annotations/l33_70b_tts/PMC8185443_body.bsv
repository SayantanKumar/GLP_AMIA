 66 years old | 0
     male | 0
     chest discomfort | 0
     right knee pain | 0
     intractable hiccups | 0
     type 2 diabetes mellitus | 0
     hypercholesterolemia | 0
     aortic atherosclerosis | 0
     ascending aortic aneurysm | 0
     premature coronary artery disease in the father | 0
     subcutaneous 200 units/mL insulin degludec | 0
     subcutaneous 18 mg/3 mL liraglutide | 0
     daily oral 500 mg metformin hydrochloride | 0
     daily oral 100 mg sitagliptin | 0
     daily oral 12.5 mg zolpidem | 0
     daily oral 5 mg tadalafil | 0
     20 mg tablet rosuvastatin daily | 0
     upper gastrointestinal (GI) endoscopy | -24
     no GI etiology | -24
     cardiac stress test | 216
     dyspnea | 216
     unstable angina | 216
     transthoracic echocardiogram | 216
     preserved ejection fraction | 216
     coronary calcium score study | 216
     Agatson calcium score of 1185 | 216
     high risk for future cardiovascular events | 216
     cardiac catheterization | 3456
     multiple arteries severely calcified | 3456
     left main artery 10% stenosis | 3456
     left anterior descending artery (LAD) 99% stenosis | 3456
     circumflex artery 20% stenosis | 3456
     right coronary artery (RCA) 30% stenosis | 3456
     revascularization | 3456
     drug eluting stent placed in the mid-segment of the LAD | 3456
     discharged | 3456
     dual antiplatelet therapy | 3456
     81 mg aspirin | 3456
     90 mg ticagrelor twice a day | 3456
     post-interventional follow-ups | 4320, 12960, 8760
     no return of intractable hiccups | 4320, 12960, 8760