 72 years old | 0
     male | 0
     board-certified ophthalmologist | 0
     admitted to the hospital | 0
     atrial fibrillation | -672
     cataract surgery | -1296
     intraocular lens implantation | -1296
     nuclear cataract | 0
     started taking oral semaglutide | 0
     oral semaglutide 3 mg daily | 0
     propranolol 20 mg twice a day | 0
     aspirin 81 mg daily | 0
     naproxen 220 mg | 0
     ibuprofen 400 mg | 0
     knee pain | -168
     observed a small, round central scotoma in his right eye | 16
     central scotoma enlarged | 17
     central scotoma became an irregular square shape | 17
     similar scotoma detected in his left eye | 19
     discontinued semaglutide | 20
     scotomas persist both eyes | 21
     enlarged scotoma right eye | 22
     residual scotomas remain | 23
     scotomas gone | 24
     returned from vacation | 24
     formal ophthalmic evaluation | 26
     uncorrected distance visual acuity measured 20/20 right eye | 26
     uncorrected distance visual acuity measured 20/25 left eye | 26
     anterior segment exam was benign | 26
     fundus examination demonstrated normal appearing optic nerves | 26
     scattered small drusen in each macula | 26
     vitreous opacities from a posterior vitreous detachment | 26
     Humphrey visual field testing revealed a reliable test | 26
     macular optical coherence tomography identified subretinal drusenoid deposits | 26
     retinal nerve fiber layer OCTs were normal | 26