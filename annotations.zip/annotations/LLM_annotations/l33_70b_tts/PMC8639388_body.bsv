 68 years old | 0
     female | 0
     type 2 diabetes | -8760
     diabetic polyneuropathy | -8760
     lower-leg edema | -720
     painful sores on the bilateral lower extremities | -720
     pruritic sores on the bilateral lower extremities | -720
     hyperkeratotic papules and nodules on the bilateral shins | -720
     lesions developed over the calves | -720
     ulcerated lesions | -720
     presented to an outside clinic | -168
     eczematous changes | -168
     bacterial superinfection | -168
     topical triamcinolone | -168
     topical compounded mupirocin/clindamycin/ivermectin/gentamicin | -168
     oral ciprofloxacin | -168
     oral fluconazole 150 mg | -168
     computed tomography angiogram | -168
     duplex ultrasound with Doppler | -168
     stasis dermatitis | -168
     extensive fungal hyphae | -168
     lives in middle Tennessee | 0
     avid gardener | 0
     tends to rosebushes | 0
     wears capri pants when gardening | 0
     never used tobacco | 0
     illicit substances | 0
     rarely drinks alcohol | 0
     denies any recent travel | 0
     dulaglutide | 0
     omeprazole | 0
     pain medications | 0
     vitamin supplements | 0
     no immunosuppressive medications | 0
     elevates her legs nightly with ice therapy | 0
     vegetative and hyperkeratotic papules and plaques | 0
     central ulceration | 0
     erythema and stasis changes | 0
     non-tender and cool to touch | 0
     no nail or additional skin changes | 0
     hemoglobin A1c of 11.8% | 0
     White blood cell count was 5600/mm3 | 0
     complete metabolic panel was unremarkable | 0
     bacterial and acid-fast bacilli cultures exhibited no growth | 0
     fungal tissue cultures were positive for P. lilacinus | 0
     fungal tissue cultures were positive for C. guilliermondii | 0
     antifungal susceptibility was not obtained | 0
     dermal fibroplasia and mixed neutrophilic and lymphocytic dermal inflammation | 0
     numerous fungal hyphae within the stratum corneum | 0
     diagnosed with a cutaneous P. lilacinus and C. guilliermondii infection | 0
     started on oral voriconazole 200 mg every 12 hours | 0
     topical triamcinolone and plastic wraps for discomfort | 0
     marked improvement was noted at 2 months | 48
     slow-healing plaques that have crusted over or healed completely with scarring and post-inflammatory hyperpigmentation | 48
     no new development of ulcerative papules or plaques has been observed | 48