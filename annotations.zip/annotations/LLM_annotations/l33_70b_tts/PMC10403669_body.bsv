 53 years old | 0
     male | 0
     White | 0
     admitted to the hospital | 0
     hypertension | -672
     former tobacco use | -672
     morbid obesity | -672
     type 2 diabetes | -672
     cystinuria | -672
     nephrolithiasis | -672
     lithotripsy | -672
     tiopronin | -504
     potassium citrate | -504
     semaglutide | -504
     amlodipine | -504
     telmisartan | -504
     chlorthalidone | -504
     blood pressure 128/92 mm Hg | 0
     body mass index of 41.5 kg/m2 | 0
     no peripheral edema | 0
     serum creatinine 1.1 mg/dl | 0
     estimated glomerular filtration rate of 80 ml/min per 1.73 m2 | 0
     urinalysis revealed 3+ protein | 0
     negative blood | 0
     no leukocyturia | 0
     24-hour urine protein of 4.6 g | 0
     serum albumin of 4.5 g/dl | 0
     normal serum complement levels | 0
     negative ANA | 0
     negative dsDNA antibody | 0
     negative hepatitis B surface antigen | 0
     negative hepatitis C antibody | 0
     negative MPO-ANCA | 0
     negative PR3-ANCA | 0
     negative anti-PLA2R antibody | 0
     negative anti-glomerular basement membranes (GBM) antibody | 0
     negative HIV | 0
     no M-spike on SPEP or UPEP | 0
     normal renal function | -504
     absence of proteinuria | -504
     kidney biopsy | 0
     segmental membranous nephropathy (MN) | 0
     NELL-1 positive | 0
     tiopronin discontinued | 0
     telmisartan | 0
     dapagliflozin | 0
     denied use of LA containing supplements | 0
     no known occupational or environmental risk factors for heavy metal exposure | 0
     cancer screening | 0
     computed tomography scan of the chest, abdomen, and pelvis | 0
     screening colonoscopy | 0
     prostate-specific antigen testing | 0
     all cancer screening tests were negative | 0
     immunosuppressive therapies deferred | 0
     serum creatinine 1.0 mg/dl | 432
     urine protein-to-creatinine ratio of 2.08 g/g | 432
     serum albumin 4 g/dl | 432