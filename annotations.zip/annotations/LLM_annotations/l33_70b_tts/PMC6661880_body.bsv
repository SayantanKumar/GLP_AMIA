 52 years old | 0
     female | 0
     BMI 29 | 0
     admitted to the hospital | 0
     mushroom poisoning | -720
     alcoholic liver cirrhosis | -720
     portal hypertension | -720
     ascites | -720
     diabetes mellitus | -7920
     alcohol dependence | -26280
     smoking addiction | -26280
     decompensated stage of liver cirrhosis | -6480
     chronic pancreatitis | -87360
     external secretory insufficiency of pancreas | -87360
     pancreatogenic diabetes | -87360
     axial hiatal hernia | -63360
     polyarthritis | -63360
     upper abdominal pain | -216
     nausea | -216
     excessive thirst | -216
     fatigue | -216
     weight loss | -216
     diarrhea | -216
     clay-colored stools | -216
     cyclical period of upper abdominal pain | -216
     radiated to the back after eating or drinking | -216
     endoscopic retrograde cholangiopancreatography | -720
     computed tomography scan of the abdomen | -720
     fecal fat test | -720
     increased serum amylase level | -720
     increased serum lipase level | -720
     serum trypsinogen | -720
     treatment focused on patient’s state stabilization | 0
     reduction of pain | 0
     improvement in digestive function | 0
     withdrawing of smoking and alcohol | 0
     dietary changes | 0
     pancreatic enzyme supplements | 0
     insulin therapy | 0
     glucagon-like peptide 1 | 0
     nonsteroidal anti-inflammatory drug | 0
     proton pump inhibitor | 0
     corticosteroids | 0
     IV fluid | 0
     cavernous transformation of the portal vein | 0
     hepatosplenomegaly | 0
     chronic toxic hepatitis | 0
     chronic calculous cholecystitis | 0
     adhesive disease | 0
     intestinal obstruction | 0
     resection of a segment of the colon | -51840
     duodenal ulcer | -51840
     erosive gastritis | -51840
     duodeno-gastric reflux | -51840
     cyst on the right kidney | -63360
     right-sided nephrectomy | -63360
     deterioration of health condition | -720
     diarrhea up to 5 times per day | -720
     ascites | 0
     tenderness of liver | 0
     chronic fatigue | 0
     general moodiness | 0
     feelings of despair | 0
     loss of appetite | 0
     nausea | 0
     bloating exacerbated after eating and exercise | 0
     liquid and tarry stools | 0
     vomiting | 0
     fever | 0
     abdominal pain | 0
     stomach upset | 0
     jaundice | 0
     altered personality | 0
     hyperreflexia | 0
     insomnia | 0
     drowsiness | 0
     bruises | 0
     pedal edema | 0
     shortness of breath | 0
     breathlessness | 0
     caput medusa | 0
     blotchy palms | 0
     nosebleeds | 0
     muscle cramps | 0
     abnormal values of complete blood count | 0
     blood chemistry | 0
     liver enzymes components | 0
     fasting high-density lipoprotein level | 0
     fasting triglyceride level | 0
     waist circumference | 0
     fasting plasma glucose | 0
     hypertension | 0
     viral tests excluded the presence of viral hepatitis | 0
     esophageal varices | 0
     hepatosplenomegaly | 0
     spleen size | 0
     vena porta | 0
     splenic vein | 0
     recanalization umbilical vein | 0
     treatment regimen | 0
     diet | 0
     insulin | 0
     aetropidi | 0
     protafan | 0
     berlitioni | 0
     solution natrium | 0
     enterogel | 0
     creonu | 0
     enterogermina | 0
     lacium | 0
     calcemin | 0
     thiotriazolini | 0
     reosirbilact | 0
     calcii | 0
     vitruni | 0
     lactovit | 0
     aevit | 0
     pimafucini | 0
     furamag | 0
     thiogamma | 0
     rheosorbilact | 0
     furosemide | 0
     dibazol | 0
     papaverine | 0
     coagulopathy | 0
     anemia | 0
     prothrombin index | 0
     liver deterioration | 0
     thymol test | 0
     liver dysfunction | 0
     leucocytosis | 0
     shift to the left | 0
     depletion of the number of neutrophils | 0
     albumin | 0
     gamma-globulin | 0
     elevated liver function enzymes | 0
     hyperammonemia | 0
     mental and behavioral disorders | 0
     chronic alcoholism | 0
     liver enzymes values | 0
     bilirubin levels | 0
     fasting glucose level | 0
     insulin-resistant diabetes | 0
     anti-diabetic medication | 0
     blood sugar test | 0
     glycated hemoglobin | 0
     hemoglobin A1c | 0
     cardiovascular failure | 0
     pre-meal blood glucose | 0
     hypoglycemia | 0
     individualized meal plans | 0
     alimentary educational strategies | 0
     calorie intake | 0
     protein | 0
     fat | 0
     carbohydrates | 0
     physical activity | 0
     health care facility | 0
     retinal examinations | 0
     urinary protein screening | 0
     foot care | 0
     hyperlipidemia | 0
     triglyceride level | 0
     HDL cholesterol | 0
     systolic and diastolic blood pressure | 0
     metabolic syndrome | 0
     abdominal girth | 0
     hypertension | 0
     hyperglycemia | 0
     dyslipidemia | 0
     obesity | 0
     ascitic fluid | 0
     liver diseases | 0
     liver insufficiency | 0
     hepatotoxicity | 0
     oral hypoglycemic drugs | 0
     liver function | 0
     liver failure | 0
     antihyperglycemic agents | 0
     diabetic treatments | 0
     liver damage | 0
     overweight | 0
     liver cirrhosis | 0
     portal hypertension | 0
     portosystemic collateral channels | 0
     abdominal wall collateral veins | 0
     intrahepatic resistance | 0
     portal blood flow | 0
     hepatic architectural changes | 0
     regenerative nodules | 0
     fibrotic septa | 0
     liver resistance | 0
     hepatic metaplasia | 0
     fibrosis | 0
     nodules | 0
     portal pressure gradient | 0
     insulin resistance | 0
     hyperinsulinemia | 0
     metabolic syndrome | 0
     viral etiologies | 0
     alcoholic liver cirrhosis | 0
     diabetes mellitus | 0
     clinical interaction | 0
     liver function tests | 0
     liver enzymes | 0
     bilirubin | 0
     albumin | 0
     gamma-globulin | 0
     prothrombin index | 0
     liver deterioration | 0
     thymol test | 0
     liver dysfunction | 0
     white blood cell count | 0
     erythrocyte sedimentation rate | 0
     C-reactive protein | 0
     liver function | 0
     liver failure | 0
     liver damage | 0
     liver cirrhosis | 0
     portal hypertension | 0
     portosystemic collateral channels | 0
     abdominal wall collateral veins | 0
     intrahepatic resistance | 0
     portal blood flow | 0
     hepatic architectural changes | 0
     regenerative nodules | 0
     fibrotic septa | 0
     liver resistance | 0
     hepatic metaplasia | 0
     fibrosis | 0
     nodules | 0
     portal pressure gradient | 0
     insulin resistance | 0
     hyperinsulinemia | 0
     metabolic syndrome | 0
     viral etiologies | 0
     alcoholic liver cirrhosis | 0
     diabetes mellitus | 0
     clinical interaction | 0
     liver function tests | 0
     liver enzymes | 0
     bilirubin | 0
     albumin | 0
     gamma-globulin | 0
     prothrombin index | 0
     liver deterioration | 0
     thymol test | 0
     liver dysfunction | 0
     white blood cell count | 0
     erythrocyte sedimentation rate | 0
     C-reactive protein | 0
     liver function | 0
     liver failure | 0
     liver damage | 0
     liver cirrhosis | 0
     portal hypertension | 0
     portosystemic collateral channels | 0
     abdominal wall collateral veins | 0
     intrahepatic resistance | 0
     portal blood flow | 0
     hepatic architectural changes | 0
     regenerative nodules | 0
     fibrotic septa | 0
     liver resistance | 0
     hepatic metaplasia | 0
     fibrosis | 0
     nodules | 0
     portal pressure gradient | 0
     insulin resistance | 0
     hyperinsulinemia | 0
     metabolic syndrome | 0
     viral etiologies | 0
     alcoholic liver cirrhosis | 0
     diabetes mellitus | 0
     clinical interaction | 0
     liver function tests | 0
     liver enzymes | 0
     bilirubin | 0
     albumin | 0
     gamma-globulin | 0
     prothrombin index | 0
     liver deterioration | 0
     thymol test | 0
     liver dysfunction | 0
     white blood cell count | 0
     erythrocyte sedimentation rate | 0
     C-reactive protein | 0
     liver function | 0
     liver failure | 0
     liver damage | 0
     liver cirrhosis | 0
     portal hypertension | 0
     portosystemic collateral channels | 0
     abdominal wall collateral veins | 0
     intrahepatic resistance | 0
     portal blood flow | 0
     hepatic architectural changes | 0
     regenerative nodules | 0
     fibrotic septa | 0
     liver resistance | 0
     hepatic metaplasia | 0
     fibrosis | 0
     nodules | 0
     portal pressure gradient | 0
     insulin resistance | 0
     hyperinsulinemia | 0
     metabolic syndrome | 0
     viral etiologies | 0
     alcoholic liver cirrhosis | 0
     diabetes mellitus | 0
     clinical interaction | 0
     liver function tests | 0
     liver enzymes | 0
     bilirubin | 0
     albumin | 0
     gamma-globulin | 0
     prothrombin index | 0
     liver deterioration | 0
     thymol test | 0
     liver dysfunction | 0
     white blood cell count | 0
     erythrocyte sedimentation rate | 0
     C-reactive protein | 0
     liver function | 0
     liver failure | 0
     liver damage | 0
     liver cirrhosis | 0
     portal hypertension | 0
     portosystemic collateral channels | 0
     abdominal wall collateral veins | 0
     intrahepatic resistance | 0
     portal blood flow | 0
     hepatic architectural changes | 0
     regenerative nodules | 0
     fibrotic septa | 0
     liver resistance | 0
     hepatic metaplasia | 0
     fibrosis | 0
     nodules | 0
     portal pressure gradient | 0
     insulin resistance | 0
     hyperinsulinemia | 0
     metabolic syndrome | 0
     viral etiologies | 0
     alcoholic liver cirrhosis | 0
     diabetes mellitus | 0
     clinical interaction | 0
     liver function tests | 0
     liver enzymes | 0
     bilirubin | 0
     albumin | 0
     gamma-globulin | 0
     prothrombin index | 0
     liver deterioration | 0
     thymol test | 0
     liver dysfunction | 0
     white blood cell count | 0
     erythrocyte sedimentation rate | 0
     C-reactive protein | 0
     liver function | 0
     liver failure | 0
     liver damage | 0
     liver cirrhosis | 0
     portal hypertension | 0
     portosystemic collateral channels | 0
     abdominal wall collateral veins | 0
     intrahepatic resistance | 0
     portal blood flow | 0
     hepatic architectural changes | 0
     regenerative nodules | 0
     fibrotic septa | 0
     liver resistance | 0
     hepatic metaplasia | 0
     fibrosis | 0
     nodules | 0
     portal pressure gradient | 0
     insulin resistance | 0
     hyperinsulinemia | 0
     metabolic syndrome | 0
     viral etiologies | 0
     alcoholic liver cirrhosis | 0
     diabetes mellitus | 0
     clinical interaction | 0
     liver function tests | 0
     liver enzymes | 0
     bilirubin | 0
     albumin | 0
     gamma-globulin | 0
     prothrombin index | 0
     liver deterioration | 0
     thymol test | 0
     liver dysfunction | 0
     white blood cell count | 0
     erythrocyte sedimentation rate | 0
     C-reactive protein | 0
     liver function | 0
     liver failure | 0
     liver damage | 0
     liver cirrhosis | 0
     portal hypertension | 0
     portosystemic collateral channels | 0
     abdominal wall collateral veins | 0
     intrahepatic resistance | 0
     portal blood flow | 0
     hepatic architectural changes | 0
     regenerative nodules | 0
     fibrotic septa | 0
     liver resistance | 0
     hepatic metaplasia | 0
     fibrosis | 0
     nodules | 0
     portal pressure gradient | 0
     insulin resistance | 0
     hyperinsulinemia | 0
     metabolic syndrome | 0
     viral etiologies | 0
     alcoholic liver cirrhosis | 0
     diabetes mellitus | 0
     clinical interaction | 0
     liver function tests | 0
     liver enzymes | 0
     bilirubin | 0
     albumin | 0
     gamma-globulin | 0
     prothrombin index | 0
     liver deterioration | 0
     thymol test | 0
     liver dysfunction | 0
     white blood cell count | 0
     erythrocyte sedimentation rate | 0
     C-reactive protein | 0
     liver function | 0
     liver failure | 0
     liver damage | 0
     liver cirrhosis | 0
     portal hypertension | 0
     portosystemic collateral channels | 0
     abdominal wall collateral veins | 0
     intrahepatic resistance | 0
     portal blood flow | 0
     hepatic architectural changes | 0
     regenerative nodules | 0
     fibrotic septa | 0
     liver resistance | 0
     hepatic metaplasia | 0
     fibrosis | 0
     nodules | 0
     portal pressure gradient | 0
     insulin resistance | 0
     hyperinsulinemia | 0
     metabolic syndrome | 0
     viral etiologies | 0
     alcoholic liver cirrhosis | 0
     diabetes mellitus | 0
     clinical interaction | 0
     liver function tests | 0
     liver enzymes | 0
     bilirubin | 0
     albumin | 0
     gamma-globulin | 0
     prothrombin index | 0
     liver deterioration | 0
     thymol test | 0
     liver dysfunction | 0
     white blood cell count | 0
     erythrocyte sedimentation rate | 0
     C-reactive protein | 0
     liver function | 0
     liver failure | 0
     liver damage | 0
     liver cirrhosis | 0
     portal hypertension | 0
     portosystemic collateral channels | 0
     abdominal wall collateral veins | 0
     intrahepatic resistance | 0
     portal blood flow | 0
     hepatic architectural changes | 0
     regenerative nodules | 0
     fibrotic septa | 0
     liver resistance | 0
     hepatic metaplasia | 0
     fibrosis | 0
     nodules | 0
     portal pressure gradient | 0
     insulin resistance | 0
     hyperinsulinemia | 0
     metabolic syndrome | 0
     viral etiologies | 0
     alcoholic liver cirrhosis | 0
     diabetes mellitus | 0
     clinical interaction | 0
     liver function tests | 0
     liver enzymes | 0
     bilirubin | 0
     albumin | 0
     gamma-globulin | 0
     prothrombin index | 0
     liver deterioration | 0
     thymol test | 0
     liver dysfunction | 0
     white blood cell count | 0
     erythrocyte sedimentation rate | 0
     C-reactive protein | 0
     liver function | 0
     liver failure | 0
     liver damage | 0
     liver cirrhosis | 0
     portal hypertension | 0
     portosystemic collateral channels | 0
     abdominal wall collateral veins | 0
     intrahepatic resistance | 0
     portal blood flow | 0
     hepatic architectural changes | 0
     regenerative nodules | 0
     fibrotic septa | 0
     liver resistance | 0
     hepatic metaplasia | 0
     fibrosis | 0
     nodules | 0
     portal pressure gradient | 0
     insulin resistance | 0
     hyperinsulinemia | 0
     metabolic syndrome | 0
     viral etiologies | 0
     alcoholic liver cirrhosis | 0
     diabetes mellitus | 0
     clinical interaction | 0
     liver function tests | 0
     liver enzymes | 0
     bilirubin | 0
     albumin | 0
     gamma-globulin | 0
     prothrombin index | 0
     liver deterioration | 0
     thymol test | 0
     liver dysfunction | 0
     white blood cell count | 0
     erythrocyte sedimentation rate | 0
     C-reactive protein | 0
     liver function | 0
     liver failure | 0
     liver damage | 0
     liver cirrhosis | 0
     portal hypertension | 0
     portosystemic collateral channels | 0
     abdominal wall collateral veins | 0
     intrahepatic resistance | 0
     portal blood flow | 0
     hepatic architectural changes | 0
     regenerative nodules | 0
     fibrotic septa | 0
     liver resistance | 0
     hepatic metaplasia | 0
     fibrosis | 0
     nodules | 0
     portal pressure gradient | 0
     insulin resistance | 0
     hyperinsulinemia | 0
     metabolic syndrome | 0
     viral etiologies | 0
     alcoholic liver cirrhosis | 0
     diabetes mellitus | 0
     clinical interaction | 0
     liver function tests | 0
     liver enzymes | 0
     bilirubin | 0
     albumin | 0
     gamma-globulin | 0
     prothrombin index | 0
     liver deterioration | 0
     thymol test | 0
     liver dysfunction | 0
     white blood cell count | 0
     erythrocyte sedimentation rate | 0
     C-reactive protein | 0
     liver function | 0
     liver failure | 0
     liver damage | 0
     liver cirrhosis | 0
     portal hypertension | 0
     portosystemic collateral channels | 0
     abdominal wall collateral veins | 0
     intrahepatic resistance | 0
     portal blood flow | 0
     hepatic architectural changes | 0
     regenerative nodules | 0
     fibrotic septa | 0
     liver resistance | 0
     hepatic metaplasia | 0
     fibrosis | 0
     nodules | 0
     portal pressure gradient | 0
     insulin resistance | 0
     hyperinsulinemia | 0
     metabolic syndrome | 0
     viral etiologies | 0
     alcoholic liver cirrhosis | 0
     diabetes mellitus | 0
     clinical interaction | 0
     liver function tests | 0
     liver enzymes | 0
     bilirubin | 0
     albumin | 0
     gamma-globulin | 0
     prothrombin index | 0
     liver deterioration | 0
     thymol test | 0
     liver dysfunction | 0
     white blood cell count | 0
     erythrocyte sedimentation rate | 0
     C-reactive protein | 0
     liver function | 0
     liver failure | 0
     liver damage | 0
     liver cirrhosis | 0
     portal hypertension | 0
     portosystemic collateral channels | 0
     abdominal wall collateral veins | 0
     intrahepatic resistance | 0
     portal blood flow | 0
     hepatic architectural changes | 0
     regenerative nodules | 0
     fibrotic septa | 0
     liver resistance | 0
     hepatic metaplasia | 0
     fibrosis | 0
     nodules | 0
     portal pressure gradient | 0
     insulin resistance | 0
     hyperinsulinemia | 0
     metabolic syndrome | 0
     viral etiologies | 0
     alcoholic liver cirrhosis | 0
     diabetes mellitus | 0
     clinical interaction | 0
     liver function tests | 0
     liver enzymes | 0
     bilirubin | 0
     albumin | 0
     gamma-globulin | 0
     prothrombin index | 0
     liver deterioration | 0
     thymol test | 0
     liver dysfunction | 0
     white blood cell count | 0
     erythrocyte sedimentation rate | 0
     C-reactive protein | 0
     liver function | 0
     liver failure | 0
     liver damage | 0
     liver cirrhosis | 0
     portal hypertension | 0
     portosystemic collateral channels | 0
     abdominal wall collateral veins | 0
     intrahepatic resistance | 0
     portal blood flow | 0
     hepatic architectural changes | 0
     regenerative nodules | 0
     fibrotic septa | 0
     liver resistance | 0
     hepatic metaplasia | 0
     fibrosis | 0
     nodules | 0
     portal pressure gradient | 0
     insulin resistance | 0
     hyperinsulinemia | 0
     metabolic syndrome | 0
     viral etiologies | 0
     alcoholic liver cirrhosis | 0
     diabetes mellitus | 0
     clinical interaction | 0
     liver function tests | 0
     liver enzymes | 0
     bilirubin | 0
     albumin | 0
     gamma-globulin | 0
     prothrombin index | 0
     liver deterioration | 0
     thymol test | 0
     liver dysfunction | 0
     white blood cell count | 0
     erythrocyte sedimentation rate | 0
     C-reactive protein | 0
     liver function | 0
     liver failure | 0
     liver damage | 0
     liver cirrhosis | 0
     portal hypertension | 0
     portosystemic collateral channels | 0
     abdominal wall collateral veins | 0
     intrahepatic resistance | 0
     portal blood flow | 0
     hepatic architectural changes | 0
     regenerative nodules | 0
     fibrotic septa | 0
     liver resistance | 0
     hepatic metaplasia | 0
     fibrosis | 0
     nodules | 0
     portal pressure gradient | 0
     insulin resistance | 0
     hyperinsulinemia | 0
     metabolic syndrome | 0
     viral etiologies | 0
     alcoholic liver cirrhosis | 0
     diabetes mellitus | 0
     clinical interaction | 0
     liver function tests | 0
     liver enzymes | 0
     bilirubin | 0
     albumin | 0
     gamma-globulin | 0
     prothrombin index | 0
     liver deterioration | 0
     thymol test | 0
     liver dysfunction | 0
     white blood cell count | 0
     erythrocyte sedimentation rate | 0
     C-reactive protein | 0
     liver function | 0
     liver failure | 0
     liver damage | 0
     liver cirrhosis | 0
     portal hypertension | 0
     portosystemic collateral channels | 0
     abdominal wall collateral veins | 0
     intrahepatic resistance | 0
     portal blood flow | 0
     hepatic architectural changes | 0
     regenerative nodules | 0
     fibrotic septa | 0
     liver resistance | 0
     hepatic metaplasia | 0
     fibrosis | 0
     nodules | 0
     portal pressure gradient | 0
     insulin resistance | 0
     hyperinsulinemia | 0
     metabolic syndrome | 0
     viral etiologies | 0
     alcoholic liver cirrhosis | 0
     diabetes mellitus | 0
     clinical interaction | 0
     liver function tests | 0
     liver enzymes | 0
     bilirubin | 0
     albumin | 0
     gamma-globulin | 0
     prothrombin index | 0
     liver deterioration | 0
     thymol test | 0
     liver dysfunction | 0
     white blood cell count | 0
     erythrocyte sedimentation rate | 0
     C-reactive protein | 0
     liver function | 0
     liver failure | 0
     liver damage | 0
     liver cirrhosis | 0
     portal hypertension | 0
     portosystemic collateral channels | 0
     abdominal wall collateral veins | 0
     intrahepatic resistance | 0
     portal blood flow | 0
     hepatic architectural changes | 0
     regenerative nodules | 0
     fibrotic septa | 0
     liver resistance | 0
     hepatic metaplasia | 0
     fibrosis | 0
     nodules | 0
     portal pressure gradient | 0
     insulin resistance | 0
     hyperinsulinemia | 0
     metabolic syndrome | 0
     viral etiologies | 0
     alcoholic liver cirrhosis | 0
     diabetes mellitus | 0
     clinical interaction | 0
     liver function tests | 0
     liver enzymes | 0
     bilirubin | 0
     albumin | 0
     gamma-globulin | 0
     prothrombin index | 0
     liver deterioration | 0
     thymol test | 0
     liver dysfunction | 0
     white blood cell count | 0
     erythrocyte sedimentation rate | 0
     C-reactive protein | 0
     liver function | 0
     liver failure | 0
     liver damage | 0
     liver cirrhosis | 0
     portal hypertension | 0
     portosystemic collateral channels | 0
     abdominal wall collateral veins | 0
     intrahepatic resistance | 0
     portal blood flow | 0
     hepatic architectural changes | 0
     regenerative nodules | 0
     fibrotic septa | 0
     liver resistance | 0
     hepatic metaplasia | 0
     fibrosis | 0
     nodules | 0
     portal pressure gradient | 0
     insulin resistance | 0
     hyperinsulinemia | 0
     metabolic syndrome | 0
     viral etiologies | 0
     alcoholic liver cirrhosis | 0
     diabetes mellitus | 0
     clinical interaction | 0
     liver function tests | 0
     liver enzymes | 0
     bilirubin | 0
     albumin | 0
     gamma-globulin | 0
     prothrombin index | 0
     liver deterioration | 0
     thymol test | 0
     liver dysfunction | 0
     white blood cell count | 0
     erythrocyte sedimentation rate | 0
     C-reactive protein | 0
     liver function | 0
     liver failure | 0
     liver damage | 0
     liver cirrhosis | 0
     portal hypertension | 0
     portosystemic collateral channels | 0
     abdominal wall collateral veins | 0
     intrahepatic resistance | 0
     portal blood flow | 0
     hepatic architectural changes | 0
     regenerative nodules | 0
     fibrotic septa | 0
     liver resistance | 0
     hepatic metaplasia | 0
     fibrosis | 0
     nodules | 0
     portal pressure gradient | 0
     insulin resistance | 0
     hyperinsulinemia | 0
     metabolic syndrome | 0
     viral etiologies | 0
     alcoholic liver cirrhosis | 0
     diabetes mellitus | 0
     clinical interaction | 0
     liver function tests | 0
     liver enzymes | 0
     bilirubin | 0
     albumin | 0
     gamma-globulin | 0
     prothrombin index | 0
     liver deterioration | 0
     thymol test | 0
     liver dysfunction | 0
     white blood cell count | 0
     erythrocyte sedimentation rate | 0
     C-reactive protein | 0
     liver function | 0
     liver failure | 0
     liver damage | 0
     liver cirrhosis | 0
     portal hypertension | 0
     portosystemic collateral channels | 0
     abdominal wall collateral veins | 0
     intrahepatic resistance | 0
     portal blood flow | 0
     hepatic architectural changes | 0
     regenerative nodules | 0
     fibrotic septa | 0
     liver resistance | 0
     hepatic metaplasia | 0
     fibrosis | 0
     nodules | 0
     portal pressure gradient | 0
     insulin resistance | 0
     hyperinsulinemia | 0
     metabolic syndrome | 0
     viral etiologies | 0
     alcoholic liver cirrhosis | 0
     diabetes mellitus | 0
     clinical interaction | 0
     liver function tests | 0
     liver enzymes | 0
     bilirubin | 0
     albumin | 0
     gamma-globulin | 0
     prothrombin index | 0
     liver deterioration | 0
     thymol test | 0
     liver dysfunction | 0
     white blood cell count | 0
     erythrocyte sedimentation rate | 0
     C-reactive protein | 0
     liver function | 0
     liver failure | 0
     liver damage | 0
     liver cirrhosis | 0
     portal hypertension | 0
     portosystemic collateral channels | 0
     abdominal wall collateral veins | 0
     intrahepatic resistance | 0
     portal blood flow | 0
     hepatic architectural changes | 0
     regenerative nodules | 0
     fibrotic septa | 0
     liver resistance | 0
     hepatic metaplasia | 0
     fibrosis | 0
     nodules | 0
     portal pressure gradient | 0
     insulin resistance | 0
     hyperinsulinemia | 0
     metabolic syndrome | 0
     viral etiologies | 0
     alcoholic liver cirrhosis | 0
     diabetes mellitus | 0
     clinical interaction | 0
     liver function tests | 0
     liver enzymes | 0
     bilirubin | 0
     albumin | 0
     gamma-globulin | 0
     prothrombin index | 0
     liver deterioration | 0
     thymol test | 0
     liver dysfunction | 0
     white blood cell count | 0
     erythrocyte sedimentation rate | 0
     C-reactive protein | 0
     liver function | 0
     liver failure | 0
     liver damage | 0
     liver cirrhosis | 0
     portal hypertension | 0
     portosystemic collateral channels | 0
     abdominal wall collateral veins | 0
     intrahepatic resistance | 0
     portal blood flow | 0
     hepatic architectural changes | 0
     regenerative nodules | 0
     fibrotic septa | 0
     liver resistance | 0
     hepatic metaplasia | 0
     fibrosis | 0
     nodules | 0
     portal pressure gradient | 0
     insulin resistance | 0
     hyperinsulinemia | 0
     metabolic syndrome | 0
     viral etiologies | 0
     alcoholic liver cirrhosis | 0
     diabetes mellitus | 