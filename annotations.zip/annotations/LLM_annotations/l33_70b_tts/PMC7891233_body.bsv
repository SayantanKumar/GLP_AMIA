 80 years old | 0
     male | 0
     admitted to the hospital | 0
     dyspnoea | 0
     oedema | 0
     weight gain | 0
     smoking | -8760
     diabetes mellitus | -8760
     hypertension | -8760
     colon carcinoma | -62280
     prostate carcinoma | -43800
     bumetanide | 0
     darbepoetin alfa | 0
     insulin degludec/liraglutide | 0
     irbesartan | 0
     nifedipine | 0
     omeprazole | 0
     pregabalin | 0
     tamsulosin | 0
     atrial fibrillation | 0
     normocytic anaemia | 0
     elevated D-dimer levels | 0
     elevated gamma-glutamyl transferase | 0
     decreased renal function | 0
     transthoracic echocardiogram | 0
     IVCT | 0
     anticoagulant therapy with tinzaparin | 0
     computed tomography scan of the abdomen | 24
     mass in the right kidney | 24
     suspect for renal cell carcinoma | 24
     computed tomography scan of the thorax | 72
     no metastases | 72
     multidisciplinary consultation | 72
     clinical condition too poor for surgery | 72
     plan biopsy | 72
     neo-adjuvant chemotherapy | 72
     switch to heparin intravenous | 96
     inadequate anti-Xa level | 96
     progressive kidney failure | 168
     congestion | 168
     start of palliative care | 216
     deceased | 288