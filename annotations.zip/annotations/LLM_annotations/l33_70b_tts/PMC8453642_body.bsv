 51 years old | 0
     female | 0
     Hashimoto’s disease | -8760
     chronic urticaria | -8760
     mast cell activation disorder | -8760
     hypertension | -8760
     diabetes mellitus type 2 | -8760
     metformin | -8760
     liraglutide | -8760
     recurrent hives | 0
     skin dryness | 0
     fatigue | 0
     weight gain | 0
     intermittent constipation | 0
     diarrhea | 0
     cold intolerance | 0
     brain fog | 0
     difficulty with word finding | 0
     swelling in lower extremities | 0
     daytime somnolence | 0
     multiple chemical sensitivities | 0
     food allergies | 0
     medication sensitivities | 0
     reactions to food dyes and additives | 0
     temperature 36.6°C | 0
     pulse 92 beats per minute | 0
     blood pressure 136/88 mmHg | 0
     respiratory rate 18 respirations per minute | 0
     O2 saturation 98% | 0
     height 1.57 m | 0
     weight 92 kg | 0
     body mass index 37.3 kg/m2 | 0
     hypoactive bowel sounds | 0
     minimal tenderness to palpation in left lower quadrant | 0
     family history of papillary thyroid cancer | 0
     bilateral nodules biopsied and found to be benign | 0
     L-T4 sodium tablets | -24
     discontinued metformin | -24
     TSH 5.30 | 0
     free T4 16.60 | 0
     free T3 not evaluated | 0
     upper endoscopy | 24
     gastritis | 24
     hiatal hernia | 24
     gastric emptying examination | 24
     20% gastric retention at 4 hours | 24
     gastroparesis | 24
     high-dose probiotics | 24
     dicyclomine hydrochloride | 24
     gastroparesis diet | 24
     rifaximin | 168
     SIBO | 168
     L-T4 oral solution 150 µg | 168
     TSH 1.55 | 168
     free T4 27.93 | 168
     free T3 4.93 | 168
     L-T4 oral solution down-titrated to 112 µg | 336
     TSH 1.95 | 336
     free T4 20.33 | 336
     free T3 4.77 | 336