 34 years old | 0
     female | 0
     abdominal obesity | -8760
     diabetes mellitus | -8760
     hypertriglyceridemia | -8760
     loss of s.c. fat on the extremities | 0
     increased fat mass around abdomen | 0
     bulging musculature | 0
     prominent veins on the upper and lower extremities | 0
     blood pressure 125/80 mmHg | 0
     HbA1c 73 mmol/mol Hb | 0
     hypertriglyceridemia | 0
     hepatomegaly | 0
     MeSH | 0
     stress eating | 0
     sweet eating | 0
     abnormal quantities of eating | 0
     reduced feeling of satiety | 0
     allergy against disinfectants | -8760
     family history of diabetes mellitus | -8760
     family history of myocardial infarction | -8760
     metformin 1000 mg twice daily | 0
     insulin glargine once daily 30 IU | 0
     simvastatin 40 mg once daily | 0
     oral contraception | 0
     PPARG c.485T>G variant | 0
     semaglutide | 24
     dapagliflozin | 24
     gemfibrozil | 24
     omega-3 fatty acids | 24
     leptin replacement therapy | 168
     metreleptin 5 mg once daily | 168
     allergic reactions at the injection sites | 168
     anti-histaminic local skin therapy | 168
     weight loss of 7 kg | 7440
     improved satiety feeling | 7440
     triglyceride levels dropped to normal range | 7440
     insulin glargine stopped | 7440
     leptin concentration increased to normal range | 7440
     GPT levels increased | 7440