 male | 0
     35 years old | 0
     obesity | 0
     T2D | 0
     dyslipidemia | 0
     gliclazide | -8760
     linagliptin | -8760
     metformin | -8760
     canagliflozin | -8760
     rosuvastatin | -8760
     Degludec insulin | -6300
     liraglutide | -8760
     HbA1c 10.1% | 0
     weight 98 kg | 0
     height 180 cm | 0
     BMI 30.2 kg/m2 | 0
     waist circumference 112 cm | 0
     physical examination | 0
     no significant alterations | 0
     VLCKD | 0
     discontinuation of medications | 0
     continuous glucose monitoring system | 0
     fasting glucose 132 mg/dL | 0
     creatinine 0.8 mg/dL | 0
     uric acid 6.2 mg/dL | 0
     AST 55 U/L | 0
     GGT 90 U/L | 0
     total cholesterol 132 mg/dL | 0
     triglycerides 81 mg/dL | 0
     HDL 43 mg/dL | 0
     LDL 73 mg/dL | 0
     TSH 1.11 mIU/L | 0
     C-peptide 4.83 ng/mL | 0
     microalbuminuria 89.6 mg/24 h | 0
     moderate hepatic steatosis | 0
     PnK method | 0
     weight loss 20 kg | 72
     weight normalization | 72
     diabetes remission | 72
     improvement in hepatic function | 72
     microalbuminuria normalization | 72
     remission of steatosis | 730
     weight 90 kg | 720
     weight 82 kg | 1440
     weight 78 kg | 2160
     weight 79 kg | 8760
     weight 80 kg | 17520
     BMI 27.8 kg/m2 | 720
     BMI 25.3 kg/m2 | 1440
     BMI 24.1 kg/m2 | 2160
     BMI 24.4 kg/m2 | 8760
     BMI 24.7 kg/m2 | 17520
     fasting glucose 126 mg/dL | 720
     fasting glucose 92 mg/dL | 1440
     fasting glucose 77 mg/dL | 2160
     fasting glucose 91 mg/dL | 8760
     fasting glucose 86 mg/dL | 17520
     HbA1c 8.1% | 720
     HbA1c 6.8% | 1440
     HbA1c 5.3% | 2160
     HbA1c 5.4% | 8760
     HbA1c 5.2% | 17520
     uric acid 5.4 mg/dL | 720
     uric acid 4.4 mg/dL | 1440
     uric acid 4.3 mg/dL | 2160
     uric acid 4.4 mg/dL | 8760
     uric acid 4.9 mg/dL | 17520
     creatinine 0.9 mg/dL | 720
     creatinine 0.7 mg/dL | 1440
     creatinine 0.7 mg/dL | 2160
     creatinine 0.9 mg/dL | 8760
     creatinine 1.0 mg/dL | 17520
     AST 37 U/L | 720
     AST 37 U/L | 1440
     AST 32 U/L | 2160
     AST 27 U/L | 8760
     AST 34 U/L | 17520
     GGT 43 U/L | 720
     GGT 45 U/L | 1440
     GGT 24 U/L | 2160
     GGT 19 U/L | 8760
     GGT 12 U/L | 17520
     total cholesterol 145 mg/dL | 720
     total cholesterol 153 mg/dL | 1440
     total cholesterol 145 mg/dL | 8760
     total cholesterol 142 mg/dL | 17520
     triglycerides 114 mg/dL | 720
     triglycerides 90 mg/dL | 2160
     triglycerides 130 mg/dL | 8760
     triglycerides 80 mg/dL | 17520
     HDL 51 mg/dL | 720
     HDL 51 mg/dL | 2160
     HDL 44 mg/dL | 8760
     HDL 44 mg/dL | 17520
     LDL 71 mg/dL | 720
     LDL 84 mg/dL | 2160
     LDL 75 mg/dL | 8760
     LDL 82 mg/dL | 17520
     microalbuminuria 28.0 mg/24 h | 2160
     microalbuminuria 25.2 mg/24 h | 8760
     microalbuminuria 22.3 mg/24 h | 17520