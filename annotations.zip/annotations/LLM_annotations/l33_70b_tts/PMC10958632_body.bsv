 33 years old | 0
     female | 0
     end-stage kidney disease | 0
     referred for diabetes management | 0
     developed diabetes | -1095
     A1C of 9.1% | -1095
     body mass index of 31 kg/m2 | -1095
     kidney transplant | -2925
     glucose levels normal | -2925
     glucose levels increasing | -730
     negative anti-GAD65 antibodies | 0
     negative antipancreatic islet cell antibodies | 0
     C-peptide 2.9 ng/mL on fasting | 0
     C-peptide 5.2 ng/mL on random check | 0
     denied family history of diabetes | 0
     denied family history of renal disease | 0
     glucose control improved | 0
     diet | 0
     exercise | 0
     administration of glucagon-like peptide-1 agonist | 0
     low doses of insulin | 0
     progressive loss of kidney function | -2925
     pretransplant imaging | -2925
     bilateral renal cysts | -2925
     atrophic left kidney | -2925
     imaging at 31 years | -730
     scarred native kidneys | -730
     atrophy of pancreas | -730
     serial sweeping transvaginal ultrasound | 0
     normal uterine body | 0
     uninterrupted endometrial stripe | 0
     abnormal fundal arcuate contour | 0
     interrupted endometrial stripe | 0
     HNF1β-associated disease diagnosed | 0
     genetic testing | 0
     complete deletion of HNF1β gene | 0
     congenital kidney disease | -2925
     onset of diabetes mellitus | -1095
     pancreatic hypoplasia | -1095
     genital tract malformations | 0
     abnormal liver function tests | 0
     hypomagnesemia | 0
     hyperuricemia | 0
     early onset gout | 0
     secondary hyperparathyroidism | 0
     neurologic features | 0