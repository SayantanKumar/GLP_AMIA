 51 years old | 0
     Asian | 0
     male | 0
     hypertension | -8760
     hyperlipidemia | -8760
     T2DM | -8760
     nonalcoholic fatty liver disease | -8760
     chronic kidney disease stage 3a | -8760
     pitavastatin | -8760
     losartan | -8760
     insulin | -8760
     oral semaglutide 3 mg daily | -30
     increased semaglutide to 7 mg | -30
     liver tests showed increase in ALP, ALT, and AST | -3
     abdominal discomfort | 182
     new-onset jaundice | 182
     nausea | 182
     vomiting | 182
     diarrhea | 182
     weakness | 182
     ibuprofen 400 mg twice daily | 130
     afebrile | 182
     tachycardic | 182
     blood pressures of 90s/60s mm Hg | 182
     scleral icterus | 182
     dry oral mucosa | 182
     blood urea nitrogen of 58 mg/dL | 182
     creatinine of 2.89 mg/dL | 182
     worsening liver tests | 182
     coagulation tests normal | 182
     alpha-fetoprotein normal | 182
     imaging with magnetic resonance with cholangiogram normal | 182
     negative serologies for autoimmune and viral hepatitis | 182
     COVID-19 negative | 182
     discharged home | 210
     repeat imaging | 300
     endoscopic retrograde cholangiopancreatogram | 300
     liver biopsies | 365
     histology showing marked and diffuse bile duct injury | 365
     cholestatic gene panel showed heterozygosity for ABCC2 and DHCR7 | 365
     renal biopsy showed chronic active interstitial nephritis | 400
     hemodialysis | 500
     ursodiol | 500
     budesonide | 500
     mycophenolate mofetil | 500
     rapamycin | 500
     no improvement in liver or kidney function | 550
     simultaneous liver and kidney transplantation | 600
     liver explant revealed cirrhosis with marked ductular reaction, cholestasis, and bile infarcts | 600