 50 years old | 0
     female | 0
     Caucasian | 0
     obesity | -132 
     psoriasis | -6336
     smoking never | 0
     T2D | 0
     abdominal obesity | 0
     low cardiovascular risk | 0
     semaglutide therapy | 0
     lifestyle modification | 0
     ixekizumab | -36
     allergic reaction | -8
     secukinumab | -24
     guselkumab | -12
     biologic therapies | -12
     topical steroids | -12
     glycated hemoglobin | 0
     waist circumference | 0
     BMI | 0
     coronary CT angiography | 0
     EAT density | 0
     PCAT density | 0
     coronary calcium content | 0
     psoriasis area and severity index | 0
     dermatology life quality index | 0
     disease activity index for psoriatic arthritis | 0
     semaglutide dose 0.25 mg | 0
     semaglutide dose 0.50 mg | 16
     semaglutide dose 1 mg | 112
     PASI improved | 112
     quality of life improved | 112
     HbA1c reduced | 112
     waist circumference reduced | 112
     CT-EAT attenuation reduced | 224
     CT-PCAT attenuation reduced | 224
     SAT attenuation unchanged | 224
     CT-EAT volume decreased | 224
     CAC score unchanged | 224
     psoriasis skin lesions improved | 224
     PASI decreased | 224
     DLQI decreased | 224
     DAPSA decreased | 224
     HbA1c normalized | 224
     weight loss | 224
     IL-6 reduced | 224
     CRP reduced | 224