 66 years old | 0
     female | 0
     hirsutism | -8760
     menopause | -6840
     abdominal obesity | -8760
     hypertension | -8760
     atherogenic dyslipidemia | -8760
     type 2 diabetes | -8760
     metformin | -8760
     semaglutide | -8760
     basal insulin | -8760
     angiotensin-receptor blocker | -8760
     calcium-channel blocker | -8760
     furosemide | -8760
     omega-3-acid ethyl esters | -8760
     ezetimibe | -8760
     rosuvastatin | -8760
     gestational diabetes | -19080
     carbohydrates restriction | -19080
     weight control | -19080
     alopecia | 0
     excess terminal hairs | 0
     clitoromegaly | 0
     cushingoid features | 0
     virilization | 0
     Ferriman-Gallwey score | 0
     body mass index | 0
     arterial blood pressure | 0
     total testosterone | 0
     dehydroepiandrosterone sulfate | 0
     delta4-androstenedione | 0
     adrenocorticotropic hormone | 0
     cortisol | 0
     chromogranin A | 0
     ovarian tumor biomarkers | 0
     glycated hemoglobin | 0
     estimated glomerular filtration rate | 0
     transvaginal ultrasound | 0
     color Doppler analysis | 0
     abdominal magnetic resonance imaging | 24
     gynecology consultation | 48
     laparoscopic bilateral salpingo-oophorectomy | 72
     luteinized thecoma | 72
     hirsutism improvement | 168
     biochemical hyperandrogenism resolution | 216
     body weight improvement | 216
     glucometabolic profile improvement | 216
     follow-up | 432
     weight | 0
     height | 0
     systolic blood pressure | 0
     diastolic blood pressure | 0
     hemoglobin | 0
     creatinine | 0
     glucose | 0
     HbA1c | 0
     total cholesterol | 0
     HDL cholesterol | 0
     LDL cholesterol | 0
     triglycerides | 0
     AST | 0
     ALT | 0
     GGT | 0