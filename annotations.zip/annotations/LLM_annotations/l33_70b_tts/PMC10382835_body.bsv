 55 years old | 0
     female | 0
     nulliparous | 0
     uterine fibroids | 0
     hypertension | 0
     insulin resistance | 0
     vaginal bleeding | -156
     BMI 80 kg/m2 | -156
     trans-vaginal pelvic ultrasound | -156
     endometrial thickness 44 mm | -156
     hysteroscopy | -156
     endometrial biopsy | -156
     levonorgestrel IUD insertion | -156
     atypical endometrial hyperplasia | -156
     weight loss program | -156
     dietician | -156
     exercise programs | -156
     weight plateaued at 195 kg | -12
     BMI 68 kg/m2 | -12
     repeat endometrial biopsy | 0
     grade 1 EAC of the uterus | 0
     strong estrogen receptor positivity | 0
     strong progesterone receptor positivity | 0
     loss of MLH1 and PMS2 | 0
     CT scan of chest, abdomen and pelvis | 0
     no metastatic disease | 0
     medroxyprogesterone 100 mg oral twice daily | 0
     Liraglutide | 12
     Metformin | 12
     weight decreased to 180 kg | 12
     repeat curettage | 12
     regression to atypical endometrial hyperplasia | 12
     medroxyprogesterone increased to 200 mg oral twice daily | 12
     blood-stained fluid discharge from umbilicus | 18
     CT scan of abdomen and pelvis | 18
     umbilical soft tissue mass | 18
     core biopsy of umbilical lesion | 18
     FIGO grade 1 EAC | 18
     ER and PR strongly positive | 18
     loss of MLH1 and PMS2 | 18
     PET scan | 18
     increased uptake in uterus, umbilicus, left parametrial lymph node and right inguinal node | 18
     CA-125 raised at 420 U/mL | 18
     diagnostic laparoscopy | 18
     no widespread peritoneal disease | 18
     systemic therapy with letrozole | 18
     disease progression after three months | 21
     changed to Carboplatin-Paclitaxel combination chemotherapy | 21
     immunotherapy with check-point inhibitor | 21
     not affordable for the patient | 21
     neoadjuvant chemotherapy | 24
     CA-125 level reduced to 50 U/mL | 24
     weight 157 kg | 24
     BMI 54.3 kg/m2 | 24
     repeat CT scan | 24
     increase in umbilical soft tissue mass | 24
     no new sites of disease | 24
     asymptomatic pulmonary embolism | 24
     treated with Apixaban for 12 weeks | 24
     cytoreductive surgery | 30
     robotic total hysterectomy | 30
     BSO | 30
     right inguinal lymph node resection | 30
     resection of umbilical mass | 30
     primary abdominal wall closure | 30
     infected abdominal wall seroma | 30
     Clavien Dindo grade 2 adverse event | 30
     prolonged drainage and systemic then oral antibiotics | 30
     final histopathological assessment | 30
     dedifferentiated endometrial carcinoma | 30
     loss of SMARCA4 | 30
     further 3 cycles of Carboplatin-Paclitaxel combination chemotherapy | 30
     external beam radiation to right inguinal region | 30
     germline testing negative for Lynch syndrome | 30
     routine CT scan chest abdomen and pelvis | 33
     progressive disease in peritoneum and retroperitoneal lymph nodes | 33
     referred for consideration of clinical trial with immune check-point inhibitor | 33
     alive at 14 months since diagnosis of umbilical metastatic disease | 42
     alive at 7 months since cytoreductive surgery | 37