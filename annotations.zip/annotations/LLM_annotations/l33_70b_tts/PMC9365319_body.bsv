 35 years old | 0
     female | 0
     T2DM | -4380
     body weight 87 kg | 0
     body mass index 31 kg/m2 | 0
     liraglutide | -8760
     metformin | -8760
     poor blood glucose | 0
     glycated hemoglobin 8.8% | 0
     hypertension | 0
     dyslipidemia | 0
     hyperuricemia | 0
     non-alcoholic fatty liver disease | 0
     insulin release test | 0
     delayed insulin secretion | 0
     no insulin deficiency | 0
     pancreatic islet autoantibodies negative | 0
     father diagnosed with T2DM | 0
     laparoscopic sleeve gastrectomy | 0
     metformin discontinued | -24
     short-acting recombinant human insulin | 0
     perioperative hyperglycaemia | 0
     short-acting recombinant human insulin discontinued | 0
     blood glucose level fluctuated | 24
     degludec insulin | 24
     metformin | 24
     dulaglutide | 24
     sipping water | 24
     enteral nutritional suspension | 24
     bloated | 48
     full | 48
     total daily fluid intake 800-1000 mL | 48
     total daily calorie intake less than 500 kcal | 48
     abdominal CT | 48
     no abnormal signs | 48
     lost 5 kg | 120
     fasting blood glucose levels 7-8 mmol/L | 120
     postprandial blood glucose levels 8-12 mmol/L | 120
     fatigue | 144
     sweating | 144
     nausea | 144
     vomiting 30 times | 144
     metabolic acidosis | 144
     blood sugar level 16.1 mmol/L | 144
     urine ketone over 4+ | 144
     glucose over 4+ | 144
     fluid resuscitation | 144
     glucose | 144
     insulin | 144
     degludec insulin discontinued | 144
     metformin discontinued | 144
     dulaglutide discontinued | 144
     crystalloid fluid plus water intake more than 4000 mL | 144
     recombinant human insulin | 144
     general state improved | 192
     no nausea | 192
     no vomiting | 192
     ketones in urine negative | 192
     random blood glucose level less than 11.1 mmol/L | 192
     insulin discontinued | 192
     fluid infusion discontinued | 192
     discharged | 240