 36 years old | 0
     male | 0
     admitted to the hospital | 0
     type 2 diabetes mellitus | -2520
     treated with liraglutide | -2520
     glycohemoglobin (HbA1c) levels 9-13% | -0
     chest pain | -336
     respiratory distress | -336
     low-grade fever | -336
     sore throat | -336
     no abdominal pain | -336
     no diarrhea | -336
     cardiomegaly | 0
     congestive heart failure suspected | 0
     blood pressure of 132/77 mmHg | 0
     pulse rate of 131/min | 0
     body temperature of 36.8℃ | 0
     respiratory rate of 14/min | 0
     pulse oximetry of 97% on room air | 0
     bilateral pitting edema of the lower extremities | 0
     no rashes | 0
     no tattoos | 0
     no cutaneous ulcers | 0
     white-blood-cell (WBC) count of 13,900 /μL | 0
     neutrophils, 75.1% | 0
     C-reactive protein, 7.3 mg/dL | 0
     plasma glucose, 422 mg/dL | 0
     HbA1c, 12.2% | 0
     creatine phosphokinase, 35 U/L | 0
     N-terminal pro-brain natriuretic peptide, 1,939 pg/mL | 0
     normal liver function | 0
     normal kidney function | 0
     normal thyroid function | 0
     sinus tachycardia at 128/min | 0
     normal QRS width and axis | 0
     low voltage | 0
     normal ST segment | 0
     pericardial effusion | 0
     pericardial thickening | 0
     bilateral pleural effusion | 0
     no pulmonary parenchymal involvement | 0
     acute pericarditis diagnosed | 0
     emergency pericardiocentesis performed | 0
     750 mL of brownish-red purulent fluid drained | 0
     chest pain improved | 0
     dyspnea on exertion improved | 0
     empiric antibiotic treatment with fosfuluconazole, daptomycin, and doripenem initiated | 0
     colchicine administered | 0
     bisoprolol fumarate initiated | 0
     cultures obtained from the pericardial fluid reported as growing Gram-negative bacilli | 24
     no obvious primary source of infection identified | 24
     S. enterica subsp. arizona identified | 96
     blood cultures negative for any bacterium including Salmonella species | 96
     patient had received a ball python and a Mexican black kingsnake as pets | -504
     Mexican black kingsnake died | -24
     chest pain gradually relieved | 144
     WBC count returned to within the reference interval | 144
     dyspnea on exertion did not ameliorate | 144
     cardiac catheterization performed | 144
     normal coronary artery | 144
     ejection fraction was 46.4% with asynergy | 144
     pulmonary capillary wedge pressure was 24 mmHg | 144
     cardiac index was 1.29 L/min/m2 | 144
     patient transferred to the department of cardiovascular surgery | 144
     constrictive pericarditis secondary to bacterial infection diagnosed | 168
     pericardiotomy performed | 168
     patient recovered well | 168
     patient discharged | 168