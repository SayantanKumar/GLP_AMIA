 62 years old | 0
     female | 0
     obesity | 0
     body mass index 40 kg/m2 | 0
     prior venous thromboembolism | 0
     heart failure with preserved ejection fraction | 0
     up to date on colorectal cancer screening | 0
     benign polyps | 0
     diverticulosis | 0
     tirzepatide 2.5 mg subcutaneous once weekly | -672
     apixaban 5 mg twice daily | 0
     spironolactone 25 mg once daily | 0
     furosemide 20 mg once daily | 0
     atorvastatin 20 mg once daily | 0
     fluoxetine 30 mg once daily | 0
     lisinopril 2.5 mg once daily | 0
     atenolol 37.5 mg once daily | 0
     new-onset constipation | -672
     firm bowel movements once every 3 days | -672
     eating smaller, more frequent meals | -672
     lower abdominal cramping pain | 0
     urge to defecate | 0
     bloody stools | 0
     hypertensive | 0
     blood pressure of 155/103 mm Hg | 0
     soft, nondistended abdomen | 0
     mild diffuse lower tenderness | 0
     white blood cell count of 12.0 | 0
     normal hemoglobin | 0
     normal platelet count | 0
     International normalized ratio was 1.6 | 0
     computed tomography scan of the abdomen and pelvis with contrast | 0
     new wall thickening | 0
     pericolonic fat stranding | 0
     colonoscopy | 0
     inflammatory mucosal changes | 0
     epithelial denudation and sloughing with necrosis | 0
     crypt withering | 0
     hyalinization of the lamina propria | 0
     lamina propria congestion and hemorrhage | 0
     admitted to the hospital | 0
     treated with intravenous fluids | 0
     bowel rest | 0
     broad-spectrum antibiotics | 0
     analgesics | 0
     apixaban held | 0
     furosemide held | 0
     spironolactone held | 0
     tirzepatide held | 0
     rapid and spontaneous resolution of symptoms | 48
     discharged | 72
     weaned off opioid pain medications | 48
     apixaban resumed | 72
     diuretics held | 72
     oral ciprofloxacin | 72
     metronidazole | 72
     no recurrence of rectal bleeding | 168
     intermittent recurrence of bloody bowel movements | 720
     repeat colonoscopy | 2160
     benign polyps | 2160
     normal mucosa | 2160