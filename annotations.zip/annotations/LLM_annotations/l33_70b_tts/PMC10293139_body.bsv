 62 years old | 0
     male | 0
     German origin | 0
     retired office worker | 0
     admitted to the hospital | 0
     portal hypertension | 0
     non-alcoholic steatohepatitis liver cirrhosis | 0
     esophageal varices | 0
     TIPS | 0
     splenic vein thrombosis | -1368
     stent implantation | -1368
     anticoagulation therapy | -1368
     metabolic syndrome | 0
     cardiovascular and liver risk factor | 0
     etiology of liver cirrhosis | 0
     good general condition | 0
     medication on admission | 0
     Spironolactone | 0
     Hydrochlorothiazide | 0
     Ornithine aspartate | 0
     Lactulose | 0
     Rifaximin | 0
     Duloxetine | 0
     Ramipril | 0
     Ursodeoxycholic acid | 0
     Apixaban | 0
     Insulin glargin | 0
     Insulin lispro | 0
     Metformin | -48
     Semaglutide | 0
     angiographic intervention | 0
     percutaneous transluminal balloon angioplasty of the TIPS | 0
     balloon percutaneous transluminal balloon angioplasty of the splenic vein stent | 0
     post-interventional abdominal pain | 0
     metamizole 1 g | 0
     first intake of metamizole | 0
     agranulocytosis | 24
     elevated indirect bilirubin | 24
     no increase of liver enzymes | 24
     manual differential blood count | 24
     no atypical cells | 24
     individual protective reverse isolation | 24
     antibiotic prophylaxis | 24
     filgrastim | 24
     revisiting medication history | 24
     no change in medication | 24
     single application of prilocaine | 0
     application of iodine-based contrast medium | 0
     Metformin discontinued | -48
     anticoagulation paused | 0
     hemolysis | 24
     free hemoglobin increased | 24
     lactate dehydrogenase increased | 24
     haptoglobin decreased | 24
     no schistocytes | 24
     no previous hematologic disease | 0
     no evidence of microangiopathy | 24
     no blood transfusion | 24
     no infectious hemolysis | 24
     no foreign travel | 0
     reticulocytes adequately elevated | 24
     Coombs test negative | 24
     hemoglobin titer decreased | 24
     no symptoms of anemia | 24
     no pectanginal symptoms | 24
     diagnosis of metamizole-induced agranulocytosis | 24
     concomitant simultaneous hemolysis | 24
     computed tomography | 48
     post-interventional imaging of the TIPS | 48
     post-interventional imaging of the splenic vein stent | 48
     good therapeutic success | 48
     discharged | 120