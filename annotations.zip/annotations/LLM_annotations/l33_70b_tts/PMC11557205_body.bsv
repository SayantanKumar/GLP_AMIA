 79 years old | 0
     male | 0
     type 2 diabetes mellitus | -7200
     hypertension | -7200
     metformin hydrochloride | -7200
     glimepiride | -7200
     dulaglutide | -7200
     nifedipine CR | -7200
     doxazosin mesylate | -7200
     telmisartan | -7200
     hydrochlorothiazide | -7200
     poor glycemic control | -408
     hemoglobin A1c 8.6% | -408
     miglitol | -408
     leg edema | -192
     general malaise | -192
     acetaminophen | -216
     admission to hospital | 0
     acute kidney injury | 0
     elevated serum creatinine | 0
     serum creatinine 8.12 mg/dL | 0
     computed tomography | 0
     edema | 0
     fractional excretion of sodium | 0
     fractional excretion of urea | 0
     elevated blood pressure | 0
     low fever | 0
     elevated C-reactive protein | 0
     urinary β2-microglobulin elevation | 0
     discontinuation of miglitol | 0
     discontinuation of metformin hydrochloride | 0
     discontinuation of glimepiride | 0
     discontinuation of dulaglutide | 0
     insulin | 0
     drug-induced lymphocyte stimulation test | 0
     renal biopsy | 264
     gallium scintigraphy | 384
     oral prednisolone | 528
     discharge from hospital | 600
     serum creatinine 4.77 mg/dL | 528