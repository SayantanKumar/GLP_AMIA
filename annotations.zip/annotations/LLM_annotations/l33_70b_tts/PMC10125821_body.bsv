 58 years old | 0
     female | 0
     admitted to the hospital | 0
     chest pain | 0
     VSD diagnosed | -64800
     DCRV detected | -5400
     regular follow-up with TTE | -5400
     hypertension diagnosed | -7200
     diabetes diagnosed | -6120
     dyslipidemia diagnosed | -720
     candesartan 8 mg/day | 0
     nifedipine 40 mg/day | 0
     atenolol 50 mg/day | 0
     doxazosin mesylate 3 mg/day | 0
     atorvastatin 5 mg/day | 0
     metformin 2 g/day | 0
     ipragliflozin L-proline 50 mg/day | 0
     glimepiride 0.5 mg/day | 0
     semaglutide 0.5 mg/week | 0
     blood pressure 94/55 mmHg | 0
     heart rate 88/bpm | 0
     oxygen saturation 98% | 0
     cardiac enlargement | 0
     new ST elevation in leads II, III, and aVF | 0
     akinesis of the basal inferior left ventricular myocardium | 0
     elevated troponin I | 0
     elevated serum creatine kinase | 0
     elevated CK-MB | 0
     acute myocardial infarction suspected | 0
     percutaneous coronary angiography | 0
     significant stenosis of the left anterior descending artery | 0
     total occlusion of the midportion of the right coronary artery | 0
     percutaneous coronary artery intervention | 0
     stenting of the right coronary artery | 0
     serum CK and CK-MB elevated | 24
     ST elevation at the right precordial leads | 24
     TTE revealed significant stenosis of the mid-right ventricle | 96
     computed tomography to evaluate the RV stenosis | 96
     mid-ventricular stenosis of the RV | 96
     RV hypertrophy | 96
     peak pressure gradient between the apical and basal RV | 168
     cardiac rehabilitation commenced | 168
     discharged | 168
     cardiac magnetic resonance imaging | 4320
     late gadolinium enhancement of the inferior LVM and RVM | 4320
     DCRV repair and coronary artery bypass grafting | 4320
     mid-RV pressure gradient of 5.7 mmHg | 4320