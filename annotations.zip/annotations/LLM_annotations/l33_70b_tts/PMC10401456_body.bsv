 42 years old | 0
     female | 0
     xerostomia | -96
     polydipsia | -96
     polyuria | -96
     blurred vision | -96
     fatigue | -96
     cesarean section | -6480
     uterine fibroids | -4320
     consumption of substantial amounts of beverages and fruits | -96
     high blood glucose | -96
     metformin | -48
     other oral drug | -48
     admission to hospital | 0
     dry lips | 0
     body mass index 31.85 kg/m2 | 0
     blood pressure 133/96 mmHg | 0
     arterial pH 7.29 | 0
     PO2 93 mmHg | 0
     bicarbonate 14.6 mmol/L | 0
     fasting blood glucose 14.54 mmol/L | 0
     islet cell antibody 45 times higher than normal | 0
     glutamic acid decarboxylase 200 times higher than normal | 0
     insulin autoantibody two times higher than normal | 0
     urine ketone significantly positive | 0
     liver function slightly abnormal | 0
     blood lipids normal | 0
     albumin/creatinine ratio normal | 0
     thyroid function normal | 0
     fluid replacement | 0
     insulin treatment | 0
     mixed protamine zinc recombinant human insulin injection | 0
     lifestyle interventions | 0
     discharge | 24
     discontinuation of insulin therapy | 720
     blood glucose normal | 720
     oral glucose tolerance test | 2160
     oral glucose-insulin release test | 2160
     HbA1c 6.2% | 2160
     liraglutide | 4320
     fasting blood glucose 5-6 mmol/L | 4320
     postprandial blood glucose 6-8 mmol/L | 4320
     HbA1c 7.3% | 6480
     next-generation sequencing | 0
     heterozygous mutation in the PAX4 gene | 0
     Sanger validation | 0
     family pedigree | 0
     diabetic ketoacidosis | 0
     type 1 diabetes mellitus | 0
     latent autoimmune diabetes in adults | 0
     PAX4 gene mutation | 0
     MODY9 | 0