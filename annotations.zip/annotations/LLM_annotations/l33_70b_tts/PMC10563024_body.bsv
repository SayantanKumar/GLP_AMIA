 84 years old | 0
     female | 0
     chronic kidney disease | 0
     hyperthyroidism | 0
     hypertension | 0
     type II diabetes mellitus | 0
     vildagliptin | 0
     repaglinide | 0
     acarbose | 0
     dulaglutide | -504
     diffuse bullous rash | 0
     mild erythematous rash | -168
     discontinued dulaglutide | -168
     numerous tense bullous lesions | 0
     serous-hematic content | 0
     single blister on oral mucosa | 0
     intense itching | 0
     cutaneous biopsy | 0
     eosinophilic papillitis | 0
     IgG and C3 deposits on basement membrane | 0
     neutrophilic leukocytosis | 0
     elevation of inflammatory indices | 0
     marked increase in total IgE | 0
     BP180 positive | 0
     BP230 positive | 0
     bullous pemphigoid diagnosis | 0
     no recent infections | 0
     no vaccinations | 0
     tumor markers negative | 0
     oral prednisone | 0
     oral doxycycline | 0
     drainage of bullous lesions | 0
     eosin touching | 0
     insulin glargine | 0
     absence of new lesions | 168
     gradual re-epithelialization | 168
     cortisone and antibiotic therapy discontinued | 504
     follow-ups every month | 168
     follow-ups every three months | 504
     follow-ups at six-month intervals | 1008