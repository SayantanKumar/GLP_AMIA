 58 years old | 0
     female | 0
     diabetes | -13248
     semaglutide | -10956
     painful diabetic polyneuropathy | -10956
     tingling | -10956
     numbness | -10956
     burning pain | -10956
     hypoesthesia | -10956
     allodynia | -10956
     sharp pain | -10956
     referred to hospital | 0
     no motor deficits | 0
     no abnormal deep tendon reflexes | 0
     no dysvitaminosis | 0
     no autoimmune/rheumatological disorders | 0
     SCS implantation | 0
     local anesthesia | 0
     intravenous light sedation | 0
     octopolar lead introduction | 0
     lead positioning | 0
     FAST stimulation | 0
     discharge | 48
     NRS 1 | 48
     no complications | 48
     follow-up at 1 month | 720
     NRS decreased | 720
     BPI improved | 720
     PIS decreased | 720
     DN4 decreased | 720
     antalgic pharmacological therapy discontinued | 720
     SF36 improved | 720
     HRUS performed | 720
     CSA reduction | 720
     ENG performed | 720
     sural nerves SCV increased | 720
     follow-up at 2 months | 1440
     CSA reduction | 1440
     follow-up at 3 months | 2160
     pain relief stable | 2160
     no changes in stimulation settings | 2160