 19 years old | 0
     male | 0
     referred to clinic | 0
     new-onset diabetes after kidney transplantation | 0
     hyperglycemia | 0
     denied catabolic symptoms | 0
     no evidence of ketoacidosis | 0
     normal blood glucose levels in childhood | -6840
     fasting blood glucose levels 4.2-5.2 mmol/L | -6840
     body weight 55 kg | 0
     BMI 21.5 kg/m2 | 0
     kidney disease suspected on fetal ultrasonographic scan | -6840
     bilateral hyperechogenic kidneys | -6840
     plasma creatinine abnormally elevated | -6840
     autosomal recessive polycystic kidney disease | -6840
     renal function progressively deteriorated | -6840
     plasma creatinine level 433.2 μmol/L | -720
     glomerular filtrate rate 15.9 mL/min/1.73 m2 | -720
     living kidney transplant | -720
     partial graft necrosis | -720
     immunosuppressive regimen | -720
     tacrolimus 15 mg/day | -720
     mycophenolate mofetil 2000 mg/day | -720
     prednisolone 15 mg/day | -720
     plasma creatinine level 185.6 μmol/L | 0
     glomerular filtrate rate 44.3 mL/min/1.73 m2 | 0
     history of diabetes in maternal grandmother and uncle | -6840
     fasting C-peptide 1.3 nmol/L | 0
     islet autoantibodies negative | 0
     US pancreatic evaluation normal | 0
     HNF1B gene mutation screening | 0
     known missense heterozygous mutation p.S148L | 0
     genetic counseling | 0
     insulin therapy started | 0
     long-acting analog 0.16 UI/kg/day | 0
     insulin dose progressively reduced | 24
     reductions in tacrolimus and prednisolone doses | 24
     switched to DPP-4 inhibitor | 120
     stopped DPP-4 inhibitor due to vomiting | 144
     glycated hemoglobin below 6.5% | 168
     sitagliptin 25 mg/day resumed | 480
     HbA1c increased to 6.9% | 672
     HbA1c increased to 8% | 960
     renal function slowly deteriorated | 960
     plasma creatinine level 185.6-229.8 μmol/L | 960
     glomerular filtrate rate 34-44 mL/min/1.73 m2 | 960
     therapy switched to liraglutide | 1200
     liraglutide titrated to 1.8 mg/day | 1200
     HbA1c dropped to 6.7% | 1260
     glycemic control deteriorated | 1320
     HbA1c increased to 10.9% | 1380
     liraglutide stopped | 1380
     insulin therapy resumed | 1380
     long-acting analog 0.14 UI/kg/day | 1380