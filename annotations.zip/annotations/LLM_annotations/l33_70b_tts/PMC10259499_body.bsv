 50 years old | 0
     female | 0
     type 2 diabetes | -2520
     high blood pressure | -2520
     obesity | -2520
     metformin | -2520
     gliclazide | -2520
     amlodipine | -2520
     deranged liver enzyme levels | 0
     elevated liver enzymes | 0
     alanine transaminase | 0
     aspartate transaminase | 0
     γ-glutamyltransferase | 0
     abnormal lipid profile | 0
     high triglycerides | 0
     fibrosis 4 index | 0
     hepatitis B surface antigen | 0
     anti-hepatitis C virus antibodies | 0
     autoantibodies | 0
     abdominal ultrasound | 0
     bright hepatomegaly | 0
     mild splenomegaly | 0
     portal vein | 0
     no ascites | 0
     NASH | 0
     weight reduction | 0
     dyslipidaemia control | 0
     liraglutide | 0
     simvastatin | 0
     silymarin | 0
     follow-up visit | 96
     decreased ALT | 96
     decreased AST | 96
     normalization of liver enzyme levels | 168
     reduced blood triglyceride levels | 168
     good treatment adherence | 168
     no adverse events | 168
     no drug interactions | 168