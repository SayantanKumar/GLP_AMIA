 63 years old | 0
     male | 0
     admitted to the emergency department | 0
     progressive, ascending weakness of the upper and lower extremities | 0
     history of hypertension | 0
     history of dyslipidemia | 0
     history of insulin-dependent diabetes mellitus | 0
     history of nephrolithiasis | 0
     history of obesity | 0
     history of anxiety | 0
     history of Guillain–Barré syndrome (GBS) after vaccination against influenza | 0
     insulin glargine | 0
     metformin | 0
     semaglutide | 0
     gliclazide | 0
     amlodipine | 0
     valsartan | 0
     atorvastatin | 0
     potassium citrate | 0
     acute facial paralysis | -10368
     ascending upper and lower extremity weakness | -10368
     paresthesias | -10368
     flaccid paralysis of all 4 extremities | -10368
     generalized areflexia | -10368
     elevated levels of cerebrospinal fluid (CSF) protein | -10368
     received his first dose of the ChAdOx1 nCoV-19 vaccine | -288
     mild chills | -288
     fatigue | -288
     paresthesias of the lips and fingers | -264
     rapidly progressive and ascending weakness in his upper and lower extremities | 0
     mild weakness of both shoulder abductors and knee flexors | 0
     areflexia | 0
     bilateral loss of pinprick and vibration sensation | 0
     loss of proprioception to the ankle joint | 0
     abnormally wide gait | 0
     weakness progressed to 1/5 strength in his ankle dorsiflexors | 24
     weakness progressed to 1/5 strength in the extensor hallucus longus | 24
     weakness progressed to 3–4/5 strength in his knee extensors | 24
     weakness progressed to 1–2/5 hip flexors’ strength | 24
     weakness progressed to 4/5 strength in his shoulder abductors, elbow flexors, extensors and wrist extensors | 24
     sensorimotor peripheral neuropathy with substantial demyelinating features and superimposed axonal features | 24
     albinocytologic dissociation | 24
     elevated protein | 24
     elevated glucose | 24
     lactate | 24
     no evidence of an infectious, metabolic or structural cause for his symptoms | 24
     treated with intravenous immune globulin | 24
     therapeutic plasma exchange | 48
     noninvasive mechanical ventilation | 48
     motor function had improved substantially | 2160
     persistent mild weakness in his hands and proximal and distal lower extremities | 2160
     areflexia | 2160
     abnormal light touch | 2160
     pinprick and vibration sensation | 2160
     suggested that the patient avoid future doses of the ChAdOx1 nCoV-19 vaccine | 2160