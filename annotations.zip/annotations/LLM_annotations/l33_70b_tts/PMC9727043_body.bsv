 53 years old | 0\
     female | 0\
     asthma diagnosis | -36000\
     mother has asthma | -36000\
     daughter has asthma | -36000\
     PRN budesonide/formoterol | -36000\
     non-COVID infectious exacerbation | -9\
     prednisone treatment | -9\
     macrolide antibiotic treatment | -9\
     COVID-19 infection | -9\
     weight gain of 40 pounds | -9\
     budesonide/formoterol increased to BID | 0\
     triple therapy indacaterol/mometasone/glycopyrronium | 0\
     proton pump inhibitor (PPI) daily | 0\
     subcutaneous semaglutide (GLP-1 RA) | 0\
     weight loss | 1\
     lung function normalization | 1\
     symptom resolution | 1\
     allergy testing | 1\
     blood eosinophil count of 100 | 1\
     fractionated exhaled nitric oxide of 11 | 1\
     repeat spirometry showing resolution of obstruction | 3\
     PPI discontinued | 3\
     asthma therapy reduced to moderate-dose ICS/LABA | 3\
     asthma therapy reduced to low-dose ICS/LABA | 6\
     weight loss of 40 pounds | 6\
     no recurrence of asthma symptoms | 6