 6 years old | 0\
     female | 0\
     presented to endocrinology clinic | 0\
     abnormal blood glucose values | 0\
     prematurity | -2190\
     gastroschisis | -2190\
     jejunal atresia | -2190\
     small bowel resection | -2190\
     short gut syndrome | -2190\
     liver failure | -2190\
     liver transplantation | -2190\
     small bowel transplantation | -2190\
     pancreas transplantation | -2190\
     total parental nutrition | -2190\
     transitioned to gastric feeds | -8760\
     celiac disease | -8760\
     loose stools | -8760\
     hyperglycemia | -24\
     hemoglobin A1c | -24\
     endocrine referral | -24\
     random blood glucose | -24\
     insulin level | -24\
     hyperinsulinism | -24\
     oral glucose tolerance test | 0\
     fasting blood glucose | 0\
     fasting insulin level | 0\
     postprandial blood glucose | 2\
     postprandial insulin level | 2\
     ileostomy bag | 0.5\
     gastric emptying study | 0\
     surgical gastroenteric anastomosis | -2190\
     duodenum tortuous | -2190\
     anastomotic strictures | -2190\
     feeds changed | 24\
     loperamide | 24\
     postprandial hypoglycemia | 48\
     headaches | 48\
     irritability | 48\
     tremors | 48\
     eating every 2 hours | 48\
     staged duodenal dilatations | 168\
     diazoxide therapy | 168\
     informed consent | 168\
     diazoxide started | 168\
     dose increased | 744\
     blood glucose levels improved | 744\
     hypoglycemia resolved | 744\
     duodenal dilatations completed | 2016\
     diazoxide weaned | 2016\
     blood glucose levels normal | 2016\
     dumping symptoms resolved | 2016\
     hypertrichosis | 2016\
     fluid retention | 2016\
     adverse effects | 2016\
     follow-up | 2016\
     exendin-(9-39) | 2016\
     glucagon-like peptide-1 receptor antagonist | 2016\
     bridging therapy | 2016\
     surgical interventions | 2016\
     glycemic improvement | 2016\
     clinical trials | 2016\
     efficacy | 2016\
     safety | 2016\
     patient collaboration | 2016\
     literature review | 2016\
     report drafted | 2016\
     report revised | 2016\
     report approved | 2016\
     patient evaluated | 2016\
     patient treated | 2016\
     data generated | 2016\
     data analyzed | 2016\
     data included | 2016\
     data repositories | 2016\
     references | 2016\
     disclosure summary | 2016\
     nothing to disclose | 2016\
     data availability | 2016\
     published article | 2016