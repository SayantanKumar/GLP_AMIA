 48 years old | 0
     female | 0
     postmenopausal | 0
     presented with lateral neck pain | -240
     pain was gradual onset non-radiating | -240
     no associated fever | -240
     no throat pain | -240
     no trauma | -240
     diabetic | 0
     regular oral hypoglycemic medication | 0
     skipped medication for the last four days | -96
     well-controlled hypothyroidism | 0
     hypertension | 0
     drinks alcohol socially | 0
     thyroxine 87.5 microgram daily | 0
     liraglutide 5 mg daily | 0
     repaglinide 1 mg thrice daily | 0
     aspirin 75 mg daily | 0
     atorvastatin 10 mg daily | 0
     conscious | 0
     calm | 0
     cooperative | 0
     well-oriented to time, place, and person | 0
     stable vitals | 0
     localized ill-defined area of around 3 × 2 cm area to the left side of the neck | 0
     tender | 0
     local rise in temperature | 0
     crepitations felt | 0
     distal neurovascular status was intact | 0
     corresponding draining lymph nodes were palpable | 0
     total leukocyte count of 30,330 | 0
     87 % neutrophils | 0
     hemoglobin level of 12.5 g/dl | 0
     platelets count of 166,000/ml | 0
     random blood sugar level was 502 mg/dl | 0
     serum urea and creatinine levels were 63 and 3.5 | 0
     normal serum sodium and potassium levels | 0
     urine examination revealed sugar +++, protein +, and acetone positive | 0
     serum protein and albumin levels were 6.4 and 3.3 g/dl | 0
     arterial blood gas analysis revealed a pH of 7.067 | 0
     pCO2 of 8.7 | 0
     pO2 of 77 % in room air | 0
     serum bicarbonate level of 12.6 | 0
     diagnosis of diabetic ketoacidosis secondary to neck abscess | 0
     admitted to the medical Intensive Care Unit (ICU) | 0
     insulin and intravenous (IV) fluids started | 0
     piperacillin and tazobactam started empirically | 0
     ultrasonography neck performed | 12
     large ill-defined mass on the left side of the neck with posterior acoustic shadow | 12
     neck exploration for thorough debridement of the wound under general anesthesia | 24
     culture and sensitivity of the wound swab showed pseudomonas aeruginosa | 24
     intravenous ciprofloxacin 200 mg twice daily and amikacin 500 mg thrice daily started | 24
     histopathology report revealed fragments of fibrofatty tissue with marked inflammatory cells infiltrate | 48
     daily dressing of the neck performed | 48
     patient stayed for the next week | 168
     showing good signs of recovery | 168
     tolerated oral feeding | 168
     lab reports showed normal hematological parameters | 168
     normal renal function | 168
     blood sugar was 166 mg/dl | 168
     wound showed good signs of healing | 168
     appropriate anti-hyperglycemic medications prescribed | 168
     advised for regular dressing and blood sugar monitoring | 168
     patient was discharged home | 168
     doing well both in terms of her wound and blood sugar | 240