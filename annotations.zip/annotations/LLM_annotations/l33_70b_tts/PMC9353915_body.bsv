 schizophrenia | -4380
     diagnosed with schizophrenia | -4380
     olanzapine | -4380
     sodium valproate | -4380
     weight gain | -8760
     hyperglycemia | -720
     polydipsia | -720
     polyuria | -720
     exceedingly thirsty | -720
     fasting blood glucose | -720
     glycated hemoglobin A1c | -720
     glargine | -720
     metformin | -720
     admitted to the hospital | 0
     physical examination | 0
     diabetes complications-related examinations | 0
     fundus examination | 0
     electromyography | 0
     renal function | 0
     laboratory examinations | 0
     urine free cortisol | 0
     blood cortisol | 0
     blood potassium | 0
     blood pressure | 0
     thyroid function | 0
     hormone | 0
     metformin discontinued | 0
     insulin pump | 0
     continuous subcutaneous insulin infusion | 72
     liraglutide | 72
     diet | 72
     daily exercise | 72
     blood glucose levels | 72
     fasting blood glucose | 72
     postprandial blood glucose | 72
     weight | 168
     discharged | 336
     follow-up | 17520
     blood glucose levels | 17520
     weight loss | 17520
     psychiatric status | 17520
     liraglutide treatment | 17520