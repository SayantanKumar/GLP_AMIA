 27 years old | 0
     male | 0
     history of Crohn disease | 0
     obesity | 0
     depression | 0
     sleep apnea | 0
     continuous positive airway pressure | 0
     low testosterone levels | -2160
     low mood | -2160
     fatigue | -2160
     normal hair distribution | 0
     normal muscle mass and strength | 0
     soft 10 mL testicles | 0
     no palpable nodule | 0
     intramuscular testosterone cypionate | -2160
     total testosterone level 2.43 ng/mL | 0
     testosterone replacement therapy discontinued | 0
     total testosterone 0.91 ng/mL | 2160
     bioavailable testosterone 0.69 ng/mL | 2160
     sex hormone binding globulin 8 nmol/L | 2160
     luteinizing hormone 3.1 mIU/mL | 2160
     follicle stimulating hormone 2.7 mIU/mL | 2160
     estradiol 23 pg/mL | 2160
     insulin like growth factor 1 193 ng/mL | 2160
     prolactin 10 ng/mL | 2160
     thyroid stimulating hormone 1.03 mIU/L | 2160
     free thyroxine 1.15 ng/dL | 2160
     8 am cortisol 13.5 μg/dL | 2160
     adrenocorticotropic hormone 37 pg/mL | 2160
     semen analysis unremarkable | 2160
     iron studies normal | 2160
     pituitary magnetic resonance imaging | 2160
     brain magnetic resonance angiography | 2160
     subcutaneous semaglutide | 2160
     weight loss 30 lb | 4320
     body mass index 33.05 | 4320
     testosterone replacement therapy not reinitiated | 4320
     hypogonadotropic hypogonadism | 4320
     intracranial kissing carotid arteries | 4320