 50 years old | 0
     female | 0
     chronic obstructive pulmonary disease | 0
     hypertension | 0
     hyperlipidemia | 0
     bipolar disorder | 0
     autoimmune hepatitis with cirrhosis | 0
     gastroesophageal reflux disease | 0
     hypothyroidism | 0
     type 2 diabetes mellitus | 0
     admitted to the hospital | 0
     headache | -72
     nausea | -72
     dizziness | -72
     weakness | -72
     air conditioner stopped working | -168
     excessive sweating | -168
     poor oral intake | -168
     hyperglycemia | -72
     albuterol inhaler | 0
     clonidine | 0
     atorvastatin | 0
     quetiapine | 0
     fluoxetine | 0
     benztropine | 0
     prednisone | 0
     pantoprazole | 0
     furosemide | 0
     levothyroxine | 0
     metformin | 0
     insulin degludec | 0
     exenatide | 0
     blood pressure 150/90 mmHg | 0
     temperature 37.4°C | 0
     heart rate 105 beats per min | 0
     respiratory rate 18 breaths per min | 0
     oxygen saturation 99% | 0
     lethargic | 0
     dry mucus membranes | 0
     hypercalcemia | 0
     calcium level 17.3 mg/dL | 0
     ionized calcium 1.95 mM/L | 0
     normal sinus rhythm | 0
     no ST-segment changes | 0
     administered 2-liter fluid bolus of normal saline | 0
     continuous infusion of normal saline at 150 mL/h | 0
     calcium level improved | 72
     calcium level normalized | 72
     discharged | 96
     follow-up visit | 168
     mammography of bilateral breast | 168
     nuclear bone imaging of the whole body | 168
     computed tomography scan of chest abdomen and pelvis | 168
     calcium level within reference range | 168