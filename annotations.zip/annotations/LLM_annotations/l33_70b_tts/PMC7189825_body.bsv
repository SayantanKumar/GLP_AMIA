 28 years old | 0
     female | 0
     accidental injection of liraglutide | 0
     liraglutide 18 mg | 0
     epigastric abdominal pain | 0
     nausea | 0
     vomiting | 0
     sweating | 0
     diabetes mellitus type II | -672
     obesity | -672
     metformin 500 mg | -672
     multivitamin | -672
     normal vital signs | 0
     blood glucose 4.6 mmol/L | 0
     normal conscious level | 0
     soft and lax abdomen | 0
     no focal tenderness | 0
     normal pH | 0
     normal PCO2 | 0
     normal HCO3 | 0
     normal lactate | 0
     mild hypokalemia | 0
     normal electrolyte | 0
     normal renal panel | 0
     normal lipase | 0
     normal amylase | 0
     normal C-peptide | 0
     observation for 16 hours | 0
     hourly blood glucose monitoring | 0
     epigastric abdominal pain persisted | 1
     persistent vomiting | 1
     dextrose D50% | 2.5
     dextrose 5% infusion | 2.5
     dextrose 10% infusion | 2.5
     asymptomatic | 16
     abdominal pain improved | 16
     normal blood glucose | 16
     discharged | 16
     good health | 360
     no hypoglycemia | 360
     no pancreatitis | 360