 37 years old | 0
     male | 0
     weight 183 kg | 0
     height 185 cm | 0
     BMI 53.5 kg/m2 | 0
     bradycardia | 0
     asthma | 0
     gout | 0
     no diabetes | 0
     laparoscopic RYGB | -8760
     alimentary limb 150 cm | -8760
     bilio-pancreatic limb 50 cm | -8760
     weight loss 88 kg | -8760
     BMI 27.7 kg/m2 | -8760
     admitted to hospital | 0
     neuroglycopenic symptoms | 0
     plasma-glucose 1.6 mmol/l | 0
     standard nutritional supplements | 0
     no drugs | 0
     rare alcohol | 0
     serum-cortisol normal | 0
     thyroid function tests normal | 0
     cerebral CT scan normal | 0
     abdominal CT scan normal | 0
     cardiac evaluation normal | 0
     plasma-glucose after 72 h fast normal | 0
     dietary modifications | 0
     self-monitoring of blood-glucose | 0
     hypoglycaemic episodes increased | 0
     hospital admissions increased | 0
     acarbose attempted | 0
     gastrointestinal side effects | 0
     diazoxide up to 600 mg daily | 0
     little effect | 0
     discontinued due to dyspnea | 0
     verapamil not considered | 0
     bradycardia | 0
     subcutaneous injection of octreotide | 0
     less severe PHH | 0
     alanine transaminase increased | 0
     aspartate transaminase increased | 0
     severe symptomatic hypoglycaemia | 0
     daily hospital admission for glucose infusions | 0
     feeding through gastrostomy tube | 0
     subileus | 0
     reoperated | 0
     mixed meal test | 0
     oral test | 0
     gastrostomy tube placement | 0
     test meal | 0
     Edinburgh symptom scale | 0
     pulse measurements | 0
     BP measurements | 0
     plasma-glucose measurements | 0
     serum-insulin measurements | 0
     plasma-GLP-1 measurements | 0
     recurrent abdominal pain | 168
     dependent on continuous parenteral glucose infusions | 168
     hypoglycaemia unawareness | 168
     reduced oral feeding | 168
     increased nutrition through gastric tube | 168
     RYGB reversal | 336
     gastrostomy tube removed | 336
     alimentary limb transected | 336
     side-to-side anastomosis | 336
     bilio-pancreatic limb divided | 336
     new side-to-side entero-entero anastomosis | 336
     mixed meal test after RYGB reversal | 480
     plasma-glucose analysis | 480
     serum-insulin analysis | 480
     plasma-GLP-1 analysis | 480
     symptoms resolved | 480
     returned to work | 504
     weight 87.3 kg | 744
     no hypoglycaemic symptoms | 744
     continuous glucose monitoring | 936
     plasma-glucose levels around 5 mmol/l | 936
     no hypoglycaemic symptoms | 936
     weight 94 kg | 2640
     dyspepsia | 2640
     normal upper endoscopy | 2640
     infrequent low blood glucose levels | 2640
     no hypoglycaemic symptoms | 2640