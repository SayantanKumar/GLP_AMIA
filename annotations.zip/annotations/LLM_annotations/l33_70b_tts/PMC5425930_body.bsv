 48 years old | 0
     male | 0
     African origin | 0
     admitted to the hospital | 0
     diagnosis of treatment-resistant paranoid schizophrenia | 0
     paranoid and grandiose delusions | 0
     auditory hallucinations | 0
     irritability | 0
     shouting | 0
     intimidating towards staff | 0
     grossly thought-disordered | 0
     perceptual abnormalities | 0
     overweight | 0
     BMI of 28.7 | 0
     smoker | 0
     one-pack-per-day | 0
     hypertension | 0
     average blood pressure: 165/101 mmHg | 0
     hypercholesterolemia | 0
     LDL levels: 270 mg/dL | 0
     first known to UK psychiatric services | -8280
     presented with paranoid and grandiose delusions | -8280
     auditory hallucinations | -8280
     various medications were trialled | -8280
     olanzapine | -14400
     risperidone | -18000
     paliperidone palmitate | -7200
     flupentixol depot | -36000
     clozapine | -7200
     stopped clozapine due to side-effects | -7200
     diabetes improved | -7200
     insulin administration was no longer necessary | -7200
     glycaemic control was maintained with metformin | -7200
     metformin 1 g twice daily | -7200
     antipsychotic treatment on admission – risperidone | 0
     switched to lurasidone | 24
     lurasidone was not effective | 168
     changed to amisulpride | 168
     amisulpride produced no improvement | 336
     commenced clozapine | 336
     fasting blood glucose levels were measured | 336
     baseline fasting blood glucose levels: 4–6 mmol/L | 336
     glucose levels started to increase linearly | 342
     HbA1c values increased | 744
     commenced on insulin therapy | 744
     initial dose of four units of fast-acting insulin once daily | 744
     clozapine was slowly titrated upwards | 744
     dose of insulin was increased | 744
     achieved glycaemic control | 744
     52 units of medium-acting insulin twice daily | 744
     commenced on a 2 mg weekly injection of long-acting exenatide | 744
     mental state improved | 744
     thought and speech disorders were ameliorated | 744
     perceptual abnormalities were no longer noted | 744
     paranoid delusions | 744
     gained partial insight | 744
     weight increased | 744
     BMI of 28.9 | 744
     smoking was reduced by half | 744
     discharged from hospital | 4320
     care taken over by local mental health team | 4320
     diabetes care was managed by general practitioner | 4320
     specialist input from endocrinologists | 4320