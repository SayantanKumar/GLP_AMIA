 22 years old | 0
     female | 0
     worsening lower left pelvic pain | 0
     nausea | 0
     vomiting | 0
     vaginal bleeding | 0
     rapid weight gain | -8760
     outpatient evaluation by an endocrinologist | -8760
     regular menses | -8760
     sleep habits | -8760
     denied hirsutism | -8760
     denied acne | -8760
     denied hair loss | -8760
     HgbA1 4.8% | -8760
     testosterone 29.9 | -8760
     LH 8.1 | -8760
     FSH 4.1 | -8760
     TSH 2.41 | -8760
     CMP normal | -8760
     lipid panel normal | -8760
     trial of off-label metformin | -8760
     increasing exercise regimen | -8760
     self-discontinued metformin | -8400
     injections of semaglutide | -8400
     abdominal striae | -8400
     not tested for Cushing's syndrome | -8400
     mildly tender over left lower quadrant | 0
     no masses appreciated | 0
     transvaginal ultrasound | 0
     CT scan | 0
     10.6 cm multi-septated left adnexal mass | 0
     pain improved | 2
     ultrasound revealed arterial and venous blood flow | 2
     outpatient follow-up | 2
     laparoscopic ovarian cystectomy | 168
     left ovary torsed | 168
     dermoid cyst removed | 168
     residual ovarian parenchyma repaired | 168
     mature cystic teratoma | 168
     mature pituitary tissue | 168
     positive pancytokeratin | 168
     positive CAM 5.2 | 168
     positive S100 | 168
     positive synaptophysin | 168
     positive growth hormone | 168
     positive prolactin | 168
     positive ACTH | 168
     modest weight loss | 720
     advised to have repeat sonogram | 720
     possible redevelopment of teratoma | 720