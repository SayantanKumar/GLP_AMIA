 72 years old | 0
     male | 0
     obese | 0
     body mass index: 34.2 kg/m2 | 0
     diabetic | 0
     poor glucose control | 0
     HbA1c: 10.8% | 0
     overt proteinuria | 0
     diabetes duration: over 20 years | 0
     basal insulin | 0
     dipeptidyl peptidase 4 inhibitor | 0
     glucose control improved | 0
     HbA1c below 7% | 0
     hypertension | 0
     dyslipidemia | 0
     beta-blocker | 0
     carvedilol | 0
     ARB | 0
     azilsartan | 0
     Ca2+ channel blocker | 0
     nifedipine | 0
     alpha-blocker | 0
     doxazosin | 0
     rosuvastatin | 0
     serum creatinine increased | -48
     empagliflozin | -12
     liraglutide | -12
     serum creatinine levels decreased | -12
     serum creatinine levels stable | -12
     renal function deteriorated | 0
     serum blood urea nitrogen increased | 0
     serum creatinine increased | 0
     eGFR decreased | 0
     metabolic acidosis | 0
     blood pH: 7.33 | 0
     sodium bicarbonate | 0
     spherical carbonaceous adsorbent | 0
     finerenone | 0
     dotinurad | 0
     hyperuricemia | 0
     serum uric acid: 7.9 mg/dL | 0
     BUN decreased | 12
     eGFR increased | 12
     urinary albumin/creatinine ratio decreased | 12
     liraglutide dose-up | 12
     finerenone dose-up | 24
     dotinurad dose-up | 24
     UA decreased | 24
     eGFR further increased | 24
     BUN further decreased | 24