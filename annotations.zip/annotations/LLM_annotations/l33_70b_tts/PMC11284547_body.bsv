 49 years old | 0
     female | 0
     pelvic pain | 0
     abnormal uterine bleeding | 0
     pelvic ultrasound | 0
     complex left adnexal mass | 0
     endometrial biopsy | 0
     normal proliferative endometrium | 0
     normal TSH/Free T4 | 0
     normal tumor markers | 0
     pelvic MRI | 0
     concern for malignancy | 0
     robotic bilateral salpingectomy | 0
     left oophorectomy | 0
     struma ovarii | 0
     intra-operative frozen section | 0
     contralateral oophorectomy not performed | 0
     hysterectomy not performed | 0
     final surgical pathology | 0
     mature thyroid tissue | 0
     papillary thyroid carcinoma | 0
     no lymphovascular space invasion | 0
     no ovarian capsule involvement | 0
     pelvic washings | 0
     no malignant cells | 0
     referred to endocrinology | 0
     thyroid and neck ultrasounds | 0
     normal thyroglobulin level | 0
     normal thyroid function tests | 0
     monitoring | 0
     thyroglobulin monitoring | 2
     abdominal imaging | 12
     increased thyroglobulin level | 24
     GLP-1 agonist started | 22
     thyroglobulin remained elevated | 24
     CT scan | 24
     neck ultrasound | 24
     pelvic ultrasound | 24
     small hyperechoic right ovarian lesion | 24
     re-evaluated by gynecologic oncology | 24
     decision to proceed with surgery | 24
     diagnostic laparoscopy | 24
     peritoneal carcinomatosis | 24
     diffuse red, cystic, nodular lesions | 24
     right ovary enlarged | 24
     complex cystic appearance | 24
     intraoperative frozen section | 24
     thyroid neoplasm | 24
     decision to proceed with cytoreduction | 24
     robotic-assisted total laparoscopic hysterectomy | 24
     right salpingo-oophorectomy | 24
     extensive peritoneal resection | 24
     omentectomy | 24
     no gross residual disease | 24
     pathology of resected specimen | 24
     strumosis | 24
     papillary thyroid carcinoma | 24
     PD-L1 testing positive | 24
     NRAS Q61R mutation | 24
     tumor mutational burden moderate | 24
     no evidence of microsatellite stability | 24
     inter-disciplinary discussion | 24
     total thyroidectomy | 30
     radioactive iodine therapy | 30
     thyroidectomy | 30
     final pathology benign | 30
     I-131 therapy | 36
     post treatment whole body I-131 scan | 40
     follow up | 40