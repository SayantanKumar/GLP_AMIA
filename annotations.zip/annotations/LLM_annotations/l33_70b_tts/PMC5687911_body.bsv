 36 years old | 0
     male | 0
     type 2 diabetes | -504
     obesity | -504
     CKD stage 4 | -504
     nephrotic syndrome | -504
     admitted to the hospital | 0
     pneumonia | 0
     heart failure | 0
     fever | 0
     tachycardia | 0
     hypoxemia | 0
     tachypnea | 0
     cardiomegaly | 0
     pleural effusion | 0
     consolidation | 0
     systolic blood pressure 168 mm Hg | 0
     diastolic blood pressure 95 mm Hg | 0
     eGFR 14 mL/min/1.73 m2 | 0
     serum creatinine 4.7 mg/dL | 0
     daily urinary protein 15.5 g/day | 0
     plasma glucose 254 mg/dL | -72
     HbA1c 8.3% | -72
     liraglutide | -72
     pioglitazone | -72
     insulin aspart | -72
     insulin glargine | -72
     stopped pioglitazone | 96
     started dapagliflozin | 96
     body weight loss | 96
     serum creatinine decreased | 168
     eGFR increased | 168
     urinary protein decreased | 168
     plasma BNP 38.6 pg/mL | 0
     plasma BNP increased | -72
     plasma BNP decreased | 264
     serum ketone bodies high | 96
     serum ketone bodies continued high | 264
     discharged from hospital | 960
     daily insulin dose decreased | 960
     treatment changed | 960