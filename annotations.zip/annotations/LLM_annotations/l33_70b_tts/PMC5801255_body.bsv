 36 years old | 0
     male | 0
     admitted to the hospital | 0
     born at 36 weeks’ gestation | -9360
     vaginal breech delivery | -9360
     newborn asphyxia | -9360
     Apgar score of 4 | -9360
     hypotonia | -9360
     weight 2150 g | -9360
     diagnosed with PWS | -3120
     floppy infant | -3120
     almond shaped eyes | -3120
     scoliosis | -3120
     obesity | -3120
     mental retardation | -3120
     hypogonadism | -3120
     bilateral cryptorchidism | -3120
     referred to a pediatric endocrinologist | -2880
     impaired glucose tolerance | -2880
     little reaction of growth hormone | -2880
     GH therapy not done | -2880
     diagnosed with diabetes | -2400
     taking oral hypoglycemic agents | -2400
     referred to department of diabetes and endocrinology | -1008
     body weight 90.6 kg | -1008
     height 152.2 cm | -1008
     BMI 39.1 kg/m2 | -1008
     no diabetic retinopathy | -1008
     microalbuminuria | -1008
     taking glibenclamide | -1008
     taking metformin | -1008
     taking pioglitazone | -1008
     HbA1c 11.2% | -1008
     genetic testing | -1008
     abnormal DNA methylation | -1008
     SNP array analysis | -1008
     microsatellite analysis | -1008
     uniparental disomy | -1008
     pharmacological treatment with metformin | -1008
     NPH insulin | -1008
     miglitol | -1008
     diet of 1600 kcal/day | -1008
     exercise therapy | -1008
     lost 12 kg of fat | -504
     HbA1c 12.2% | -504
     replaced NPH insulin with exenatide | -504
     lost 15 kg body weight | -360
     body weight 62.5 kg | -72
     basal insulin of insulin glargine | -72
     lixisenatide | -72
     tofogliflozin | 0
     switched to dulaglutide | 0
     HbA1c 8.5% | 216
     total ketone body level 781 µM | 216
     abdominal CT scan | 216
     subcutaneous fat area decreased | 216
     visceral fat area hardly changed | 216
     fatty infiltration of the pancreas disappeared | 216
     lipid deposition in the pancreas improved | 216
     discharged | 216