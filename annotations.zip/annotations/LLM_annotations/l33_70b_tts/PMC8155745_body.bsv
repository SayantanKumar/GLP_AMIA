 26 years old | 0
     female | 0
     referred for evaluation | 0
     persistent fatigue | -72
     unintentional weight gain | -72
     possible hypothyroidism | 0
     right thyroid lobectomy | -2190
     benign nodule | -2190
     thyroid-stimulating hormone measurements | -2190
     fatigue | -13140
     poor exertional tolerance | -13140
     unintentional weight gain | -13140
     denied dietary restrictions | 0
     computed tomography of the abdomen | -24
     abdominal pain | -24
     diarrhea | -24
     mild hepatic steatosis | 0
     body mass index | 0
     well healed low neck incision | 0
     right thyroid lobe and isthmus absent | 0
     two children | 0
     first child tested positively on NBS for PCD | -8760
     repeat measurement of serum carnitine level | -8736
     second child tested positively on NBS for PCD | -8760
     serum carnitine level remained low | -8736
     measurements of the patient’s carnitine and carnitine ester levels | 0
     pattern consistent with PCD | 0
     genetic testing | 0
     SLC22A5 mutations | 0
     c.34G>A mutation | 0
     c.41G>A mutation | 0
     compound heterozygote | 0
     buccal swabs | 24
     DNA sequencing | 24
     genomic DNA isolated | 24
     PCR amplified | 24
     Sanger sequencing | 24
     nonsense-mediated decay | 0
     electrocardiogram | 24
     echocardiogram | 24
     anatomically normal heart | 24
     preserved left ventricular ejection fraction | 24
     carnitine supplementation started | 24
     adjusted to 50 mg/kg/d | 168
     significant improvements in sense of well-being | 168
     exertional tolerance | 168
     dietitian | 168
     regular aerobic exercise | 168
     treatment with Saxenda | 168
     intentional 15 pound weight loss | 4032
     follow-up appointment | 4032