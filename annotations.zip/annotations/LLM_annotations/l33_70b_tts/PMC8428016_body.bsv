 73 years old | 0
     male | 0
     obese | 0
     Caucasian | 0
     diagnosed with T2DM | -48
     treated with lifestyle modifications | -48
     treated with metformin | -48
     chronic obstructive pulmonary disease | -48
     inhaled long-acting beta-adrenoceptor agonists | -48
     steroids | -48
     severe psoriasis | -72
     treated with adalimumab | -14
     adalimumab discontinued | -2
     glycated hemoglobin 7.9% | 0
     fasting glucose level 162 mg/dL | 0
     self-monitoring blood glucose poor control | 0
     height 158 cm | 0
     weight 106.7 kg | 0
     BMI 42.7 kg/m2 | 0
     psoriasis area and severity index 33.2 | 0
     dermatology life quality index 26.0 | 0
     semaglutide added to metformin | 0
     semaglutide dose 0.25 mg/week | 0
     semaglutide dose increased to 0.50 mg/week | 4
     semaglutide dose increased to 1 mg/week | 16
     visited by dermatologist | 16
     psoriasis area and severity index 8.0 | 16
     glycated hemoglobin 6.4% | 16
     fasting glucose level 124 mg/dL | 16
     BMI 40.3 | 16
     dermatology life quality index 3 | 16
     significant amelioration of quality of life | 16
     psoriasis area and severity index 2.6 | 40
     glycated hemoglobin 5.4% | 40
     fasting glucose level 98 mg/dL | 40
     BMI 38.3 | 40
     dermatology life quality index 0 | 40
     no effect of psoriasis on patient | 40
     patient refused reintroduction of adalimumab | 40