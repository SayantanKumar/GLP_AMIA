 57 years old | 0
     male | 0
     HIV infection | -14400
     zidovudine | -11520
     zalcitabine | -11520
     zidovudine and lamivudine | -6912
     efavirenz, didanosine, and lamivudine | -5760
     dizziness | -5760
     rash | -5760
     depression | -5760
     atazanavir, tenofovir, and lamivudine | -5760
     abdominal distention | -2880
     raltegravir | -2880
     weight gain | -2880
     type 2 diabetes | -2880
     lifestyle consultation | -2880
     metformin | -2880
     A1C rose to 8.8% | -2400
     NPH insulin | -2400
     body weight increased | -1800
     insulin treatment replaced by glimepiride | -1200
     A1C remained 8.3% | -1200
     insulin glargine | -720
     glimepiride discontinued | -720
     weight increased | -360
     liraglutide initiated | 0
     dietitian and diabetes educator consultation | 0
     body weight dropped | 168
     insulin dose reduced | 168
     insulin discontinued | 504
     fasting glucose decreased | 504
     no side-effects or hypoglycemia | 504
     less fatigue | 504
     improved quality of life | 504
     self-monitored blood glucose varied | 504
     HIV-RNA remained undetectable | 504
     A1C decreased to 6.8% | 1008
     body weight decreased | 1008
     liver enzymes normalized | 1008
     lipid profile improved | 1008
     body weight rose slightly | 1512
     A1C remained 6.8% | 1512