 21 years old | 0
     male | 0
     Japanese | 0
     severe abdominal pain | -720
     diagnosed with UC | -720
     treatment with 60 mg prednisolone | -720
     treatment with 10 mg tacrolimus | -720
     treatment with 4,000 mg mesalazine | -720
     hyperglycemia | -720
     HbA1c 5.2% | -720
     glycated albumin (GA) 16.8% | -720
     emergency sub-total colectomy | -720
     intensive insulin therapy | -720
     body mass index 18.6 kg/m2 | -720
     rectumectomy | 0
     total colectomy | 0
     UC resolved | 0
     discontinuation of prednisolone | 0
     discontinuation of other agents | 0
     insulin therapy switched to vildagliptin | 0
     HbA1c increased to 9.5% | 0
     treatment with 1,000 mg metformin | 0
     treatment with 1 mg glimepiride | 0
     HbA1c decreased to 8.2% | 0
     treatment with 0.75 mg dulaglutide | 168
     HbA1c decreased to 5.9% | 672
     HbA1c decreased to 5.4% | 1344
     HbA1c worsened to 11.3% | 2816
     intensive insulin therapy | 2816
     urinary C-peptide secretion 26.8 μg/day | 2816
     C-peptide index 0.36 | 2816
     ΔC-peptide on glucagon loading test 0.1 ng/mL | 2816
     GLP-1-positive cells sparse | 0
     GIP-positive cells sparse | 0
     fasted serum active GLP-1 level 5.80 pmol/L | 0
     fasted serum active GIP level 2.52 pmol/L | 0
     Firmicutes 40.8% | 0
     Bacteroidetes 31.7% | 0
     Bifidobacterium 25.8% | 0
     Lactobacillales 0.7% | 0
     Porphyromonadaceae 0.0% | 0
     Clostridiaceae 16.6% | 0
     Streptococaceae 0.5% | 0
     Burkholderiales 0.0% | 0