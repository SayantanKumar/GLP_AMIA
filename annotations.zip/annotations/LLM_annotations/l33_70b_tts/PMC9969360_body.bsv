 70 years old | 0
     female | 0
     enrolled in the Program of All-inclusive Care for the Elderly (PACE) | 0
     left lower extremity (LLE) pain | 0
     generalized weakness | 0
     major depressive disorder (MDD) | 0
     mild depression | 0
     high-density lipoprotein (HDL) 47 | 0
     low-density lipoprotein (LDL) 97 | 0
     total cholesterol (TC) 176 | 0
     atherosclerotic cardiovascular disease (ASCVD) risk 20.3% | 0
     high-intensity statin therapy | 0
     medication safety review | 0
     fluoxetine changed to citalopram | 36
     ezetimibe discontinued | 36
     atorvastatin 20 mg changed to pravastatin 40 mg | 36
     updated medication list | 36
     warfarin dosing | 0
     international normalization ratio (INR) goal between 2.5 and 3.5 | 0
     unstable INR readings | 0
     PGx test ordered | 87
     PGx results | 87
     decreased function of solute carrier organic anion transporter family member 1B1 (SLCO1B1) | 87
     close monitoring for signs of myopathy | 87
     decreasing pravastatin to 20 mg | 87
     VKORC1, CYP4F2, and CYP2C9 status | 87
     increased warfarin sensitivity | 87
     drug-drug-gene interaction (DDGI) between warfarin and citalopram | 87
     minimizing risk by separating the time of administration | 87
     minor LLE pain | 192
     patient wellbeing improved | 192
     HDL 51 | 192
     LDL 70 | 192
     total cholesterol 134 | 192
     LDL reduction 28% | 192
     total cholesterol reduction 24% | 192
     INR checked every 3 to 4 days | 192
     INR more stable | 192
     MedWise Risk Score decreased from high risk to moderate risk | 192
     improved mental and physical health | 192
     motor vehicle accident | -8760
     trauma | -8760
     atorvastatin 20 mg | -672
     ezetimibe 10 mg | -672
     carvedilol 12.5 mg | -672
     furosemide 20 mg | -672
     diltiazem 120 mg | -672
     doxycycline hyclate 100 mg | -672
     fluoxetine 20 mg | -672
     dulaglutide 0.75 mg | -672
     insulin glargine 10 units | -672
     insulin aspart 5 units | -672
     lansoprazole 30 mg | -672
     levothyroxine 200 mcg | -672
     lorazepam 0.5 mg | -672
     warfarin 17.5 mg | -672
     pravastatin 40 mg | 36
     citalopram 10 mg | 36
     lansoprazole time of administration changed to bedtime | 36
     lisinopril 2.5 mg | 192