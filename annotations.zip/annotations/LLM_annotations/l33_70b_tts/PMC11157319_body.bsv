 74 years old | 0
     female | 0
     hypertension | 0
     diabetes | 0
     dyslipidemia | 0
     cerebral infarction | 0
     ischemic heart disease | 0
     amlodipine | 0
     atorvastatin | 0
     aspirin | 0
     liraglutide | 0
     Insulin Glargine | 0
     COVID-19 vaccinations | -672
     tested positive for SARS-CoV-2 | -24
     syncope episode | -24
     admitted to hospital | 0
     body temperature 37.4°C | 0
     blood pressure 128/70 mmHg | 0
     heart rate 82 bpm | 0
     peripheral oxygen saturation 94% | 0
     lungs clear on auscultation | 0
     no abnormal heart murmur | 0
     electrocardiogram showed sinus rhythm | 0
     C-reactive protein level elevated | 0
     white blood cell count 3,800 /μL | 0
     chest computed tomography no signs of pneumonia or heart failure | 0
     Remdesivir administered | 0
     fainted while walking back to bed | 2
     sinus arrest | 2
     temporary transvenous pacemaker inserted | 2
     temporary pacemaker removed | 168
     felt an urge to defecate | 171
     staggered into the bathroom | 171
     found standing blankly in front of the toilet | 171
     blood pressure 115/79 mmHg | 171
     heart rate dropped from 80 to 36 bpm | 171
     2.4 second pause | 171
     dual-chamber pacemaker implanted | 171
     experienced dizziness while walking to the bathroom | 172
     passed out and injured her head | 172
     face was pale and sweaty | 172
     blood pressure too low to measure | 172
     heart rate 70-80 bpm | 172
     head-up tilt test | 173
     blood pressure 140/76 mmHg | 173
     heart rate 80 bpm | 173
     blood pressure decreased to 67/52 mmHg | 178
     heart rate 81 bpm | 178
     cold sensations | 178
     consecutive yawns | 178
     syncope | 178
     diagnosed with vasodepressor reflex syncope | 178
     Metoprolol prescribed | 178
     myocardial scintigraphy performed | 178
     no myocardial ischemia | 178
     discharged from hospital | 4320
     no fainting episodes | 4320
     no bradycardia | 4320
     normal pulse without pacemaker | 4320