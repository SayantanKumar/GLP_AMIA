 40 years old | 0
     male | 0
     type 1 DM | 0
     obesity | 0
     hypertension | 0
     dyslipidemia | 0
     admitted to the hospital | 0
     nausea | -48
     vomiting | -48
     GLP-1 agonist | -48
     chills | -48
     diarrhea | -48
     blood glucose 303 mg/dL | -24
     anion gap 16 mEq/L | -24
     beta-hydroxybutyrate 1.4 mmol/L | -24
     nontoxic appearing | -24
     denied consuming any foreign food | -24
     Dexcom 6 continuous glucose monitor | -24
     insulin pump | -24
     conservative management | -24
     discharged home | -24
     worsening symptoms | 0
     mild leukocytosis | 0
     blood glucose 171 mg/dL | 0
     anion gap 16 mEq/L | 0
     beta-hydroxybutyrate 1.8 mmol/L | 0
     discharged home | 0
     unable to keep anything down | 24
     blood glucose levels around 150 mg/dL | 24
     less than 1 unit of insulin | 24
     tachycardia | 24
     mild hypertension | 24
     normothermia | 24
     small bowel obstruction | 24
     electrocardiogram | 24
     troponin testing | 24
     infection | 24
     DKA | 24
     metabolic derangements | 24
     pancreatic pathology | 24
     lipase within normal limits | 24
     chronic marijuana usage | 24
     venous blood gas | 24
     pH 7.34 | 24
     PaCO2 42.3 mm Hg | 24
     PaO2 31.2 mm Hg | 24
     HCO3– 22.2 mMol/L | 24
     base excess –3.5 mMol/L | 24
     IV fluids | 24
     admitted to the family medicine residency service | 24
     insulin drip | 24
     5% dextrose IV fluids | 24
     anion gap trended every 4 hours | 24
     insulin drip stopped | 48
     insulin pump restarted | 48
     good glucose control | 48
     dextrose-containing IV fluid stopped | 48
     regular diet | 48
     nausea completely resolved | 48
     discharged home | 72