 type 2 diabetes mellitus | -8760\
     hypertension | -8760\
     hyperlipidemia | -8760\
     metabolic dysfunction-associated steatotic liver disease | -8760\
     Gilbert syndrome | -8760\
     coronary artery disease | -8760\
     atorvastatin 40 mg | -6720\
     elevated liver enzymes | -6720\
     discontinuation of atorvastatin | -6720\
     discontinuation of statins | -5040\
     rosuvastatin 5 mg | -5040\
     progressive proximal muscle weakness | -216\
     extreme muscle pain | -216\
     difficulty climbing stairs | -216\
     rising from a chair | -216\
     reduced muscle strength | 0\
     moderate to significant weakness in the biceps | 0\
     moderate to significant weakness in the triceps | 0\
     moderate to significant weakness in the shoulder girdles | 0\
     good strength in the wrists and hands | 0\
     significant weakness in the hip muscles | 0\
     good strength at the knee and ankles | 0\
     elevated total CK | 0\
     elevated aspartate transaminase (AST) | 0\
     elevated alanine transaminase (ALT) | 0\
     elevated potassium | 0\
     normal renal function tests | 0\
     discontinuation of statin | 0\
     discontinuation of dulaglutide | 0\
     syncopal episode | 72\
     increasing trend of CK level | 72\
     elevated aldolase | 72\
     aggressive intravenous hydration | 72\
     improvement of CK level | 96\
     electromyography | 120\
     diffuse myopathy with myotonic discharges | 120\
     myonecrosis | 120\
     vacuolization | 120\
     fibrous splitting | 120\
     abnormal pulmonary function test | 120\
     left vastus lateralis muscle biopsy | 120\
     scattered necrotic and regenerating fibers | 120\
     positive anti-HMGCR assay | 120\
     negative Anti Signal Recognition Particle Immunofluorescence (SRP IFA) screen | 120\
     colonoscopy | 168\
     unremarkable colonoscopy | 168\
     whole-body fluorodeoxyglucose positron emission tomography/computed tomography | 168\
     prednisone 40 mg daily | 168\
     lowering of CK levels | 744\
     intravenous immunoglobulin | 744\
     ezetimibe 10 mg | 744\
     evolocumab 140 mg subcutaneous injections | 744\
     normalization of CK levels | 1008\
     tapering of prednisone | 1008\
     methotrexate | 1008\
     continuation of intravenous immunoglobulin | 1008\
     re-evaluation of lipid panel | 1008