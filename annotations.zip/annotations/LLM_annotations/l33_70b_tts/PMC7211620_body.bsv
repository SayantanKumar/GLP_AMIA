 70 years old | 0
     male | 0
     chronic obstructive pulmonary disease | -672
     obstructive sleep apnea syndrome | -672
     insulin-dependent type 2 diabetes | -672
     retinopathy | -672
     nephropathy | -672
     polyneuropathy | -672
     arterial hypertension | -672
     coronary heart disease | -672
     obesity | -672
     proximal deep vein thrombosis | -336
     long-acting beta agonist/long-acting muscarinic antagonist combination | -672
     inhaled glucocorticoid | -672
     valsartan | -672
     spironolactone | -672
     ivabradine | -672
     atorvastatin | -672
     metformin | -672
     liraglutide | -672
     insulin glargine | -672
     enoxaparin | -672
     productive cough | -168
     dyspnea | -168
     intermittent fever | -168
     arterial pO2 67 mmHg | -168
     white blood cell count within normal limits | -168
     C-reactive protein slightly elevated | -168
     D-dimer within normal range | -168
     bilateral basal coarse reticular opacities | -168
     SARS-CoV-2 positive | -168
     discharged home | -168
     oral doxycycline | -168
     clinical deterioration | -168
     hypoxemia | -168
     arterial pO2 46 mmHg | -168
     multiple bilateral ground-glass opacities | -168
     reversed halo sign | -168
     white blood-cell count slightly elevated | -168
     neutrophils elevated | -168
     CRP level elevated | -168
     interleukin-6 elevated | -168
     ferritin elevated | -168
     creatinine levels increased | -168
     lymphocytes within normal range | -168
     admitted to ICU | 0
     moderate ARDS | 0
     meropenem | 0
     azithromycin | 0
     hydroxychloroquine | 0
     intubated | 0
     mechanically ventilated | 0
     progression of bilateral infiltrates | 48
     endotracheal aspiration | 72
     Aspergillus fumigatus | 72
     Aspergillus lateral-flow device positive | 72
     putative invasive pulmonary aspergillosis | 96
     intravenous voriconazole | 96
     multiorgan failure | 120
     deceased | 120