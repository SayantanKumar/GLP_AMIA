 15 years old | 0\
     male | 0\
     Caucasian | 0\
     admitted to the hospital | 0\
     severe obesity | 0\
     heart failure | 0\
     palliative care consultation | 0\
     vomiting | -336\
     diarrhea | -336\
     shortness of breath | -336\
     malaise | -336\
     bilateral lower extremity edema | -336\
     tachypnea | -336\
     elevated BNP level | -336\
     elevated troponin level | -336\
     furosemide | -336\
     pressors | -336\
     continuous positive airway pressure therapy | -336\
     milrinone drip | -336\
     transferred to the pediatric cardiac intensive care unit | -336\
     intubated | -336\
     left ventricular ejection fraction of 12-17% | -336\
     cardiac transplant consultation | -336\
     unable to be weaned off intravenous cardiac support | -336\
     prediabetes | -336\
     metformin XR 1000 mg once daily | -336\
     weight 400 pounds | 0\
     BMI 71.6 kg/m2 | 0\
     3L oxygen via nasal cannula | 0\
     oxygen saturations 92-93% | 0\
     anemia | 0\
     hemoglobin of 9.7 g/dL | 0\
     HgbA1c 6.1% | 0\
     lipid profile | 0\
     Total 103 mg/dL | 0\
     triglycerides 67 mg/dL | 0\
     HDL 19 mg/dL | 0\
     LDL 71 mg/dL | 0\
     almost blind | 0\
     round-shaped facies | 0\
     stubby hands | 0\
     stubby feet | 0\
     hyperphagia | -10080\
     foraging behaviors | -10080\
     distress around food | -10080\
     cabinets were often locked | -10080\
     sleep apnea | 0\
     snoring | -10080\
     witnessed apneas | -10080\
     bullying in school | -10080\
     concussions | -10080\
     homeschooling | -10080\
     acetaminophen | 0\
     carvedilol | 0\
     enoxaparin | 0\
     furosemide | 0\
     lisinopril | 0\
     melatonin | 0\
     metformin XR | 0\
     milrinone infusion | 0\
     spironolactone | 0\
     liraglutide 3.0 mg | 0\
     pramlintide | 0\
     empagliflozin 5 mg once daily | 0\
     genetic obesity testing | 0\
     buccal swab | 0\
     weight loss -30 lbs | 336\
     weaned off milrinone infusion | 336\
     weaned off diuretics | 336\
     transferred to the step-down unit | 336\
     discharged home | 672\
     weight loss -101 pounds | 4032\
     weight 299 lbs | 4032\
     BMI 49.9 kg/m2 | 4032\
     left ventricular ejection fraction 39% | 4032\
     liraglutide 3.0 mg daily | 4032\
     empagliflozin | 4032