 39 years old | 0
     female | 0
     Moroccan | 0
     admitted to the hospital | 0
     polyuria | -168
     polydipsia | -168
     weight loss | -168
     blood glucose 340 mg/dL | 0
     hemoglobin A1c 12.4% | 0
     not ketotic | 0
     aunt had T2D | -8760
     gastric ulcer disease | -8760
     4 miscarriages | -8760
     daughter born prematurely | -8760
     vesicoureteral reflux | -8760
     thyroid-stimulating hormone 0.01 | 0
     deranged liver function tests | 0
     hyperthyroidism | 0
     free triiodothyronine elevated | 0
     free thyroxine elevated | 0
     thyrotropin receptor autoantibodies positive | 0
     antithyroid peroxidase antibodies positive | 0
     Graves’ disease | 0
     carbimazole 60 mg/day | 0
     propranolol 20 mg 3× day | 0
     abdominal ultrasound unremarkable | 24
     viral and autoimmune hepatitis ruled out | 24
     Wilson’s disease ruled out | 24
     hemochromatosis ruled out | 24
     coeliac disease ruled out | 24
     liver elastography A0F0 | 24
     biochemical liver abnormalities attributed to hyperthyroidism or seronegative autoimmune hepatitis | 24
     type 1 diabetes diagnosis | 0
     basal bolus insulin therapy | 0
     no microvascular complications | 0
     weight gain | 720
     HbA1c 5.7% | 720
     hypoglycemic episodes | 720
     antiglutamate decarboxylase negative | 720
     anti-islet antigen 2 negative | 720
     diagnosis of T1D in doubt | 4320
     HLA typing | 4320
     protective HLA DRB1*15-DQB1*0602 haplotype | 4320
     type 2 diabetes diagnosis | 4320
     sulfonylurea | 4320
     hyperglycemia postprandial | 4320
     thyroid hormones normal | 4320
     thyrotropin receptor antibodies negative | 4320
     carbimazole stopped | 4320
     diabetes well controlled | 6048
     HbA1c 6.7-7.9% | 6048
     glimepiride 1-3 mg/day | 6048
     hypoglycemia | 6048
     liver function tests worsened | 6048
     autoimmune hepatitis ruled out | 7776
     coeliac disease ruled out | 7776
     biliary magnetic resonance imaging unremarkable | 7776
     liver biopsy normal | 7776
     ursodeoxycholic acid | 7776
     insulin glargine resumed | 8760
     HbA1c 12.4% | 8760
     dietary errors | 8760
     HbA1c 7.7% | 9072
     hypomagnesemia | 9504
     HNF1B-MODY diagnosis | 9504
     genetic testing | 9504
     complete heterozygous deletion of HNF1B gene | 9504
     diabetes poorly controlled | 11304
     HbA1c 9.2% | 11304
     glargine 14 units | 11304
     glimepiride 4 mg | 11304
     renal assessment | 11304
     serum creatinine 54 µmol/L | 11304
     microalbuminuria | 11304
     normal renal morphology | 11304
     test meal | 11304
     C peptide levels 0.181 nmol/L and 0.654 nmol/L | 11304
     normal fecal chymotrypsin and elastase levels | 11304
     pancreatic magnetic resonance imaging unremarkable | 11304
     pelvic ultrasonography normal | 11304
     liver function tests persistent cholestasis and cytolysis | 11304
     liraglutide | 11616
     repaglinide 4-1-2 mg | 11616
     HbA1c 6.7% | 11616
     hypoglycemia | 11616
     repaglinide dosage decreased | 11616
     HbA1c 6.6% | 11904
     liraglutide 1.2 mg | 11904
     repaglinide 1-0-1 mg | 11904
     weight 45 kg | 11904