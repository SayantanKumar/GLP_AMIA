 45 years old | 0
     female | 0
     presented to the ED | 0
     sudden onset of right flank pain | 0
     sweating | 0
     lightheadedness | 0
     fainting | 0
     syncope | 0
     recovered within a minute | 0
     brought to the ED by EMS | 0
     no history of fever | 0
     no vomiting | 0
     no falls | 0
     no urinary tract symptoms | 0
     no jerky movements | 0
     no post-event confusion | 0
     type 2 diabetes | -8760
     Semaglutide | -8760
     pulse 88/min | 0
     blood pressure 115/75 mmHg | 0
     respiratory rate 18/min | 0
     temperature 36.4 C | 0
     abdomen soft | 0
     mild tenderness in the right flank | 0
     mild tenderness in the costovertebral angle | 0
     hemoglobin 13.3 gm/dl | 0
     raised total leukocyte count | 0
     neutrophilic shift | 0
     urinalysis positive for red blood cells | 0
     urinalysis positive for hemoglobinuria | 0
     PoCUS performed | 0
     hyperechoic heterogeneous mass | 0
     anechoic region surrounding the right kidney | 0
     free fluid suggestive of hematoma | 0
     CT abdomen ordered | 1
     large heterogenous exophytic right renal mass | 1
     fat-density elements | 1
     soft tissue | 1
     prominent vessels | 1
     angiomyolipoma | 1
     large perinephric hematoma | 1
     tumor bleed | 1
     consultation with urology | 2
     consultation with interventional radiology | 2
     angioembolization | 3
     monitoring of hemoglobin levels | 3
     stable hemoglobin levels | 72
     no blood product transfusion | 72
     discharged | 72
     oral analgesics prescribed | 72