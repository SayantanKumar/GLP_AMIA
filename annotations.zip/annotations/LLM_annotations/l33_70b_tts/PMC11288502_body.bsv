 male | 0
54 years old | 0
type 2 diabetes mellitus | -6480
dyslipidemia | -6480
hypertension | -6480
coronary artery disease | -6480
percutaneous coronary intervention | -6480
recurrent ITP | -6480
metformin | -6480
empagliflozin | -6480
gliclazide | -6480
semaglutide | -6480
atorvastatin | -6480
amlodipine | -6480
losartan | -6480
metoprolol | -6480
aspirin | -6480
low ferritin levels | -720
ferrous gluconate | -720
decline in platelet count | -720
platelet count 223 x 10^9/L | -720
platelet count 89 x 10^9/L | 0
asymptomatic | 0
ITP diagnosis | -11880
gum bleeding | -11880
petechiae | -11880
bone marrow biopsy | -11880
corticosteroids | -11880
annual follow-ups | -11880
widespread petechiae | -5400
persistent epistaxis | -5400
upper respiratory tract infection | -5400
critically low platelet count | -5400
prednisone | -5400
intravenous immunoglobulin | -5400
tapering course of prednisone | -5400
ranitidine | -5400
iron deficiency anemia | -120
ferritin level 20.7ug/L | -120
prescribed ferrous gluconate | -120
platelet levels reduced significantly | 0
platelet levels 86x10^9/L | 0
cessation of ferrous gluconate | 0
platelet count increased | 240
platelet count 144 x 10^9/L | 240