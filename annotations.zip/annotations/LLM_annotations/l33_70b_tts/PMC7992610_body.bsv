 54 years old | 0
     male | 0
     type 2 diabetes | -6120
     exenatide extended-release injections | -840
     nodule on left thigh | -168
     physical examination | 0
     solitary 2-cm skin-colored nodule | 0
     tenderness | 0
     no pain | 0
     excised | 0
     histopathologic examination | 0
     lobular and septal panniculitis | 0
     fat necrosis | 0
     lymphohistiocytic cells | 0
     eosinophils | 0
     multinucleate giant cells | 0
     vacuoles | 0
     spaces | 0
     diagnosed with EP | 0
     changed to oral medication | 0
     no relapse | 1752
     discharged | 1752