 36 years old | 0
     female | 0
     hyperinsulinism hyperammonemia syndrome | -1814
     seizures | -1814
     hypoglycemia | -1814
     diazoxide | -1814
     low-protein diet | -1814
     family history of T2DM | 0
     acanthosis nigricans | 0
     body mass index 45.9 kg/m2 | 0
     mild elevation in serum ammonia level | 0
     continued diazoxide | 0
     lost to follow-up | 168
     weight gain | 168
     high carbohydrate intake | 168
     blood glucose levels 120-130 mg/dL | 168
     reduced diazoxide dose | 168
     counseled to reduce carbohydrate intake | 168
     missed follow-up appointments | 336
     random glucose level 238 mg/dL | 336
     HbA1c level 10% | 336
     diagnosed with T2DM | 336
     discontinued diazoxide | 336
     started metformin | 336
     glutamic acid decarboxylase antibodies <5 | 336
     C-peptide level 6.5 ng/mL | 336
     negative antipancreatic islet-cell antibodies | 336
     insulin level 69 μU/ml | 336
     genetic analysis | 336
     heterozygous pathogenic variant in GLUD1 gene | 336
     poor compliance with treatment and diet | 504
     HbA1c 9.5% | 504
     added semaglutide to therapy | 504
     decrease in HbA1c to 8.2% | 504
     weight loss of 10 lbs | 504