 61 years old | 0
     female | 0
     type II diabetes mellitus | 0
     semaglutide | -30
     glimepiride | 0
     hypertension | 0
     hyperlipidemia | 0
     lichen sclerosus | 0
     fibromyalgia | 0
     chronic gingivitis | 0
     rheumatoid arthritis | 0
     cyclobenzaprine | 0
     amitriptyline | 0
     hydroxychloroquine | 0
     oxycodone/paracetamol | 0
     atorvastatin | 0
     losartan | 0
     chlorhexidine oral rinse | 0
     clobetasol 0.05% cream | 0
     erythematous crusted lesion on breast | -30
     new crusted erosions of breast and lower back | 30
     worsening erythema and edema of gingivae | 30
     applied 2% ketoconazole cream | 20
     applied 2.5% hydrocortisone cream | 20
     skin biopsies | 30
     subepidermal vesiculation with brisk mixed dermal infiltrate | 30
     linear immunoglobulin G (IgG) reactivity | 30
     linear C3 staining along basement membrane | 30
     positive IgG4 epidermal localization on human split-skin substrate | 30
     elevated levels of anti-BP180 antibodies | 30
     discontinued semaglutide | 60
     marked improvement in cutaneous erosions | 120
     reduced inflammation of gingivae | 120
     mild gingival irritation | 1560
     repeated IIF titers | 1560
     elevated levels of anti-BP180 antibodies | 1560
     negative anti-BP230 antibody testing | 1560