 22 years old | 0
     female | 0
     type 2 diabetes mellitus | -672
     panhypopituitarism | -672
     craniopharyngioma | -672
     partial resection of craniopharyngioma | -672
     pituitary hormone substitution | -672
     hydrocortisone | -672
     thyroxine | -672
     oestradiol/norgestrel | -672
     growth hormone | -672
     nasal desmopressin | -672
     liraglutide | -672
     common cold | -168
     progressive leg pain | 0
     muscle weakness | 0
     polyuria | 0
     admission to emergency department | 0
     normal motor function | 0
     normal level of consciousness | 0
     afebrile | 0
     bodyweight 97 kg | 0
     BMI 35 kg/m2 | 0
     blood pressure 105/69 mmHg | 0
     heart rate 79 bpm | 0
     oxygen saturation 98% | 0
     urine output 3880 mL | 24
     severe hypernatraemia | 0
     moderate hypokalaemia | 0
     hyperglycaemia | 0
     increased serum osmolality | 0
     free water deficit 8.8 L | 0
     mild hyperchloraemic metabolic acidosis | 0
     normal anion gap | 0
     treatment with intravenous volume repletion | 0
     treatment with intravenous hydrocortisone | 0
     treatment with oral and IV potassium supplementation | 0
     treatment with subcutaneous insulin | 0
     transfer to intensive care unit | 10
     further fluid replacement | 10
     increase of IV insulin infusion | 10
     administration of IV desmopressin | 24
     normalization of serum sodium levels | 48
     decrease of urine output | 48
     discharge from hospital | 168
     full recovery | 168
     hyperosmolar hyperglycaemic state | 0
     central diabetes insipidus | 0
     Wolfram syndrome | -672
     DIDMOAD | -672
     pituitary metastases | -672
     hypoxic brain injury | -672
     idiopathic CDI | -672
     obesity | -672
     impaired sense of satiety | -672
     insulin resistance | -672
     upper airway infection | -168
     malabsorption of desmopressin | -168
     polyuria-induced tubular resistance to vasopressin | -168
     impaired sensation of thirst | -672
     chronic hypernatraemia | -672
     under-dosing of desmopressin | -672
     treatment malcompliance | -672