 60 years old | 0
     female | 0
     metabolic syndrome | -12000
     obesity | -12000
     weight gain | -12000
     bariatric surgery | -12000
     laparoscopic gastric band | -3600
     laparoscopic gastric sleeve | -2400
     chronic back pain | -2400
     abdominal pain | -2400
     dyslipidaemia | -2400
     statin intolerance | -2400
     laparoscopic cholecystectomy | -2400
     revision bariatric surgery | 0
     mesenteric adhesions | 0
     shortening of the mesentery | 0
     interloop adhesions of the intestines | 0
     biopsy of the abnormal mesenteric tissue | 0
     reactive epithelial changes of the mesentery | 0
     diffuse intraepithelial lymphocytes | 0
     mesenteric panniculitis | 0
     abdominal CT scan | 0
     mildly prominent lymph nodes | 0
     central mesenteric fat infiltration | 0
     facial pain | 8760
     ocular symptoms | 8760
     facial disfigurement | 8760
     CT scan of the head | 8760
     left orbital enlargement | 8760
     osteochondromas | 8760
     MRI | 10512
     left FD of the zygoma | 10512
     ground glass appearance | 10512
     tamoxifen | 0
     venous thromboembolism | 0
     azathioprine | 0
     linaclotide | 0
     surveillance | 10512
     sleep apnoea | 0
     treatment for sleep apnoea | 0
     new onset hearing loss | 10512
     auditory nerve involvement | 10512
     abdominal CT scan | 10512
     hepatic steatosis | 10512
     diabetes type 2 | 10512
     semaglutide | 10512
     tirzepatide | 10512
     weight loss | 10512
     highly sensitive C-reactive protein | 0
     erythrocyte sedimentation rate | 0
     high-density lipoproteins cholesterol | 0
     triglycerides | 0
     LDL cholesterol | 0