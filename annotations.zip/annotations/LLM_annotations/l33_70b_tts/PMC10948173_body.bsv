 51 years old | 0
     male | 0
     Gulf War veteran | 0
     diabetes mellitus type II | 0
     alcohol use disorder | 0
     chronic pancreatitis | 0
     abdominal pain | -336
     abdominal distension | -336
     nausea | -336
     intermittent chills | -336
     quit alcohol use | -7560
     former smoker | 0
     denied recent travel | 0
     denied exposure to livestock | 0
     semaglutide | 0
     omeprazole | 0
     acetaminophen | 0
     last colonoscopy | -3456
     tachycardia | 0
     heart rate of 134 beats per minute | 0
     temperature of 100.4 F | 0
     blood pressure 130/96 mm Hg | 0
     100% oxygen saturation | 0
     firm and distended abdomen | 0
     tenderness to palpation | 0
     palpable hepatomegaly | 0
     white blood cell count of 13,360 cells/mm3 | 0
     neutrophilic predominance | 0
     thrombocytosis | 0
     hemoglobin 8.0 g/dL | 0
     ALT of 73 IU/L | 0
     AST of 171 IU/L | 0
     ALP 625 IU/L | 0
     total bilirubin of 1.9 mg/dL | 0
     direct bilirubin of 1.3 mg/dL | 0
     acute kidney injury | 0
     BUN 50 mg/dL | 0
     creatinine 1.2 mg/dL | 0
     lactic acidosis | 0
     elevated lactic acid of 5.2 mmol/L | 0
     multiple masses throughout the liver | 0
     partial splenic vein and portal vein thrombosis | 0
     no liver pathology on CT scan 6 months prior | -4320
     hepatomegaly | 0
     craniocaudal liver span in the mid clavicular line measuring up to 26 cm | 0
     multiseptated cystic hepatic masses | 0
     PVT | 0
     largest cystic lesion measured at 9.0 cm × 5.4 cm | 0
     IV cefepime | 0
     oral metronidazole | 0
     therapeutic IV heparin | 0
     bacterial and fungal blood cultures obtained | 0
     blood cultures did not reveal growth | 0
     laboratory testing negative for hepatitis A IgM | 0
     laboratory testing negative for hepatitis B core antibody IgM | 0
     laboratory testing negative for hepatitis B surface antigen | 0
     laboratory testing negative for hepatitis C antibody | 0
     laboratory testing negative for HIV antibody 1 and 2 | 0
     laboratory testing negative for Entamoeba histolytica IgG | 0
     laboratory testing negative for Echinococcus IgG antibody | 0
     CT-guided liver biopsy | 0
     aspiration of abscess material | 0
     H&E stain from the aspirate | 0
     inflamed and degenerating liver parenchyma | 0
     scant identifiable portal tracts | 0
     abundant fibrinopurulent inflammation | 0
     resultant cultures showed no growth | 0
     antibiotics changed to IV ampicillin-sulbactam and oral trimethoprim-sulfamethoxazole | 24
     16S PCR sent for next-generation sequencing | 24
     16S PCR analysis returned positive for F. nucleatum | 48
     patient passed away | 72
     cardiac arrest | 72