 36 years old | 0
     female | 0
     presented to the hospital | 0
     waxing and waning rash | -744
     rash affecting her axillae | -744
     rash affecting her inframammary area | -744
     burning pain | -744
     minimally pruritic | -744
     denied any systemic symptoms | -744
     denied oral lesions | -744
     obesity | 0
     nephrolithiasis | 0
     multivitamins | -744
     fish oil | -744
     levonorgestrel IUD | -744
     semaglutide injections | -744
     initiation of weekly injections of compounded semaglutide | -744
     visited urgent care | -744
     prescribed clotrimazole-betamethasone 1%/0.05% cream | -744
     prescribed ketoconazole 2% cream | -744
     prescribed hydrocortisone 2.5% cream | -744
     prescribed fluconazole 150 mg | -744
     ill-defined erythematous patches | 0
     minimal fine scale | 0
     lacking vesicles | 0
     lacking pustules | 0
     lacking satellite lesions | 0
     no lymphadenopathy | 0
     no mucosal lesions | 0
     potassium hydroxide examination was deferred | 0
     started on hydrocortisone 2.5% ointment | 0
     started on prednisone 40 mg | 0
     rash continued to spread | 240
     ongoing burning pain | 240
     stopped treatment | 240
     missing 2 consecutive doses of semaglutide | 240
     rash began resolving | 240
     rash reappeared | 264
     annular erythematous patches | 264
     prominent trailing scale | 264
     punch biopsy | 504
     subcorneal pustular dermatosis | 504
     parakeratosis | 504
     mild acanthosis | 504
     mild spongiosis | 504
     lymphocytic and neutrophilic infiltrate | 504
     periodic acid-Schiff stain was negative | 504
     diagnosis of AGEP sine pustules | 504
     Naranjo adverse drug reaction probability score was 9 | 504
     AGEP validation score of 6 | 504
     semaglutide was discontinued | 504
     eruption cleared | 720
     patch testing was considered | 720
     patch testing was deferred | 720