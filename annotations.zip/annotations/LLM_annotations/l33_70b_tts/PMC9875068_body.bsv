 72 years old | 0
     male | 0
     type 2 diabetes | -8760
     central obesity | -8760
     raised triglycerides | -8760
     raised blood pressure | -8760
     ileocecal resection for Crohn’s disease | -8760
     post-operative bile acid malabsorption | -8760
     CT of the abdomen | -1752
     no liver abnormalities | -1752
     participated in a clinical study | 0
     incidental finding of possible cirrhosis | 0
     referred to a hepatologist | 0
     physical examination | 0
     no cirrhosis stigmata | 0
     elevated levels of alanine aminotransferase | 0
     elevated levels of alkaline phosphate | 0
     elevated levels of gamma-glutamyl-transferase | 0
     normal aspartate aminotransferase | 0
     normal bilirubin | 0
     normal platelets | 0
     normal albumin | 0
     transient elastography | 0
     liver stiffness | 0
     Fib-4 score | 0
     fasting FibroScan | 24
     percutaneous liver biopsy | 24
     histology showed mild steatosis | 24
     histology showed inflammation | 24
     histology showed ballooning | 24
     histology showed fibrosis grade 4 | 24
     ruled out alcoholic cirrhosis | 24
     ruled out other liver diseases | 24
     lifestyle intervention | 168
     advice regarding diet | 168
     advice regarding physical activity | 168
     advice regarding alcohol intake | 168
     semaglutide treatment | 168
     atorvastatin treatment | 168
     empagliflozin treatment | 168
     decrease in BMI | 504
     decrease in HbA1c | 504
     decrease in total cholesterol | 504
     decrease in low-density lipoprotein | 504
     decrease in triglycerides | 504
     decrease in ALT | 504
     decrease in AST | 504
     decrease in liver stiffness | 504
     no signs of hepatic decompensation | 504