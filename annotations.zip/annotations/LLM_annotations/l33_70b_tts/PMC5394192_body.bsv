 36 years old | 0
     female | 0
     Filipino | 0
     severe psoriasis | -84
     psoriatic arthritis | -84
     abdominal pain | 0
     abdominal swelling | 0
     fevers | 0
     weight loss | 0
     living in Ireland | -5760
     moved to Ireland | -5760
     last visited Philippines | -336
     narrow-band ultraviolet B phototherapy | -240
     cyclosporine | -240
     methotrexate | -240
     etanercept | -240
     adalimumab | -240
     investigated for TB | -84
     chest radiograph normal | -84
     tuberculin purified protein derivative skin test positive | -84
     isoniazid treatment | -84
     pyridoxine treatment | -84
     ulcerated hyperkeratotic plaque | -24
     multiple biopsies | -24
     noncaseating granulomas | -24
     skin biopsy normal | -24
     polymerase chain reaction negative | -24
     deterioration in renal function | -24
     interstitial nephritis | -24
     eosinophilia | -24
     oral corticosteroids | -24
     adalimumab discontinued | -24
     plaque resolved | -12
     psoriasis flared | -12
     ustekinumab treatment started | -12
     QuantiFERON-TB Gold test normal | -12
     chest radiograph normal | -12
     urine β human chorionic gonadotrophin test positive | 0
     ultrasound scan of abdomen | 0
     ectopic pregnancy considered | 0
     laparotomy | 0
     chronic inflammatory bowel deposits | 0
     omental caking | 0
     abdominal and pelvic adhesions | 0
     peritoneal tuberculosis | 0
     acid-fast bacilli present | 0
     ustekinumab treatment discontinued | 0
     empiric treatment for M tuberculosis started | 0
     rifampacin treatment | 0
     isoniazid treatment | 0
     pyrazinamide treatment | 0
     ethambutol treatment | 0
     pyridoxine treatment | 0
     polymerase chain reaction positive | 0
     M tuberculosis complex | 0
     rifampacin sensitive | 0
     ethambutol treatment discontinued | 0
     mycobacterial culture confirmed | 0
     abdominal pain settled | 24
     treatment for peritoneal TB | 24
     psoriasis flared | 144
     narrow-band ultraviolet B phototherapy failed | 144
     PsA flare | 144
     intralesional corticosteroid injection | 144
     prednisolone treatment | 144
     psoriasis unstable | 168
     admitted to hospital | 168
     liraglutide treatment started | 168
     intensive topical therapy | 168
     erythrodermic | 168
     hypotensive | 168
     high-dependency unit | 168
     cyclosporine treatment started | 168
     secukinumab treatment started | 168
     psoriasis cleared | 216
     joint pain settled | 216
     cyclosporine treatment withdrawn | 216
     discharged home | 216
     psoriasis and PsA under control | 432