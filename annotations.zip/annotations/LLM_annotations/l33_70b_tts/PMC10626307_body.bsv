 58 years old | 0
     female | 0
     admitted to the emergency department | 0
     dyspnea | 0
     bilateral flank pain | 0
     pallor | 0
     clamminess | 0
     blood pressure 170/120 mmHg | 0
     heart rate 120 beats/min | 0
     body temperature 38.2°C | 0
     respiration rate 30 breaths/min | 0
     oxygen saturation 89% | 0
     body mass index 25.1 kg/m2 | 0
     phendimetrazine tartrate for weight loss | -12000
     crackles in the right lung field | 0
     abdomen soft without tenderness | 0
     elevated CRP | 0
     elevated ESR | 0
     leukocytosis | 0
     normocytic anemia | 0
     normal platelet count | 0
     acute kidney injury | 0
     liver injury | 0
     mixed metabolic-respiratory acidosis | 0
     elevated lactate levels | 0
     bilateral diffuse infiltrations | 0
     round mass lesion in the left paravertebral area | 0
     sedated | 0
     intubated | 0
     admitted to the intensive care unit | 0
     broad-spectrum antibiotics | 0
     mechanical ventilation | 0
     rapid resolution of the lung infiltrations | 24
     high fever | 0
     uncontrolled hypertension | 0
     elevated troponin-I | 0
     elevated creatinine kinase | 0
     elevated NT-proBNP | 0
     hypokinetic mid inferior and apical segments | 0
     reduced left ventricular ejection fraction | 0
     referred to an endocrinologist | 0
     extra-adrenal mass | 0
     clinical signs and symptoms suggesting PPGL | 0
     elevated 24-hour urinary metanephrine | 0
     elevated plasma norepinephrine | 0
     elevated plasma normetanephrine | 0
     normal plasma epinephrine | 0
     normal plasma metanephrine | 0
     elevated plasma IL-6 | 0
     18F-fluorodeoxyglucose PET/CT | 0
     increased uptake in the left paravertebral mass | 0
     no metastases | 0
     diagnosis of functional paraganglioma | 0
     preoperative alpha-blockers | -408
     body temperature normalized | -408
     blood pressure well controlled | -408
     open excision of the retroperitoneal mass | 0
     excised tumor 4.3×3.5×3.7 cm3 | 0
     well encapsulated | 0
     prominent cell-nesting pattern | 0
     round to ovoid nuclei | 0
     abundant basophilic granular cytoplasm | 0
     diffuse positive staining of chromogranin A | 0
     postoperative complications | 0
     inflammatory, cardiac, renal, and hepatic biomarkers improved | 96
     24-hour urinary metanephrine levels decreased | 96
     replaced phendimetrazine tartrate with a glucagon-like peptide-1 receptor agonist | 96
     follow-up abdominal CT | 312
     no evidence of recurrence or distant metastases | 312
     asymptomatic during the follow-up visits | 312