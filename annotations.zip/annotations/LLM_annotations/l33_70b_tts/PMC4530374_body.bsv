 54 years old | 0
     female | 0
     type 2 diabetes | -8760
     morbid obesity | -8760
     BMI 42 kg/m2 | -8760
     laparoscopic gastric bypass | 0
     biliopancreatic limb | 0
     post-prandial episodes of sweating | 17520
     fainting | 17520
     hypoglycemia | 17520
     capillary blood glucose <50 mg/dl | 17520
     stabilized BMI of 30 kg/m2 | 17520
     type 2 diabetes in clinical remission | 10440
     abdominal ultrasound | 17520
     solid mass in the pancreatic head | 17520
     abdominal CT scan | 17520
     octreotide scan | 17520
     focus of abnormal uptake of the radiotracer | 17520
     laboratory glucose | 17520
     insulin | 17520
     plasma chromogranin A levels | 17520
     72-h fast test | 17520
     laparoscopic enucleation of the pancreatic nodule | 17520
     pancreatic nodule | 17520
     intraoperative pancreatic ultrasound | 17520
     postoperative period | 17544
     complete remission of the hypoglycemic episodes | 17544
     histology of the surgical specimen | 17544
     pseudoglandular neuroendocrine neoplasia | 17544
     CAM 5.2 | 17544
     chromogranin A | 17544
     synaptophysin | 17544
     glucagon | 17544
     GLP1 | 17544
     low Ki-67 | 17544
     mitotic index | 17544
     low-grade well-differentiated neuroendocrine tumor | 17544
     PET-68aGa-SRP | 17544
     frozen tumor sample | 17544
     peptide hormone levels | 17544
     glucagon | 17544
     GLP1 | 17544
     insulin | 17544
     somatostatin | 17544
     tumor peptide content analysis | 17544
     discharge | 17568