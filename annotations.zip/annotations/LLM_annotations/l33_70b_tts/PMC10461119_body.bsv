 67 years old | 0
     male | 0
     Hispanic | 0
     admitted to the hospital | 0
     diabetes mellitus | -9360
     insulin | -9360
     metformin | -9360
     dulaglutide | -9360
     interstitial cystitis (IC) | -9360
     pentosan polysulfate sodium (PPS) | -9360
     bilateral RPE detachments | 0
     best-corrected visual acuity (BCVA) of 20/32 | 0
     intraocular pressures of 18 and 20 mmHg | 0
     nuclear sclerosis (NC2NO1) | 0
     yellow deposits | 0
     retinal pigment epithelium (RPE) mottling | 0
     fundus pseudocolor imaging | 0
     fundus autofluorescence (FAF) | 0
     near-infrared reflectivity imaging | 0
     macular SD-OCT | 0
     subretinal vitelliform lesions | 0
     hyperreflective elevations | 0
     Bruch's membrane and RPE reflectivity | 0
     RPE thickening | 0
     hyperreflective nodular elevations | 0
     discontinued taking PPS | 0
     referred to the Inherited Retinal Disease (IRD) clinic | 0
     reduced BCVA of 20/50 | 168
     SD-OCT | 168
     multifocal electroretinogram (mfERG) | 168
     full-field electroretinogram (ffERG) | 168
     microperimetry | 168
     exome IRD testing | 168
     genetic testing | 168
     reduced BCVA to 20/60 | 504
     microperimetry | 504
     FAF | 504
     SD-OCT | 504
     resolution of the vitelliform deposits | 504
     nodular excrescences | 504
     plaque-like lesion | 504
     disrupted ellipsoid zone | 504
     intact external limiting membrane (ELM) | 504