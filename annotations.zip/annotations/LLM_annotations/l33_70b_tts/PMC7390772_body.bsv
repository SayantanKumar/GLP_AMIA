 37 years old | 0
     male | 0
     LASIK | -4320
     ectasia | -2160
     penetrating keratoplasty (PKP) | -2160
     type 2 diabetes mellitus | 0
     obesity | 0
     obstructive sleep apnea | 0
     liraglutide | 0
     lorcaserin | 0
     acutely elevated intraocular pressure | -1300
     Baerveldt glaucoma drainage implant | -1300
     scleral contact lens (SCL) | -1300
     uncomfortable SCL | -624
     left eye pain | -624
     dorzolamide/timolol | -624
     loteprednol | -624
     artificial tears | -624
     left-sided headaches | -624
     redness | -416
     swelling | -416
     waxing and waning retrobulbar ache | -416
     burning sensation | -416
     increasing pain severity | -336
     limiting normal work functions | -336
     interfering with sleep | -336
     evaluation by cornea subspecialist | -336
     evaluation by uveitis subspecialist | -336
     evaluation by oculoplastics subspecialist | -336
     evaluation by optometric subspecialist | -336
     magnetic resonance imaging (MRI) | -336
     enlarged left lacrimal gland | -336
     uveitis work-up examination | -336
     tenderness over aqueous shunt bleb | -336
     ibuprofen | -336
     fluorometholone | -336
     oral prednisone | -336
     gabapentin | -168
     pain reduced | -168
     able to tolerate SCL | -168
     discharged | 0