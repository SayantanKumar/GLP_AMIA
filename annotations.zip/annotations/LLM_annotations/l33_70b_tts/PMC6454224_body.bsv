 45 years old | 0
     male | 0
     white | 0
     carpenter | 0
     referred to bariatric clinic | 0
     severe obesity | 0
     poorly controlled type 2 diabetes | 0
     10-year duration of type 2 diabetes | -8760
     well-controlled hypertension | 0
     well-controlled dyslipidaemia | 0
     stable non-alcoholic steatohepatitis | 0
     basal bolus insulin regime | 0
     insulin aspart 20 units | 0
     insulin aspart 18 units | 0
     insulin aspart 22 units | 0
     insulin glargine 40 units | 0
     total insulin dose 100 units per day | 0
     metformin 500 mg | 0
     metformin 500 mg three times daily | 0
     ramipril 2.5 mg | 0
     ramipril 2.5 mg once daily | 0
     simvastatin 30 mg | 0
     simvastatin 30 mg once daily | 0
     aspirin 75 mg | 0
     aspirin 75 mg once daily | 0
     no alcohol consumption | 0
     stopped smoking | -120
     26 pack year smoking history | -120
     family history of type 2 diabetes | 0
     single | 0
     lives with two siblings | 0
     persistently elevated glucometer readings | 0
     thirst | 0
     polydipsia | 0
     polyuria | 0
     nocturia | 0
     weight 113.8 kg | 0
     height 168.2 cm | 0
     BMI 40.2 kg/m2 | 0
     waist 117 cm | 0
     hip 120 cm | 0
     waist-to-hip ratio 0.98 | 0
     blood pressure 105/62 mmHg | 0
     no retinopathy | 0
     no neuropathy | 0
     no cutaneous markers of insulin resistance | 0
     HbA1c 72 mmol/mol | 0
     HbA1c 8.7% | 0
     lipid profile excellent | 0
     total cholesterol 3.3 mmol/L | 0
     LDL 0.8 mmol/L | 0
     HDL 1.0 mmol/L | 0
     triglycerides 1.9 mmol/L | 0
     liver profile normal | 0
     iron studies normal | 0
     renal function normal | 0
     thyroid function normal | 0
     ECG normal | 0
     right bundle branch block | 0
     declined laparoscopic sleeve gastrectomy | 0
     declined GLP1 agonist therapy | 0
     no underlying psychiatric or psychological disorder | 0
     assessed by bariatric dietician | 0
     advised on healthy eating | 0
     large intake of sugary snacks | 0
     large intake of starchy carbohydrates | 0
     started milk-based LELD | 0
     basal metabolic rate 1983 kcal | 0
     semi-skimmed milk 2.2 L | 0
     semi-skimmed milk 1012 kcal | 0
     semi-skimmed milk 75 g protein | 0
     semi-skimmed milk 36 g fat | 0
     semi-skimmed milk 113 g carbohydrate | 0
     multivitamin and mineral supplement | 0
     fibre supplement | 0
     sodium replacement | 0
     fortnightly clinical assessments | 0
     weight loss phase | 0
     weight stabilisation phase | 168
     weight maintenance phase | 336
     improved diet | 840
     improved glycaemic control | 840
     weight gain 1.6 kg | 840
     weight 115.2 kg | -840
     BMI 40.7 kg/m2 | -840
     weight 101.2 kg | 168
     BMI 35.8 kg/m2 | 168
     weight 94.6 kg | 504
     BMI 33.4 kg/m2 | 504
     insulin titrated downwards | 168
     insulin stopped | 168
     glucometer readings normalised | 168
     HbA1c normalised | 168
     weight regain 2.2 kg | 1008
     HbA1c 48 mmol/mol | 1008
     HbA1c normal | 1008
     weight 92.6 kg | 1512
     BMI 32.7 kg/m2 | 1512
     HbA1c 104 mmol/mol | 1512
     poor glycaemic control | 1512
     metformin increased to 1 g twice daily | 1512
     linagliptin 5 mg once daily | 1512
     canagliflozin 100 mg once daily | 1512
     HbA1c improved | 2268
     weight 100.4 kg | 2268
     BMI 35.5 kg/m2 | 2268
     patient felt well | 2268