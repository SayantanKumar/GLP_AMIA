 52 years old | 0
     female | 0
     moderately overweight | 0
     BMI 29 kg/m2 | 0
     severe reflux disease | 0
     laparoscopic Toupet fundoplication | 0
     episodes of severe symptomatic late dumping syndrome | -12
     hypoglycemic symptoms | -12
     palpitations | -12
     nausea | -12
     sweating | -12
     weakness | -12
     collapse | -12
     no history of diabetes | 0
     no hypoglycemic symptoms before operation | 0
     clinical evaluation | -12
     blood tests | -12
     functional X-ray examination | -12
     upper endoscopy | -12
     magnetic resonance imaging of the upper abdomen | -12
     diagnosis of symptomatic hyperinsulinemic hypoglycemia | -12
     Sigstad score questionnaire | -12
     oral glucose tolerance test (OGTT) | -12
     continuous glucose measurement (CGM) | -12
     dietary changes | -12
     administration of acarbose | -12
     treatment failure | -12
     liraglutide treatment | -10
     informed consent | -10
     liraglutide dosage 0.6 mg per day | -10
     OGTT and CGM at week 2 | -8
     marginal improvement in subjective hypoglycemic symptoms | -8
     fasting glucose level 88 mg/dL | -8
     fasting insulin level 19.3 μU/mL | -8
     peak insulin level 311 μU/mL | -8
     peak glucose level 155 mg/dL | -8
     hypoglycemic glucose level 48 mg/dL | -8
     liraglutide dosage increased to 1.2 mg/day | -6
     OGTT and CGM at week 4 | -4
     fasting insulin level 10.7 μU/mL | -4
     fasting glucose level 83 mg/dL | -4
     peak insulin level 413 μU/mL | -4
     glucose level remained above 66 mg/dL | -4
     84% of glucose values reached target normoglycemia level | -4
     patient remains free of symptoms | 0