 binge eating | 0\
     loss of control | 0\
     Binge Eating Disorder (BED) | 0\
     bulimia nervosa (BN) | 0\
     cognitive-behavioral therapy (CBT) | 0\
     selective serotonin reuptake inhibitors (SSRIs) | 0\
     Topiramate | 0\
     Lisdexamfetamine (LDX) | 0\
     glucagon-like peptide-1 receptor agonists (GLP-1RAs) | 0\
     GLP-1 | 0\
     appetite control | 0\
     food intake | 0\
     weight loss | 0\
     Liraglutide | 0\
     Exenatide | 0\
     Lixisenatide | 0\
     Semaglutide | 0\
     Dulaglutide | 0\
     eating disorder | 0\
     BED diagnosis | 0\
     BN diagnosis | 0\
     binge eating episodes | 0\
     purging | 0\
     obesity | 0\
     metabolic comorbidities | 0\
     diabetes | 0\
     hypertension | 0\
     hypertriglyceridemia | 0\
     high triglycerides | 0\
     Barrera et al study | 0\
     Sabine Naessén et al study | 0\
     GLP-1RAs side effects | 0\
     nausea | 0\
     vomiting | 0\
     diarrhea | 0\
     hypoglycemia | 0\
     Liraglutide study | 0\
     Semaglutide study | 0\
     Dulaglutide study | 0\
     Exenatide study | 0\
     Lixisenatide study | 0\
     GLP-1RA treatment | 0\
     cognitive behavioral therapy | 0\
     medication treatment | 0\
     SSRIs treatment | 0\
     future research | 0\
     limitations of studies | 0\
     small sample sizes | 0\
     short durations | 0\
     lack of head-to-head comparisons | 0\
     animal studies | 0\
     behavioral therapy | 0\
     pharmacological treatments | 0\
     GLP1-RAs comparison | 0\
     conclusion | 0\
     BED and BN treatment | 0\
     GLP1-RAs efficacy | 0\
     GLP1-RAs safety | 0\
     optimal dosing | 0\
     treatment duration | 0\
     patient responder subgroups | 0\
     side effect monitoring | 0\
     GLP1-RAs comparison to existing options | 0\
     CRediT authorship contribution statement | 0\
     Laurence Aoun | 0\
     Shaza Almardini | 0\
     Fares Saliba | 0\
     Fadi Haddadin | 0\
     Omar Mourad | 0\
     Jennifer Jdaidani | 0\
     Zeina Morcos | 0\
     Ibrahim Al Saidi | 0\
     Elie Bou Sanayeh | 0\
     Saliba Saliba | 0\
     Michel Almardini | 0\
     Julie Zaidan | 0\
     Declaration of competing interest | 0\
     Fig. A | 0\
     Fig. B | 0\
     Fig. C | 0