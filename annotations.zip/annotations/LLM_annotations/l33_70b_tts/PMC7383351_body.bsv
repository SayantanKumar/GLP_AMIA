 60 years old | 0
     female | 0
     admitted to the hospital | 0
     dyspnea on moderate exertion | -168
     denied chest pain | -168
     denied palpitations | -168
     denied orthopnea | -168
     denied lower leg edema | -168
     denied paroxysmal nocturnal dyspnea | -168
     denied syncope | -168
     type 2 diabetes mellitus | -8760
     essential arterial hypertension | -8760
     dyslipidemia | -8760
     untreated asymptomatic stable pulmonary sarcoidosis | -4380
     resected epidermoid carcinoma of the tongue | -4380
     bisoprolol | -4380
     acetylsalicylic acid | -4380
     atorvastatine | -4380
     metformin | -4380
     gliquidone | -4380
     dulaglutide | -4380
     no family history of sudden cardiac death | 0
     no recent severe illness | 0
     no respiratory symptoms | 0
     temperature of 37.2 °C | 0
     blood pressure of 130/70 mmHg | 0
     heart rate of 50 beats/min | 0
     oxygen saturation of 97% on room air | 0
     no jugular vein distention | 0
     no carotid bruit | 0
     peripheral pulses were present and equal | 0
     no skin lesions | 0
     heart rate was regular | 0
     occasional premature beat | 0
     first and second heart sounds were heard | 0
     no murmurs | 0
     no rubs | 0
     no gallops | 0
     lung and abdomen exams were unremarkable | 0
     no lower leg edema | 0
     elevated level of glycated hemoglobin | 0
     normal levels of potassium | 0
     normal cardiac ultrasensitive troponin | 0
     normal thyroid findings | 0
     angiotensin converting enzyme levels were within normal range | 0
     regular sinus rhythm with prolonged PR interval | 0
     QTc at 450 ms | 0
     exercise stress test | 24
     multifocal ventricular extrasystoles | 24
     self-limiting TdP | 24
     increase in bisoprolol | 24
     stopped dulaglutide | 24
     admitted to the hospital for diagnostic coronary angiography | 48
     stable 40%-50% mid-left anterior descending plaque | 48
     cardiac continuous monitoring | 48
     ectopic supraventricular beats | 48
     polymorphic ventricular extrasystoles | 48
     intermittent type I second degree atrioventricular block | 48
     cardiac electrophysiology study | 72
     induced sustained monomorphic ventricular tachycardia | 72
     cardiac magnetic resonance imaging | 96
     nondilated and normotrophic left ventricle | 96
     basoseptal and mid-septal dyskinesis | 96
     MRI-derived left ventricular ejection fraction was 45% | 96
     delayed enhancement showed patchy transmural fibrosis of the septum | 96
     hyperenhancement of the papillary muscles | 96
     whole-body positron emission tomography | 120
     no myocardial uptake | 120
     final diagnosis of CS with pulmonary sarcoidosis in remission | 120
     double-chamber implantable cardiac defibrillator | 144
     methylprednisolone | 144
     methotrexate | 144
     episodes of asymptomatic nonsustained ventricular tachycardia | 168
     asymptomatic episode of nonsustained ventricular tachycardia | 168
     antitachycardia pacing run | 168