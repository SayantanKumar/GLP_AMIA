 37 years old | 0
     female | 0
     obesity | 0
     hypertension | 0
     hypercholesterolemia | 0
     elevated liver enzymes | 0
     denied nausea | 0
     denied vomiting | 0
     denied abdominal distension | 0
     denied jaundice | 0
     denied episodes of confusion | 0
     normal physical examination | 0
     denied supplement use | 0
     denied excessive alcohol use | 0
     denied family history of autoimmune disease | 0
     ethinyl estradiol 0.15 mg/levonorgestrel 30 mg | -8760
     tirzepatide | -60
     weight loss 30 pounds | -60
     ALT level 500 U/L | 0
     AST level 261 U/L | 0
     hepatitis serologies unremarkable | 0
     antinuclear antibody level unremarkable | 0
     antimitochondrial antibody level unremarkable | 0
     ceruloplasmin level unremarkable | 0
     alpha-1 antitrypsin level unremarkable | 0
     anti-smooth muscle antibody level 37 | 0
     abdominal ultrasound normal | 0
     tirzepatide discontinued | 0
     ALT level 110 U/L | 504
     AST level 57 U/L | 504
     tirzepatide resumed | 504
     ALT level 184 U/L | 1008
     AST level 104 U/L | 1008
     liver biopsy | 1008
     benign hepatic tissue | 1008
     lymphocytic infiltration | 1008
     macrophage infiltration | 1008
     no steatosis | 1008
     no bile duct injury | 1008
     no bile duct proliferation | 1008
     no interface hepatitis | 1008
     no necrosis | 1008
     RUCAM score 5 | 1008
     diagnosis of DILI | 1008
     tirzepatide not reinitiated | 1008
     ALT level 36 U/L | 2592
     AST level 24 U/L | 2592
     semaglutide initiated | 2592
     normal liver enzyme levels | 3456