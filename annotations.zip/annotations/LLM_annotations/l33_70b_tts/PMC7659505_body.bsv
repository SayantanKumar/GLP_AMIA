 51 years old | 0
     female | 0
     admitted to the hospital | 0
     type 2 diabetes | -7488
     hypertension | -624
     hypercholesterolemia | 0
     rheumatic disease | 0
     depression | 0
     borderline personality disorder | 0
     normal birth weight | -48960
     extreme hunger | -48960
     obesity | -48960
     gastric bypass operation | -4032
     weight loss of 40 kg | -4032
     weight regain | -208
     pathogenic MC4R mutation | 0
     liraglutide treatment | 0
     weight loss of 9.7 kg | 112
     reduced fasting plasma glucose | 112
     reduced fasting insulin | 112
     reduced HbA1c | 112
     reduced triglycerides | 112
     improved glucose tolerance | 112
     reduced systolic blood pressure | 112
     reduced diastolic blood pressure | 112
     reduced pulse | 112
     nausea | 24
     stomach pain | 24
     reduced hunger | 24
     increased satiety | 24
     liraglutide injection | 0
     oral glucose tolerance test | 0
     dual energy X-ray absorptiometry | 0
     plasma analyses | 0
     genotyping | 0
     sequencing | 0
     data analysis | 0
     study completion | 1120