 35 years old | 0
     male | 0
     no medical illness | 0
     presented for medical weight-loss management | 0
     Liraglutide 0.6 mg | -168
     low-calorie diet | -168
     mild exercise | -168
     weight 118 kg | -168
     height 171 cm | -168
     body mass index (BMI) 40.4 | -168
     Liraglutide 1.2 mg | -112
     Liraglutide 1.8 mg | -56
     Liraglutide 2.4 mg | 0
     Liraglutide 3.0 mg | 168
     weight 102 kg | 360
     body mass index (BMI) 34.9 | 360
     13.55% weight loss | 360
     no remarkable blood analysis | 360
     no remarkable urine analysis | 360
     no remarkable lipid profile | 360
     no remarkable liver function tests | 360
     CBC WBC 6.62×10^9/L | -168
     CBC Platelets 296×10^9/L | -168
     CBC Hb (g/dL) 16.1 | -168
     Fasting glucose (mmol/L) 5.5 | -168
     Urea (mmol/L) 4.5 | -168
     Creatinine (µmol/L) 65 | -168
     Uric acid (µmol/L) 341 | -168
     Cholesterol (mmol/L) 5.2 | -168
     Triglycerides (mmol/L) 1.1 | -168
     Sodium (mmol/L) 133 | -168
     Potassium (mmol/L) 4.5 | -168
     Chloride (mmol/L) 101 | -168
     Total bilirubin (µmol/L) 26 | -168
     AST (IU/L) 36 | -168
     ALT (IU/L) 51 | -168
     ALP (IU/L) 60 | -168
     CBC WBC 6.2×10^9/L | 360
     CBC Platelets 300×10^9/L | 360
     CBC Hb (g/dL) 15.8 | 360
     Fasting glucose (mmol/L) 5.1 | 360
     Urea (mmol/L) 5.5 | 360
     Creatinine (µmol/L) 67 | 360
     Uric acid (µmol/L) 339 | 360
     Cholesterol (mmol/L) 5.1 | 360
     Triglycerides (mmol/L) 1 | 360
     Sodium (mmol/L) 138 | 360
     Potassium (mmol/L) 3.8 | 360
     Chloride (mmol/L) 105 | 360
     Total bilirubin (µmol/L) 20 | 360
     AST (IU/L) 36 | 360
     ALT (IU/L) 40 | 360
     ALP (IU/L) 65 | 360