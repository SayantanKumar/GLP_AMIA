 75 years old | 0
     female | 0
     admitted to the hospital | 0
     shortness of breath | -1280
     chest pressure | -1280
     left pleural effusion | -1280
     LAA closure with Watchman device | -1280
     paroxysmal atrial fibrillation | -1280
     hypertension | -1280
     dyslipidemia | -1280
     diabetes mellitus type 2 | -1280
     chronic kidney disease | -1280
     aspirin | -1280
     bisoprolol | -1280
     evolocumab | -1280
     ferrous sulfate | -1280
     fluoxetine | -1280
     gabapentin | -1280
     rosuvastatin | -1280
     semaglutide | -1280
     furosemide | -1280
     subjective fevers | -1280
     weight loss | -1280
     lack of appetite | -1280
     emergency department visits | -1280
     prior hospitalization | -1280
     thoracenteses | -1280
     clear fluid from left pleural space | -1280
     chest radiograph | 0
     reaccumulation of left pleural effusion | 0
     placement of chest tube | 0
     drainage of clear yellow exudative pleural fluid | 0
     lymphocyte predominance | 0
     pleural fluid analysis | 0
     white blood cells 425 cells/μl | 0
     right blood cells 7,123 cells/μl | 0
     neutrophils 12% | 0
     lymphocytes 50% | 0
     eosinophils 1% | 0
     total protein 3.8 g/dl | 0
     glucose 176 mg/dl | 0
     cultures negative for any infection | 0
     cytology negative for any malignant cells | 0
     chronic anemia | 0
     elevated high-sensitivity C-reactive protein | 0
     chest computed tomography | 0
     multiple sub-centimeter lung nodules | 0
     positron emission tomography scan | 0
     small-size pericardial effusion | 0
     left ventricular ejection fraction preserved | 0
     no signs of restriction or constriction on echocardiography | 0
     transesophageal echocardiogram | 0
     Watchman device seated in LAA | 0
     small 1-mm leak through the device | 0
     cardiac CT with contrast | 0
     occlusive device in LAA | 0
     passage of contrast into distal portion of LAA | 0
     no passage of contrast into pericardial or pleural spaces | 0
     pericarditis | 0
     recurrent left pleural effusion | 0
     nonsteroidal anti-inflammatory drugs | 0
     colchicine | 0
     symptoms improvement | 72
     predischarge chest radiograph | 72
     left basilar atelectasis | 72
     no reaccumulation of left pleural effusion | 72
     chest tube removal | 72
     discharged | 72
     follow-up phone call | 504
     resolution of symptoms | 504
     intermittent chest pain | 504
     repeat chest CT scans | 504
     unchanged small left pleural effusion | 504
     trace pericardial effusion | 504
     NSAIDs as needed | 504
     relief of chest pain | 504
     complete resolution of symptoms | 1344
     resumed daily activities | 1344