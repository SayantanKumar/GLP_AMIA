 32 years old | 0
     male | 0
     Japanese | 0
     MADD | -8760
     hypoglycemia | -8760
     hyperammonemia | -8760
     metabolic acidosis | -8760
     loss of consciousness | -8760
     urinary organic acid profiles | -8760
     hypoketotic | -8760
     dicarboxylic aciduria | -8760
     ethylmalonic acid | -8760
     2-hydroxyglutaric acid | -8760
     isovaleric glycine | -8760
     genetic analysis | -8760
     ETFA gene | -8760
     compound heterozygous pathogenic variants | -8760
     c.[478del];[764G > T] | -8760
     p.[(Asp160Metfs*4)];[(Gly255Val)] | -8760
     dietary therapy | -8760
     riboflavin | -8760
     levocarnitine | -8760
     high-carbohydrate diet | -8760
     low-fat diet | -8760
     low-protein diet | -8760
     frequent meals | -8760
     avoidance of prolonged fasting | -8760
     episodes of hypoglycemia | -8760
     polydipsia | -30
     polyuria | -30
     muscle spasms | -30
     fatigue | -30
     decreased appetite | -30
     HbA1c | -30
     insulin | -30
     CPR | -30
     HOMA-R index | -30
     T2DM | -30
     physical labor | -30
     high energy intake | -30
     soft drink consumption | -30
     weight loss | -60
     BMI decrease | -60
     laboratory examination | 0
     postprandial blood glucose | 0
     HbA1c | 0
     total ketone bodies | 0
     3-hydroxybutyrate | 0
     serum cholinesterase | 0
     creatine kinase | 0
     urea nitrogen | 0
     creatinine | 0
     venous blood gas | 0
     urinalysis | 0
     insulin level | 0
     AST | 0
     ALT | 0
     GGT | 0
     acylcarnitine profile | 0
     CT scans | 0
     fatty liver | 0
     visceral fat area | 0
     subcutaneous fat area | 0
     intravenous saline | 0
     short-acting insulin infusion | 0
     intensive insulin therapy | 24
     insulin lispro | 24
     glargine | 24
     liraglutide | 24
     once-daily liraglutide injection | 264
     dietary management change | 264
     macronutrient composition | 264
     NAFLD | -720
     obesity | -720
     excessive sugar consumption | -720
     T2DM diagnosis | 0
     DKA-like symptoms | 0
     hypoketotic state | 0
     insulin resistance | 0
     hyperosmolar hyperglycemic syndrome | 0
     AST decrease | 0
     ALT decrease | 0
     GGT decrease | 0
     cholinesterase decrease | 0
     liver steatosis reduction | 0
     blood acylcarnitine profile | 0
     cellular energy insufficiency | 0
     fatty acid catabolism | 0
     flavoprotein | 0
     liver improvement | 0