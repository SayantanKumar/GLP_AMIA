 40 years old | 0\
     transgender woman | 0\
     hypertension | 0\
     prediabetes | 0\
     mixed hyperlipidemia | 0\
     nonalcoholic steatohepatitis | 0\
     gastroesophageal reflux | 0\
     solitary congenital kidney | 0\
     presented to an academic weight management program | 0\
     weight 280 pounds | 0\
     BMI 39.6 kg/m2 | 0\
     estradiol valerate 10 mg IM weekly | -156\
     spironolactone 50 mg | -156\
     weight stable at 240 pounds | -156\
     started micronized progesterone 100 mg orally nightly | -52\
     weight increased to 294 pounds | -12\
     lost 14 pounds | -1\
     eating mostly at fast food restaurants | 0\
     sweet cravings | 0\
     drinking multiple sugary beverages daily | 0\
     instructed to follow a lower calorie diet | 0\
     referred for a sleep study | 0\
     primary physical activity was walking at work | 0\
     body dysmorphia | 0\
     concerns about discrimination | 0\
     counseled on home exercises | 0\
     prescribed semaglutide 0.25 mg weekly | 0\
     experienced significant improvements in hunger and satiety | 4\
     dose escalated to semaglutide 1.0 mg weekly | 12\
     weighed 241 pounds | 12\
     BMI 34.1 kg/m2 | 12\
     hemoglobin A1c improved | 12\
     creatinine increased | 12\
     acute kidney injury | 12\
     AKI resolved with increased water consumption | 12\
     estradiol level increased | 12\
     referred to plastic surgeon to schedule surgery | 12\
     sleep study results consistent with moderate OSA | 12\
     started home resistance band training program | 12\
     discharged | 12\
     weight loss 13.9% | 12\
     BMI reduction 5.5 points | 12\
     qualified for breast augmentation | 12\
     required dose reduction in estrogen | 12\
     experienced weight gain after starting progesterone | -52\
     weight gain reversed after semaglutide treatment | 12\
     largest barriers to engaging in lifestyle modification were body dysmorphia and fear of discrimination | 0\
     internalized transphobia | 0\
     negative expectations | 0\
     victimization | 0\
     inadequate changing rooms | 0\
     desired body contour | 0\
     health care providers must individually tailor physical activity recommendations | 0