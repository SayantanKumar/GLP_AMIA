 55 years old | 0
     male | 0
     relapsing-remitting multiple sclerosis | -8760
     methylprednisolone treatment | -720
     methotrexate | -720
     Tripterygium wilfordii | -720
     numbness in hands | -720
     hiccups | -720
     demyelination in C1 and C3 spinal cord | -720
     demyelination and marrow edema in T7 spinal cord | -720
     fasting blood glucose level 8.0 mmol/L | -720
     fasting blood glucose level 13.0 mmol/L | -144
     HbA1c level 12.4% | -144
     admitted to hospital | 0
     poor glycemic control | 0
     high body mass index | 0
     body weight 85 kg | 0
     body temperature 36.5 °C | 0
     blood pressure 124/75 mmHg | 0
     pulse 75 beats/minute | 0
     hyperinsulinemia | 0
     severe insulin resistance | 0
     oral glucose tolerance test | 0
     diammonium glycyrrhizinate enteric-coated capsules | 0
     insulin aspart 60 U/day | 0
     insulin glargine 26 U/day | 0
     liver enzyme abnormalities | 0
     ALT 178 U/L | 0
     AST 198 U/L | 0
     γ-GTP 265 U/L | 0
     insulin allergy | 72
     wheals with redness and itching | 72
     hypereosinophilia | 72
     high total IgE level | 72
     eosinophilic infiltration | 72
     switched to insulin lispro | 72
     induration at insulin injection sites | 120
     metformin 1.5 g/day | 168
     liraglutide 0.6 mg/day | 168
     reduced insulin dose | 216
     improved glycemic control | 216
     decreased HbA1c level | 216
     weight loss 6.8 kg | 432
     discontinued insulin lispro | 720
     liraglutide 1.2 mg/day | 720
     insulin glargine 10 U/day | 720
     HbA1c level 8.6% | 720
     improved serum insulin and eosinophil levels | 720
     no allergic symptoms | 720