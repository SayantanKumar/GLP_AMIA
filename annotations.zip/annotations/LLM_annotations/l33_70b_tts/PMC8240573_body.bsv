 37 years old | 0
     female | 0
     admitted to the hospital | 0
     sensation of disequilibrium | -336
     unsteadiness on her feet | -336
     difficulty closing both eyes | -336
     right lip numbness | -336
     sequential bilateral hearing impairment | -336
     slurred speech | -336
     denied limb weakness | -336
     denied numbness | -336
     denied headache | -336
     denied neck stiffness | -336
     denied photophobia | -336
     denied nausea | -336
     denied vomiting | -336
     denied visual changes | -336
     denied fever | -336
     denied rash | -336
     denied lymph node swelling | -336
     denied night sweats | -336
     10 kg weight loss | -720
     type 2 diabetes mellitus | -720
     commenced metformin | -720
     commenced gliclazide | -720
     commenced dulaglutide | -720
     improved diabetic control | -720
     morbid obesity | 0
     asthma | 0
     eczema | 0
     denied steroids | 0
     denied immunosuppressant medication | 0
     born and raised in a subtropical region in Australia | 0
     denied significant travel history | 0
     engaging in unprotected sex | 0
     denied intravenous drug use | 0
     bilateral cranial neuropathies | 0
     trigeminal nerve involvement | 0
     abducens nerve involvement | 0
     facial nerve involvement | 0
     vestibulocochlear nerve involvement | 0
     hypoglossal nerve involvement | 0
     lateral gaze restricted bilaterally | 0
     bilateral upper and lower facial weakness | 0
     impaired eyebrow raise | 0
     impaired eye closure | 0
     inability to smile | 0
     Weber’s test lateralised to the left ear | 0
     Rinne’s test demonstrated air conduction greater than bone bilaterally | 0
     tongue was weak but midline on protrusion | 0
     sensation decreased to light touch and pinprick in V2 distribution on the right side | 0
     C reactive protein elevated | 0
     erythrocyte sedimentation rate elevated | 0
     thrombocytosis | 0
     serum beta human chorionic gonadotropin <1.2 IU/L | 0
     haemoglobin A1c 8.7% | 0
     CSF examination demonstrated normal opening pressure | 0
     elevated protein in CSF | 0
     normoglycaemia in CSF | 0
     lymphocyte predominant leucocytosis in CSF | 0
     MRI scan of the brain with gadolinium demonstrated enhancement of the trigeminal nerve | 0
     facial and vestibulochoclear nerves at the geniculate ganglion | 0
     no evidence of recent infarct or leptomeningeal enhancement | 0
     contrast-enhanced MRI of the spine was unremarkable | 0
     CT scans of the neck, chest, abdomen and pelvis were negative for malignancy or lymphadenopathy | 0
     serum T. pallidum particle agglutination assay positive | 0
     chemiluminescent microparticle immunoassay IgG and IgM positive | 0
     rapid plasma reagin titre of 1:32 | 0
     CSF analysis showed positive TPPA | 0
     VDRL titre of 1:8 | 0
     negative T. pallidum PCR | 0
     workup for other infectious, autoimmune and neoplastic disorders was negative | 0
     denied primary syphilitic chancre | 0
     Chlamydia trachomatis detected on first-pass urine PCR | 0
     commenced on intravenous benzylpenicillin | 0
     15-day course of antibiotic therapy | 0
     concurrent chylamydia infection treated with doxycycline | 0
     cranial neuropathies improved dramatically by the eighth day of treatment | 192
     discharged home to complete antibiotic therapy | 360
     scheduled for outpatient review with the local infectious diseases team | 360