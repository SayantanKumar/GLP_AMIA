 47 years old | 0
     male | 0
     type 2 diabetes | -672
     heart failure with preserved ejection fraction | -672
     chronic obstructive pulmonary disease | -672
     insulin | -672
     dulaglutide | -672
     evolocumab | -672
     hyperlipidemia | -672
     statin-induced rhabdomyolysis | -1344
     hospitalization | -1344
     empagliflozin | 0
     hemoglobin A1c 8.42% | 0
     pain in bilateral lower extremities | 168
     constant aching in legs and thighs | 168
     no recent trauma or fall | 168
     no new medications or herbal supplements | 168
     home medications | 168
     insulin lispro | 168
     insulin glargine | 168
     dulaglutide | 168
     evolocumab | 168
     gabapentin | 168
     atenolol | 168
     bupropion | 168
     ziprasidone | 168
     rimegepant | 168
     galcanezumab | 168
     albuterol inhaler | 168
     no weight loss | 168
     no change in urination | 168
     no feeling thirsty | 168
     vital signs within normal limits | 168
     skin examination showed no erythema | 168
     skin examination showed no subcutaneous edema | 168
     skin examination showed no lesions | 168
     no evidence of dehydration | 168
     musculoskeletal examination revealed no joint effusions | 168
     range of motion was normal | 168
     neurological examination indicated intact strength | 168
     deep tendon reflexes were normal | 168
     sensation was intact | 168
     elevated creatinine kinase | 168
     glucose was elevated | 168
     creatinine was at baseline | 168
     estimated glomerular filtration rate >60 mL/min/1.73 m2 | 168
     magnesium was in range | 168
     urinalysis was negative for blood or red blood cells | 168
     mild elevation of liver enzymes | 168
     aspartate aminotransferase was 64 U/L | 168
     alanine aminotransferase was 117 U/L | 168
     alkaline phosphatase was 138 U/L | 168
     autoimmune workup for evaluation of myositis was unremarkable | 168
     negative antinuclear antibody | 168
     normal erythrocyte sedimentation rate | 168
     empagliflozin discontinued | 168
     intravenous fluids given | 168
     significant improvement in muscle pain and weakness | 336
     complete resolution of symptoms | 336
     CK was downtrending | 336
     physical examination showed normal pain and strength | 336
     negative screening inflammatory testing | 336
     further laboratory or imaging testing for autoimmune causes of myopathies were deferred | 336