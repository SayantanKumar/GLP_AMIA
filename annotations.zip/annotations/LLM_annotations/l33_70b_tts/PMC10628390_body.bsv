 56 years old | 0
     male | 0
     Caucasian | 0
     presented to the outpatient dermatology clinic | 0
     new-onset pruritic symptoms | -504
     pruritic symptoms progressed | -504
     symptoms began at the lower extremities | -504
     symptoms advanced to the upper extremities | -504
     decreased quality of life | -504
     inability to work | -504
     inability to sleep | -504
     itching exacerbated by stress | -504
     excoriations on lower and upper extremities | 0
     post-inflammatory hyperpigmentation | 0
     pruritic nodules | 0
     attempted to relieve itch with over-the-counter anti-itch creams | -168
     attempted to relieve itch with low-dose steroids | -168
     no improvement | -168
     past medical history of possible prediabetes | 0
     past medical history of joint pain | 0
     takes Ozempic | 0
     non-adherent to Ozempic | 0
     history of allergic symptoms | 0
     allergic symptoms exacerbated by sun exposure | 0
     controlled with over-the-counter first-generation antihistamines | 0
     bloodwork showed slight elevations in AST/ALT | 0
     abdominal ultrasound negative | 0
     CT abdomen and pelvis negative | 0
     P-ANCA normal | 0
     differential diagnosis of atopic dermatitis | 0
     started on topical and oral steroids | 0
     no relief of pruritic symptoms | 24
     started on gabapentin 1,000 mg | 24
     titrated down to 500 mg | 168
     complete resolution of symptomatology | 168
     written informed consent obtained | 0