 26 years old | 0
     male | 0
     admitted to the hospital | 0
     agitation | 0
     shortness of breath | 0
     abdominal pain | 0
     fatigue | -96
     malaise | -96
     fever | -96
     sore throat | -96
     diagnosed with T2DM | -5040
     metformin | -5040
     canagliflozin | -2190
     gliclazide | -2190
     pioglitazone | -2190
     liraglutide | -2190
     metformin/sitagliptin | -2190
     dry oral mucosa | 0
     distress | 0
     febrile | 0
     tachycardic | 0
     tachypneic | 0
     low blood pressure | 0
     morbidly obese | 0
     non-exudative pharyngitis | 0
     shallow deep breathing | 0
     bilateral vesicular breathing | 0
     sinus tachycardia | 0
     mild epigastric tenderness | 0
     hyperglycemia | 0
     metabolic acidosis | 0
     high anion gap | 0
     urine ketone level high | 0
     leukocytosis | 0
     elevated C-reactive protein | 0
     elevated procalcitonin | 0
     negative toxicology screen | 0
     normal sodium | 0
     normal potassium | 0
     normal creatinine | 0
     normal urea | 0
     normal total creatinine kinase | 0
     elevated serum osmolality | 0
     normal liver function | 0
     normal thyroid tests | 0
     broad-spectrum antibiotic therapy started | 0
     diabetic ketoacidosis protocol initiated | 0
     insulin bolus | 0
     insulin infusion | 0
     sodium bicarbonate infused | 0
     respiratory distress | 4
     assisted ventilation | 4
     renal replacement therapy initiated | 4
     basal insulin started | 48
     insulin infusion rate titrated based on capillary ketone measurements | 38
     serial capillary blood ketone measurements | 38
     hemodialysis sessions | 38
     continuous veno-venous hemodiafiltration | 38
     metabolic acidosis corrected | 62
     anion gap closed | 62
     extubated | 96
     shifted to basal bolus regimen | 120
     ketonemia persisted | 288
     urine organic acid profile revealed peaks of 2-ketoisovaleric acid, acetoacetic acid, 3-OH butyric acid, and 2-OH isovaleric acid | 120
     significant diuresis | 24
     blood cultures negative | 120
     sputum cultures negative | 120
     urine cultures negative | 120
     influenza screen negative | 120
     Strep A negative | 120
     HIV negative | 120
     hepatitis B and C negative | 120
     respiratory viral panel MDX positive for adenovirus | 120
     chest x-ray normal | 0
     HbA1C | 0
     C-peptide | 0
     Anti IA2, GAD antibodies, and insulin antibodies negative | 0
     femoral line site deep venous thrombosis | 120
     pulmonary embolism | 120
     anticoagulants started | 120
     discharged | 384