 66 years old | 0
     male | 0
     referred for evaluation for cataract surgery | 0
     phacoemulsification and intraocular lens (IOL) implantation in his left eye | -156
     large residual myopia | -156
     hypertension | 0
     type 2 diabetes mellitus | 0
     hyperlipidemia | 0
     chronic obstructive pulmonary disease | 0
     prostate cancer | 0
     morbid obesity | 0
     glipizide | 0
     metformin | 0
     liraglutide | 0
     carvedilol | 0
     simvastatin | 0
     levothyroxine | 0
     tiotropium | 0
     no known allergies | 0
     denied tobacco or alcohol use | 0
     poor vision at all distances | 0
     no recent worsening of vision | 0
     BCVA was 20/70 | 0
     BCVA was 20/200 | 0
     corrected to 20/50 with pinhole | 0
     corrected to 20/70 with pinhole | 0
     near visual acuity was J3 | 0
     manifest refraction was −14.00 D + 1.75 × 075 | 0
     manifest refraction was −16.00 D + 1.00 × 075 | 0
     intraocular pressures (IOP) were 15 | 0
     intraocular pressures (IOP) were 18 | 0
     2+ nuclear sclerotic cataract | 0
     posterior chamber IOL with mild capsular fibrosis | 0
     pathologic myopia | 0
     scleral thinning | 0
     compound myopic astigmatism | 0
     long axial lengths | 0
     normal corneal thickness and architecture | 0
     off-label placement of a phakic IOL | 0
     uncomplicated surgery | 24
     placement of a sulcus-located pIOL | 24
     refractive power of −16.00 D | 24
     diameter of 13.2 mm | 24
     postoperative day 1 | 24
     denied any new symptoms | 24
     uncorrected best visual acuity (UCVA) in his left eye was improved to 20/50 | 24
     pinhole visual acuity of 20/40 | 24
     postoperative IOP was constant in his right eye | 24
     decrease in IOP to 16 in his left eye | 24
     sutured wound on the temporal limbus | 24
     pharmacologically dilated pupil | 24
     deep and quiet anterior chamber | 24
     visualization of the pIOL in correct position | 24
     space between the two implants | 24
     subjective improvement in his vision | 168
     ongoing mild blurriness | 168
     UCVA was improved to 20/25 | 168
     IOP was decreased to 13 | 168
     intact sutured wound on the temporal limbus | 168
     deep and quiet anterior chamber | 168
     visualization of the pIOL in correct position | 168
     space between the two implants | 168
     referred to his primary ophthalmologist | 168
     treatment of the nuclear sclerotic cataract | 168
     +4.0 D AMO SensAr Lens implant | 192
     uncomplicated right eye surgery | 192
     20/20 UCVA | 192