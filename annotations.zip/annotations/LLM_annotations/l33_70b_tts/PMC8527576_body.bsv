



GLP-1 coined | -8160
incretin | -8160
La Barre | -8160
GLP-1 agonists | -8160
Nauck et al | -720
GLP-1 | -720
type 2 diabetic patients | -720
GLP-1 agonists | -720
fasting plasma glucose | -720
GLP-1 | -720
pancreatic hormone secretion | -720
diabetes treatment | -720
GLP-1 | 0
GLP-1 receptor agonists | 0
American Diabetes Association | 0
ADA | 0
treatment algorithm | 0
diabetic patients | 0
atherosclerotic cardiovascular disease | 0
ASCVD | 0
chronic kidney disease | 0
CKD | 0
metformin | 0
GLP-1 receptor agonists | 0
cancer | 0
systematic complications | 0
hypoglycemia | 0
combined treatments | 0
GLP-1 receptor agonists | 0
hypoglycemic symptoms | 0
individuals | 0
non-glucose-dependent action | 0
GLP-1 receptor agonists | 0
action | 0
factors | 0
GLP-1 | 0
insulin secretion | 0
GLP-1 receptor | 0
Gs protein signaling cascade | 0
adenyl cyclase | 0
AC | 0
cAMP | 0
protein kinase A | 0
PKA | 0
Ca2+ | 0
intracellular Ca2+ stores | 0
insulin translocation | 0
exocytosis | 0
secretory granules | 0
GLP1 receptor agonists | 0
physiology | 0
hypoglycemia | 0
oral glucose | 0
insulin | 0
IV glucose | 0
incretin hormones | 0
GIP | 0
GLP-1 | 0
short-acting | 0
long-acting | 0
GLP-1 receptor agonists | 0
duration | 0
subcutaneous injections | 0
DPP-4 | 0
degradation | 0
incretins | 0
sitagliptin | 0
vildagliptin | 0
saxagliptin | 0
linagliptin | 0
CVD | 0
cardiovascular disease | 0
outcomes | 0
liraglutide | 0
dulaglutide | 0
semaglutide | 0
cardiovascular events | 0
gastrointestinal effects | 0
nausea | 0
diarrhea | 0
vomiting | 0
constipation | 0
abdominal pain | 0
dyspepsia | 0
pancreatitis | 0
pancreatic cancer | 0
incretin therapy | 0
animals | 0
metaanalyses | 0
studies | 0
GLP-1 | 0
β-cell mass | 0
animal models | 0
β-cell growth factor | 0
insulin synthesis | 0
β-cell mass | 0
humans | 0
medullary thyroid cancer | 0
rodents | 0
primates | 0
GLP-1 receptor agonists | 0
hypoglycemia | 0
Edwards et al | 0
GLP-1 | 0
healthy subjects | 0
hypoglycemia | 0
Lerche et al | 0
native GLP-1 | 0
healthy men | 0
hypoglycemia | 0
Nauck et al | 0
liraglutide | 0
metformin | 0
glimepiride | 0
hypoglycemia | 0
Marre et al | 0
liraglutide | 0
glimepiride | 0
rosiglitazone | 0
hypoglycemia | 0
Nauck et al | 0
IV GLP-1 | 0
regular insulin | 0
healthy volunteers | 0
Gough et al | 0
liraglutide | 0
insulin degludec | 0
hypoglycemia | 0
Blevins et al | 0
exenatide | 0
hypoglycemia | 0
Ratner et al | 0
lixisenatide | 0
hypoglycemia | 0
Vilsbøll et al | 0
GLP-1 | 0
IV glucose | 0
hypoglycemia | 0
Knop et al | 0
GLP-1 | 0
IV glucose | 0
hypoglycemia | 0
GLP-1 receptor agonists | 0
hypoglycemia | 0
sulphonylureas | 0
hypoglycemia | 0
GLP-1 | 0
glucagon | 0
euglycemia | 0
insulinoma | 0
GLP-1 receptors | 0
hypoglycemia | 0
insulin | 0
GLP-receptor agonist | 0
hypoglycemia | 0
LixiLan-L | 0
trial | 0
patients | 0
type 2 diabetes | 0
hypoglycemia | 0
bariatric surgery | 0
hypoglycemia | 0
GLP-1 | 0
gastrectomy | 0
hypoglycemia | 0
GLP-1 receptor agonists | 0
hypoglycemia | 0
liraglutide | 0
exenatide | 0
hypoglycemia | 0
albiglutide | 0
dulaglutide | 0
semaglutide | 0
hypoglycemia | 0
GLP-1 receptor agonists | 0
gastrointestinal effects | 0
nausea | 0
vomiting | 0
diarrhea | 0
constipation | 0
abdominal pain | 0
dyspepsia | 0
pruritus | 0
erythema | 0
injection site | 0
pancreatitis | 0
incretin-mimetic therapies | 0
FDA | 0
US Food and Drug Administration | 0
pancreatitis | 0
cardiovascular effect | 0
GLP-1 receptor agonists | 0
systolic blood pressure | 0
SBP | 0
diastolic blood pressure | 0
DBP | 0
dulaglutide | 0
albiglutide | 0
exenatide | 0
lipid levels | 0
LDL cholesterol | 0
total cholesterol | 0
heart failure | 0
incretin-based drugs | 0
hospitalization | 0
GLP-1 RA | 0
cardiac resynchronization therapy | 0
CRT-d | 0
NYHA | 0
New York Association Heart | 0
SIRT6 | 0
gene | 0
sirtuin family | 0
NAD-dependent enzymes | 0
cellular stress resistance | 0
genomic stability | 0
aging | 0
energy homeostasis | 0
incretin therapy | 0
diabetic patients | 0
SIRT6 expression | 0
carotid plaques | 0
EPCs | 0
endothelial progenitor cells | 0
inflammation | 0
oxidative stress | 0
NSTEMI-NOCS | 0
Non-ST-Elevation Myocardial Infarction | 0
non-obstructive coronary artery stenosis | 0
diabetics | 0
incretin-based therapy | 0
GLP-1 agonists | 0
DPP-4 inhibitors | 0
cardiovascular outcomes | 0
allergy | 0
angioedema | 0
hypersensitivity | 0
immunological reactions | 0
exenatide | 0
antibodies | 0
treatment-emergent adverse effects | 0
anaphylactic reactions | 0
liraglutide | 0
lixisenatide | 0
pruritus | 0
urticaria | 0
angioneurotic edema | 0
injection-site reactions | 0
albiglutide | 0
exenatide | 0
lixisenatide | 0
nodules | 0
pruritus | 0
erythema | 0
anti-drug antibodies | 0
conclusions | 0
GLP-1 agonist-induced hypoglycemia | 0
GLP-1 receptor agonists | 0
glycemic control | 0
type 2 diabetic patients | 0
elderly patients | 0
weight gain | 0
hypoglycemia | 0
insulin resistance | 0
impaired insulin response | 0
Edwards et al | 0
hypoglycemia | 0
healthy patients | 0