 patient diagnosed with severe mental illnesses | 0
     undergoing therapy with atypical antipsychotics | 0
     metabolic dysfunctions | 0
     fasting hyperglycaemia | 0
     impaired glucose tolerance | 0
     prediabetes | 0
     diabetes | 0
     obesity | 0
     metabolic syndrome | 0
     atypical antipsychotics treatment initiated | -672
     weight gain | -672
     insulin sensitivity alteration | -672
     secretion alteration | -672
     schizophrenia spectrum disorders diagnosed | -672
     antipsychotic use | -672
     impaired glucose metabolism | -672
     first episode of psychosis | -672
     fasting plasma glucose level altered | -672
     plasma glucose level after an oral glucose tolerance test altered | -672
     fasting plasma insulin level altered | -672
     insulin resistance | -672
     plasma triglycerides level high | -672
     excessive caloric intake | -8
     consumption of refined grain foods and discretionary foods | -8
     energy balance excess | -8
     antipsychotics associated with adverse metabolic effects | 0
     switching from currently administered agent to a metabolically more favourable one | 0
     monotherapy rarely used | 0
     other pharmacological agents used as add-ons | 0
     weight loss | 0
     glycaemic control | 0
     cardiovascular complications | 0
     diabetes remission | 0
     first-generation antidiabetic agents | 0
     sodium-glucose co-transporter 2 inhibitors | 0
     glucagon-like peptide receptor agonists | 0
     body weight loss | 0
     waist circumference reduction | 0
     HbA1c reduction | 0
     blood glucose reduction | 0
     blood pressure reduction | 0
     empagliflozin | 0
     canagliflozin | 0
     dapagliflozin | 0
     ertugliflozin | 0
     preclinical study | 0
     clinical guidelines | 0
     expert consensus | 0
     systematic review | 0
     case report | 0
     metformin | 0
     dipeptidyl-peptidase-4 inhibitors | 0
     pioglitazone | 0
     sulfonylureas | 0
     insulin | 0
     exenatide | 0
     SGLT2Is recommended as add-on to metformin | 0
     SGLT2Is may be used in combination with metformin | 0
     SGLT2Is and GLP1RAs as second-line therapy | 0
     clozapine discontinued | 24
     insulin initiated | 24
     exenatide initiated | 24
     empagliflozin initiated | 24