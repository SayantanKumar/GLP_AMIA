 white British man | 0\
     50s | 0\
     implanted cardiac defibrillator (ICD) | -8760\
     Ventricular Fibrillation (VF) arrest | -8760\
     congenital heart disease | -8760\
     pulmonary stenosis | -8760\
     pulmonary valve replacement | -8760\
     ICD Implantation | -8760\
     Atrial Fibrillation | -8760\
     Type 2 Diabetes Mellitus | -8760\
     Hypercholesterolemia | -8760\
     Gout | -8760\
     Amiodarone | -8760\
     Apixaban | -8760\
     Bisoprolol | -8760\
     Lisinopril | -8760\
     Furosemide | -8760\
     Allopurinol | -8760\
     Canagliflozin | -8760\
     Lansoprazole | -8760\
     Liraglutide | -8760\
     Metformin | -8760\
     Atorvastatin | -8760\
     abnormal cardiac rhythm | 0\
     heart rate dropped | 0\
     asystole | 0\
     death | 3\
     remote clinic appointment | 48\
     device check | -120\
     CPAP machine | 3\
     obstructive sleep apnoea | 3\
     autopsy | 72\
     device extraction | 72\
     scarring of the heart | 72\
     pathological changes | 72\
     lead malfunction | 72\
     device evaluation | 72\
     digital forensic analysis | 72\
     software bugs | 72\
     malicious hacks | 72\
     EM interference | 72\
     cloud data analysis | 72\
     digital death markers | 72\
     mortuary protocols | 72\
     post-mortem radiological imaging | 72\
     digital analytics | 72\
     device memory hardware | 72\
     cybersecurity risks | 72\
     digital pathways to disease and death | 72\
     end-of-life care | 72\
     technology-facilitated abuse | 72\
     health equity | 72\
     digital systems | 72\
     Artificial Intelligence (AI) software | 72\
     racial and gender-based health disparities | 72\
     urban-to-rural health disparities | 72\
     cellular coverage | 72\
     cloud-based platforms | 72\
     economic factors | 72\
     digital data availability | 72\
     device donation | 72\
     reuse | 72\
     misidentification of victims | 72\
     comprehensive device digital forensics | 72\
     public health measures | 72\
     simulation training | 72\
     breaking bad news | 72\
     morticians | 72\
     technical specialists | 72\
     manufacturers | 72\
     forensic capabilities | 72\
     cybersecurity risks | 72\
     preservation of digital data | 72\
     implanted technology | 72\
     subcutaneous RFID chips | 72\
     Royal College of Pathologists | 72\
     guidelines | 72\
     updates | 72\
     institutional review board approval | 0\
     written informed consent | 0\
     publication | 0\
     conflict of interest | 0