 59 years old | 0
     female | 0
     type 2 diabetes mellitus | -1560
     generalized anxiety disorder | -1560
     major depressive disorder | -1560
     hypertension | -1560
     hyperlipidemia | -1560
     heart murmur | -1560
     degenerative arthritis of the knee | -1560
     esophageal reflux disease | -1560
     iron deficiency anemia | -1560
     insomnia | -1560
     vitamin D deficiency | -1560
     tobacco use | -1560
     denies alcohol use | -1560
     denies illicit drug use | -1560
     insulin glargine | -1560
     metformin extended release | -1560
     dulaglutide | -1560
     venlafaxine ER | -1560
     aspirin | -1560
     losartan | -1560
     ezetimibe | -1560
     polysaccharide iron complex | -1560
     multivitamin | -1560
     omeprazole-sodium bicarbonate | -1560
     HbA1c 7.5% | -216
     average self-monitoring FBG 96 mg/dL | -216
     average bedtime blood glucose 175 mg/dL | -216
     titrated to dulaglutide 1.5 mg | -216
     FBG 88 mg/dL | -168
     2-hour postprandial blood glucose 165 mg/dL | -168
     HbA1c 7.2% | -84
     average FBG 106 mg/dL | -84
     2-hour postprandial blood glucose 129 mg/dL | -84
     discontinued venlafaxine | 0
     initiated desvenlafaxine ER 50 mg daily | 0
     baseline patient health questionnaire-9 score 8 | 0
     average blood glucose increased | 720
     FBG 136 mg/dL | 720
     2-hour postprandial blood glucose 207 mg/dL | 720
     increased insulin glargine to 10 units daily | 720
     average FBG 129 mg/dL | 1440
     2-hour postprandial blood glucose 192 mg/dL | 1440
     increased insulin glargine to 12 units daily | 1440
     initiated insulin lispro 2 units before dinner | 1560
     increased insulin lispro to 8 units prior to dinner | 2160
     average FBG 106 mg/dL | 2160
     2-hour postprandial blood glucose 146 mg/dL | 2160
     HbA1c 7.3% | 2160
     HbA1c 6.9% | 2880
     patient health questionnaire-9 score 8 | 4320