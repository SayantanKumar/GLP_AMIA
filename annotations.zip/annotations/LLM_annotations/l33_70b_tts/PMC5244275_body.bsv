 59 years old | 0
     African American | 0
     male | 0
     unilateral left-sided tongue swelling | 0
     difficulty swallowing | 0
     throat tightness | 0
     no dyspnea | 0
     no abdominal pain | 0
     no nausea | 0
     no vomiting | 0
     no syncope | 0
     no cutaneous symptoms | 0
     no history of angioedema | 0
     no food allergies | 0
     no latex allergies | 0
     no recent insect stings | 0
     no family history of angioedema | 0
     hydrocodone | -120
     metformin | -120
     exenatide | -120
     insulin glargine | -120
     daily aspirin | -120
     Lotrel (amlodipine besylate and benazepril) | -120
     tongue swelling over the course of an hour | -1
     emergency department evaluation | 0
     intravenous access | 0
     management for histamine-mediated angioedema | 0
     methylprednisolone 125 mg IV | 0
     diphenhydramine 25 mg IV | 0
     epinephrine 1 μg IV | 0
     no improvement in symptoms | 0.25
     additional epinephrine 9 μg IV | 0.25
     no response | 0.5
     airway collapse imminent | 0.5
     ranitidine 150 mg IV | 0.5
     C1-INH (Berinert) 3000 U | 0.5
     response noted 15 minutes after C1-INH dose | 1
     reduction of swelling | 1
     resolution of dysphagia | 1
     admission to medical intensive care unit | 1
     evaluation by otolaryngology specialist | 1
     complement levels drawn | 1
     normal C4 level | 1
     normal C1-INH functionality | 1
     diagnosis of ACEI-AAE confirmed | 1
     discontinuation of ACEI | 1
     transition to valsartan/hydrochlorothiazide | 1
     discharge | 24
     follow-up with allergy department | 24
     no recurrence of angioedema at 1-year follow-up | 8760
     blood pressure well controlled on combination medication | 8760