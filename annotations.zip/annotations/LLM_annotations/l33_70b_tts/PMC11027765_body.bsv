 38 years old | 0
     female | 0
     presented to the obesity clinic | 0
     weight management | 0
     partially willing to lose weight | 0
     first-degree family history of obesity | 0
     resides with her aging parents and a housekeeper | 0
     height 146 cm | 0
     weight 193 kg | 0
     BMI 90.5 kg/m2 | 0
     central obesity | 0
     blood pressure was normal | 0
     regular pulse | 0
     prediabetes level of blood sugar | 0
     elevated risk of obstructive sleep apnea | 0
     no physical activity | 0
     major mobility limitations | 0
     sugary foods and drinks | 0
     ultra-processed foods | 0
     little intake of fruits and vegetables | 0
     unrefreshed 4 - 5 h of sleep | 0
     limited social connections | 0
     generally stable mental health | 0
     multidisciplinary team formed | 0
     lifestyle medicine training | 0
     structured lifestyle intervention | 0
     weight loss medications | 0
     metformin prescribed | 0
     continuous positive airway pressure (CPAP) | 0
     plant-based diet | 0
     reduced calorie consumption | 0
     physical activity | 0
     Harvard’s healthy eating plate | 0
     avoid overeating | 0
     stop eating snacks | 0
     drinking 2 - 3 L of water and herbal teas | 0
     walking 2 min three times daily | 0
     moderate-intensity walking | 0
     resistance training | 0
     weightlifting | 0
     interrupt setting with physical activity | 0
     social connection with family | 0
     fill time away from eating | 0
     overcome feelings of fatigue | 0
     adjust bedtime and wake-up times | 0
     extend sleep duration | 0
     incremental approach to sleep schedule | 0
     consistent use of CPAP therapy | 0
     uninterrupted sleep | 0
     increase nighttime sleep duration to 6 h | 0
     family support | 0
     sister’s home | 0
     shared goal of losing excess weight | 0
     dietary recommendations | 0
     healthy food options | 0
     nutritious meals | 0
     portion control | 0
     balanced diet | 0
     exercise practices | 0
     walking alongside the patient | 0
     resistance training | 0
     collaborative exercise routine | 0
     adherence to physical activity regimens | 0
     overall well-being | 0
     hybrid follow-up visits | 0
     weight measurements | 0
     lost 23 kg | 168
     percent weight loss of 11.9% | 168
     willing to continue weight management | 168
     trusted ability to lose weight | 168
     liraglutide introduced | 168
     lost an additional 5 kg | 216
     total weight loss of 28 kg | 336
     percent weight loss of 14% | 336
     BMI decreased to 77.4 kg/m2 | 336
     regained ability to perform daily activities | 336
     took care of herself and others | 336