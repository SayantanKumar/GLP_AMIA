 weight gain | -2520
     overeating | -2520
     mental stress | -2520
     disc herniation | -1320
     retired from work | -1320
     decreased physical activity | -1320
     weight gain | -1320
     body weight 153 kg | -1200
     height 156.2 cm | -1200
     body mass index (BMI) 62.7 kg/m2 | -1200
     HbA1c level 8.8% | -1200
     admitted to the hospital | -1200
     dietary intake 1200 kcal per day | -1200
     weight reduction | -1200
     body weight 131.2 kg | -1050
     BMI 53.9 kg/m2 | -1050
     HbA1c level 6.5% | -1050
     discharged from the hospital | -1050
     weight regain | -840
     body weight 163.0 kg | -840
     BMI 66.8 kg/m2 | -840
     HbA1c level 9.3% | -840
     weight reduction | -600
     body weight 144.1 kg | -600
     BMI 59.1 kg/m2 | -600
     insulin treatment 36 units | -600
     HbA1c level 10.5% | -600
     weight reduction | -420
     body weight 121 kg | -420
     BMI 49.6 kg/m2 | -420
     insulin treatment 28 units | -420
     weight reduction | -360
     body weight 114 kg | -360
     BMI 46.7 kg/m2 | -360
     HbA1c level 6.6% | -360
     no medication | -360
     weight reduction | -240
     body weight 112.1 kg | -240
     BMI 45.9 kg/m2 | -240
     HbA1c level 6.0% | -240
     weight regain | 0
     body weight 133.8 kg | 0
     BMI 54.8 kg/m2 | 0
     HbA1c level 8.2% | 0
     exenatide treatment | 0
     exenatide 5 μg twice a day | 0
     nausea | 24
     appetite loss | 24
     weight loss | 168
     body weight 96.3 kg | 168
     BMI 39.5 kg/m2 | 168
     HbA1c level 5.1% | 168
     resting metabolic rate (RMR) 1618 kcal/day | 168
     homeostasis model assessment of insulin resistance (HOMA-IR) 1.29 | 168
     homeostasis model assessment of β cell function (HOMA-β) 57.2% | 168
     quantitative insulin-sensitivity check index (QUICKI) 0.195 | 168
     continuous glucose monitoring (CGM) | 168
     glucose levels 117 ± 7 mg/dL | 168
     insulin levels | 168
     glucagon levels | 168
     active glucagon-like peptide-1 (GLP-1) levels | 168
     total glucose-dependent insulinotropic polypeptide (GIP) levels | 168
     area under the curve (AUC) values for glucose | 168
     AUC values for insulin | 168
     AUC values for glucagon | 168
     AUC values for GLP-1 | 168
     AUC values for GIP | 168
     weight regain | 720
     body weight 99.3 kg | 720
     weight loss maintenance | 720