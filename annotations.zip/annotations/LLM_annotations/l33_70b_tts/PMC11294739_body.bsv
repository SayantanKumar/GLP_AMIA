 40 years old | 0
     female | 0
     T1DM | -3 years
     diabetic ketoacidosis | -3 years
     hemoglobin A1c 9.3% | -3 years
     C-peptide 0.8 ng/mL | -3 years
     Glutamic Acid Decarboxylase antibodies positive | -3 years
     body mass index 28 kg/m2 | -3 years
     insulin glargine | -3 years
     insulin aspart | -3 years
     pod insulin pump therapy | -2.5 years
     skin reactions | -2 years
     pruritic and painful erythema | -2 years
     wheals | -2 years
     induration | -2 years
     subcutaneous nodules | -2 years
     lipodystrophy | -2 years
     barrier adhesives | -2 years
     topical antihistamines | -2 years
     oral antihistamines | -2 years
     topical glucocorticoids | -2 years
     sulfonamide antibiotic allergy | -2 years
     insulin aspart | -1 year
     insulin lispro | -1 year
     insulin regular | -1 year
     insulin glulisine | -1 year
     inhaled human insulin | -1 year
     cough | -1 year
     drug allergy clinic | -1 year
     intradermal insulin lispro test positive | -1 year
     metacresol skin test negative | -1 year
     serum human insulin-specific IgG antibody testing positive | -1 year
     IgE antibody testing negative | -1 year
     skin punch biopsy | -1 year
     sublobular panniculitis | -1 year
     metformin | -4 months
     dapagliflozin | -4 months
     liraglutide | -4 months
     insulin requirement 60 units/d | -4 months
     insulin requirement 50 units/d | 0
     weight loss 12 pounds | 0
     HbA1c 5.8% to 6.8% | 0
     rituximab | 0
     diphenhydramine | 0
     acetaminophen | 0
     infusion-related reactions | 0
     serum human insulin-specific antibody testing 122 mg/L | 2 weeks
     IgE antibodies undetectable | 2 weeks
     skin reactions improved | 2 weeks
     second round of rituximab | 18 months
     skin reactions recurred | 18 months
     deeper punch biopsy | 18 months
     sublobular panniculitis | 18 months
     second round of rituximab infusion | 18 months
     skin reactions improved | 18 months
     no recurrent skin reactions | 4 years