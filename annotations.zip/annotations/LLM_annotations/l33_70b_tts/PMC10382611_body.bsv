 60 years old | 0
     male | 0
     White | 0
     T2DM | -8760
     stable glycemic control | -8760
     CM | -8760
     HTG | -8760
     TG levels between 1100 and 4000 mg/dL | -8760
     alcohol consumption <1 drink/week | 0
     20% low fat diet | 0
     30 minutes of daily walking | 0
     no history of pancreatitis | 0
     moderate hepatomegaly | 0
     no eruptive xanthomata | 0
     A1C level between 6.0% and 7.0% | -8760
     HeLPL | -8760
     p.Asn291Ser in LPL | -8760
     fenofibrate 145 mg daily | -8760
     icosapent ethyl 2 g twice daily | -8760
     ezetimibe 10 mg daily | -8760
     atorvastatin 40 mg daily | -8760
     semaglutide 1.0 mg subcutaneously weekly | -8760
     empagliflozin 10 mg/day | -8760
     metformin 1000 mg twice daily | -8760
     switched to tirzepatide | 0
     tirzepatide 15 mg subcutaneously weekly | 0
     TG level decreased 58% | 168
     resolution of CM | 168
     A1C level decreased from 6.9% to 6.3% | 168
     body weight decreased by 12 lbs | 168
     TG level continued to decrease to 202 mg/dL | 504
     near normalization of HTG | 504
     improvement in glycemic control | 168
     improvement in body weight | 168
     potential mechanism for TG lowering | 168
     dose-dependent decrease in apolipoprotein CIII | 168
     increase in LPL activity | 168
     risk of pancreatitis | 0
     tirzepatide may decrease risk of pancreatitis | 168
     discontinued semaglutide | 0