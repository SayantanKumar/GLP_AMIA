 14 years old | 0
male | 0
poor socioeconomic background | 0
disoriented and confused state | -48
emesis | -48
osmotic symptoms | -720
respiratory frequency 30 breaths/min | 0
heart rate 120 bpm | 0
blood pressure 110/60 mmHg | 0
temperature 101°F | 0
blood glucose 609 mg/dL | 0
arterial blood gas pH 7.1 | 0
serum bicarbonate 9.5 mEq/L | 0
serum ketones 6 mmol/L | 0
urinary ketones strongly positive | 0
electrocardiogram showed Q waves in infero-lateral leads | 0
DKA | 0
treated with intravenous fluids, insulin, potassium, and antibiotics | 0
A1C of 10.5% | 0
pancreatic autoantibodies (anti-GAD65 and anti-IA2 antibodies) were negative | 0
difficulties with walking and standing | 24
slurring of speech | 24
ataxic gait | 24
hypoactive knee and ankle jerks | 24
bilateral extensor plantar responses | 24
impairment of position and vibratory senses | 24
dysmetria | 24
intentional tremors | 24
progressive ataxia | -8760
magnetic resonance imaging scan of brain was reportedly normal | -8760
nerve conduction velocity study of both lower limbs suggested axonal type sensorimotor neuropathy | 24
hereditary sensory neuropathy was considered | 24
concentric, symmetric hypertrophy of the left ventricle with asymmetric septal hyperthrophy | 24
genetic analysis showed peaks beyond the threshold level (∼250 base pairs) | 24
homozygous alleles in the FRDA gene | 24
diagnosed with FA-associated insulin-dependent diabetes and cardiomyopathy | 24
discharged with a split-mixed insulin regimen of NPH and rapid-acting insulins | 48
postmeal serum C-peptide level was 2.1 ng/mL | 144
FA | -8760
diabetes | 0
insulin-dependent diabetes | 0
cardiomyopathy | 24
genetic syndromes | 0
mitochondrial disorders | 0
GAA trinucleotide repeat expansion | 0
β-cell dysfunction | 0
insulin resistance | 0
mitochondrial defects | 0
metabolic stress | 0
endoplasmic reticulum stress–induced apoptosis | 0
GLP-1 | 0
incretin analogs | 0