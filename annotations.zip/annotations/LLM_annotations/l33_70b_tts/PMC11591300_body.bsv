 53 years old | 0
     female | 0
     weight 50 kg | -9360
     gained weight after childbirth | -9360
     hypothyroidism | -720
     thyroid hormone supplementation | -720
     weight increased | -720
     edema | -24
     weight gain | -24
     severe hypercapnic respiratory failure | -24
     hospitalization | 0
     height 149 cm | 0
     weight 109 kg | 0
     BMI 49.0 kg/m2 | 0
     blood pressure 108/69 mmHg | 0
     pulse rate 83 beats/min | 0
     SpO2 40-60% | 0
     body temperature 38.0°C | 0
     decreased bilateral breath sounds | 0
     systemic edema | 0
     D-dimer level 5.1 μg/mL | 0
     brain natriuretic peptide level 108 pg/mL | 0
     type-2 respiratory failure | 0
     PaO2 31 mmHg | 0
     PaCO2 75 mmHg | 0
     chest radiography | 0
     echocardiography | 0
     chest computed tomography | 0
     OHS | 0
     congestive heart failure | 0
     upper airway infection | 0
     intubation | 24
     mechanical ventilation | 24
     diuretics | 24
     extubation | 96
     NPPV | 96
     IPAP/EPAP 14/7 cmH2O | 96
     oxygen therapy | 96
     pulmonary function test | 504
     VC 1.59 L | 504
     FEV1 1.46 L | 504
     restricted ventilation failure | 504
     discharged | 720
     weight loss | 8760
     continuous glucagon-like peptide 1 receptor agonist | 8760
     weight loss 30 kg | 17520
     readmitted | 17520
     NPPV withdrawal | 17520
     oxygen therapy withdrawal | 17520
     chest radiography | 17520
     CT | 17520
     respiratory function test | 17520
     VC 1.96 L | 17520
     arterial blood gas analysis | 17520
     PtcCO2 monitoring | 17520
     SpO2 | 17520
     PtcCO2 ≥55 mmHg | 17520
     PtcCO2 ≥50 mmHg | 17520
     NPPV | 17520
     oxygen therapy | 17520
     CPAP | 17520
     weaned off oxygen therapy | 17520
     not weaned off NPPV | 17520