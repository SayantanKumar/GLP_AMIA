 32 years old | 0
     female | 0
     Crohn’s disease | -8760
     primary tonic-myoclonic epilepsy | -8760
     recurrent depression | -8760
     diarrhea | -8760
     SeHCAT scintigraphy | -4380
     severe bile acid malabsorption | -4380
     colestyramine | -4380
     colesevelam | -4380
     loperamide | -4380
     codeine phosphate | -4380
     6-mercaptopurine | -4380
     levetiracetam | -4380
     lamotrigine | -4380
     escitalopram | -4380
     venlafaxin | -4380
     infliximab | -4380
     adalimumab | -4380
     natalizumab | -4380
     vedolizumab | -4380
     colonoscopy | -4380
     fecal calprotectin measurement | -4380
     admission to the hospital | 0
     electrolyte deficiency | 0
     low plasma levels of potassium | 0
     low plasma levels of magnesium | 0
     normal plasma sodium level | 0
     low urinary sodium | 0
     fecal cultures | 0
     Clostridium difficile toxin test | 0
     vancomycin | 0
     MRI of the small bowel | 0
     pan-enteric double balloon endoscopy | 0
     duodenal biopsies | 0
     jejunal biopsies | 0
     ileal biopsies | 0
     colonic biopsies | 0
     laxative screen | 0
     spironolactone | 0
     octreotide | 0
     liraglutide | 0
     obeticholic acid | 0
     fecal transplant | 24
     increase in dose of obeticholic acid | 96
     reduction of bowel movements | 120
     weight increase | 168
     improvement of quality of life | 168
     pause of obeticholic acid | 720
     restart of obeticholic acid | 744
     follow-up | 2160
     increase in FGF19 levels | 2160
     decrease in plasma lipids | 2160
     single episode of increased serum pancreatic amylase | 2160
     normalization of p-amylase level | 2160
     restart of 6-mercaptopurine | 2160