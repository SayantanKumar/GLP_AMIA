 21 years old | 0
     female | 0
     admitted to the ICU | 0
     abdominal pain | 0
     vomiting | -48
     diarrhoea | -48
     no fever | -48
     no cough | -48
     no dysuria | -48
     no headache | -48
     no chest pain | -48
     tirzepatide treatment | -168
     weight reduction | -168
     diarrhoea | -168
     loss of 5 kg | -168
     pantoprazole | -168
     dehydrated | 0
     tachyponea | 0
     heart rate of 110 beats per minute | 0
     blood pressure of 130/80 mmHg | 0
     oxygen saturation of 99% | 0
     BMI of 28.2 kg/m2 | 0
     pH of 7.22 | 0
     partial pressure of carbon dioxide of 33 mmHg | 0
     partial pressure of oxygen of 70 mmHg | 0
     bicarbonate concentration of 13.8 mmol/l | 0
     anion gap of 25 | 0
     blood ketone concentration of 5.2 mmol/l | 0
     blood glucose level of 4.9 mmol/l | 0
     normal lactate | 0
     undetectable paracetamol | 0
     undetectable salicylate | 0
     high anion gap metabolic ketoacidosis | 0
     treated with 0.9 saline | 0
     treated with dextrose 10% | 0
     ondansetron | 0
     pantoprazole IV | 0
     anion gap closed | 24
     acidosis corrected | 24
     advised against taking tirzepatide | 24
     resolution of all symptoms | 672
     gained one kg | 672