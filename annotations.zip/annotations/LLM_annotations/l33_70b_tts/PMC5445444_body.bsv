 53 years old | 0
     male | 0
     type 2 diabetes mellitus | -18000
     vertigo | -18000
     hypertension | -18000
     obstructive sleep apnea | -18000
     obesity | -18000
     hyperlipidemia | -18000
     bilateral carpal tunnel syndrome | -18000
     arthralgia | -18000
     pituitary macroadenoma | -18000
     acromegaly | 0
     IGF-1 levels uncontrolled | 0
     GH levels elevated | 0
     FPG elevated | 0
     HbA1c elevated | 0
     metformin | 0
     pioglitazone | 0
     glipizide | 0
     insulin detemir | 0
     octreotide | 0
     refused surgical removal of pituitary adenoma | 0
     enrolled in C2305 study | 0
     assigned to receive octreotide | 0
     baseline IGF-1 | 0
     baseline GH | 0
     dose increase of octreotide | 156
     insulin aspart added | 156
     HbA1c remained elevated | 312
     FPG remained elevated | 312
     crossed over to pasireotide | 876
     IGF-1 levels decreased | 936
     GH levels decreased | 936
     dose of pasireotide increased | 1008
     IGF-1 levels normalized | 1128
     GH levels further decreased | 1128
     weight decreased | 6048
     FPG levels initially increased | 876
     FPG levels decreased | 936
     HbA1c levels stable | 936
     sitagliptin added | 4080
     liraglutide added | 5544
     biochemical control achieved | 1128
     biochemical control maintained | 6048
     patient consent obtained | 0 
     Note: The time stamps are approximate and based on the provided text. The negative time stamps indicate events that occurred before the patient's admission to the study, while the positive time stamps indicate events that occurred after the patient's admission to the study. The time stamps are in hours.