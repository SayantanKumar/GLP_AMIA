 30 years old | 0
     female | 0
     obese | 0
     weight 95 kg | 0
     body mass index (BMI) of 36 kg/m2 | 0
     type II diabetes | 0
     oral medication | 0
     cesarean section | -8760
     Situs inversus totalis (SIT) | -8760
     dieting | -8760
     exercise | -8760
     medical treatment | -8760
     liraglutide injection | -8760
     multidisciplinary approach | 0
     bariatric surgeon | 0
     bariatric general practitioner | 0
     psychologist | 0
     dietician | 0
     preoperative workup | 0
     normal laboratory investigations | 0
     electrocardiography | 0
     extreme axis deviation | 0
     upright P waves in AVR lead | 0
     inverted P waves in leads I and II | 0
     echocardiography | 0
     dextrocardia | 0
     chest X-ray | 0
     barium meal test | 0
     right-sided stomach | 0
     no contrast obstruction | 0
     ultrasound of the abdomen | 0
     normal gall bladder | 0
     cardiology evaluation | 0
     endocrinology evaluation | 0
     anesthesia evaluation | 0
     respirology evaluation | 0
     fit for surgery | 0
     no associated organic abnormalities | 0
     induction of general anesthesia | 0
     intubation | 0
     reverse Trendelenburg position | 0
     skin preparation | 0
     draping | 0
     carbon dioxide insufflation | 0
     Veress needle | 0
     bladeless trocar | 0
     examination of the peritoneal cavity | 0
     right-sided stomach and spleen | 0
     liver and gallbladder on the left side | 0
     monitor positioning | 0
     surgeon positioning | 0
     nursing assistant positioning | 0
     iron intern laparoscopic liver retractor | 0
     dissection | 0
     gastrocolic ligament | 0
     gastrosplenic ligament | 0
     stapling | 0
     Endo GIA black articulating reload | 0
     calibrating tube | 0
     stapling the remainder of the stomach | 0
     Endo GIA purple articulating reload | 0
     staple line reinforcement | 0
     10 mm Endo clips | 0
     methylene blue leak test | 0
     no leak | 0
     calibrating tube removal | 0
     interrupted 2.0 vicryl gastropexy stitches | 0
     5 mm free gravity surgical drain | 0
     resected stomach removal | 0
     port site closure | 0
     skin closure | 0
     surgical duration 28 min | 0
     no surgical or anesthesia complications | 0
     extubation | 0
     transfer to recovery room | 0
     oral fluid intake | 6
     gastrografin leak test | 24
     satisfactory contrast flow | 24
     no leak | 24
     drain removal | 24
     discharge | 24
     follow-up in outpatient clinic | 168
     early postoperative complications excluded | 168
     wound care | 168
     follow-up at 3 months | 744
     weight loss | 744
     good glycemic control | 744
     follow-up at 6 months | 1488
     weight loss | 1488
     good glycemic control | 1488
     follow-up at 12 months | 2976
     weight loss | 2976
     good glycemic control | 2976
     off medications | 2976