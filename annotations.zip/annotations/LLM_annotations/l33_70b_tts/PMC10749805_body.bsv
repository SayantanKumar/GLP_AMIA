 70 years old | 0
     male | 0
     admitted to the hospital | 0
     type 2 diabetes mellitus | -7305
     hypertension | -7305
     chronic heart failure | -7305
     nephrotic syndrome | -7305
     bilateral leg swelling | -216
     dermatosclerosis | 0
     height 167.5 cm | 0
     body weight 78.7 kg | 0
     body mass index 28.1 kg/m2 | 0
     blood pressure 134/90 mmHg | 0
     pulse rate 95 beats per minute | 0
     atrial fibrillation | 0
     enlarged heart | 0
     cardiothoracic ratio 57% | 0
     right pleural effusion | 0
     serum BNP level 390.7 pg/mL | 0
     serum creatinine level 0.78 mg/dL | 0
     estimated glomerular filtration rate 75.2 mL/min/1.73 m2 | 0
     24-h quantity of protein in the urine 3.8 g | 0
     serum albumin level 3.0 g/dL | 0
     fasting plasma glucose level 141 mg/dL | 0
     hemoglobin A1c value 7.8% | 0
     glimepiride 1 mg/day | -7305
     dapagliflozin 5 mg/day | -7305
     nifedipine CR 60 mg/day | -216
     azilsartan 40 mg/day | -216
     diet therapy 1800 kcal/day | 0
     salt restriction NaCl 6 g/day | 0
     sacubitril/valsartan 200 mg/day | 216
     blood pressure dropped to 86/59 mmHg | 432
     sacubitril/valsartan 100 mg/day | 432
     azilsartan 20 mg/day | 576
     olmesartan 20 mg/day | 696
     multiple insulin injection therapy | 96
     glimepiride discontinued | 96
     dapagliflozin 10 mg/day | 120
     oral semaglutide 3 mg/day | 336
     mitiglinide 30 mg/day | 504
     voglibose 0.9 mg/day | 528
     discharged | 696
     urinary C-peptide level 49 μg/day | 0
     urinary C-peptide level 307 μg/day | 312
     serum C-peptide level 2.03 ng/mL | 0
     serum C-peptide level 2.71 ng/mL | 312
     serum C-peptide level 3.16 ng/mL | 648
     insulin requirement 51 units/day | 432
     insulin requirement 22 units/day | 696