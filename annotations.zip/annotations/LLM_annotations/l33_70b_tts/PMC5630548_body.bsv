 62 years old | 0
     male | 0
     body mass index 18.5 kg/m2 | 0
     type 2 diabetes | 0
     vildagliptin 100 mg/day | -8760
     dilated cardiomyopathy | -8760
     left ventricular assist device | -8760
     cerebral hemorrhage | -744
     craniotomy | -744
     left-side hemiparesis | -744
     glargine 6 units | 0
     insulin aspart 6-6-4 units | 0
     poor glycemic control | 0
     fasting plasma glucose level 120 mg/dL | 0
     postprandial plasma glucose 180-230 mg/dL | 0
     skin reactions | 0
     redness | 0
     itching | 0
     swelling | 0
     insulin aspart 30 mix 20-0-10 units | 24
     insulin degludec 12-0-4 units | 24
     allergic skin reactions | 24
     anti-insulin antibodies >50 U/mL | 0
     anti-insulin-specific immunoglobulin E 27 UA/mL | 0
     anti-insulin receptor antibodies 25.2% | 0
     hyperinsulinemia | 0
     fasting plasma glucose level 160 mg/dL | 0
     C-peptide level 7.22 ng/mL | 0
     immunoreactive insulin level 1150 μU/mL | 0
     type B insulin resistance syndrome | 0
     insulin allergy | 0
     acanthosis nigricans not found | 0
     no Helicobacter pylori infection | 0
     no renal impairment | 0
     glutamic acid decarboxylase antibody negative | 0
     low complement levels | 0
     serum C4 7 mg/dL | 0
     CH50 27 U/mL | 0
     Scatchard analysis | 0
     high-affinity sites | 0
     low affinity constant | 0
     high binding capacity | 0
     urinary tract infection | 0
     liraglutide 0.3 mg/day | 168
     liraglutide dose increased | 168
     liraglutide 0.9 mg/day | 336
     improved glycemic control | 720
     fasting plasma glucose level 90-110 mg/dL | 720
     postprandial plasma glucose level <160 mg/dL | 720
     no allergic skin reactions | 720
     no liraglutide-related side effects | 720
     no hypoglycemic event | 720
     laboratory parameters improved | 744
     fasting plasma glucose level 101 mg/dL | 744
     C-peptide level 4.1 ng/mL | 744
     immunoreactive insulin level 732 μU/mL | 744
     anti-insulin antibody level unchanged | 744
     anti-insulin receptor antibody level reduced | 744
     good glycemic control | 17520
     fasting plasma glucose level 100 mg/dL | 17520
     HbA1c 6.4% | 17520