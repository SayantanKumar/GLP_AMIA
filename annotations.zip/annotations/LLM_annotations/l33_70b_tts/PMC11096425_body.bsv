 50 years old | 0
     female | 0
     AF | -504
     AFL | -504
     Corvia atrial shunt | -504
     weekly palpitations | -504
     electrocardiograms documenting AF and AFL | -504
     rate control | -504
     drinks 2 standard drinks once per week | 0
     nonsmoker | 0
     does not exercise | 0
     mother has AF | 0
     father has AF | 0
     reduced weight from 108 kg to 96 kg on Ozempic | -168
     severe asthma | 0
     sotalol relatively contraindicated | 0
     Flecainide not preferred | 0
     sinus rhythm | 0
     general anesthesia | 0
     decapolar catheter in coronary sinus | 0
     Boston Scientific Farawave sheath for ablation | 0
     atrial burst pacing | 0
     isoproterenol 4 mcg/min | 0
     left-sided atrial ectopy | 0
     short, self-terminating AF | 0
     pulmonary vein isolation | 0
     CTI line ablation | 0
     Farapulse ablation catheter | 0
     flower configuration | 0
     intravenous glyceryl trinitrate 200 mcg | 0
     CTI block | 0
     pacing across CTI | 0
     Rosen wire through Corvia shunt | 0
     Farawave sheath through Corvia shunt | 0
     heparin | 0
     target activated clotting time 350-400 seconds | 0
     Farapulse ablation advanced to veins | 0
     eight pulses per vein | 0
     catheter retracted into sheath | 0
     sheath pulled back through Corvia device | 0
     no complications | 0
     typical AFL | -504
     atypical AFL | -504
     electrophysiology catheters getting caught on Corvia | 0
     shunt diameter too narrow | 0
     ablating tissue close to Corvia | 0
     transseptal puncture | 0
     discussion between electrophysiologist and interventional cardiologists | 0
     transseptal access via Corvia | 0
     dual antiplatelet therapy | -504
     device endothelialization | -504
     left atrial pressure measurement | -504
     low-caliber catheters | -504
     consultancy fees for Farapulse | 0
     investigators on RESPONDER-HF trial | 0