 36 years old | 0
     female | 0
     type 1 diabetes mellitus | 0
     poorly controlled | 0
     prescribed tirzepatide | -84
     weight 192 lbs | -84
     body mass index 32.2 kg/m2 | -84
     hemoglobin A1c 9.4% | -84
     lost 50 lbs | -28
     weight 142 lbs | -28
     body mass index 25.3 kg/m2 | -28
     severe nausea | -28
     heartburn | -28
     continued tirzepatide | -28
     acute worsening of nausea | -96
     acute worsening of heartburn | -96
     vomiting | -96
     inability to keep anything down | -96
     positive urine ketone finding | -96
     t:slim CIQ reported hypoglycemia | -96
     suspension of insulin delivery | -96
     treated hypoglycemia with glucose tablets | -96
     presented to emergency room | 0
     tachycardia | 0
     tachypnea | 0
     elevated blood pressure | 0
     normal body temperature | 0
     Kussmaul breathing | 0
     dry oral mucosa | 0
     volume depletion | 0
     CGM readings between 40 and 180 mg/dL | 0
     intermittent hypoglycemia | 0
     intermittent insulin delivery suspension | 0
     correction boluses for hyperglycemia | 0
     total daily dose of insulin 30 units | 0
     point of care glucose testing 289 mg/dL | 0
     serum glucose level 322 mg/dL | 0
     concurrent Dexcom CGM reading 40 mg/dL | 0
     hemoglobin level 16.2 g/dL | 0
     hematocrit 45.3% | 0
     HbA1c 7.4% | 0
     bicarbonate level 12 mmol/L | 0
     sodium level 131 mmol/L | 0
     potassium level 5 mmol/L | 0
     creatinine level 1.00 mg/dL | 0
     glomerular filtration rate 75 mL/min/1.73 m2 | 0
     anion gap 21 mmol/L | 0
     high-anion-gap metabolic acidosis | 0
     diagnosed with DKA | 0
     removed CLS and CGM devices | 0
     treated with continuous regular insulin | 0
     intravenous normal saline infusion | 0
     improvement in serum glucose level | 8
     closure of anion gap | 8
     improvement in bicarbonate level | 72
     transitioned to subcutaneous insulin | 72
     basal glargine and prandial lispro | 72
     total daily dose of insulin 24 units | 72
     discontinued tirzepatide | 72
     transitioned to t:slim CIQ system | 96
     Dexcom G6 CGM at preadmission settings | 96
     glycemic control within optimal range | 120
     total daily dose of insulin 37 units | 120
     outpatient follow-up | 240