 7 years old | 0
     male | 0
     Japanese | 0
     admitted to the hospital | 0
     diagnosed with DM | -144
     polyuria | -144
     polydipsia | -144
     blood glucose level 682 mg/dL | -144
     hemoglobin A1c level 12.2% | -144
     serum fasting C-peptide level 0.30 ng/mL | -144
     serum immunoreactive insulin concentration 0.8 µU/mL | -144
     anti-glutamic acid decarboxylase antibody negative | -144
     anti-insulin antibody negative | -144
     anti-insulinoma-associated protein-2 antibody negative | -144
     anti-zinc transporter 8 antibody negative | -144
     subcutaneous insulin injection therapy | -144
     insulin therapy twice daily | -96
     basal-bolus therapy | -72
     referred to Asahikawa Medical University Hospital | -24
     initiation of insulin-pump therapy | -24
     total daily dose of insulin 0.46 units/kg/day | -24
     HbA1c level 6.9% | -24
     serum fasting C-peptide level 0.24 ng/mL | -24
     endogenous insulin secretion impaired | -24
     ophthalmologic screening | -24
     uncorrected visual acuity 0.15 in the right eye | -24
     uncorrected visual acuity 0.2 in the left eye | -24
     optic nerve head pallor | -24
     critical flicker frequency 23.1 Hz in the right eye | -24
     critical flicker frequency 20.8 Hz in the left eye | -24
     magnetic resonance imaging | -24
     no obvious optic nerve atrophy | -24
     no hearing loss | -24
     no urinary tract malformations | -24
     no diabetes insipidus | -24
     no psychiatric symptoms | -24
     WFS1 gene analysis | -24
     INS gene analysis | -24
     KCNJ11 gene analysis | -24
     ABCC8 gene analysis | -24
     two heterozygous variants in exon 8 of the WFS1 gene | -24
     NM_006005.3: c.2483delinsGGA | -24
     NM_006005.3: c.1247T>A | -24
     compound heterozygous variants | -24
     mother had only the c.2483delinsGGA variant | -24
     diagnosed with WS | 0
     optic atrophy | 0
     diabetes insipidus | 0
     deafness | 0
     neurological complications | 0
     GLP-1 receptor analog treatment | 24
     no deterioration of insulin secretion | 168
     no significant changes in ophthalmological parameters | 168
     no significant changes in neuroradiological parameters | 168
     no significant changes in neurophysiological parameters | 168