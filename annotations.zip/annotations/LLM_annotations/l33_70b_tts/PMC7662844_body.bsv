 73 years old | 0
     male | 0
     type 2 diabetes | -1296
     anorexia | -1296
     weight loss | -1296
     diarrhea | -1296
     tetany attacks | -1296
     DPP4 inhibitor | -1296
     Metformin | -1296
     Glimipiride | -1296
     Abasaglar | -216
     Liraglutide | -216
     abdominal pain | -216
     episodes of tetany attacks | -216
     admission | 0
     conscious | 0
     normocardial | 0
     normotensive | 0
     eupnetic | 0
     afebrile | 0
     weight: 84kg | 0
     Height: 1.69 m | 0
     BMI: 29.13 | 0
     sign of Chvosteket negative | 0
     sign of keychain negative | 0
     normal parathyroid hormone | 0
     low vitamin D | 0
     urinary excretion of magnesium | 72
     IV magnesium supplementation | 0
     sodium | 0
     potassium | 0
     chloride | 0
     CO2 | 0
     glycemia | 0
     urea | 0
     creatinine | 0
     clearance | 0
     calcium | 0
     albumin | 0
     prealbumin | 0
     phosphorus | 0
     magnesium | 0
     intravenous electrolyte supplementation | 0
     calcium gluconate | 0
     magnesium sulfate | 0
     potassium chloride | 0
     ECG monitoring | 0
     normalization of serum calcium | 48
     normalization of serum magnesium | 48
     normalization of serum potassium | 48
     elevation of PTH | 48
     improvement of glycemic cycle | 48
     oral magnesium intake | 48
     discontinuation of Liraglutide | 48
     improvement in digestive disorders | 48
     stable balance | 48
     absence of hypoparathyroidism | 48
     causal link incriminating Liraglutide | 48