61 years old|0
male|0
presented to the office for a regular follow-up|0
blood pressure 124/72 mm Hg|0
heart rate 78 bpm|0
respiratory rate 12 bpm|0
temperature 98.3 F|0
asymptomatic|0
family history of T2DM in both parents|0
family history of cardiovascular disease in his mother|0
denied smoking|0
denied alcohol abuse|0
denied illicit drug intake|0
amlodipine|0
valsartan|0
atorvastatin|0
pioglitazone|0
metformin|0
insulin detemir|0
liraglutide|0
dapagliflozin|0
no calcium supplementation|0
no vitamin D supplementation|0
no proton pump inhibitors or histamine H2-receptor antagonists|0
no known medication allergies|0
proper hydration|0
denied palpitations|0
denied fatigue|0
denied abdominal pain|0
denied polyuria|0
denied impaired concentration|0
denied constipation|0
denied dysuria|0
denied flank pain|0
denied history of nephrolithiasis|0
denied weight loss|0
denied night sweats|0
denied dyspnea|0
denied cough|0
denied rash|0
physical examination unremarkable|0
no evidence of dehydration|0
laboratory testing performed| -24
calcium 11.1 mg/dL| -24
albumin 4.7 g/dL| -24
blood urea nitrogen 21 mg/dL| -24
creatinine 0.91 mg/dL| -24
chloride 101 mmol/L| -24
fasting glucose 139 mg/dL| -24
sudden-onset epigastric burning| -36
took six chewable tables of Tums 200 mg calcium (500 mg)| -36
denied taking Tums on a regular basis and had not had any in weeks|0
asked to refrain from ingesting Tums or any other over-the-counter antacid medication|0
asked to increase oral hydration|0
electrocardiography not ordered|0
repeat blood work|120
calcium normalized to 9.3 mg/dL|120
ruled out hyperparathyroidism|120
ionized calcium 4.8 mg/dL|120
parathyroid hormone intact 54 pg/mL|120
urine protein electrophoresis did not detect any monoclonal proteins|120
serum protein electrophoresis did not detect any monoclonal proteins|120