Ileocecal resection for Crohn’s disease|-20000  
Post-operative bile acid malabsorption|-20000  
CT of the abdomen showed no liver abnormalities|-17520  
4-day continuous glucose monitoring assessed using iPro2®|-96  
Referral to a hepatologist for further investigations|-1  
72 years old|0  
Male|0  
Participated as a control person in a clinical study|0  
Exercised regularly|0  
Low intake of alcohol|0  
No liver-related symptoms|0  
No family members with known liver disease|0  
No family members with known type 2 diabetes|0  
Type 2 diabetes|0  
Central obesity (waist circumference 100 cm)|0  
Raised triglycerides (1.8 mmol/L)|0  
Raised blood pressure (systolic 144 mm Hg)|0  
BMI 26.1 kg/m2|0  
Mean sensor glucose 8.0 mmol/L|0  
Glucose levels within the time-in-target-range 96%|0  
Physical examination performed|0  
No cirrhosis stigmata|0  
Modestly elevated alanine aminotransferase 78 U/L|0  
Elevated alkaline phosphatase 108 U/L|0  
Elevated gamma-glutamyl-transferase 159 U/L|0  
Aspartate aminotransferase within normal range|0  
Bilirubin within normal range|0  
Platelet count within normal range|0  
Albumin within normal range|0  
Transient elastography median 16.1 kPa|0  
Fib-4 score 1.56|0  
Fasting FibroScan median 19.8 kPa|0  
Percutaneous liver biopsy performed|1  
Mild steatosis on histology|1  
Inflammation on histology|1  
Ballooning on histology|1  
Fibrosis grade 4 on histology|1  
Alcoholic cirrhosis ruled out|1  
Other liver diseases ruled out|1  
Advice regarding diet|2  
Advice regarding physical activity|2  
Advice regarding alcohol intake|2  
Patient did not smoke|0  
Semaglutide therapy|0  
Atorvastatin therapy|0  
Empagliflozin added|3  
Follow-up 21 months after initial investigation|15120  
Decrease in BMI to 24.7 kg/m2|15120  
Decrease in HbA1c by 1 mmol/mol|15120  
Decrease in total cholesterol by 0.2 mmol/L|15120  
Decrease in LDL cholesterol by 0.3 mmol/L|15120  
Decrease in triglycerides by 0.35 mmol/L|15120  
Decrease in ALT to 61 U/L|15120  
Decrease in AST to 37 U/L|15120  
Decrease in liver stiffness to 12.2 kPa|15120  
No signs of hepatic decompensation|15120