21 years old|0  
male|0  
admitted to hospital|0  
severe abdominal pain| -720  
total colonoscopy| -700  
diagnosed with UC| -700  
prednisolone started| -690  
tacrolimus started| -690  
mesalazine started| -690  
hyperglycemia (~300–400 mg/dL)| -680  
HbA1c 5.2%| -680  
GA 16.8%| -680  
anti-GAD antibody <5.0 U/mL (negative)|0  
anti-IA-2 antibody <0.6 U/mL (negative)|0  
anti-ZnT8 antibody <10.0 U/mL (negative)|0  
urinary C-peptide 52.3 μg/day|0  
C-peptide index 0.7|0  
∆C-peptide on glucagon load 0.4 ng/mL|0  
HLA-DRB1 1503|0  
acute paralytic ileus| -24  
emergency subtotal colectomy|0  
symptom resolution|24  
prednisolone tapered|48  
hyperglycemia persisted|72  
intensive insulin therapy (lispro/glargine)|72  
BMI 18.6 kg/m2|72  
rectumectomy (completion of total colectomy)|1080  
UC resolved|1100  
prednisolone discontinued|1104  
tacrolimus discontinued|1104  
mesalazine discontinued|1104  
insulin switched to vildagliptin|1110  
HbA1c increased to 9.5%|2160  
metformin 1000 mg started|2160  
glimepiride 1 mg started|2160  
minor glycemic effect (HbA1c to 8.2%)|3600  
dulaglutide initiated (0.75 mg weekly)|3600  
HbA1c decreased to 5.9% (after 8 weeks)|4944  
HbA1c decreased to 5.4% (after 20 weeks)|6960  
no adverse events|6960  
HbA1c worsened to 11.3% (after 11 months)|11520  
intensive insulin therapy reintroduced (lispro/glargine)|11520  
HbA1c controlled to 5.3%|11600  
urinary C-peptide 26.8 μg/day|11600  
C-peptide index 0.36|11600  
∆C-peptide on glucagon load 0.1 ng/mL|11600  