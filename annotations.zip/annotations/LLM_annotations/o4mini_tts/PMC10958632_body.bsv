33 years old|0
female|0
referred for diabetes management|0
developed diabetes|−26280
A1C of 9.1% (76 mmol/mol)|−26280
body mass index of 31 kg/m2|−26280
kidney transplant|−70080
normal glucose levels|−70080
moderately increased glucose levels|−8760
negative anti-GAD65 antibodies|0
negative antipancreatic islet cell antibodies|0
fasting C-peptide 2.9 ng/mL|0
random C-peptide 5.2 ng/mL|0
denied family history of diabetes|0
denied family history of renal disease|0
improved glucose control|0
diet|0
exercise|0
administration of glucagon-like peptide-1 agonist|0
low doses of insulin|0
progressive loss of kidney function|−183960
pretransplant imaging|−70080
bilateral renal cysts|−70080
markedly atrophic left kidney|−70080
imaging at age 31 years|−17520
scarred native kidneys|−17520
atrophy of the body of the pancreas|−17520
atrophy of the tail of the pancreas|−17520
serial sweeping transvaginal ultrasound|0
normal uterine body|0
uninterrupted endometrial stripe|0
abnormal fundal arcuate contour|0
interrupted endometrial stripe|0
genetic testing|0
complete deletion of the entire coding sequence of gene HNF1β|0