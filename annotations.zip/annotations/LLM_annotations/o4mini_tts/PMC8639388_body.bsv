painful sores|-7200
pruritic sores|-7200
hyperkeratotic papules|-7200
nodules|-7200
initial presentation to outside clinic|-720
topical triamcinolone|-720
topical compounded mupirocin/clindamycin/ivermectin/gentamicin|-720
oral ciprofloxacin|-720
oral fluconazole|-720
computed tomography angiogram unremarkable|-720
duplex ultrasound with Doppler unremarkable|-720
biopsy revealed stasis dermatitis|-720
biopsy revealed extensive fungal hyphae|-720
long-term systemic antifungal therapy not initiated|-720
68-year-old woman|0
female|0
type 2 diabetes mellitus|0
diabetic polyneuropathy|0
lower-leg edema|0
presented to our clinic|0
no fever|0
no cough|0
no lymphadenopathy|0
lives in middle Tennessee|0
gardener|0
tends to rosebushes|0
wears capri pants when gardening|0
never used tobacco|0
never used illicit substances|0
rarely drinks alcohol|0
denies recent travel|0
dulaglutide|0
omeprazole|0
pain medications|0
vitamin supplements|0
does not take immunosuppressive medications|0
elevates her legs nightly with ice therapy|0
vegetative papules|0
hyperkeratotic papules|0
plaques|0
central ulceration|0
erythema|0
stasis changes|0
plaques non-tender|0
plaques cool to touch|0
no nail changes|0
no additional skin changes|0
hemoglobin A1c of 11.8%|0
white blood cell count of 5600/mm3|0
complete metabolic panel unremarkable|0
bacterial cultures exhibited no growth|0
acid-fast bacilli cultures exhibited no growth|0
fungal tissue cultures positive for P. lilacinus|0
fungal tissue cultures positive for C. guilliermondii|0
antifungal susceptibility not obtained|0
dermal fibroplasia|0
mixed neutrophilic and lymphocytic dermal inflammation|0
no abscess formation|0
no granuloma formation|0
Grocott methenamine silver stain revealed numerous fungal hyphae within the stratum corneum|0
Gram staining failed to reveal a causative organism|0
acid-fast bacilli staining failed to reveal a causative organism|0
diagnosed with cutaneous P. lilacinus infection|0
diagnosed with cutaneous C. guilliermondii infection|0
started oral voriconazole 200 mg every 12 hours|0
topical triamcinolone|0
plastic wraps for discomfort|0
planned 6-month course of antifungal therapy|0
marked improvement noted|1440
images at 2 months|1440
slow-healing plaques that have crusted over|1440
slow-healing plaques healed completely with scarring and post-inflammatory hyperpigmentation|1440
no new development of ulcerative papules|1440
no new development of plaques|1440