80 years old|0  
male|0  
obese|0  
past history of smoking|0  
diabetes mellitus|0  
hypertension|0  
colon carcinoma treated with surgery and radiation therapy|0  
prostate carcinoma treated with surgery and radiation therapy|0  
admission to the hospital|0  
progressive dyspnoea|0  
bilateral lower extremity oedema|0  
weight gain of 10 kg in a few weeks|-504  
vital signs normal|0  
cardiac examination normal|0  
no additional heart sounds heard|0  
jugular veins not visualized due to severe obesity|0  
pulmonary auscultation: mildly decreased breath sounds in lower region bilaterally|0  
abdominal distension with tympanitic percussion suspect for ascites|0  
extensive bilateral oedema in lower extremities|0  
medication: bumetanide 4 mg once a day|0  
medication: darbepoetin alfa every 2 weeks|0  
medication: insulin degludec/liraglutide 32 E once a day|0  
medication: irbesartan 300 mg once a day|0  
medication: nifedipine 30 mg once a day|0  
medication: omeprazole 20 mg once a day|0  
medication: pregabalin 75 mg twice a day|0  
medication: tamsulosin 0.4 mg once a day|0  
electrocardiogram showed new-onset atrial fibrillation with normal ventricular response|0  
electrocardiogram: no signs of ischaemia|0  
normocytic anaemia (haemoglobin 7.6 mmol/L)|0  
elevated D-dimer level (3.17 mg/L)|0  
elevated gamma-glutamyl transferase (89 IU/L)|0  
decreased renal function (creatinine 233 μmol/L)|0  
transthoracic echocardiogram: left ventricle normal dimensions|0  
transthoracic echocardiogram: preserved left heart function (EF 60%)|0  
transthoracic echocardiogram: D-shaped left ventricle in systole and diastole suggesting increased right-sided pressure|0  
transthoracic echocardiogram: mitral annular calcification without valve dysfunction|0  
transthoracic echocardiogram: left atrial dilatation|0  
transthoracic echocardiogram: snake thrombus in IVC extending into right atrium|0  
start anticoagulant therapy with tinzaparin 14 000 IE once a day|0  
CT scan abdomen showed large mass in right kidney suspect for RCC|24  
CT scan thorax showed no metastases|72  
multidisciplinary consultation: clinical condition too poor for surgery|72  
plan biopsy to consider neo-adjuvant chemotherapy|72  
diagnosis of right-sided T3bN0Mx renal cell carcinoma|72  
inadequate anti-Xa level (0.33 U/mL)|96  
switch to heparin intravenous|96  
progressive kidney failure with congestion|168  
start of palliative care|216  
patient deceased|288