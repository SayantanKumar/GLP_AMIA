35-year-old male|0  
no medical illness|0  
presented for medical weight-loss management|0  
low-calorie diet not exceeding 1,500 calories/day|0  
mild exercise of walking 45 min three times per week|0  
Liraglutide 0.6 mg started|0  
initial weight 118 kg|0  
height 171 cm|0  
BMI 40.4|0  
initial WBC 6.62×10^9/L|0  
initial platelets 296×10^9/L|0  
initial Hb 16.1 g/dL|0  
initial fasting glucose 5.5 mmol/L|0  
initial urea 4.5 mmol/L|0  
initial creatinine 65 µmol/L|0  
initial uric acid 341 µmol/L|0  
initial cholesterol 5.2 mmol/L|0  
initial triglycerides 1.1 mmol/L|0  
initial sodium 133 mmol/L|0  
initial potassium 4.5 mmol/L|0  
initial chloride 101 mmol/L|0  
initial total bilirubin 26 µmol/L|0  
initial AST 36 IU/L|0  
initial ALT 51 IU/L|0  
initial ALP 60 IU/L|0  
Liraglutide 1.2 mg started|168  
Liraglutide 1.8 mg started|336  
Liraglutide 2.4 mg started|504  
Liraglutide 3.0 mg started|672  
after 45 days weight 102 kg|1080  
after 45 days BMI 34.9|1080  
13.55% weight loss|1080  
after-treatment WBC 6.2×10^9/L|1080  
after-treatment platelets 300×10^9/L|1080  
after-treatment Hb 15.8 g/dL|1080  
after-treatment fasting glucose 5.1 mmol/L|1080  
after-treatment urea 5.5 mmol/L|1080  
after-treatment creatinine 67 µmol/L|1080  
after-treatment uric acid 339 µmol/L|1080  
after-treatment cholesterol 5.1 mmol/L|1080  
after-treatment triglycerides 1 mmol/L|1080  
after-treatment sodium 138 mmol/L|1080  
after-treatment potassium 3.8 mmol/L|1080  
after-treatment chloride 105 mmol/L|1080  
after-treatment total bilirubin 20 µmol/L|1080  
after-treatment AST 36 IU/L|1080  
after-treatment ALT 40 IU/L|1080  
after-treatment ALP 65 IU/L|1080  
no remarkable blood analysis|1080  
no remarkable urine analysis|1080  
no remarkable lipid profile|1080  
no remarkable liver function tests|1080