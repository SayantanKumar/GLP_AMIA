GDM diagnosed at 15 weeks of gestation|-2520  
serum glucose level of 266 mg/dL|-2520  
HbA1C level of 5.9%|-2520  
initiation of neutral protamine Hagedorn insulin once daily|-1680  
initiation of regular insulin three times daily|-1680  
nonadherence to insulin regimen|-1680  
general malaise|-72  
altered sensorium|-72  
nausea|-72  
emesis|-72  
brought to the emergency department|0  
30 weeks of gestation|0  
class III obesity|0  
no diagnosis of preexisting DM|0  
blood pressure 70/40 mm Hg|0  
heart rate 150 beats/min|0  
respiratory rate 26 breaths/min|0  
dry mucous membranes|0  
decreased skin turgor|0  
serum glucose level 920 mg/dL|0  
pH 7.02|0  
anion gap 38 mmol|0  
bicarbonate level 5.0 mEq/L|0  
serum potassium level 3.4 mEq/L|0  
large serum ketones present|0  
white blood cell count 24.13 × 10^3/μL|0  
predominance of leukocytes|0  
SARS-CoV-2 polymerase chain reaction negative|0  
IUFD diagnosed by ultrasound|0  
treated with intravenous fluids|0  
treated with continuous insulin|0  
received potassium|0  
received bicarbonate|0  
received piperacillin-tazobactam|0  
new HbA1C level of 9%|0  
hypokalemia worsened to 2.5 mEq/L|0  
insulin withheld until serum potassium reached above 3.3 mEq/L|0  
spontaneously delivered a nonviable fetus|20  
DKA resolved|20  
managed with basal-bolus insulin therapies|20  
managed with sliding scale insulin|20  
patient’s mental status returned to baseline|68  
negative for DM before pregnancy|68  
transferred to regular medicine ward|68  
hyperglycemia between 250 and 300 mg/dL|68  
basal-bolus insulin dose increased|68  
glycemia reduced to 180 to 200 mg/dL|68  
negative antiglutamic acid decarboxylase antibodies|120  
negative islet cell antibodies|120  
negative zinc transporter 8 antibodies|120  
C-peptide level of 2.4 ng/dL|120  
discharged|168  
basal insulin 25 units twice daily|168  
preprandial insulin 10 units three times daily|168  
metformin 500 mg twice daily|168  
outpatient follow-up visit scheduled|336  
autopsy of the nonviable fetus|408  
female fetus with macrosomia (bodyweight 1640 g)|408  
heart weight 12.7 g|408  
pancreatic islet cell hyperplasia|408  
mild adrenal granulosa layer hyperplasia|408  
no congenital anomalies|408  
no inflammation or thrombosis of a 3-vessel umbilical cord|408  
multiple focal hyperacute ischemic infarction|408  
small intervillous thrombi associated with peripheral parenchymal infarction|408  
mildly increased fibrin deposition on her basal plate|408  
returned to diabetes clinic|1608  
point of care HbA1C level of 5.5%|1608  
body mass index 48 kg/m2|1608  
preprandial insulin discontinued|1608  
basal insulin decreased to 25 units daily|1608  
metformin dose increased to 1 g twice daily|1608  
glucagon-like peptide 1 receptor agonist initiated|1608  
3-month follow-up HbA1C level of 5.3%|3768  
6-month follow-up HbA1C level of 5%|5928  
metformin 500 mg twice daily (maintenance)|5928  
dulaglutide 1.5 mg once a week|5928