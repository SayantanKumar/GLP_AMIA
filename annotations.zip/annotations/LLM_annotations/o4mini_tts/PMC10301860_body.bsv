40-year-old transgender woman | 0  
hypertension | 0  
prediabetes (hemoglobin A1c, 6.1%) | 0  
mixed hyperlipidemia | 0  
nonalcoholic steatohepatitis | 0  
gastroesophageal reflux | 0  
solitary congenital kidney | 0  
presented to academic weight management program | 0  
weight 280 pounds (127 kg) | 0  
BMI 39.6 kg/m2 | 0  
no prior experience with weight loss programs | 0  
no prior experience with antiobesity medications | 0  
no prior experience with metabolic and bariatric surgery | 0  
wished to lose 35 pounds (16 kg) | 0  
instructed to follow lower calorie diet | 0  
referred for sleep study | 0  
walking at work | 0  
not willing to engage in gym exercises | 0  
not willing to engage in outdoor activities | 0  
counseled on home exercises | 0  
provided online queer-friendly resources | 0  
prescribed semaglutide 0.25 mg weekly | 0  
no disordered eating | 0  
endorsed sweet cravings | 0  
drinking multiple sugary beverages daily | 0  
did not incorporate resistance activity | 0  
encouraged to do light resistance activity | 0  
began home resistance band training program | 0  
weight stable at 240 pounds (109 kg) for 3 years | -26280  
estradiol valerate 10 mg IM weekly | -26280  
spironolactone 50 mg orally | -26280  
started micronized progesterone 100 mg orally nightly | -8760  
peak weight 294 pounds (133 kg) | -4380  
lost 14 pounds in 1 month | -720  
reduced candy and sugary beverages | -720  
experienced significant improvements in hunger and satiety | 168  
dose escalated at monthly appointment | 720  
abdominal cramping | 720  
reached semaglutide 1.0 mg weekly | 2160  
weight 241 pounds (109 kg) | 2160  
BMI 34.1 kg/m2 | 2160  
13.9% total body weight loss | 2160  
hemoglobin A1c improved to 5.4% | 2160  
creatinine increased to 1.36 mg/dL | 2160  
acute kidney injury | 2160  
AKI resolved with increased water consumption | 2200  
estradiol level increased >500 pg/mL | 2160  
estradiol dose reduction | 2160  
referred to plastic surgeon to schedule surgery | 2160  
sleep study results consistent with moderate OSA | 168  
referred to sleep medicine | 168  