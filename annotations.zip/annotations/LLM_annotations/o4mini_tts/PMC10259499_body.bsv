type 2 diabetes diagnosed | -61320  
50‐year‐old woman | 0  
female | 0  
referred to our department | 0  
check‐up examinations | 0  
deranged liver enzyme levels accidentally discovered | 0  
hypertension | 0  
obesity (BMI 39.2) | 0  
metformin 1 g daily prescribed | 0  
gliclazide 120 mg daily prescribed | 0  
amlodipine 10 mg daily prescribed | 0  
no palmar erythema | 0  
no vascular spiders | 0  
palpable liver on abdominal exam | 0  
relatively soft liver on abdominal exam | 0  
mild splenomegaly on abdominal exam | 0  
blood and liver function tests performed | 0  
elevated ALT | 0  
elevated AST | 0  
elevated GGT | 0  
abnormal lipid profile with high triglycerides (324 mg/dL) | 0  
FIB-4 index elevated (6.4) | 0  
hepatitis B surface antigen negative | 0  
anti-hepatitis C virus antibodies negative | 0  
autoantibodies negative | 0  
abdominal ultrasound performed | 0  
bright hepatomegaly on ultrasound | 0  
portal vein diameter 14 mm on ultrasound | 0  
no ascites on ultrasound | 0  
diagnosed with NASH | 0  
advised weight reduction | 0  
advised dyslipidaemia control | 0  
liraglutide 0.6 mg daily prescribed | 0  
liraglutide dose maintained at 3 mg daily | 0  
simvastatin 20 mg daily prescribed | 0  
silymarin 140 mg three-times daily recommended | 0  
follow-up visit after 4 months | 2880  
ALT levels decreased | 2880  
AST levels decreased | 2880  
follow-up visit after 7 months | 5040  
ALT normalized | 5040  
AST normalized | 5040  
GGT levels decreased | 5040  
triglyceride levels normalized | 5040  
good treatment adherence | 5040  
no adverse events | 5040  
no drug interactions | 5040