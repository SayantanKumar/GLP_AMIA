cataract surgery with intraocular lens implantation in the right eye| -13140  
72-year-old| 0  
male| 0  
board-certified ophthalmologist| 0  
atrial fibrillation| 0  
mild, not-visually-significant nuclear cataract on the left| 0  
absence of diabetes mellitus| 0  
absence of retinopathy| 0  
started oral semaglutide 3.0 mg daily| 0  
propranolol 20 mg twice a day| 0  
aspirin 81 mg daily| 0  
naproxen 220 mg as needed| 0  
ibuprofen 400 mg as needed| 0  
knee pain from a fall| 216  
first noticed right eye round central scotoma| 384  
symptoms observed under scotopic conditions| 384  
symptoms persisted throughout the night| 384  
symptoms present in a dimly lit hallway| 384  
symptoms disappeared upon turning on a lamp| 384  
symptoms disappeared with emergence of daylight| 384  
bright white afterimage of the scotoma faded over 5 seconds when closing his eyes| 384  
scotoma took on a dark brown appearance for a fraction of a second and then disappeared when entering a partially lit bathroom| 384  
denied any associated neurologic changes| 384  
denied any associated autoimmune changes| 384  
denied any associated psychiatric changes| 384  
denied any other systemic changes| 384  
enlarging square scotoma including and just below fixation| 408  
minimal, small and round scotoma in the left eye| 456  
discontinued semaglutide| 480  
round scotomas persist both eyes| 504  
enlarged scotoma in the right eye covering a door panel| 528  
residual scotomas remain| 552  
scotomas gone| 576  
returned from vacation| 624  
formal ophthalmic evaluation| 624  
uncorrected distance visual acuity 20/20 in the right eye| 624  
uncorrected distance visual acuity 20/25 in the left eye| 624  
anterior segment exam benign including well-centered intraocular lens and clear posterior capsule in the right eye| 624  
mild nuclear sclerotic cataract in the left eye| 624  
fundus examination normal appearing optic nerves| 624  
fundus examination scattered small drusen in each macula| 624  
fundus examination vitreous opacities from a posterior vitreous detachment in the left eye| 624  
Humphrey visual field testing 10-2 reliable without evidence of visual field loss| 624  
macular optical coherence tomography subretinal drusenoid deposits with a poorly defined interdigitation zone in the fovea| 624  
macular optical coherence tomography preserved interdigitation zone elsewhere in the macula| 624  
retinal nerve fiber layer OCTs normal| 624