20-year-old male|0  
autism spectrum disorder|0  
intellectual disability|0  
severe food obsessions|0  
compulsive overeating|0  
treatment with antipsychotics|-720  
weight gain|-720  
worsening of food-related behaviors|-720  
Liraglutide 2.4 mg/day|0  
weight loss of 12–13%|6048  
no adverse side effects|6048