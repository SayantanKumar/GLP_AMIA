37-year-old woman|0  
presented|0  
progressive neurological complaints| -336  
disequilibrium| -336  
unsteadiness on her feet| -336  
difficulty closing both eyes| -168  
right lip numbness| -168  
right hearing impairment| -168  
left hearing impairment| -168  
slurred speech| -168  
denies limb weakness|0  
denies limb numbness|0  
denies headache|0  
denies neck stiffness|0  
denies photophobia|0  
denies nausea|0  
denies vomiting|0  
denies visual changes|0  
denies fever|0  
denies rash|0  
denies lymph node swelling|0  
denies night sweats|0  
10 kg weight loss| -2160  
diagnosed type 2 diabetes mellitus| -2160  
metformin| -2160  
gliclazide| -2160  
dulaglutide| -2160  
morbid obesity|0  
asthma|0  
eczema|0  
not taking steroids|0  
not taking immunosuppressant medication|0  
engaging in unprotected sex|0  
denies intravenous drug use|0  
bilateral trigeminal (V) neuropathy|0  
bilateral abducens (VI) neuropathy|0  
bilateral facial (VII) neuropathy|0  
bilateral vestibulocochlear (VIII) neuropathy|0  
bilateral hypoglossal (XII) neuropathy|0  
lateral gaze restricted bilaterally|0  
upper facial weakness|0  
lower facial weakness|0  
impaired eyebrow raise|0  
eye closure impairment|0  
inability to smile|0  
Weber’s test lateralized to left ear|0  
Rinne’s test air conduction > bone|0  
tongue weak|0  
tongue midline on protrusion|0  
sensation decreased to light touch in right V2 distribution|0  
sensation decreased to pinprick in right V2 distribution|0  
remainder of neurological exam unremarkable|0  
no palpable lymphadenopathy|0  
no splenomegaly|0  
elevated C reactive protein 12 mg/L|0  
elevated erythrocyte sedimentation rate 21 mm/hour|0  
thrombocytosis 447×10^9/L|0  
full blood examination unremarkable|0  
renal function unremarkable|0  
electrolytes unremarkable|0  
liver function tests unremarkable|0  
serum β-human chorionic gonadotropin <1.2 IU/L|0  
haemoglobin A1c 8.7%|0  
CSF opening pressure normal|0  
CSF elevated protein 1.28 g/L|0  
CSF normoglycaemia|0  
CSF lymphocyte-predominant leucocytosis 0.441×10^9/L|0  
MRI enhancement of trigeminal nerve at pons|0  
MRI enhancement of facial nerve at geniculate ganglion|0  
MRI enhancement of vestibulocochlear nerve at geniculate ganglion|0  
no recent infarct on brain MRI|0  
no leptomeningeal enhancement on brain MRI|0  
contrast-enhanced spine MRI unremarkable|0  
CT neck/chest/abdomen/pelvis negative for malignancy|0  
CT neck/chest/abdomen/pelvis negative for lymphadenopathy|0  
serum TPPA positive|0  
serum CMIA IgG and IgM positive|0  
serum RPR titre 1:32|0  
CSF TPPA positive|0  
CSF VDRL titre 1:8|0  
CSF T. pallidum PCR negative|0  
workup for other infectious disorders negative|0  
workup for autoimmune disorders negative|0  
workup for neoplastic disorders negative|0  
early syphilitic meningitis diagnosed|0  
denies primary syphilitic chancre|0  
Chlamydia trachomatis detected on urine PCR|0  
intravenous benzylpenicillin 1.8 g every 4 hours started|0  
prophylactic steroid medication not given|0  
no Jarisch–Herxheimer reaction|0  
cranial neuropathies improved|192  
doxycycline 100 mg twice daily started|0  
discharged home to complete antibiotic therapy|360  
outpatient infectious diseases review scheduled|360  
serological monitoring of RPR titre planned|360  
consideration of repeat CSF examination planned|360