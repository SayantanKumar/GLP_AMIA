Diagnosed with PCOS|-61320  
Diagnosed with T2D|-61320  
treated with metformin|-61320  
treated with liraglutide|-61320  
treated with ACE inhibitor|-61320  
irregular periods|-2065  
significant weight loss of 30 kg|-2065  
regular periods|-2065  
spontaneous pregnancy|-2065  
HbA1c 41 mmol/mol|-2065  
blood pressure normal|-2065  
discontinued metformin|-2065  
discontinued liraglutide|-2065  
discontinued ACE inhibitor|-2065  
referred to the outpatient clinic|0  
36 years old|0  
pre-pregnancy BMI 40 kg/m2|0  
blood pressure 136/71 mmHg|0  
no medical history of lipodystrophy|0  
no clinical or biochemical features of severe acanthosis nigricans|0  
no hirsutism|0  
no obstructive sleep apnea|0  
no Cushing’s syndrome|0  
no acromegaly|0  
no hyperthyroidism|0  
HbA1c 59 mmol/mol|0  
initiated insulin treatment with Novomix 30 20 IU/day|0  
dietary advice given|0  
caloric restriction recommended|0  
exercise recommendations given|0  
self-monitoring of glucose seven times a day|0  
frequent insulin adjustments performed|0  
target capillary plasma glucose 4–6 mmol/L preprandial|0  
target capillary plasma glucose 4–8 mmol/L 1½ h after meals|0  
Novomix 30 14 IU×2 per day|96  
Novomix 30 18 IU×3 per day|240  
Novomix 30 24+18+24 IU/day|432  
Novomix 30 66+30+66 IU and Insulatard 30 IU/day|936  
Insulatard 90+0+35 IU and Novorapid 26+20+40 IU per day|1368  
weight 53 kg|1368  
Insulatard 90+0+40 IU and Novorapid 40+50+60 IU per day|1704  
Insulatard 100+0+40 IU and Novorapid 40+50+60 IU per day|2040  
Insulatard 120+0+50 IU and Novorapid 60+50+65 IU per day|2376  
Insulatard 130+0+60 IU and Novorapid 40+50+80 IU per day|2712  
weight 50 kg|2712  
Insulatard 150+0+90 IU and Novorapid 120+100+120 IU per day|3120  
Insulatard 120+120+120 IU and Novorapid 120+120+120+60 IU per day|3264  
Insulatard 180+0+120 IU and Novorapid 180+180+300+60 +200–400 IU prn per day|3720  
insulin requirements 1420 IU/day|3720  
metformin not attempted|3720  
blood samples taken for cause of extreme insulin resistance|3744  
insulin requirements 720 IU/day|3816  
admission for observation|3816  
no signs of placental insufficiency|3816  
insulin requirements 520 IU/day|3840  
insulin requirements 480 IU/day|3864  
weight 155 kg|3888  
HbA1c 59 mmol/mol|3888  
insulin requirements 60 IU/day|3888  
C-peptide 3294 pmol/L|3888  
P-Insulin 923 pmol/L|3888  
P-proinsulin 102 pmol/L|3888  
insulin antibody 4 (negative)|3888  
prolactin 5280 ×10−3 IU/L|3888  
IGF-1 401 µg/L|3888  
P-cortisol 377 nmol/L|3888  
CRP 14 mg/L|3888  
CD163 2.02 mg/L|3888  
adiponectin 7.70 mg/L|3888  
FFA 0.46 mmol/L|3888  
hsCRP 10.2 mg/L|3888  
MBL 2418 ng/mL|3888  
IL-6 1.48 pg/mL|3888  
TNF-α 6.91 pg/mL|3888  
leptin 117.6 µg/L|3888  
FGF-21 181.2 ng/L|3888  
antibodies against insulin undetectable|3888  
INSR gene sequenced, no mutations detected|3888  
P-Insulin 1295 pmol/L|3912  
P-proinsulin 177 pmol/L|3912  
insulin requirements 0 IU/day|3912  
P-Insulin 228 pmol/L|3936  
insulin requirements 0 IU/day|3936  
insulin requirements 0 IU/day|3984  
cesarean section|4008  
unsuccessful induction of labor|4008  
Apgar scores normal|4008  
baby no abnormalities|4008  
birthweight 3850 g|4008  
placental weight 920 g|4008  
baby blood glucose 2.8 mmol/L at 1 h|4009  
baby blood glucose 4.3 mmol/L at 4 h|4012  
P-Insulin 76 pmol/L|4056  
C-peptide 1623 pmol/L|4056  
prolactin 4787 ×10−3 IU/L|4056  
IGF-1 123 µg/L|4056  
breastfeeding|4056  
no antidiabetic medication|4056  
discharged mother and baby|4128  
advise self-monitoring of glucose regularly|4128  
consult general practitioner for diabetes check-up|4128  
P-Insulin 258 pmol/L|9048  
C-peptide 1836 pmol/L|9048  
P-proinsulin 76 pmol/L|9048  
HbA1c 116 mmol/mol|9048  
insulin increased above reference range|9048  
treatment warranted|9048