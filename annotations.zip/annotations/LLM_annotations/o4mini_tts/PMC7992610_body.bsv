type 2 diabetes onset | -148920  
exenatide extended-release injections start | -3600  
slowly enlarging nodule on his left thigh onset | -168  
54 years old | 0  
male | 0  
complained of a slowly enlarging nodule on his left thigh | 0  
solitary subcutaneous nodule | 0  
2-cm nodule | 0  
skin-colored nodule | 0  
without pain | 0  
with some tenderness | 0  
history of type 2 diabetes | 0  
received exenatide extended-release injections | 0  
injected once per week | 0  
experienced no side effects | 0  
nodule excision | 0  
histopathologic examination | 0  
lobular panniculitis | 0  
septal panniculitis | 0  
fat necrosis | 0  
lymphohistiocytic cells | 0  
eosinophils | 0  
multinucleate giant cells | 0  
vacuoles | 0  
spaces | 0  
diagnosed with EP | 0  
EP due to exenatide extended-release injection | 0  
changed to an oral medication | 0  
no relapse on follow-up | 0