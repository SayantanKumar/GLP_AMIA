falling night heart rate to 37 bpm | -1440  
last device check (four months earlier) | -2880  
good battery life and stable lead parameters | -2880  
no arrhythmias | -2880  
VF arrest | -17520  
pulmonary valve replacement | -17520  
ICD implantation | -17520  
data streaming from ICD began to transmit an abnormal cardiac rhythm | 0  
alert notified secondary care team | 0  
attempted to contact patient (unsuccessful) | 0  
heart rate drop to around 30 bpm | 0  
entered asystole | 0  
last device transmissions showed a heart rate of 24 bpm | 0  
device delivering multiple shocks | 0  
corresponding alert “Right ventricular intrinsic amplitude out of range” | 0  
pulmonary stenosis with previous valvotomy | 0  
congenital heart disease | 0  
atrial fibrillation | 0  
Type 2 Diabetes Mellitus | 0  
hypercholesterolemia | 0  
gout | 0  
Next of Kin contacted by cardiology doctors during ambulance journey | 1  
ambulance arrived at patient’s address | 3  
found deceased in bed | 3  
CPAP machine on with mask in situ for obstructive sleep apnoea | 3  
pathologists pulled out leads during autopsy | 24  
scarring of the heart and pathological changes observed (prevented delicate extraction) | 24  
device treated as medical waste by funeral team | 24  
historic transmitted data not interrogated | 24  
cloud data not retrospectively analysed | 24  
sleep mask not collected for analysis | 24  
cause of death assigned to underlying heart failure; digital components not considered | 24  
remote clinic appointment documented | 48  
booked another appointment in six months’ time | 48  