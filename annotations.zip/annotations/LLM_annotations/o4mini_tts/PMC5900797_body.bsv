common cold | -168
admitted to emergency department | 0
type 2 diabetes mellitus | 0
panhypopituitarism | 0
partial resection of craniopharyngioma | 0
previous episodes of hyperosmolarity | 0
decreased feeling of thirst | 0
malcompliance with desmopressin regimen | 0
hydrocortisone therapy | 0
thyroxine therapy | 0
oestradiol/norgestrel therapy | 0
growth hormone therapy | 0
nasal desmopressin therapy | 0
liraglutide therapy | 0
leg pain | 0
muscle weakness | 0
polyuria | 0
normal motor function | 0
normal level of consciousness | 0
afebrile | 0
blood pressure 105/69 mmHg | 0
heart rate 79 bpm | 0
oxygen saturation 98% on ambient air | 0
first 24 h urine output 3880 mL | 0
haemoglobin 145 g/L | 0
leukocytes 4.2 ×10^9/L | 0
platelets 159 ×10^9/L | 0
haematocrit 0.43 | 0
INR 1.0 | 0
sodium 161 mmol/L | 0
potassium 3.2 mmol/L | 0
chloride 132 mmol/L | 0
calcium 2.66 mmol/L | 0
serum osmolality 387 mosmol/kg | 0
urea nitrogen 6.2 mmol/L | 0
creatinine 80 µmol/L | 0
glucose 35.4 mmol/L | 0
ALT 77 U/L | 0
LDH 393 U/L | 0
alkaline phosphatase 140 U/L | 0
creatine kinase 70 U/L | 0
CRP 6 mg/L | 0
HbA1c 8.7% | 0
venous blood gas pH 7.269 | 0
pCO2 7.35 kPa | 0
pO2 4.68 kPa | 0
bicarbonate 25.3 mmol/L | 0
lactate 1.3 mmol/L | 0
diagnosis of HHS | 0
intravenous volume repletion | 0
intravenous hydrocortisone | 0
potassium supplementation | 0
subcutaneous insulin boluses (total 14 IU) | 0
BGL decreased to 27.0 mmol/L | 10
serum sodium increased to 169 mmol/L | 10
polyuria persisted | 10
transferred to ICU | 10
arrival in ICU | 10
BGL 26.0 mmol/L | 10
serum sodium 165 mmol/L | 10
BGL decreased to 14.5 mmol/L | 24
hypernatraemia persisted | 24
polyuria persisted | 24
urine osmolality 773 mosmol/kg | 24
urine-specific gravity 1.011 | 24
suspected concurrent diabetes insipidus | 24
administered 2 µg IV desmopressin | 24
nasal desmopressin continued | 24
IV hydrocortisone tapered | 24
serum sodium normalized | 48
urine output decreased to 650 mL/24 h | 48
urine output 1400–1600 mL/24 h | 48
BGL returned to normal | 48
electrolytes returned to normal | 48
acid–base status returned to normal | 48
muscle weakness resolved | 48
leg pain resolved | 48
discharged from hospital | 168
recovered fully | 168