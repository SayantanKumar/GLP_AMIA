35 years old|0
male|0
obesity|0
dyslipidemia|0
T2D for 5 years| -43800
gliclazide 60 mg/day|0
linagliptin 5 mg/day|0
metformin 2 g/day|0
canagliflozin 300 mg/day|0
rosuvastatin 20 mg/day|0
Degludec insulin started| -17520
progressive increase in degludec dose up to 30 units/day|0
liraglutide 1.8 mg use| -8760
undesirable side effects from liraglutide| -8760
HbA1c 10.1% (baseline)|0
weight 98 kg (basal)|0
height 180 cm|0
BMI 30.2 kg/m2 (basal)|0
waist circumference 112 cm|0
physical examination no significant alterations|0
not studied for changes in body composition|0
never underwent any treatment for obesity|0
decision to initiate a VLCKD (PnK method)|0
all medications discontinued except rosuvastatin|0
rosuvastatin continued|0
continuous glucose monitoring system used|0
C-peptide dosage performed|0
positive microalbuminuria 89.6 mg/24 h|0
moderate hepatic steatosis diagnosed by ultrasound|0
no tool used for screening of fibrosis|0
evaluation by specialist physician|0
assessment by expert dietician|0
exercise recommendations given|0
protein preparations five times a day (step 1)|0
step 2 protein substitution|360
step 3 second serving substitution|744
supplements of vitamins and minerals provided|0
ketogenic phase active stage start|0
ketogenic phase active stage end|1440
step 4 start and end of ketosis (LCD begun)|1464
progressive incorporation of food groups|1464
maintenance diet prescribed|2160
end of PnK method|2160
weight loss of 20 kg|2160
weight normalization|2160
diabetes remission|2160
renal function unchanged|2160
hepatic function improved|2160
microalbuminuria normalization|2160
after 2 years follow-up without pathologies|17520
remission of steatosis|17520
weight 90 kg (30 days)|720
weight 82 kg (60 days)|1440
weight 78 kg (90 days)|2160
weight 79 kg (1 year)|8760
weight 80 kg (2 years)|17520
BMI 27.8 kg/m2 (30 days)|720
BMI 25.3 kg/m2 (60 days)|1440
BMI 24.1 kg/m2 (90 days)|2160
BMI 24.4 kg/m2 (1 year)|8760
BMI 24.7 kg/m2 (2 years)|17520
FG 132 mg/dL (basal)|0
FG 126 mg/dL (30 days)|720
FG 92 mg/dL (60 days)|1440
FG 77 mg/dL (90 days)|2160
FG 91 mg/dL (1 year)|8760
FG 86 mg/dL (2 years)|17520
HbA1c 8.1% (30 days)|720
HbA1c 6.8% (60 days)|1440
HbA1c 5.3% (90 days)|2160
HbA1c 5.4% (1 year)|8760
HbA1c 5.2% (2 years)|17520
uric acid 6.2 mg/dL (basal)|0
uric acid 5.4 mg/dL (30 days)|720
uric acid 4.4 mg/dL (60 days)|1440
uric acid 4.3 mg/dL (90 days)|2160
uric acid 4.4 mg/dL (1 year)|8760
uric acid 4.9 mg/dL (2 years)|17520
creatinine 0.8 g/dL (basal)|0
creatinine 0.9 g/dL (30 days)|720
creatinine 0.7 g/dL (60 days)|1440
creatinine 0.7 g/dL (90 days)|2160
creatinine 0.9 g/dL (1 year)|8760
creatinine 1.0 g/dL (2 years)|17520
AST 55 U/L (basal)|0
AST 37 U/L (30 days)|720
AST 37 U/L (60 days)|1440
AST 32 U/L (90 days)|2160
AST 27 U/L (1 year)|8760
AST 34 U/L (2 years)|17520
GGT 90 U/L (basal)|0
GGT 43 U/L (30 days)|720
GGT 45 U/L (60 days)|1440
GGT 24 U/L (90 days)|2160
GGT 19 U/L (1 year)|8760
GGT 12 U/L (2 years)|17520
TC 132 mg/dL (basal)|0
TC 145 mg/dL (30 days)|720
TC 153 mg/dL (90 days)|2160
TC 145 mg/dL (1 year)|8760
TC 142 mg/dL (2 years)|17520
TG 81 mg/dL (basal)|0
TG 114 mg/dL (30 days)|720
TG 90 mg/dL (90 days)|2160
TG 130 mg/dL (1 year)|8760
TG 80 mg/dL (2 years)|17520
HDL 43 mg/dL (basal)|0
HDL 51 mg/dL (30 days)|720
HDL 51 mg/dL (90 days)|2160
HDL 44 mg/dL (1 year)|8760
HDL 44 mg/dL (2 years)|17520
LDL 73 mg/dL (basal)|0
LDL 71 mg/dL (30 days)|720
LDL 84 mg/dL (90 days)|2160
LDL 75 mg/dL (1 year)|8760
LDL 82 mg/dL (2 years)|17520
microalbuminuria normalization to 28.0 mg/24 h (90 days)|2160
microalbuminuria 25.2 mg/24 h (1 year)|8760
microalbuminuria 22.3 mg/24 h (2 years)|17520