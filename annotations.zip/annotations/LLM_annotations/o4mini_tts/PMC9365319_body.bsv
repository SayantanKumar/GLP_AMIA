35-year-old female|0  
history of T2DM for 6 years| -52560  
liraglutide once prescribed (≤3 months)| -10920  
liraglutide stopped| -8760  
metformin 1000 mg bid (ongoing)|0  
glycated hemoglobin 8.8%|0  
hypertension|0  
dyslipidemia|0  
hyperuricemia|0  
non-alcoholic fatty liver disease|0  
insulin release test performed|0  
delayed insulin secretion|0  
pancreatic islet autoantibodies negative|0  
family history of T2DM (father)|0  
admitted to hospital for poor blood glucose and comorbidities|0  
laparoscopic sleeve gastrectomy|0  
metformin discontinued (day before surgery)| -24  
short-acting recombinant human insulin started (perioperative)|0  
short-acting recombinant human insulin discontinued (immediately after surgery)|0  
postoperative Day 1 blood glucose 13.4–16.8 mmol/L|24  
degludec insulin 20 IU qn started|24  
metformin 500 mg tid started|24  
dulaglutide 1.5 mg weekly started|24  
started sipping water|24  
started enteral nutritional suspension|24  
bloating and fullness|24  
total daily fluid intake 800–1000 mL|24  
total daily calorie intake <500 kcal|24  
abdominal CT showed no abnormal signs|24  
weight loss of 5 kg in 5 days|120  
fasting blood glucose 7–8 mmol/L|24  
postprandial blood glucose 8–12 mmol/L|24  
postoperative Day 6 fatigue|144  
sweating|144  
nausea|144  
vomiting 30 times|144  
blood gas analysis: metabolic acidosis|144  
blood glucose 16.1 mmol/L|144  
urine ketone ≥4+|144  
urine glucose ≥4+|144  
fluid resuscitation administered|144  
glucose administered|144  
insulin administered|144  
degludec insulin discontinued|144  
metformin discontinued|144  
dulaglutide discontinued|144  
crystalloid fluid + water intake >4000 mL/day|144  
recombinant human insulin infusion 0.05 U/kg/h started|144  
no infection|144  
no alcohol intake|144  
diagnosis of euglycaemic ketoacidosis (EKA)|144  
postoperative Day 8 general state improved|192  
no nausea|192  
no vomiting|192  
urine ketones negative|192  
random blood glucose <11.1 mmol/L|192  
insulin infusion discontinued|192  
fluid infusion discontinued|192  
advice to ensure adequate fluid and energy intake|192  
discharged|240  