27 years old|0  
male|0  
admitted to hospital|0  
exceedingly thirsty|-1440  
polydipsia|-1440  
polyuria|-1440  
diagnosed with schizophrenia|-52560  
risperidone therapy|-52560  
aripiprazole therapy|-52560  
ziprasidone therapy|-52560  
50 kg weight gain|-17520  
FBG 20 mmol/L|-1440  
HbA1c 12.3%|-1440  
glargine therapy|-1440  
metformin therapy|-1440  
FBG fluctuated 10–20 mmol/L|-1440  
PBG fluctuated 13–24 mmol/L|-1440  
physical examination no obvious abnormalities|0  
fundus examination no obvious abnormalities|0  
EMG no obvious abnormalities|0  
renal function no obvious abnormalities|0  
height 166 cm|0  
weight 106.3 kg|0  
BMI 38.58|0  
blood pressure 130/80 mmHg|0  
pulse rate 80 per min|0  
blood glucose 15.0 mmol/L|0  
insulin level 733.10 pmol/L|0  
total bilirubin 12.11 μmol/L|0  
albumin 45.1 g/L|0  
ALT 22 IU/L|0  
AST 27 IU/L|0  
total cholesterol 6.02 mmol/L|0  
triglyceride 1.81 mmol/L|0  
uric acid 484 μmol/L|0  
creatinine 70 μmol/L|0  
HDL 1.20 mmol/L|0  
LDL 3.48 mmol/L|0  
testosterone 14.940 nmol/L|0  
TSH 1.770 mIU/L|0  
serum potassium 4.26 mmol/L|0  
urine free cortisol 168.3 nmol/24 h|0  
fasting plasma cortisol 254 nmol/L|0  
diabetes diagnosis|0  
obesity diagnosis|0  
schizophrenia diagnosis|0  
metformin discontinued|0  
insulin pump initiated|0  
CSII 48 U/d|0  
diabetic diet pattern|0  
daily exercise recommended|0  
walk 10 min after meals|0  
add-on liraglutide 0.6 mg/d|72  
liraglutide dose increased to 1.2 mg/d|144  
insulin dose decreased to 14 U/d|144  
liraglutide dose increased to 1.8 mg/d|192  
insulin stopped|192  
FBG dropped to 4.9 mmol/L|264  
PBG dropped to 5.1 mmol/L|264  
blood glucose before bedtime dropped to 5.2 mmol/L|264  
weight 104 kg|264  
BMI 37.74|264  
blood pressure 122/78 mmHg|264  
pulse rate 78 per min|264  
triglyceride 1.7 mmol/L|264  
LDL 3.21 mmol/L|264  
discharged from hospital|264  
advised to attend psychiatric unit|264  
followed-up by telephone|17520  
blood glucose well controlled within normal range|17520  
total weight loss 8 kg|17520  
psychiatric status stable|17520  
weight 98.4 kg|17520  
BMI 35.71|17520  
blood pressure 120/80 mmHg|17520  
pulse rate 78 per min|17520  
blood glucose 5.07 mmol/L|17520  
HbA1c 6.0%|17520  
triglyceride 1.62 mmol/L|17520  
uric acid 382 μmol/L|17520  
creatinine 72 μmol/L|17520  
HDL 1.39 mmol/L|17520  
LDL 2.29 mmol/L|17520  
TSH 3.500 mIU/L|17520  
serum potassium 4.51 mmol/L|17520