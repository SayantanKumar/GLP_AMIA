65 years old | 0  
female | 0  
obesity | 0  
type 2 diabetes mellitus | 0  
hypertension | 0  
hyperlipidaemia | 0  
transient ischaemic attack | 0  
left-sided breast cancer in remission | 0  
progressively worsening fever | -168  
dry cough | -168  
exertional dyspnoea | -168  
hypoxia (oxygen saturation 87% on room air) | 0  
chest computed tomography demonstrating bilateral ground-glass opacities | 0  
nasopharyngeal swab positive for SARS-CoV-2 PCR | 0  
admission to specialized COVID-19 unit | 0  
temperature 36.1°C | 0  
blood pressure 107/62 mmHg | 0  
heart rate 83 b.p.m. | 0  
diminished breath sounds at lung bases | 0  
chest X-ray demonstrating bilateral infiltrates | 0  
remdesivir administration (enrolled in clinical trial) | 24  
ceftriaxone administration | 24  
azithromycin administration | 24  
decompensation with shock and multiorgan system failure | 168  
acute biventricular heart failure | 168  
acute respiratory distress syndrome | 168  
acute kidney injury (eGFR 26 mL/min/1.73 m2) | 168  
ischaemic hepatitis | 168  
elevated inflammatory markers (cytokine storm) | 168  
emergent rapid sequence intubation | 168  
transfer to medical intensive care unit | 168  
transthoracic echocardiography showing severe biventricular failure, LVEF 25% | 168  
norepinephrine administration | 192  
vasopressin administration | 192  
dobutamine administration | 192  
sodium bicarbonate administration | 192  
inhaled epoprostenol administration | 192  
hydrocortisone administration | 192  
tocilizumab administration 400 mg IV | 192  
propofol administration | 192  
fentanyl administration | 192  
cisatracurium administration | 192  
significant clinical improvement | 240  
repeat transthoracic echocardiography showing recovery, LVEF 64% | 240  
down-trending inflammatory markers | 240  
titration off norepinephrine | 240  
titration off vasopressin | 240  
titration off dobutamine | 240  
titration off sodium bicarbonate | 240  
cessation of neuromuscular blockade | 240  
tracheostomy | 264  
discharge from intensive care unit | 264  
discharge from hospital | 288