35 years old|0  
male|0  
obesity|0  
no medical conditions|0  
no history of surgery|0  
undergone insertion of MedSil IGB|0  
balloon filled with 600 mL normal saline|0  
balloon filled with 10 mL methylene blue|0  
left-sided varicocele|168  
varicocele never noticed before|168  
scrotal ultrasound confirmed varicocele|168  
abdominal-pelvic CT scan performed|168  
balloon compression of splenic vein|168  
splenic vein nonenhancement|168  
radiologist could not exclude thrombosis|168  
dilatation of left gonadal vein|168  
no other abdominal abnormality detected|168  
gastric balloon removed endoscopically|168  
started rivaroxaban|168  
no isolated gastric varices found|168  
significant improvement in varicocele|168  
repeat abdominal CT performed|336  
patent splenic vein with complete recanalization|336  
significant reduction in gonadal vein caliber|336  
advised to continue rivaroxaban for 3 months|336  
symptoms completely resolved|336  
referred to bariatric surgeon|336