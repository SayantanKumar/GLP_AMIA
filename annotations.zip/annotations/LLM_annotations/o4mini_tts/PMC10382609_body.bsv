quit smoking | -61320  
empagliflozin introduced | -2880  
glycosylated hemoglobin A1C 14% | -2880  
left flank pain | -48  
radiating to groin | -48  
vomiting | -48  
dizziness | -48  
lightheadedness | -48  
presentation to emergency department | 0  
60-year-old | 0  
woman | 0  
coronary artery disease | 0  
prior angioplasty | 0  
type 2 diabetes mellitus | 0  
insulin glargine 30 units twice a day | 0  
insulin lispro 30 units thrice a day | 0  
dulaglutide 1.5 mg weekly injection | 0  
empagliflozin 25 mg once daily | 0  
hypertension | 0  
losartan 50 mg daily | 0  
hypertriglyceridemia | 0  
icosapent ethyl 2 g twice a day | 0  
former smoker | 0  
strong family history of heart disease | 0  
strong family history of hypertension | 0  
strong family history of diabetes | 0  
strong family history of dyslipidemia | 0  
absence of urinary symptoms | 0  
absence of fever | 0  
body mass index 26 kg/m2 | 0  
costovertebral tenderness | 0  
tachycardia | 0  
hypotension | 0  
hypotension not responding to crystalloids | 0  
required vasopressors | 0  
lactic acidosis 8.4 mmol/L | 0  
leukocytosis 10 900 | 0  
left shift (segments 77% and bands 9%) | 0  
platelet count 76 000 | 0  
acute kidney function compromise (creatinine 3.5 mg/dL) | 0  
blood urea nitrogen 57 mg/dL | 0  
aspartate aminotransaminase 81 U/L | 0  
alanine transaminase 79 U/L | 0  
alkaline phosphatase 160 U/L | 0  
total bilirubin 1.6 mg/dL | 0  
serum glucose >500 mg/dL | 0  
urine analysis large amount of glucose | 0  
urine analysis rare bacteria | 0  
urine analysis white blood cells <1/HPC | 0  
imaging severe emphysematous pyelonephritis of left kidney | 0  
imaging left kidney 80% parenchyma involvement | 0  
imaging radiological signs of ischemic colitis | 0  
imaging presence of portal venous gas | 0  
imaging presence of air within branches of the superior mesenteric vein | 0  
cefepime treatment started | 1  
vancomycin treatment started | 1  
metronidazole treatment started | 1  
emergent nephrectomy | 2  
bowel found to be viable | 2  
postoperative management in ICU | 3  
Escherichia coli pan-susceptible isolated | 4  
antibiotics de-escalated | 5  
discharged home | 336  
cefpodoxime 200 mg twice daily started | 336  
empagliflozin discontinued | 336  
readmission to hospital | 1440  
near-syncope episode | 1440  
abdominal pain | 1440  
small bowel obstruction | 1440  
decompensated quickly | 1441  
cardiopulmonary arrest | 1441  
massive emesis | 1441  
aspiration of gastric contents | 1441  
full resuscitation | 1441  
ICU stay (second) | 1442  
anoxic brain injury | 1442  
surgery not performed | 1442  
withdrew life support | 1443  
death | 1443