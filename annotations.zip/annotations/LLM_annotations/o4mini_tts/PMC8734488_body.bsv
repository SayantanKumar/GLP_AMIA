intermittent fevers|-4320
fatigue|-4320
body aches|-4320
weight loss of 30 lbs|-4320
palpable purpuric lesions on lower extremities|-4320
type 2 diabetes mellitus|0
coronary artery disease|0
presented to the hospital|0
metoprolol|0
ranolazine|0
prasugrel|0
atorvastatin|0
alirocumab|0
insulin|0
liraglutide|0
empagliflozin|0
cyanocobalamin|0
physical examination unremarkable|0
no inflammatory arthritis|0
no muscle weakness|0
low hemoglobin of 10.1 g/dL|0
low hematocrit of 30%|0
elevated mean corpuscular volume of 108.3 fL|0
elevated erythrocyte sedimentation rate of 97 mm/h|0
elevated C-reactive protein of 6.9 mg/dL|0
white blood cell count 5,100 cells/µL|0
normal differential|0
platelet count 176,000/µL|0
negative rheumatoid factor|0
negative antinuclear antibodies|0
negative antineutrophil cytoplasmic antibodies|0
negative cryoglobulins|0
negative serum protein electrophoresis for M-protein|0
normal B12 levels|0
normal folic acid levels|0
elevated ferritin of 413 ng/mL|0
no proteinuria|0
skin biopsy of thigh lesion performed|0
nuclear dust in superficial dermis|0
scattered neutrophilic infiltration|0
fibrinoid necrosis of blood vessels|0
leukocytoclastic vasculitis|0
computed tomography of lungs performed|0
bilateral lung nodules measuring up to 9 mm|0
new lung nodules|0
resolved lung nodules|0
bone marrow aspirate performed|0
myelodysplastic syndrome with multilineage dysplasia|0
bone marrow hypercellular >95% cellularity|0
trilineage dysplasia|0
12% ring sideroblasts|0
no increase in blasts|0
cytoplasmic vacuolization in erythroid and myeloid precursors|0
hypogranular neutrophils with nuclear projections|0
normal male karyotype|0
normal FISH for multiple loci|0
negative next generation sequencing for MDS genes|0
low IPSS risk score of 0|0
no medication-induced vacuolization|0
genetic testing for UBA1 gene ordered|0
UBA1 c.121A>C (p.Met41Leu) variant identified|0
variant allele frequency 57-67%|0
no other UBA1 variants|0
VEXAS syndrome diagnosed|0
clinically stable|5760
gradual improvement in his symptoms without intervention|5760
hemoglobin stable in range of 10.0 - 11.0 g/dL|5760
no red blood cell transfusion support|5760
no other cytopenias|5760
systemic therapy for MDS not currently warranted|5760
leukocytoclastic vasculitis rash resolved|5760
rash resolved without oral medications|5760
topical steroid cream resulted in symptomatic relief|5760
continues to have fatigue|5760
fevers improved|5760
body aches improved|5760
elevated erythrocyte sedimentation rate improved to 60 mm/h|5760
elevated C-reactive protein improved to 2.4 mg/dL|5760
no lung biopsy recommended|5760