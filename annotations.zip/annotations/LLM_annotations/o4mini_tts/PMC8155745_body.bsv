poor exertional tolerance | -113880
unintentional weight gain | -61320
right thyroid lobectomy | -52560
uninodular goiter | -52560
nodule confirmed benign on postoperative histopathology | -52488
computed tomography of the abdomen ordered | -48
abdominal pain | -48
diarrhea | -48
mild hepatic steatosis | -48
26 years old | 0
female | 0
referred for evaluation | 0
persistent fatigue | 0
possible hypothyroidism | 0
denies sustained or current dietary restrictions | 0
body mass index 38 kg/m2 | 0
well healed low neck incision | 0
right thyroid lobe absent to palpation | 0
isthmus absent to palpation | 0
remainder of history and physical examination unremarkable | 0
measurement of carnitine and carnitine ester levels | 0
pattern consistent with PCD discovered | 0
genetic testing arranged | 0
total carnitine (#1) measured | 0
total carnitine (#2) measured | 0
carnitine esters measured | 0
electrocardiogram showing no conduction abnormalities | 0
echocardiogram showing anatomically normal heart with preserved ejection fraction | 0
carnitine supplementation started at 20 mg/kg/d in 4 divided doses | 24
found to have 2 SLC22A5 mutations by Sanger DNA sequencing | 48
SLC22A5 c.34G>A (p.Gly12Ser) mutation identified | 48
SLC22A5 c.41G>A (p.Trp14Ter) mutation identified | 48
carnitine dose adjusted to 50 mg/kg/d | 48
significant improvement in sense of well-being | 72
significant improvement in exertional tolerance | 72
saw a dietitian | 2880
began regular aerobic exercise program | 2880
started treatment with Saxenda (liraglutide) | 2880
achieved intentional 15 pound weight loss | 2880