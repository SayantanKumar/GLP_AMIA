27 years old|0  
female|0  
class III obesity (mass index, 40.0 kg/m2)|0  
presented to the hospital|0  
severe fatigue|0  
generalized muscle weakness|0  
multiple falls|0  
decreased oral intake|0  
proximal greater than distal weakness of bilateral upper and lower extremities|0  
neck weakness|0  
trace to absent lower extremity reflexes|0  
pulmonary embolism|0  
severe ketoacidosis|0  
venous pH 7.00|0  
beta hydroxybutyrate 5.67 nmol/L|0  
rhabdomyolysis with CK 4656 units/L|0  
lactate peaking at 6.0 mmol/L|0  
admission to the intensive care unit|1  
sodium bicarbonate infusion|1  
normal saline infusion|1  
thiamine infusion|1  
dextrose infusion|1  
heparin infusion|1  
venous pH normalized to 7.45|24  
CK improved to 245 units/L|24  
lactate improved to 3.6 mmol/L|24  
started carnitine supplementation|24  
started riboflavin supplementation|24  
started cyanocobalamin supplementation|24  
started coenzyme Q10 supplementation|24  
continued objective proximal greater than distal weakness|24  
genetic testing result heterozygous frameshift mutation c.51dup;p.(A18Cfs∗5) in ETFDH|48  
diagnosis of multiple acyl-coenzyme A dehydrogenase deficiency|48  
discharged to inpatient rehabilitation|72  
maintained on carnitine supplementation|72  
maintained on riboflavin supplementation|72  
maintained on cyanocobalamin supplementation|72  
maintained on coenzyme Q10 supplementation|72  
maintained on thiamine supplementation|72  
high carbohydrate low-fat diet prescribed|72  
discharged home to continue treatment|168  
intermittent nausea requiring ondansetron|336  
neuropathic pain requiring pregabalin|336  
improved strength and energy|336  
CK normalized to 36 units/L|504  
additional whole genome trio sequencing normal|504  
karyotype and microarray carrier of balanced translocation 46,XX,t(5;19)(p10;q10)|504  
repeat plasma acylcarnitine profile relative shift towards short- and medium-chain species|504  
repeat urine organic acid analysis normal|504  
weight gain of nearly 30 lbs (13.61 kg)|2880  
started metformin|2880  
started liraglutide|2880  
TSH 21.58 μIU/mL|2880  
levothyroxine increased to 100 mcg daily|2880  
continues to feel well with improved strength and energy|8760  
presented to neurology clinic| -3600  
fatigue| -3600  
proximal muscle weakness primarily affecting her lower extremities| -3600  
elevated thyroid stimulating hormone 5.45 μIU/mL| -3600  
elevated thyroid peroxidase antibodies| -3600  
elevated CK 588.0 units/L| -3600  
started Levothyroxine 25 mcg daily| -3600  
TSH still high at 4.17 μIU/mL| -3600  
normal myositis antibody testing| -3000  
normal necrotizing myopathy testing| -3000  
normal myasthenia gravis antibody testing| -3000  
normal panel-based genetic testing for muscular dystrophies| -3000  
electromyography inflammatory genetic or metabolic myopathy| -3000  
vastus lateralis biopsy vacuolated muscle fibers with lipid droplets| -3000  
plasma acylcarnitine profile elevated small medium and long chain species| -3000  
urine organic acid analysis elevated orotic acid and 2-hydroxy glutaric acid| -3000  
genetic testing ordered| -3000  
started low carbohydrate calorie restricted diet| -7920  
developed severe vomiting after a week on diet| -7752  
discontinued low carbohydrate calorie restricted diet after a month| -7200  
lost 20 lbs (9.07 kg)| -7200