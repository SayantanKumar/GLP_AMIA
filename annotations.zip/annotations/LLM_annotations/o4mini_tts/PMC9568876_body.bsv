48 years old|0  
postmenopausal female|0  
admitted to medical ICU|0  
lateral neck pain| -240  
no fever|0  
no throat pain|0  
no trauma|0  
diabetes mellitus|0  
skipped oral hypoglycemic medication| -96  
hypothyroidism|0  
hypertension|0  
works at a private firm|0  
three children|0  
social alcohol use|0  
thyroxine 87.5 microgram daily|0  
liraglutide 5 mg daily|0  
repaglinide 1 mg thrice daily|0  
aspirin 75 mg daily|0  
atorvastatin 10 mg daily|0  
normal body mass index|0  
conscious|0  
calm|0  
cooperative|0  
well-oriented to time, place, and person|0  
vitals stable|0  
general examination non-revealing|0  
left lateral neck ill-defined area 3x2 cm|0  
tenderness|0  
local rise in temperature|0  
crepitations felt|0  
distal neurovascular status intact|0  
draining lymph nodes palpable|0  
increased leukocyte count 30330|0  
neutrophilia 87% neutrophils|0  
hemoglobin level 12.5 g/dl|0  
platelet count 166000/ml|0  
random blood sugar 502 mg/dl|0  
serum urea 63|0  
serum creatinine 3.5|0  
normal serum sodium|0  
normal serum potassium|0  
urine sugar +++|0  
urine protein +|0  
urine acetone positive|0  
serum protein 6.4 g/dl|0  
serum albumin 3.3 g/dl|0  
arterial pH 7.067|0  
arterial pCO2 8.7|0  
arterial pO2 77%|0  
serum bicarbonate 12.6|0  
diagnosis diabetic ketoacidosis|0  
diagnosis neck abscess|0  
insulin therapy started|0  
intravenous fluids started|0  
piperacillin started|0  
tazobactam started|0  
ultrasonography neck performed|2  
neck mass 3x6 cm|2  
posterior acoustic shadow|2  
mass separate from parotid and submandibular glands|2  
neck exploration|24  
debridement|24  
general anesthesia|24  
daily neck dressing|24  
wound swab culture pseudomonas aeruginosa|48  
amikacin sensitivity|48  
ciprofloxacin sensitivity|48  
intravenous ciprofloxacin 200 mg twice daily started|48  
intravenous amikacin 500 mg thrice daily started|48  
histopathology reveal necrotizing fasciitis|72  
good signs of recovery|168  
tolerated oral feeding|168  
normal hematological parameters|168  
normal renal function|168  
blood sugar 166 mg/dl|168  
good wound healing|168  
prescribed anti-hyperglycemic medications|168  
advised regular dressing|168  
advised blood sugar monitoring|168  
discharged home|168  
follow-up visits doing well|336