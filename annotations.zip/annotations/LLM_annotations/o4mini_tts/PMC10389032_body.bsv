58-year-old female patient|0  
referred to hospital|0  
diabetes since 2009| -96360  
treated with semaglutide 0.25 mg sc|0  
onset of P-DPN| -26280  
tingling|0  
numbness|0  
burning pain|0  
hypoesthesia|0  
allodynia|0  
severe sharp pain|0  
NRS of 9|0  
DN4 of 7|0  
no motor deficits|0  
no abnormal deep tendon reflexes|0  
no dysvitaminosis|0  
no autoimmune disorders|0  
no rheumatological disorders|0  
specific blood tests performed|0  
failed conservative therapeutic options|0  
failed first-line medications|0  
failed second-line medications|0  
elected for SCS implantation technique|0  
dorso-lumbar MRI performed|0  
MRI normal|0  
lower-limb somatosensory evoked potentials performed|0  
somatosensory evoked potentials normal|0  
EMG performed|0  
no signs of radiculopathy|0  
ENG performed|0  
reduction of SN sensory conduction velocity|0  
normal ENG amplitude|0  
HRUS of peripheral nerves performed|0  
CSA measurement of C7|0  
CSA measurement of C6|0  
CSA measurement of ulnar nerve at forearm|0  
CSA measurement of median nerve at forearm|0  
CSA measurement of superficial radial nerve at forearm|0  
CSA measurement of external popliteal nerve (left)|0  
CSA measurement of external popliteal nerve (right)|0  
CSA measurement of posterior tibial nerve|0  
CSA measurement of sural nerve|0  
NRS assessment performed|0  
SF36 assessment performed|0  
BPI assessment performed|0  
PIS assessment performed|0  
written informed consent obtained|0  
SCS lead implantation performed|0  
lead introduction into posterior epidural space|0  
lead positioned at T9|0  
paresthesia coverage >80% achieved|0  
FAST stimulation parameters set|0  
lead anchored to thoracolumbar fascia|0  
lead tunneled and connected to implantable pulse generator|0  
discharged|48  
NRS of 1 at discharge|48  
no complications|48  
immediate postoperative pain relief|0  
1-month follow-up|720  
NRS decreased|720  
BPI improvement|720  
PIS decreased|720  
DN4 decreased|720  
antalgic pharmacological therapy discontinued|720  
SF36 improvement|720  
PCS increased|720  
MCS increased|720  
HRUS CSA reduction detected|720  
CSA reduction of external popliteal nerve|720  
CSA reduction of posterior tibial nerve|720  
CSA reduction of sural nerve|720  
ENG performed at 1-month follow-up|720  
increased sural nerve SCV left|720  
increased sural nerve SCV right|720  
2-month follow-up|1440  
HRUS CSA reduction detected|1440  
CSA reduction of external popliteal nerve|1440  
CSA reduction of posterior tibial nerve|1440  
CSA reduction of sural nerve|1440  
3-month follow-up|2160  
pain relief stable|2160  
no changes in questionnaire scores|2160  
no changes in CSA measurements|2160  
no changes in stimulation settings|2160