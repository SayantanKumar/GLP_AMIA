admission | 0  
reduction in serum glucose levels below 70 mg/dL | 0  
clinical signs manifest when plasma glucose falls below 55 mg/dL | 0  
presentation with adrenergic symptoms | 0  
hunger | 0  
sweating | 0  
nausea | 0  
anxiety | 0  
tremor | 0  
palpitations | 0  
tachycardia | 0  
presentation with neuroglycopenic symptoms | 0  
confusion | 0  
dizziness | 0  
lethargy | 0  
seizures | 0  
coma | 0  
presence of hypoglycemia-related symptoms (Whipple’s triad) | 0  
plasma glucose <55 mg/dL (Whipple’s triad) | 0  
alleviation of symptoms following correction of hypoglycemia (Whipple’s triad) | 0  
factitious hypoglycemia from insulin misuse | 0  
factitious hypoglycemia from sulfonylurea misuse | 0  
insulinoma | 0  
non‐insulinoma pancreatogenous hypoglycemia syndrome (NIPHS) | 0  
post‐bariatric surgery hypoglycemia | 0  
sepsis as a cause of hypoglycemia | 0  
hepatic failure as a cause of hypoglycemia | 0  
cortisol deficiency–related hypoglycemia | 0  
growth hormone deficiency–related hypoglycemia | 0  
alcohol‐induced hypoglycemia | 0  
paraneoplastic hypoglycemia (NICTH) | 0  
hepatocellular carcinoma–associated NICTH (first described by Nadler et al.) | 0  
solitary fibrous tumor–associated hypoglycemia (Doege‐Potter syndrome) | 0  
tumor production of IGF-2 | 0  
tumor production of “big” IGF-2 | 0  
surgical resection of underlying tumor | 0  
external radiotherapy for tumor control | 0  
transcatheter arterial embolization (TACE) | 0  
conventional TACE with intratumoral lactic acidosis modulation (TILA-TACE) | 0  
systemic chemotherapy (FOLFOX regimen) | 0  
imatinib therapy for recurrent SFT | 0  
alpelisib therapy for recurrent lung SFT | 0  
dacarbazine + bevacizumab therapy | 0  
glucocorticoid therapy | 0  
recombinant growth hormone therapy | 0  
pasireotide therapy | 0  
diazoxide therapy | 0  
glucagon infusion | 0  
oral glucose administration | 0  
uncooked cornstarch at bedtime | 0