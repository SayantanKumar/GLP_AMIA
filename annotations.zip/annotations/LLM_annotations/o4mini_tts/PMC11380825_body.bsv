presented to an emergency department to an outside hospital with headache | -48  
decreased appetite | -48  
non-contrasted computed tomography of the head negative for an acute process | -48  
serologic workup negative for acute infection | -48  
serologic workup negative for toxic derangements | -48  
serologic workup negative for metabolic derangements | -48  
analgesics given for headache | -48  
discharged in stable condition | -47  
presented again to the same emergency department | 0  
83-year-old male | 0  
anxiety | 0  
hyperlipidemia | 0  
type 2 diabetes mellitus | 0  
hypertension | 0  
glaucoma | 0  
semaglutide (home medication) | 0  
empagliflozin (home medication) | 0  
brimonidine (home medication) | 0  
latanoprost (home medication) | 0  
atorvastatin (home medication) | 0  
worsened mental status | 0  
worsening headache | 0  
nausea | 0  
worsening appetite | 0  
afebrile | 0  
blood pressure 131/99 mmHg | 0  
heart rate 81 beats/min | 0  
respiratory rate 18 breaths/min | 0  
fingerstick glucose 260 mg/dL | 0  
two units of insulin aspart given | 0  
fentanyl administration | 0  
ondansetron administration | 0  
CT abdomen and pelvis negative for an acute process | 0  
repeat non-contrast CT head obtained | 1  
new acute left occipital intraparenchymal hemorrhage without mass effect or interventricular extension | 1  
loaded with 2 g levetiracetam for seizure prophylaxis | 1  
transferred to neurocritical care unit at our facility | 2  
encephalopathic appearance on arrival | 2  
not oriented to date or place | 2  
right homonymous hemianopsia | 2  
trouble completing complex commands | 2  
intact strength | 2  
intact sensation | 2  
National Institutes of Health Stroke Scale score of 5 | 2  
no increased skin turgor | 2  
no dry skin | 2  
no dry mucosal membranes | 2  
no polydipsia | 2  
no decreased urine output | 2  
electrocardiogram normal sinus rhythm | 2  
hemoglobin A1c 10.2% | 2  
blood urea nitrogen 23 mg/dL | 2  
anion gap 17 mmol/L | 2  
bicarbonate 20 mmol/L | 2  
β-hydroxybutyrate 3.65 mmol/L | 3  
glucose 120 mg/dL at β-hydroxybutyrate draw | 3  
urine glucose >1000 mg/dL | 3  
urine ketones >80 mg/dL | 3  
urinalysis negative for infection | 3  
urinalysis did not reflex on culture | 3  
urine toxicology screen negative | 3  
diagnosis of euglycemic diabetic ketoacidosis | 3  
dextrose 10% + potassium chloride infusion 250 cc/h initiated | 3  
insulin drip 1 U/h initiated without bolus | 3  
diet given and allowed to eat | 3  
electrolyte and β-hydroxybutyrate monitoring every 4 h | 3  
potassium corrected as needed | 3  
repeat CT head at 6 h stable | 8  
CT angiogram of head and neck obtained | 8  
CT angiogram showed prominent arterial branches concerning for vascular lesion | 8  
magnetic resonance imaging of the brain with and without contrast obtained | 12  
MRI showed curvilinear enhancement with saccular focus suggesting arteriovenous malformation | 12  
digital subtraction angiography performed | 12  
digital subtraction angiography negative for arteriovenous malformation | 13  
intracerebral hemorrhage attributed to uncontrolled hypertension | 13  
lisinopril started for long-term blood pressure control | 13  
anion gap closed to 10 mmol/L | 16  
β-hydroxybutyrate decreased to 0.93 mmol/L | 16  
transitioned to insulin sliding scale | 16  
encephalopathy and nausea resolved | 16  
visual field cut remained | 16  
discharged home with home health on hospital day 9 | 216  
semaglutide discontinued | 216  
empagliflozin discontinued | 216  
glargine started | 216  
lispro started | 216  
outpatient endocrinology follow-up arranged | 216  
outpatient vascular neurology follow-up arranged | 216  
lost to follow-up | 217