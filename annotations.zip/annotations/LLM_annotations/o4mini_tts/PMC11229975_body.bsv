diabetes mellitus|0  
elevated blood glucose levels|0  
destruction of β cells|0  
malfunction of β cells|0  
insulin resistance in peripheral tissues|0  
insufficient production of insulin|0  
prolonged hyperglycemia|0  
serious complications (microvascular, macrovascular)|0  
impairment of growth|0  
susceptibility to infections|0  
classification of diabetes as type 1 (T1D)|0  
classification of diabetes as type 2 (T2D)|0  
autoimmune destruction of β cells (T1D)|0  
insufficient insulin production (T1D)|0  
non-response of peripheral tissue to insulin (T2D)|0  
inflammation in T1D|0  
inflammation in T2D|0  
gestational diabetes|0  
increase in β cell number during pregnancy|0  
expected 693 million DM patients by 2045|0  
T2D represents >85% of diabetes prevalence|0  
obesity and sedentary lifestyle influence T2D|0  
improved survival of diabetes patients|0  
bone disease in diabetes|0  
retinopathy|0  
nephropathy|0  
neuropathy|0  
ischemic heart disease|0  
stroke|0  
peripheral vascular disease|0  
impaired wound healing|0  
exogenous insulin administration|0  
multiple daily insulin injections|0  
continuous subcutaneous insulin infusion|0  
Diabetes Control and Complications Trial intensive therapy|0  
continuous glucose monitor integration|0  
automatic suspension of insulin delivery|0  
FDA approval of hybrid closed-loop pump systems|0  
3-month hybrid closed-loop vs sensor-augmented pump trial|0  
6-month International Diabetes Closed Loop trial|0  
pramlintide approval for T1D adults|0  
liraglutide clinical trials|0  
SGLT2 inhibitor clinical trials|0  
insulin initiation for glucose ≥300 mg/dL or HbA1c >10%|0  
medical nutrition therapy (MNT)|0  
MNT for 3–6 months|0  
personalized macronutrient distribution|0  
Mediterranean, vegetarian, low-carbohydrate, plant-based diets|0  
weight management program (7–10% weight loss)|0  
behavioral interventions in prediabetes|0  
5% weight loss target in T2D overweight/obese|0  
up to 15% sustained weight loss|0  
aerobic and resistance exercise combined training trial|0  
150 min/week moderate-to-vigorous aerobic activity recommendation|0  
2–3 days/week resistance exercise recommendation|0  
interrupt sitting every 30 min recommendation|0  
flexibility and balance training 2–3 times/week|0  
risk of hypoglycemia with physical activity|0  
monitor blood glucose before/after exercise|0  
ESC and iPSC differentiation into β cells preclinical work|0  
TMEM219 blockade preclinical β cell expansion|0  
rapamycin preclinical and phase II trial findings|0  
pancreas transplantation indications|0  
islet transplantation protocol optimization|0  
Edmonton protocol for islet transplantation|0  
CIT-07 phase 3 islet transplantation trial|0  
omentum islet transplantation clinical trial (NCT02213003)|0  
laparoscopic omental islet transplant case report|0  
Eurotransplant donor statistics 2020|0  
MSC and islet cotransplantation pilot study|0  
MSC immunomodulatory properties|0  
exosomes from MSCs in diabetic wound healing|0  
ATV‐pretreated MSC-exosome angiogenesis study|0  
circ-Snhg11 MSC-exosome wound healing study|0  
MSC-exosome therapy in diabetic peripheral neuropathy|0  
engineered miR-146a MSC-exosomes in DPN|0  
MSC-exosome therapy in erectile dysfunction|0  
repeat intracavernous MSC-exosome injection erectile function study|0  
MSC implantation for diabetic wound healing|0  
hydrogel scaffold MSC delivery|0  
sponge scaffold MSC delivery|0  
nanofibrous scaffold MSC delivery|0  
spray/decellularized MSC delivery|0  