60 years old|0  
male|0  
long-standing T2DM|0  
stable glycemic control|0  
chylomicronemia|0  
hypertriglyceridemia|0  
triglyceride levels between 1100 and 4000 mg/dL|0  
adherent to lipid-lowering therapy|0  
alcohol consumption <1 drink/week|0  
consistent 20% low fat diet|0  
exercise with 30 minutes of daily walking|0  
no history of pancreatitis|0  
moderate hepatomegaly|0  
no eruptive xanthomata|0  
A1C level consistently between 6.0% and 7.0%| -17520  
stable glycemic control for at least 2 years| -17520  
diagnosed with HeLPL|0  
fenofibrate 145 mg daily|0  
icosapent ethyl 2 g twice daily|0  
ezetimibe 10 mg daily|0  
atorvastatin 40 mg daily|0  
semaglutide 1.0 mg subcutaneously weekly|0  
empagliflozin 10 mg/day|0  
metformin 1000 mg twice daily|0  
stable for several months on both lipid and diabetes therapies| -2160  
semaglutide discontinued|0  
switched to tirzepatide|0  
tirzepatide titrated up to 15 mg subcutaneously weekly|0  
no major side effects|0  
lipid-lowering therapy remained consistent and adherent|0  
no other changes in clinical care, medications, exercise, or diet|0  
TG level decreased approximately 58% from 1404 to 583 mg/dL|1440  
resolution of CM|1440  
TG level <880 mg/dL|1440  
A1C level decreased from 6.9% to 6.3%|1440  
body weight decreased by 12 lbs|1440  
TG level decreased to 202 mg/dL|4320  
lowest TG level ever reported|4320