36 years old|0
female|0
Filipino|0
admitted to the hospital|0
abdominal pain|-1440
abdominal swelling|-1440
fevers|-1440
weight loss of 10 kg|-1440
lived in Ireland|-140160
moved to Ireland|-140160
last visited the Philippines|-8760
severe psoriasis|-65700
psoriatic arthritis|-65700
tuberculin purified protein derivative skin test result of greater than 5 mm (positive)|-65700
chest radiograph normal|-65700
isoniazid 300 mg daily (latent TB treatment) started|-65700
pyridoxine 20 mg daily (latent TB treatment) started|-65700
narrow-band ultraviolet B phototherapy|-40050
cyclosporine treatment|-40050
methotrexate treatment|-40050
etanercept treatment|-40050
adalimumab treatment|-40050
ulcerated hyperkeratotic plaque developed on abdomen|-17520
multiple biopsies taken from abdominal plaque|-17520
histopathologic examination found noncaseating granulomas|-17520
skin biopsy for mycobacterium and atypical mycobacterium culture normal|-17520
PCR negative for Mycobacterium tuberculosis complex|-17520
deterioration in renal function|-17520
renal biopsy found interstitial nephritis with prominent eosinophilia|-17520
oral corticosteroids treatment started|-17520
adalimumab discontinued|-17520
plaque resolved off adalimumab treatment|-13140
psoriasis flared|-14400
QuantiFERON-TB Gold test result normal (negative)|-14400
chest radiograph normal|-14400
ustekinumab treatment initiated|-14400
initial urine β human chorionic gonadotrophin test positive|0
ultrasound scan of the abdomen showed fluid|0
ectopic pregnancy considered|0
laparotomy found chronic inflammatory bowel deposits|0
omental caking|0
abdominal and pelvic adhesions typical of peritoneal tuberculosis|0
serum β human chorionic gonadotrophin test negative subsequently|0
acid-fast bacilli present on ascitic fluid aspirate|0
acid-fast bacilli present on omental biopsy|0
chest radiograph showed no evidence of TB|0
HIV test negative|0
ustekinumab discontinued|0
empiric treatment for Mycobacterium tuberculosis started|0
rifampacin 720 mg daily started|0
isoniazid 300 mg daily (TB treatment) started|0
pyrazinamide 1800 mg daily started|0
ethambutol 1600 mg daily started|0
pyridoxine 20 mg daily (TB treatment) started|0
PCR found Mycobacterium tuberculosis complex rifampacin sensitive|0
ethambutol discontinued|0
mycobacterial culture confirmed Mycobacterium tuberculosis|0
peritoneal TB treatment for 12 months started|0
abdominal pain settled|168
psoriasis flare|4320
narrow-band ultraviolet B phototherapy failed to control psoriasis|4320
flare of psoriatic arthritis on right ankle|4320
intralesional corticosteroid injection|4320
prednisolone 15 mg daily started|4320
psoriasis unstable|4656
admitted to the hospital|4656
liraglutide treatment started|4656
intensive topical therapy started|4656
erythrodermic|4660
hypotensive|4660
admission to high-dependency unit|4660
cyclosporine treatment initiated|4670
psoriasis remained extensive|4670
secukinumab treatment commenced|4670
cyclosporine discontinued|4680
psoriasis cleared|5000
joint pain settled|5000
discharged home|5664
psoriasis remained under control on secukinumab for 9 months|12144
psoriatic arthritis remained under control on secukinumab for 9 months|12144