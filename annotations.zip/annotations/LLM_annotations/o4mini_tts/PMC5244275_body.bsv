59 years old|0  
male|0  
African American man|0  
presented to the emergency department|0  
rapidly evaluated|0  
IV access obtained|0  
unilateral left-sided tongue swelling|0  
tongue had significantly swollen over the course of an hour|-1  
difficulty swallowing|0  
throat tightness|0  
no dyspnea|0  
no abdominal pain|0  
no nausea|0  
no vomiting|0  
no syncope|0  
no cutaneous symptoms|0  
no rash|0  
no hives|0  
no history of angioedema|0  
no food allergies|0  
no latex allergies|0  
no recent insect stings|0  
no family history of angioedema|0  
hydrocodone for rheumatoid arthritis pain|0  
metformin|0  
exenatide|0  
insulin glargine|0  
aspirin|0  
Lotrel (amlodipine besylate and benazepril) for hypertension|0  
Lotrel (amlodipine besylate and benazepril) started for hypertension|-43800  
management for histamine-mediated angioedema|0  
methylprednisolone 125 mg IV|0  
diphenhydramine 25 mg IV|0  
epinephrine 1 µg IV|0  
no improvement in symptoms|0  
epinephrine 9 µg IV|0.25  
no response|0.25  
condition continued to decline|0.583  
airway collapse was imminent|0.583  
ranitidine 150 mg IV|0.583  
C1-INH (Berinert, 3000 U) IV|0.583  
reduction of swelling|0.833  
resolution of dysphagia|0.833  
admitted to the medical intensive care unit|1  
evaluation by an otolaryngology specialist|1  
complement levels drawn|1  
normal C4 level (35 mg/dL)|1  
normal C1-INH functionality (105% mean normal)|1  
diagnosis of ACEI-AAE|1  
instructed to discontinue and avoid future use of all ACEIs|1  
discharged|24  
scheduled follow-up with the allergy department|24  
transitioned to valsartan/hydrochlorothiazide (160 mg/25 mg)|24  
1-year follow-up|8760  
no recurrence of angioedema|8760  
blood pressure remained well controlled|8760