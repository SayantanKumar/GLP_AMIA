35-year-old woman|0  
female|0  
diagnosed with diabetes at 17 years of age| -157680  
started oral hypoglycemic agents| -157680  
SPIDDM proven at 25 years of age| -87600  
insulin treatment introduced| -87600  
had been obese from childhood| -219000  
height 152 cm at 20 years of age| -131400  
weight 90 kg at 20 years of age| -131400  
BMI 39.0 kg/m2 at 20 years of age| -131400  
weight reached 120.8 kg with BMI 52.3 at 35 years of age|0  
introduced to Department of Bariatric Surgery|0  
metformin 2,250 mg daily|0  
pioglitazone 15 mg daily|0  
miglitol 150 mg daily|0  
dulaglutide 0.75 mg weekly|0  
insulin 62 units daily| -24  
HbA1c 6.8%| -24  
strict lifestyle modifications|0  
insulin dose decreased to 35 units daily|0  
HbA1c 5.7%|0  
anti-GAD antibody titer 623 U/mL|0  
plasma CPR response to glucagon 1.21 ng/mL|0  
decision to perform bariatric/metabolic surgery|0  
laparoscopic sleeve gastrectomy with duodenojejunal bypass|0  
blood glucose level stabilized|48  
cessation of metformin|48  
cessation of pioglitazone|48  
cessation of miglitol|48  
cessation of dulaglutide|48  
insulin glargine 5 units daily|48  
insulin glargine discontinued|1440  
HbA1c 5.8% at 6 months after surgery|4320  
body weight decreased to 76.1 kg at 6 months after surgery|4320  
%EWL 66.6% at 6 months after surgery|4320  
abdominal fat area decreased to 233 cm2 at 6 months after surgery|4320  
subcutaneous fat area decreased to 162 cm2 at 6 months after surgery|4320  
visceral fat area decreased to 71 cm2 at 6 months after surgery|4320  
fat mass decreased to 24.9 kg at 6 months after surgery|4320  
muscle mass decreased to 48.1 kg at 6 months after surgery|4320  
protein mass decreased to 9.9 kg at 6 months after surgery|4320  
body fat percentage 32.7% at 6 months after surgery|4320  
plasma CPR response to glucagon increased to 2.34 ng/mL at 6 months after surgery|4320  
FBG 85 mg/dL at 6 months after surgery|4320  
F-CPR 0.89 ng/mL at 6 months after surgery|4320  
CPI 1.05 at 6 months after surgery|4320  
no severe adverse events observed|4320  
AST 15 IU/L|0  
ALT 14 IU/L|0  
γGTP 10 IU/L|0  
T-BIL 0.6 mg/dL|0  
ALP 132 IU/L|0  
LDH 208 IU/L|0  
CPK 71 IU/L|0  
UN 8.2 mg/dL|0  
UA 4.3 mg/dL|0  
Cr 0.44 mg/dL|0  
TP 7 g/dL|0  
Alb 4.2 g/dL|0  
AMY 49 IU/L|0  
Na 140 mEq/L|0  
K 4 mEq/L|0  
Cl 102 mEq/L|0  
Ca 9.1 mEq/L|0  
CRP 0.75 mg/dL|0  
TG 65 mg/dL|0  
HDL-Cho 47 mg/dL|0  
LDL-Cho 96 mg/dL|0  
TSH 2.63 µIU/mL|0  
FT4 1.3 ng/dL|0  
ACTH 10.1 pg/mL|0  
COR 7.89 µg/dL|0  
LH 2.68 mIU/mL|0  
FSH 5.60 mIU/mL|0  
PRL 10.9 ng/mL|0  
E2 34 pg/mL|0  
WBC 6,100/µL|0  
RBC 4.75×10^6/µL|0  
Hb 12.4 g/dL|0  
Ht 39.4%|0  
MCV 82.9 fL|0  
MCH 26.1 pg|0  
MCHC 31.5%|0  
Plt 3.49×10^5/µL|0  
urine pH 7.5|0  
urine specific gravity 1.013|0  
urine protein ±|0  
urine occult blood −|0  
urine urobilinogen −|0  
height 151.3 cm (preoperative)|0  
body weight 111.4 kg (preoperative)|0  
BMI 49.8 kg/m2 (preoperative)|0  
%EWL − (preoperative)|0  
abdominal fat area 968 cm2 (preoperative)|0  
subcutaneous fat area 609 cm2 (preoperative)|0  
visceral fat area 359 cm2 (preoperative)|0  
fat mass 59.0 kg (preoperative)|0  
muscle mass 49.8 kg (preoperative)|0  
protein mass 10.4 kg (preoperative)|0  
body fat percentage 53.0% (preoperative)|0  
FBG 86 mg/dL (preoperative)|0  
HbA1c 5.7% (preoperative)|0  
F-CPR 1.1 ng/mL (preoperative)|0  
CPI 1.28 (preoperative)|0  
CPR response to glucagon 1.21 ng/mL (preoperative)|0