49-year-old | 0  
female | 0  
no pertinent past medical history | 0  
pelvic pain | 0  
abnormal uterine bleeding | 0  
pelvic ultrasound | 0  
6.5 cm complex left adnexal mass | 0  
features consistent with a dermoid cyst | 0  
endometrial biopsy | 0  
normal proliferative endometrium | 0  
TSH normal | 0  
Free T4 normal | 0  
CA-125 normal | 0  
CEA normal | 0  
CA 19-9 normal | 0  
bHCG normal | 0  
inhibin A normal | 0  
inhibin B normal | 0  
pelvic MRI | 0  
concern for malignancy | 0  
robotic bilateral salpingectomy | 24  
left oophorectomy | 24  
mass removed through midline port site in a bag with contained rupture | 24  
intra-operative frozen section | 24  
struma ovarii (frozen section) | 24  
no contralateral oophorectomy | 24  
no hysterectomy | 24  
no residual struma ovarii at primary surgery | 24  
final surgical pathology | 72  
struma ovarii predominantly composed of mature thyroid tissue | 72  
three microscopic foci of papillary thyroid carcinoma | 72  
largest foci measuring 1.6 mm | 72  
papillary architecture with classic nuclear features | 72  
no lymphovascular space invasion | 72  
no ovarian capsule involvement | 72  
pelvic washings no malignant cells | 72  
referred to endocrinology | 96  
thyroid ultrasound | 96  
neck ultrasound | 96  
thyroglobulin level normal | 96  
thyroid function tests normal | 96  
elected monitoring | 96  
thyroglobulin monitoring initiated | 100  
abdominal imaging initiated | 100  
thyroglobulin levels normal | 100  
GLP-1 agonist started | 16848  
thyroglobulin increase | 17520  
normal thyroid function tests | 17520  
thyroglobulin remained elevated off GLP-1 agonist | 17520  
CT chest/abdomen/pelvis | 17524  
no evidence of disease on CT | 17524  
neck ultrasound (follow-up) | 17524  
reassuring without evidence of disease on ultrasound | 17524  
pelvic ultrasound (follow-up) | 17524  
small hyperechoic right ovarian lesion measuring 6.4x9x7.5 mm | 17524  
increased vascularity | 17524  
re-evaluated by gynecologic oncology | 17524  
decision to proceed with removal of remaining ovary and possible hysterectomy | 17524  
diagnostic laparoscopy | 18000  
peritoneal carcinomatosis | 18000  
diffuse red cystic nodular lesions on omentum, peritoneal surfaces, sigmoid mesentery, and uterine serosa | 18000  
right ovary enlarged with a complex cystic appearance | 18000  
intraoperative frozen section of omentum consistent with thyroid neoplasm | 18000  
robotic-assisted total laparoscopic hysterectomy | 18000  
right salpingo-oophorectomy | 18000  
extensive peritoneal resection | 18000  
omentectomy | 18000  
no gross residual disease | 18000  
pathology of resected specimen | 18072  
foci consistent with strumosis | 18072  
metastatic lesions with cytologic features of papillary thyroid carcinoma | 18072  
PD-L1 testing positive (CPS score 4) | 18072  
NRAS Q61R mutation detected | 18072  
tumor mutational burden moderate at 4.2 m/MB | 18072  
microsatellite stability | 18072  
interdisciplinary discussion | 18100  
thyroglobulin 127 ng/ml | 19008  
TSH 1.97 | 19008  
plan total thyroidectomy and radioactive iodine therapy | 19008  
total thyroidectomy | 19032  
final pathology benign | 19032  
planned start I-131 therapy | 19032  
plan post-treatment whole body I-131 scan | 19032  
plan follow up in 3-4 months | 19032