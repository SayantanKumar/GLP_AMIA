50-year-old female|0  
moved to the United States| -175200  
establishing care with a new primary care provider|0  
inability to lose weight|0  
strict lifestyle interventions|0  
initial work up revealed hypothyroidism|0  
levothyroxine|0  
vegetarian|0  
eating predominantly at home|0  
healthy meals|0  
small portion size|0  
doing regular household chores|0  
keeping herself active|0  
frustrated with inability to lose weight|0  
interested in pharmacotherapy|0  
normal vital signs|0  
normal systemic exam|0  
abdominal visceral obesity|0  
total cholesterol 219 mg/dl|0  
triglycerides 93 mg/dl|0  
HDL-C 46 mg/dl|0  
LDL-C 154 mg/dl|0  
Hemoglobin A1c 5.3%|0  
TSH 1.25 mIU/ml|0  
free T4 0.93 ng/dl|0  
fasting glucose 101 mg/dl|0  
ANA 1:80|0  
thyroid ultrasound showed mildly enlarged gland|0  
two small nodules on thyroid ultrasound|0  
PCP prescribed Bupropion|0  
referred to an obesity specialist|0  
BMI 32.61 kg/m2|0  
no weight loss with Bupropion|2160  
stopped Bupropion|2160  
started Topiramate|2160  
decreased appetite with Topiramate|2160  
no weight loss with Topiramate|2160  
added phentermine|2880  
lost 10 pounds with Topiramate and phentermine|5760  
weight loss plateau|5760  
seen by obesity specialist|5760  
custom-tailored Indian Vegetarian meal plan for 1200 calories|5760  
SMART goal patient instructions|5760  
two visits with obesity specialist|6480  
followed up regularly with PCP|6480  
regained weight|6480  
went to India|6480  
strict all-natural diet|6480  
liposuction|6480  
exercising regularly|6480  
lost 10 pounds after liposuction and diet|7200  
gained all the weight back|15960  
returned to PCP with weight of 200 pounds|15960  
BMI 34.1 kg/m2|15960  
started weekly injectable Semaglutide|15960  
continued lifestyle interventions|15960  
titrated Semaglutide dose to maximum dose|18120  
lost a total of 59 pounds|22440  
BMI decreased to 23.5 kg/m2|22440  
decreased Semaglutide dose|22440  
maintained on optimal Semaglutide dose|22440