type 2 diabetes mellitus diagnosed | -61320  
HbA1c levels 9-13% (during preceding 2 years) | -17520  
received a ball python as a pet | -5040  
received a Mexican black kingsnake as a pet | -2880  
Mexican black kingsnake died | -720  
low-grade fever | -336  
sore throat | -336  
36 years old | 0  
male | 0  
visited primary doctor | 0  
chest pain | 0  
respiratory distress | 0  
liraglutide treatment | 0  
no abdominal pain | 0  
no diarrhea | 0  
cardiomegaly | 0  
suspected congestive heart failure | 0  
referred to our hospital | 0  
height 174 cm | 0  
weight 88.0 kg | 0  
BMI 29.1 kg/m2 | 0  
blood pressure 132/77 mmHg | 0  
pulse rate 131/min | 0  
body temperature 36.8℃ | 0  
respiratory rate 14/min | 0  
pulse oximetry 97% on room air | 0  
no heart murmur | 0  
no pericardial friction rub | 0  
no abnormal breath sound | 0  
bilateral pitting edema of the lower extremities | 0  
no rashes | 0  
no tattoos | 0  
no cutaneous ulcers | 0  
WBC count 13,900 /μL | 0  
neutrophils 75.1% | 0  
C-reactive protein 7.3 mg/dL | 0  
plasma glucose 422 mg/dL | 0  
HbA1c 12.2% | 0  
creatine phosphokinase 35 U/L | 0  
N-terminal pro-brain natriuretic peptide 1,939 pg/mL | 0  
liver function unimpaired | 0  
kidney function unimpaired | 0  
thyroid function unimpaired | 0  
sinus tachycardia 128/min | 0  
normal QRS width and axis | 0  
low voltage | 0  
normal ST segment | 0  
large pericardial effusion around the heart | 0  
pericardial thickening | 0  
bilateral pleural effusion | 0  
no pulmonary parenchymal involvement | 0  
acute pericarditis diagnosed | 0  
admitted to our hospital for further evaluation | 0  
emergency pericardiocentesis performed | 0  
750 mL brownish-red purulent fluid drained | 0  
chest pain improved | 0  
dyspnea on exertion improved | 0  
fosfuluconazole initiated | 0  
daptomycin initiated | 0  
doripenem initiated | 0  
colchicine administered | 0  
bisoprolol fumarate initiated | 0  
culture from pericardial fluid grew Gram-negative bacilli | 24  
no primary source of infection identified | 24  
Gram-negative bacilli identified as S. enterica subsp. arizona | 96  
blood cultures negative | 96  
chest pain gradually relieved | 144  
WBC count returned to within the reference interval | 144  
dyspnea on exertion did not ameliorate | 144  
cardiac catheterization performed | 144  
normal coronary artery | 144  
ejection fraction 46.4% with asynergy | 144  
pulmonary capillary wedge pressure 24 mmHg | 144  
cardiac index 1.29 L/min/m2 | 144  
unstable hemodynamic status | 144  
transferred to department of cardiovascular surgery at another hospital | 144  
pericardiotomy performed | 144  
constrictive pericarditis secondary to bacterial infection diagnosed | 144  
recovered well after the procedure | 144  
discharged from the hospital | 168  