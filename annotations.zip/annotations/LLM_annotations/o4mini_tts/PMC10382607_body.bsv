36-year-old female|0
referred to endocrine outpatient clinic to establish care|0
history of hyperinsulinism hyperammonemia syndrome|0
diagnosed with HI/HA syndrome| -315360
frequent seizures| -315360
hypoglycemia| -315360
started on diazoxide| -315360
started low-protein diet| -315360
no recent episodes of hypoglycemia|0
seizure-free for >10 years|0
taking diazoxide 5 mL every 12 hours|0
strong family history of T2DM|0
9-year-old son diagnosed with HI/HA syndrome as an infant|0
vitals normal|0
body mass index 45.9 kg/m2|0
acanthosis nigricans on the back of her neck|0
physical examination unremarkable|0
initial laboratory testing unremarkable|0
mild elevation in serum ammonia level|0
continued on diazoxide at current dosing|0
lost to follow-up for approximately 1 year|0
next clinic visit|8760
blood glucose levels 120 to 130 mg/dL|8760
no hypoglycemia|8760
weight gain|8760
eating a lot of carbohydrates|8760
hemoglobin A1c level 7.2%|8760
dose of diazoxide reduced to 2 mL every 12 hours|8760
counseled to reduce carbohydrate intake|8760
missed follow-up appointments|8760
clinic visit|14520
no hypoglycemia during this time frame|14520
random glucose level 238 mg/dL|14520
hemoglobin A1c level 10%|14520
diagnosed with T2DM|14520
discontinued diazoxide|14520
started metformin 500 mg twice a day|14520
glutamic acid decarboxylase antibodies <5|14520
C-peptide level 6.5 ng/mL|14520
negative antipancreatic islet-cell antibodies|14520
insulin level 69 μU/ml|14520
ordered genetic analysis|14520
positive heterozygous pathogenic variant in the GLUD1 gene exon 12/13 on nucleotide position c1519C>T and amino acid position His507Tyr|14520
hemoglobin A1c went down to 7.3%|16680
hemoglobin A1c went back up to 9.5%|18840
semaglutide added to her therapy|18840
hemoglobin A1c decreased to 8.2%|19560
weight loss of approximately 10 lbs|19560