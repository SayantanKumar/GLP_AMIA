randomized to Corvia atrial shunt device insertion | -5040
50-year-old woman | 0
HFpEF | 0
AF | 0
AFL | 0
weekly palpitations | 0
electrocardiogram documenting AF | 0
electrocardiogram documenting AFL | 0
symptoms persisted despite rate control | 0
drinks 2 standard drinks once per week | 0
nonsmoker | 0
does not exercise | 0
mother with AF | 0
father with AF | 0
reduced weight from 108 kg to 96 kg on Ozempic | 0
severe asthma | 0
sotalol relatively contraindicated | 0
flecainide not preferred | 0
patient was in sinus rhythm on the day of the procedure | 0
general anesthesia | 0
venous access for decapolar catheter in the coronary sinus | 0
venous access for Boston Scientific Farawave sheath for ablation | 0
did not use intracardiac echocardiography | 0
atrial burst pacing with and without isoproterenol 4 mcg/min | 0
left-sided atrial ectopy | 0
short self-terminating AF | 0
decision to proceed with pulmonary vein isolation | 0
decision to proceed with cavotricuspid isthmus line ablation | 0
16F Farawave sheath introduced into the right atrium | 0
Boston Scientific Farapulse ablation catheter introduced into the right atrium | 0
CTI line ablation using the flower configuration of the Farapulse catheter | 0
200 mcg of intravenous glyceryl trinitrate given | 0
2 pulses at 4 locations | 0
CTI block confirmed with pacing across the CTI between the Farapulse and Boston Scientific decapolar catheter in the coronary sinus | 0
Rosen wire inside the Farawave sheath placed through the Corvia shunt into the left atrium | 0
Farawave sheath guided over the wire through the Corvia shunt into the left atrium without resistance | 0
wire and sheath passed within 60 seconds without image guidance | 0
heparin given to maintain a target activated clotting time between 350 and 400 seconds | 0
Farapulse ablation advanced to the pulmonary veins | 0
catheter and sheath moved easily and freely through the fixed Corvia device to the pulmonary veins without resistance | 0
eight pulses per vein applied (2 × 2 flower, 2 × 2 basket) | 0
catheter retracted into the sheath | 0
sheath pulled back through the fixed Corvia device into the right atrium without resistance | 0
no complications | 0
16F outer diameter sheath traveled through the Corvia atrial shunt device without resistance and was easily manipulated around the left atrium | 0
accessing the left atrium via the shunt device negated the need to perform a transseptal puncture | 0
left atrial ablation using Farapulse was performed successfully | 0
transseptal access via the Corvia device performed | 0
procedure performed as standard for suspected AFL and AF procedures | 0
did not use transseptal needle | 0