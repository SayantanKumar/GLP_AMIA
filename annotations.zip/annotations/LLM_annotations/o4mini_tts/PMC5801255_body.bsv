35 years old|0
male|0
born at 36 weeks’ gestation via vaginal breech delivery| -306600
newborn asphyxia| -306600
Apgar score of 4| -306600
hypotonia| -306600
height could not be measured| -306600
weight was 2150 g| -306600
diagnosed with Prader–Willi syndrome| -219000
floppy infant| -219000
almond shaped eyes| -219000
scoliosis| -219000
obesity (weight more than 20% of standard)| -219000
mental retardation (IQ of 61)| -219000
hypogonadism| -219000
bilateral cryptorchidism| -219000
referred to pediatric endocrinologist| -201480
assessment of pituitary function| -201480
assessment of glucose tolerance| -201480
impaired glucose tolerance| -201480
little reaction of growth hormone| -201480
GH therapy was not done| -201480
diagnosed with diabetes| -166440
began to take several kinds of oral hypoglycemic agents| -166440
referred to department of diabetes and endocrinology| -61320
obesity| -61320
body weight of 90.6 kg| -61320
height of 152.2 cm| -61320
BMI of 39.1 kg/m2| -61320
no sign of diabetic retinopathy| -61320
microalbuminuria (13.6 mg/gCr)| -61320
treated with glibenclamide (1.25 mg/day)| -61320
treated with metformin (1000 mg/day)| -61320
treated with pioglitazone (15 mg/day)| -61320
HbA1c was 11.2% (99 mmol/mol)| -61320
never had a neuroleptic drug prescribed| -61320
written informed consent was obtained| -61320
genetic testing was performed| -61320
abnormal DNA methylation detected by pyrosequencing| -61320
SNP array analysis performed| -61320
copy number variants not found| -61320
microsatellite analysis performed| -61320
uniparental disomy revealed| -61320
metformin (2.25 g/day) administered| -61320
NPH insulin at bedtime of 28 U administered| -61320
miglitol (150 mg/day) administered| -61320
diet of 1600 kcal/day| -61320
exercise therapy| -61320
lost 12 kg of fat| -56280
HbA1c deteriorated to 12.2% (110 mmol/mol)| -56280
replaced NPH insulin with exenatide (20 μg/day)| -56280
HbA1c fluctuated| -17520
continued to lose 15 kg body weight (6 kg fat, 9 kg muscle)| -17520
massive loss of muscle mass| -17520
body weight reached 62.5 kg| -17520
basal insulin (insulin glargine 6 U/day) administered| -17520
lixisenatide administered| -17520
body weight stabilized| -17520
HbA1c did not improve| -17520
addition of tofogliflozin (20 mg/day)|0
switched lixisenatide to dulaglutide (0.75 mg/week)|0
just after initiation of tofogliflozin, HbA1c began to decrease|0
body weight maintained at 62.8 kg|6480
HbA1c improved to 8.5% (69 mmol/mol)|6480
total ketone body level of 781 µM|6480
C-peptide induced by glucagon did not differ significantly|6480
received abdominal CT scan|6480
subcutaneous fat area decreased from 263.6 to 116.0 cm2|6480
visceral fat area hardly changed|6480
abdominal CT at 28 years showed severe fatty infiltration of pancreas| -61320
abdominal CT at 35 years showed disappearance of fatty infiltration|6480
pancreatic attenuation (P) at 28 years –41.9 HU| -61320
splenic attenuation (S) at 28 years 48.9 HU| -61320
pancreatic attenuation (P) at 35 years –2.6 HU|6480
splenic attenuation (S) at 35 years 60.0 HU|6480
P/S value at 28 years –0.857| -61320
P/S value at 35 years –0.043|6480
lipid deposition in pancreas improved|6480
lipid deposition in liver did not differ significantly|6480
continue follow-up, effect has lasted at least 1 year|8760