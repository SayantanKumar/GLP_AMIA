diagnosed with T2DM | -131400  
metformin therapy initiated | -131400  
sulfonylureas therapy initiated | -131400  
sitagliptin therapy initiated | -131400  
hypertension (history) | -131400  
worsening central obesity (history) | -131400  
insulin therapy initiated | -17520  
hemoglobin A1c 11.4% | -2880  
hypertriglyceridemia (496 mg/dL) | -2880  
hypercholesterolemia (total cholesterol 267 mg/dL) | -2880  
presented to outpatient endocrine clinic | 0  
54-year-old female | 0  
second opinion regarding underlying cause of diabetes and obesity | 0  
optimization of glycemic control | 0  
poor and deteriorating glycemic control | 0  
difficulty maintaining optimal weight | 0  
denies easy bruising | 0  
denies striae | 0  
denies muscle weakness | 0  
patient uncertainty about diagnosis | 0  
family history of T2DM | 0  
family history of obesity | 0  
denies smoking | 0  
minimal alcohol use | 0  
denies glucocorticoid use | 0  
metformin 1000 mg twice daily | 0  
insulin glargine 18 units once daily | 0  
insulin aspart (avg 32 units daily) | 0  
lisinopril 40 mg daily | 0  
hydrochlorothiazide 25 mg daily | 0  
vitals within normal limits | 0  
BMI 33.4 kg/m2 | 0  
abdominal obesity | 0  
lipoatrophy of gluteal and extremities | 0  
denies palmar xanthomas | 0  
denies xanthelasma | 0  
denies supraclavicular fat pad | 0  
denies dorsocervical fat pad | 0  
denies moon facies | 0  
denies violaceous striae | 0  
denies bruising | 0  
denies proximal muscle weakness | 0  
denies hirsutism | 0  
denies acanthosis nigricans | 0  
denies skin tags | 0  
denies acromegaly signs | 0  
24-hr urinary free cortisol 16 mcg/24 h | 0  
dexamethasone suppression test 0.77 mcg/dL | 0  
concern for partial lipodystrophy | 0  
fasting leptin level 56.6 ng/mL | 0  
informed consent for NCT00001987 | 0  
X-ray densitometry trunk-to-lower limb fat percent ratio 1.74 | 0  
hepatic steatosis | 0  
genetic testing for LMNA and PPARG negative | 0  
whole-exome sequencing pending | 0  
diagnosis of FPLD type 1 | 0  
recognition of partial lipodystrophy as cause | 0  
patient relieved | 0  
dulaglutide 0.75 mg once weekly initiated | 0  
atorvastatin 40 mg daily initiated | 0  
basal-bolus insulin continued | 0  
metformin continued | 0  
pioglitazone 15 mg daily initiated | 0  
pioglitazone discontinued | 2880  
improvement of hyperglycemia (A1c) | 8760  
insulin therapy discontinued | 8760  
weight loss of 35 pounds | 8760  
triglycerides 155 mg/dL | 8760  
total cholesterol 168 mg/dL | 8760