6-year-old girl|0  
presented to endocrinology clinic|0  
concerns of abnormal blood glucose values|0  
hyperglycemia (random blood glucose 10.6 mmol/L)|0  
hemoglobin A1c of 5.8%|0  
endocrine referral|0  
random blood glucose of 7.2 mmol/L|0  
insulin level of 129.7 µIU/mL|0  
hyperinsulinism|0  
no signs or symptoms concerning for diabetes mellitus|0  
oral glucose tolerance test|1  
30-mg glucose load|1  
fasting blood glucose of 3.9 mmol/L|1  
fasting insulin level of 6.5 µIU/mL|1  
ileostomy bag fully filled twice with loose stools|1  
gastric emptying study|2  
92% gastric emptying within 1 hour|2  
duodenum tortuous with two anastomotic strictures|2  
inability to pass manometry|2  
oral contrast passed preferentially through gastrojejunostomy|2  
feeding tube passed preferentially through gastrojejunostomy|2  
120-minute blood glucose of 2.8 mmol/L|3  
120-minute insulin level of 5.9 µIU/mL|3  
feeds changed to 40% carbohydrates, 40% fat, and 20% protein with 2 g of fiber and added cornstarch every 6 hours|3  
loperamide started|3  
episodes of postprandial hypoglycemia (as low as 2.0 mmol/L)|6  
headaches|6  
irritability|6  
tremors|6  
relieved by eating|6  
eating every 2 hours|6  
definitive surgical recommendation for staged duodenal dilatations|7  
staged duodenal dilatations initiated|7  
failure of first-line therapy for dumping syndrome|7  
discussion to add diazoxide to treatment plan|8  
parents gave informed consent|9  
diazoxide started at 3 mg/kg/d orally|9  
no hypertrichosis|9  
no fluid retention|9  
no other adverse effects of diazoxide|9  
diazoxide dose increased to 5 mg/kg/d divided every 8 hours|729  
2-hour postprandial blood glucose improved to 3.6–5.0 mmol/L|730  
episodes of substantial hypoglycemia resolved|730  
symptoms of dumping almost resolved|2169  
diazoxide slowly weaned|2169  
blood glucose levels remained in the normal range|2169  
prematurity| -52560  
born at 32 weeks’ gestational age| -52560  
gastroschisis| -52560  
jejunal atresia| -52560  
small bowel resection| -52560  
short gut syndrome| -52560  
total parenteral nutrition as main nutritional source| -52560  
surgical gastroenteric anastomosis| -52560  
transition to gastric feeds through gastrostomy tube| -8760  
gastrostomy tube feeding| -8760  
celiac disease diagnosis| -8760  
loose stools with bolus feeds via gastrostomy tube| -8760  
liver transplantation| -43800  
small bowel transplantation| -43800  
pancreas transplantation| -43800  
liver failure| -43800