58 years old|0  
female|0  
presented to the emergency department|0  
dyspnea|0  
bilateral flank pain|0  
pallor|0  
clamminess|0  
blood pressure 170/120 mmHg|0  
heart rate 120 beats/min|0  
body temperature 38.2 °C|0  
respiration rate 30 breaths/min|0  
oxygen saturation 89% on room air|0  
body mass index 25.1 kg/m2|0  
no medical history|0  
no significant family history|0  
phendimetrazine tartrate for weight loss|−43800  
crackles in right lung field|0  
abdomen soft without tenderness|0  
elevated C-reactive protein (29.5 mg/dL)|0  
elevated erythrocyte sedimentation rate (120 mm/hr)|0  
leukocytosis (14.82×10^3/μL)|0  
normocytic anemia (hemoglobin 9.9 g/dL)|0  
mean corpuscular volume 90.7 fL|0  
normal platelet count|0  
blood urea nitrogen 25 mg/dL|0  
creatinine 1.66 mg/dL|0  
elevated aspartate aminotransferase (179 IU/L)|0  
elevated alanine aminotransferase (106 IU/L)|0  
mixed metabolic-respiratory acidosis|0  
elevated lactate (20 mmol/L)|0  
chest radiography bilateral diffuse infiltrations|0  
chest and abdominal CT round mass 3.8 cm in left paravertebral area with heterogeneous contrast enhancement|0  
diagnosis of sepsis of unknown origin|1  
acute respiratory distress syndrome|1  
sedation|1  
intubation|1  
mechanical ventilation|1  
admission to intensive care unit|1  
start broad-spectrum antibiotics (vancomycin, meropenem, azithromycin)|2  
resolution of lung infiltrations on chest radiography|24  
high fever persisted|24  
uncontrolled hypertension persisted|24  
elevated troponin-I (0.841 ng/mL)|24  
elevated creatine kinase (5.3 ng/mL)|24  
elevated NT-proBNP (35 000 pg/mL)|24  
administration of acetaminophen for fever control|24  
transthoracic echocardiogram hypokinetic mid inferior and apical segments|24  
echocardiogram reduced left ventricular ejection fraction (38%)|24  
echocardiogram could not explain fever|24  
echocardiogram could not explain paroxysmal hypertension|24  
referral to endocrinologist|25  
incidentally discovered extra-adrenal mass|25  
palpitations|25  
tachycardia|25  
elevated 24-hour urinary metanephrine (2.12 mg/day)|26  
elevated plasma norepinephrine (1 588 pg/mL)|26  
elevated plasma normetanephrine (2.27 nmol/L)|26  
normal plasma epinephrine (18 pg/mL)|26  
normal plasma metanephrine (0.04 nmol/L)|26  
elevated plasma interleukin-6 (16.5 pg/mL)|26  
somatostatin receptor PET/CT not available|27  
18F-FDG PET/CT increased uptake in left paravertebral mass without metastases|27  
diagnosis of functional paraganglioma|28  
suspicion of interleukin-6 production|28  
succinate dehydrogenase complex subunit B (SDHB) mutation c.541-3C>R|29  
initiation of preoperative alpha-blocker doxazosin|30  
doxazosin administration for 17 days|30  
normalization of body temperature to 36.5 °C|31  
blood pressure well controlled|31  
open excision of retroperitoneal mass|408  
tumor size 4.3×3.5×3.7 cm3 excised|408  
discontinuation of doxazosin|408  
no postoperative complications|408  
prominent cell-nesting pattern (zellballen) in tumor|408  
immunohistochemistry chromogranin A positive staining|408  
IL-6 immunohistochemical testing not performed|408  
improvement of inflammatory biomarkers|504  
improvement of cardiac biomarkers|504  
improvement of renal biomarkers|504  
improvement of hepatic biomarkers|504  
24-hour urinary metanephrine decreased to 0.25 mg/day|504  
phendimetrazine tartrate replaced with glucagon-like peptide-1 receptor agonist|504  
follow-up abdominal CT 13 months after tumor removal no recurrence or metastases|9360  
patient asymptomatic during follow-up visits|9360