100–200 mg PPS daily for 26 years|-227760  
67-year-old|0  
Hispanic man|0  
referred by his optometrist for evaluation of bilateral RPE detachments|0  
diabetes mellitus|0  
insulin|0  
metformin|0  
dulaglutide|0  
chronic interstitial cystitis (IC)|0  
no known history of ocular disease|0  
estimated cumulative dose of 1338 g|0  
comprehensive ophthalmologic evaluation|0  
best-corrected visual acuity of 20/32 in both eyes|0  
intraocular pressures of 18 and 20 mmHg|0  
anterior segment examination with nuclear sclerosis (NC2NO1)|0  
dilated fundus examination revealed yellow deposits and retinal pigment epithelium mottling of the macula in both eyes|0  
fundus pseudocolor imaging highlighted yellow deposits in the central macula bilaterally|0  
fundus autofluorescence identified central macula hyper-autofluorescence with surrounding spots of hypo-autofluorescence|0  
near-infrared reflectivity imaging demonstrated heterogenous reflectance|0  
macular SD-OCT identified subretinal vitelliform lesions bilaterally with overlying intact external limiting membrane and ellipsoid zone|0  
multiple hyperreflective elevations at the level of the RPE in the parafoveal region|0  
Bruch’s membrane and RPE reflectivity were not clear in the sub-foveal region with parafoveal RPE thickening and hyperreflective nodular elevations|0  
suspicion of PPS maculopathy|0  
advised to discontinue taking PPS|0  
referral to the Inherited Retinal Disease clinic for further work-up|0  
multifocal electroretinogram performed|336  
mfERG found ring responses slightly reduced in ring 1 including the fovea on the right eye and within normal limits although with poor waveform morphology in ring 1 on the left eye|336  
full-field electroretinogram performed|336  
ffERG showed responses within normal limits for both general cone-dominated and rod-dominated responses|336  
microperimetry performed|336  
exome IRD testing including sequence analysis and deletion/duplication testing of 330 genes|336  
genetic testing did not identify any variants associated with a genetic disorder|336  
initial visit to IRD clinic one month after discontinuation of PPS|720  
repeat comprehensive ophthalmologic examination found BCVA of 20/50 in both eyes|720  
SD-OCT revealed a small decrease in the peak height of the subfoveal deposits by 38 μm (right eye) and 28 μm (left eye)|720  
12-week follow-up in IRD clinic|2016  
BCVA reduced to 20/60 in the right eye and 20/125 in the left eye|2016  
microperimetry showed reduced sensitivity at the fovea in both eyes with eccentric fixation|2016  
FAF showed a more mottled appearance with areas of hyper- and hypo-autofluorescence at the fovea|2016  
SD-OCT revealed resolution of the vitelliform deposits bilaterally|2016  
nodular excrescences remained in the right eye at the level of the RPE in the parafovea|2016  
plaque-like lesion extending from the Bruch’s membrane–RPE complex remained in the left eye|2016  
external limiting membrane was intact bilaterally|2016  
ellipsoid zone appeared disrupted in the left eye but intact on the right subfoveally|2016