diagnosed with type 2 DM | -157680  
episodes of polydipsia | -157680  
episodes of polyuria | -157680  
glibenclamide (10 mg/day) | -157680  
metformin (2000 mg/day) | -157680  
dietary changes | -157680  
fasting blood glucose maintained within 8.5 to 11 mmol/L | -157680  
oral antidiabetic medication suspended | -17520  
Neutral Protamine Hagedorn insulin 30 IU in the morning | -17520  
Neutral Protamine Hagedorn insulin 20 IU at night | -17520  
regular insulin 10 IU before meals | -17520  
poor treatment compliance | -17520  
insulin doses progressively increased to 240 IU (total daily dose) | -17520  
resumption of metformin (2000 mg/day) | -17520  
resumption of liraglutide (2.4 mg/day) | -17520  
self-monitoring blood glucose ranges of 300 to 450 mg/dL | -17520  
admitted to the emergency department | 0  
59 years old | 0  
male | 0  
pain in lower limbs | 0  
tingling | 0  
weakness | 0  
impaired bilateral lower limb movement | 0  
foot drop | 0  
frequent urination | 0  
random glucose measurement 16.6 mmol/L | 0  
diabetic polyneuropathy | 0  
ischemic heart disease | 0  
human insulin 240 IU (total daily dose) | 0  
liraglutide (2.4 mg/day) | 0  
metformin (2000 mg/day) | 0  
aspirin (80 mg/day) | 0  
valsartan (80 mg/day) | 0  
bisoprolol (2.5 mg/day) | 0  
hydrochlorothiazide (25 mg/day) | 0  
alert | 0  
vital signs stable | 0  
cardiopulmonary examination unremarkable | 0  
acanthosis nigricans | 0  
skin tags | 0  
body mass index 30 kg/m2 | 0  
no deep tendon reflex in lower limbs | 0  
disturbed sense of position | 0  
paresthesia in socks and gloves distribution | 0  
reduced force in lower limbs (4/5) | 0  
normal force in upper limbs (5/5) | 0  
Gowers’ sign positive | 0  
insulin dose increased to 530 IU (total daily dose) | 24  
uncontrolled blood glucose levels | 24  
HbA1c of 16.1% | 24  
fasting blood sugar ranges of 400 to 500 mg/dL | 24  
diagnosed with severe insulin resistance | 24  
other potential causes of high blood sugar ruled out | 24  
normal kidney function tests | 24  
normal liver function tests | 24  
Type B insulin resistance syndrome considered | 24  
autoantibodies against the insulin receptor (5.23 U/mL) | 24  
Electromyography and nerve conduction velocity tests performed | 48  
chronic axonal sensory-motor polyneuropathy suggestive of CIDP | 48  
neurology consultation requested | 48  
plasmapheresis initiated (12 sessions of 1500 L each) | 72  
improvement in pain | 96  
improvement in weakness | 96  
improvement in movement disorders of the lower extremities | 96  
improvement in blood glucose levels | 96  
patient refusal to continue plasmapheresis | 96  
oral prednisolone (60 mg/day) initiated | 96  
amelioration of neurological manifestations | 120  
significant blood glucose control | 120  
discharged | 168  
human insulin discontinued | 168  
controlled blood glucose with oral medications and lispro | 168  
prednisolone tablets (30 mg/day) prescribed on discharge | 168  
homologous insulin (lispro) total dose of 100 IU/day prescribed on discharge | 168  
liraglutide (1.8 mg/day) prescribed on discharge | 168  
acarbose (150 mg/day) prescribed on discharge | 168  
metformin (1500 mg/day) prescribed on discharge | 168  
glibenclamide (20 mg/day) prescribed on discharge | 168  
pioglitazone (30 mg/day) prescribed on discharge | 168  
follow-up visit (3 months after discharge) | 2328  
significant improvements in lower limb symptoms | 2328  
mild pain in proximal parts of lower limbs | 2328  
daily prednisolone dose decreased to 15 mg/day | 2328  
fasting blood sugar 120–150 mg/dL | 2328  
HbA1c 7.8% | 2328