40 years old|0
male|0
history of type 1 DM|0
history of obesity|0
history of hypertension|0
history of dyslipidemia|0
GLP-1 agonist (Wegovy) 1.7 mg started| -48
first injection of Wegovy| -48
chills| -48
nausea| -48
vomiting| -48
diarrhea| -48
presented to ED| -24
blood glucose 303 mg/dL| -24
anion gap 16 mEq/L| -24
beta-hydroxybutyrate 1.4 mmol/L| -24
nontoxic appearing| -24
denied consuming foreign food| -24
Dexcom 6 continuous glucose monitor revealed| -24
insulin pump delivered 10 units after meals| -24
insulin pump delivered 12 units basal insulin over 24 hours| -24
insulin pump functional| -24
conservative management pursued| -24
discharged home with nausea control| -24
presented to ED| -12
mild leukocytosis| -12
blood glucose 171 mg/dL| -12
anion gap 16 mEq/L| -12
beta-hydroxybutyrate 1.8 mmol/L| -12
discharged home with nausea control| -12
presented to ED|0
unable to keep anything down|0
blood glucose average 150 mg/dL|0
insulin pump delivered <1 unit above basal|0
unable to eat any food without vomiting|0
did not give himself postprandial insulin dose|0
chills|0
nausea|0
vomiting|0
body aches|0
diarrhea with eating or drinking|0
no prior history of DKA|0
tachycardia|0
mild hypertension|0
normothermia|0
small bowel obstruction considered|0
history of symptomatic small bowel obstruction|0
electrocardiogram performed|0
troponin testing performed|0
no acute coronary syndrome pathology|0
infection considered less likely|0
anion gap 18 mEq/L|0
blood glucose 158 mg/dL|0
beta-hydroxybutyrate 2 mmol/L|0
pancreatic pathology considered|0
lipase within normal limits|0
chronic marijuana usage|0
venous blood gas assessed (pH 7.34, PaCO2 42.3 mm Hg, PaO2 31.2 mm Hg, HCO3– 22.2 mMol/L, base excess −3.5 mMol/L)|0
DKA diagnosed|0
IV fluids 2 liters administered|0
admitted to family medicine residency service|0
insulin drip with 5% dextrose started|1
no insulin bolus administered|1
anion gap trended every 4 hours|1
insulin drip stopped|24
insulin pump restarted|24
dextrose-containing IV fluid stopped|24
regular diet tolerated|24
nausea completely resolved|24
feeling well on home medications|24
discharged home with regular medications|48
follow-up with endocrinologist instructed|48
blood glucose levels well controlled via insulin pump and continuous glucose monitoring|0