79 years old | 0
man | 0
admitted to our hospital for the treatment of diabetes | 0
orchiectomy | -5760
prostate cancer (T2bN0M0 Stage B, Gleason score 8) | -5760
preoperative body weight 81 kg | -5760
gained 4 kg of body weight | -5760
not diagnosed with diabetes mellitus | -5760
preoperative postprandial blood glucose 115 mg/dL | -5760
preoperative HbA1c 6.6% | -5760
preoperative prostate-specific antigen concentration 8.334 ng/mL | -5760
felt thirst | -1440
polyuria | -1440
lost 10 kg of body weight | -1440
visited a clinic | -72
underwent laboratory tests | -72
postprandial plasma glucose 518 mg/dL | -72
HbA1c 11.9% | -72
took medication for hypertension | 0
took medication for dyslipidemia | 0
took medication for paroxysmal atrial fibrillation | 0
no family history of diabetes | 0
ethanol intake under 30 g a day | 0
body temperature 35.6 °C | 0
blood pressure 113/65 mmHg | 0
pulse 88 bpm | 0
body weight 75 kg | 0
body mass index 25.6 kg/m2 | 0
performed glucagon stimulation test | 0
C-peptide immunoreactivity fasting 2.33 ng/mL | 0
C-peptide immunoreactivity 6 min after glucagon 6.68 ng/mL | 0
preserved endogenous insulin secretion | 0
anti-glutamic acid decarboxylase antibody negative | 0
anti-insulin antibody negative | 0
prostate-specific antigen concentration on admission 0.739 ng/mL | 0
postoperative serum free testosterone concentration 1 pg/mL | 0
serum estradiol below detection | 0
normal thyroid function test findings | 0
normal adrenal function test findings | 0
abdominal CT lower liver intensity | 0
L/S ratio decreased to 0.37 | 0
visceral fat area increased by 40.8% | 0
subcutaneous fat area increased by 15.9% | 0
normal liver function test findings | 0
viral hepatitis tests negative | 0
anti-nuclear antibody negative | 0
anti-mitochondrial M2 antibody negative | 0
no hypergammaglobulinemia | 0
diagnosed with severe diabetes after orchiectomy | 0
administered multiple daily insulin injection therapy | 0
administered canagliflozin 100 mg/day | 0
administered sitagliptin 50 mg/day | 0
blood glucose well controlled | 168
changed insulin regimen to insulin aspart/insulin degludec combination twice daily | 168
changed sitagliptin to dulaglutide injection 75 mg once a week | 168
CT improvement in L/S ratio | 336
reduction in visceral fat area | 336
reduction in subcutaneous fat area | 336