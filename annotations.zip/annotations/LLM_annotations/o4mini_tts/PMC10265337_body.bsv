66-year-old female|0  
Referral to endocrinology outpatient service|0  
Hirsutism onset (developed after menopause)|-166440  
Menopause occurred at age 47 years|-166440  
No personal history of infertility during reproductive age|-166440  
No menstrual irregularity during reproductive age|-166440  
No hirsutism during reproductive age|-166440  
Gestational diabetes during last pregnancy|-166440  
Progressive worsening of hirsutism over past year|-8760  
Abdominal obesity|0  
Hypertension|0  
Atherogenic dyslipidemia|0  
Type 2 diabetes|0  
Metformin therapy|0  
Semaglutide therapy|0  
Basal insulin therapy|0  
Angiotensin-receptor blocker therapy|0  
Calcium-channel blocker therapy|0  
Furosemide therapy|0  
Omega-3-acid ethyl esters therapy|0  
Ezetimibe therapy|0  
Rosuvastatin therapy|0  
Alopecia|0  
Excess terminal hairs (>5 mm)|0  
Ferriman–Gallwey score 20/36 (moderate hirsutism)|0  
Clitoromegaly not detected|0  
No cushingoid features|0  
No overt virilization|0  
Body mass index 31.9 kg/m2|0  
Arterial blood pressure 120/70 mmHg|0  
Biochemical hyperandrogenism confirmed|0  
Total testosterone 384.5 ng/dl|0  
Dehydroepiandrosterone sulfate 136.2 µg/dl|0  
Delta-4-androstenedione 6.09 ng/dl|0  
ACTH normal|0  
Cortisol normal|0  
Chromogranin A normal|0  
Carcinoembryonic antigen normal|0  
Cancer antigen 125 normal|0  
Human epididymis protein 4 normal|0  
Glycated hemoglobin (HbA1c) 8.1% (65 mmol/mol)|0  
Estimated glomerular filtration rate 44 ml/min/1.73 m2|0  
Transvaginal ultrasound: normal ovaries, no follicular activity|0  
Transvaginal Doppler: no vascularization of right ovary|0  
Transvaginal Doppler: slightly enhanced vascular signal in left ovary|0  
Abdominal MRI performed|24  
MRI: left ovary 20×11 mm|24  
MRI: inhomogeneous T2 signal with central hyperintensity|24  
MRI: intense postcontrast enhancement|24  
Referral for gynecology consultation|48  
Laparoscopic bilateral salpingo-oophorectomy proposed|48  
Laparoscopic bilateral salpingo-oophorectomy performed|72  
Histological diagnosis of luteinized thecoma in left ovary|96  
Improvement of hirsutism clinical features|336  
Weight 87 kg (at presentation)|0  
Height 1.65 m (at presentation)|0  
Diastolic blood pressure 70 mmHg (at presentation)|0  
Hemoglobin 10.5 g/dl (at presentation)|0  
Creatinine 1.28 mg/dl (at presentation)|0  
Glucose 115 mg/dl (at presentation)|0  
SHBG 47.60 nmol/L (at presentation)|0  
LH 42.1 mUI/ml (at presentation)|0  
FSH 68.5 mUI/ml (at presentation)|0  
Total cholesterol 127 mg/dl (at presentation)|0  
HDL cholesterol 35 mg/dl (at presentation)|0  
LDL cholesterol 58 mg/dl (at presentation)|0  
Triglycerides 119 mg/dl (at presentation)|0  
AST 35 U/L (at presentation)|0  
ALT 61 U/L (at presentation)|0  
GGT 87 U/L (at presentation)|0  
Weight 85 kg (3-month follow-up)|2160  
BMI 31.2 kg/m2 (3-month follow-up)|2160  
Systolic blood pressure 120 mmHg (3-month follow-up)|2160  
Diastolic blood pressure 70 mmHg (3-month follow-up)|2160  
Hemoglobin 11.1 g/dl (3-month follow-up)|2160  
Creatinine 1.24 mg/dl (3-month follow-up)|2160  
Glucose 92 mg/dl (3-month follow-up)|2160  
HbA1c 47 mmol/mol (3-month follow-up)|2160  
Total testosterone 19.8 ng/dl (3-month follow-up)|2160  
SHBG 44.5 nmol/L (3-month follow-up)|2160  
Delta-4-androstenedione 1.5 ng/ml (3-month follow-up)|2160  
DHEA-S 107.5 µg/dl (3-month follow-up)|2160  
ACTH 26.1 pg/ml (3-month follow-up)|2160  
Cortisol 14.9 µg/dl (3-month follow-up)|2160  
LH 44.2 mUI/ml (3-month follow-up)|2160  
FSH 85.7 mUI/ml (3-month follow-up)|2160  
AST 31 U/L (3-month follow-up)|2160  
ALT 38 U/L (3-month follow-up)|2160  
Weight 83 kg (6-month follow-up)|4320  
BMI 30.5 kg/m2 (6-month follow-up)|4320  
Systolic blood pressure 125 mmHg (6-month follow-up)|4320  
Diastolic blood pressure 70 mmHg (6-month follow-up)|4320  
Hemoglobin 11.4 g/dl (6-month follow-up)|4320  
Creatinine 1.22 mg/dl (6-month follow-up)|4320  
Glucose 100 mg/dl (6-month follow-up)|4320  
HbA1c 49 mmol/mol (6-month follow-up)|4320  
Total testosterone 19.9 ng/dl (6-month follow-up)|4320  
SHBG 41.4 nmol/L (6-month follow-up)|4320  
Delta-4-androstenedione 1.8 ng/ml (6-month follow-up)|4320  
DHEA-S 121.3 µg/dl (6-month follow-up)|4320  
Total cholesterol 142 mg/dl (6-month follow-up)|4320  
HDL cholesterol 39 mg/dl (6-month follow-up)|4320  
LDL cholesterol 73 mg/dl (6-month follow-up)|4320  
Triglycerides 149 mg/dl (6-month follow-up)|4320  
AST 35 U/L (6-month follow-up)|4320  
ALT 40 U/L (6-month follow-up)|4320