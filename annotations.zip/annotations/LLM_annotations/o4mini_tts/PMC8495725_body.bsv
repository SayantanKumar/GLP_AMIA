34-year-old female|0  
presented to outpatient lipid clinic|0  
physical examination: height 184 cm|0  
physical examination: weight 102 kg|0  
physical examination: BMI 30.1 kg/m2|0  
increased fat mass around abdomen|0  
loss of subcutaneous fat on extremities|0  
body fat content 33.2%|0  
fat mass index 8.8 kg/m²|0  
total muscle mass content 28.9 kg|0  
prominent bulging musculature and veins on extremities|0  
no signs of acanthosis nigricans|0  
no fat accumulation in face or neck|0  
blood pressure 125/80 mmHg|0  
suboptimal diabetes control (HbA1c 73 mmol/mol; 8.8%)|0  
hypertriglyceridemia (blood triglycerides 47.9 mmol/L)|0  
hepatomegaly|0  
metabolic steatohepatitis|0  
stress eating|0  
sweet eating|0  
abnormal quantities of eating|0  
reduced feeling of satiety|0  
blood glucose 13.5 mmol/L|0  
insulin level increased to 34.6 mlU/L|0  
C-peptide level increased to 5.86 μg/L|0  
thyroid-stimulating hormone within reference range|0  
insulin-like growth factor 1 within reference range|0  
cortisol within reference range|0  
blood cholesterol total 12.6 mmol/L|0  
HDL cholesterol 0.24 mmol/L|0  
AST 102.2 U/L|0  
ALT 57.2 U/L|0  
gamma-glutamyl transferase 60 U/L|0  
C-reactive protein 14.4 mg/L|0  
metformin 1000 mg twice daily|0  
insulin glargine 30 IU once daily|0  
simvastatin 40 mg once daily|0  
oral contraception|0  
no IV insulin treatment|0  
no lipid-apheresis|0  
PPARG c.485T>G variant detected|0  
in silico Varsome analysis classified variant as pathogenic|0  
no deletion or duplication in AGPAT2, BSCL2, CAV1, CAVIN1, CIDEC, LIPE, PIK3R1, PLIN1|0  
no deletion or duplication in LMNA by MLPA|0  
addition of semaglutide|0  
addition of dapagliflozin|0  
switched statin to gemfibrozil|0  
started omega-3 fatty acids|0  
recombinant leptin therapy initiated|0  
hypertriglyceridemia first diagnosed in 2018|-17520  
leptin level normalized (13.0 ng/mL)|336  
triglyceride level 35.1 mmol/L|336  
improved appetite and satiety|336  
ALT reduced to 13.2 U/L|336  
HbA1c after leptin initiation (7.2% NGSP)|336  
severe allergic reactions at injection sites|336  
weight loss of 7 kg (BMI 26.6 kg/m²)|3600  
triglyceride level 2.3 mmol/L|3600  
insulin glargine discontinued|3600  
leptin concentration 63.0 ng/mL|3600  
ALT increased to 58.3 U/L|3600