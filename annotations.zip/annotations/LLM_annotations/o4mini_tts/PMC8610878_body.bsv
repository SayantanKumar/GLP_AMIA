63 years old|0  
male|0  
Caucasian|0  
retired|0  
no pertinent personal or family history|0  
no significant alcohol intake|0  
no smoking|0  
no recreational drugs use|0  
no history of reflux disease prior to this episode|0  
no history of dysphagia prior to this episode|0  
history of hypertension|0  
history of dyslipidemia|0  
history of type 2 diabetes mellitus|0  
metformin 500 mg twice daily|0  
ramipril 5 mg daily|0  
ezetimibe 10 mg daily|0  
duloxetine 60 mg daily|0  
pravastatin 40 mg daily|0  
symptom onset of severe epigastric pain| -120  
symptom onset of dysphagia| -120  
symptom onset of odynophagia| -120  
symptom onset of anorexia| -120  
symptom onset of nausea| -120  
symptom onset of non-bloody non-bilious emesis| -120  
bed rest| -120  
cessation of oral intake| -120  
switch from liraglutide to semaglutide| -168  
ketogenic diet started| -168  
presented to Emergency with severe epigastric pain|0  
dysphagia|0  
odynophagia|0  
anorexia|0  
nausea|0  
non-bloody non-bilious emesis|0  
no overt gastrointestinal bleeding|0  
tachycardia (125 beats per minute)|0  
tachypnea (respiratory rate 40)|0  
Kussmaul respirations|0  
blood pressure 136/81|0  
voluntary abdominal guarding|0  
frequent painful belching|0  
hemoglobin 165 g/L|0  
leukocytes 17.9×10^9/L|0  
anion gap 25|0  
bicarbonate 5 mmol/L|0  
arterial pH 7.02|0  
B-hydroxybutyrate 10.2 mmol/L|0  
glucose initially 17 mmol/L|0  
glucose peaked at 82 mmol/L|0  
urinalysis negative for leukocytes or nitrites|0  
abdominal CT ruled out bowel obstruction|0  
abdominal CT ruled out intra-abdominal infection/abscess|0  
circumferential wall thickening of distal esophagus on CT|0  
diagnosis of diabetic ketoacidosis (DKA)|0  
C-peptide ordered|0  
C-peptide result within normal limits|0  
resolution of DKA|48  
continued epigastric pain after DKA resolution|48  
continued reflux symptoms after DKA resolution|48  
continued dysphagia after DKA resolution|48  
esophagogastroduodenoscopy performed|48  
severe class D esophagitis involving entire esophagus|48  
circumferential black necrotic inflammatory changes mid to distal esophagus|48  
necrosis stopping at gastroesophageal junction|48  
gastric and duodenal mucosa biopsies taken|48  
histology showing chronic gastroduodenitis with no H. pylori, no infectious organisms, no neoplasia|72  
pantoprazole 40 mg IV twice daily|48  
sucralfate suspension 1 g PO four times daily|48  
nil per os then clear to full fluid diet instructions|48  
discharged home in stable condition|96  
liquid diet at discharge|96  
sucralfate 2 g with meals and nightly for two weeks|96  
pantoprazole 40 mg twice daily at discharge|96  
metformin discontinued|96  
GLP-1 receptor agonist discontinued|96  
insulin aspart 5 units three times daily initiated|96  
insulin glargine 15 units nightly initiated|96  
repeat EGD 8 weeks post-discharge|1440  
healed esophagus with one polyp on repeat EGD|1440  
biopsies showing healed gastric and duodenal mucosa|1440  
mild inflammatory changes in removed polyp|1440  
follow-up HbA1c improved from 8.4 to 7.2|1440