white blood cells 5.9×10^3/µL|-336
hemoglobin 12.0 gm/dL|-336
platelets 166×10^3/µL|-336
sodium 133 mEq/L|-336
potassium 4.7 mEq/L|-336
chloride 110 mEq/L|-336
bicarbonate 18 mM/L|-336
blood urea nitrogen 11 mg/dL|-336
creatinine 0.85 mg/dL|-336
glomerular filtration rate >60 mL/min/1.73 sq m|-336
glucose 379 mg/dL|-336
hemoglobin A1c not checked|-336
serum calcium 8.1 mg/dL|-336
ionized calcium not checked|-336
albumin 4.1 gm/dL|-336
total protein 5.9 gm/dL|-336
aspartate transaminase 24 U/L|-336
alanine transaminase 29 U/L|-336
alkaline phosphatase 155 U/L|-336
total bilirubin 0.4 mg/dL|-336
air conditioner stopped working|-168
home overheated|-168
standing close to the freezer door|-168
eating pieces of ice|-168
feeling heated|-168
sweating profusely|-168
headache|-72
dizziness|-72
nausea|-72
weakness|-72
50-year-old woman|0
chronic obstructive pulmonary disease|0
hypertension|0
hyperlipidemia|0
bipolar disorder|0
autoimmune hepatitis with cirrhosis|0
gastroesophageal reflux disease|0
hypothyroidism|0
type 2 diabetes mellitus|0
albuterol inhaler|0
clonidine 0.2 mg twice a day|0
atorvastatin 40 mg nightly|0
quetiapine 300 mg nightly|0
fluoxetine 20 mg daily|0
benztropine 1 mg twice a day|0
prednisone 5 mg daily|0
pantoprazole 40 mg daily|0
furosemide 20 mg daily|0
levothyroxine 50 mcg daily|0
metformin 1000 mg twice a day|0
insulin degludec 16 units every morning|0
exenatide 2 mg weekly|0
denies taking over-the-counter medications|0
denies antacids|0
denies calcium supplements|0
denies vitamin A supplements|0
admitted to the hospital|0
blood pressure 150/90 mmHg|0
temperature 37.4°C|0
heart rate 105 beats per min|0
respiratory rate 18 breaths per min|0
oxygen saturation 99% on room air|0
patient was lethargic|0
dry mucus membranes|0
rest of physical examination unremarkable|0
white blood cells 8.6×10^3/µL|0
hemoglobin 12.7 gm/dL|0
platelets 235×10^3/µL|0
sodium 135 mEq/L|0
potassium 3.5 mEq/L|0
chloride 101 mEq/L|0
bicarbonate 28 mM/L|0
blood urea nitrogen 9 mg/dL|0
creatinine 0.97 mg/dL|0
glomerular filtration rate >60 mL/min/1.73 sq m|0
blood glucose 365 mg/dL|0
hyperglycemia without diabetic ketoacidosis|0
electrocardiogram normal sinus rhythm without ST-segment changes|0
serum calcium 17.3 mg/dL|0
ionized calcium 1.95 mM/L|0
hypercalcemia|0
laboratory tests unremarkable|0
blood gas not done|0
administration of 2-liter fluid bolus of normal saline|0
start continuous infusion of normal saline at 150 mL/h|0
admitted to medical floor|0
extensive laboratory workup|0
parathyroid hormone 5 pg/mL|0
parathyroid hormone-related peptide <0.4 pmol/L|0
thyroid-stimulating hormone 1.266 uIU/mL|0
cortisol 11.5 ug/dL|0
25-hydroxy vitamin D 23 ng/mL|0
1,25-dihydroxy vitamin D 11.2 pg/mL|0
kappa free light chain 23.9 mg/L|0
lambda free light chain 20.3 mg/L|0
kappa/lambda ratio 1.18|0
albumin SPE 3.31 g/dL|0
alpha 1-globulin SPE 0.28 g/dL|0
alpha 2 SPE 0.81 g/dL|0
beta 2 SPE 0.60 g/dL|0
gamma SPE 0.49 g/dL|0
serum paraprotein 1 0 g/dL|0
serum paraprotein 2 0 g/dL|0
serum paraprotein 3 0 g/dL|0
bisphosphonate therapy not needed|0
calcium level gradually improved|0
calcium normalized|72
i.v. hydration stopped|72
patient’s symptoms resolved|96
discharged home|96
white blood cells 6.4×10^3/µL|264
hemoglobin 12.0 gm/dL|264
platelets 239×10^3/µL|264
sodium 134 mEq/L|264
potassium 4.9 mEq/L|264
chloride 102 mEq/L|264
bicarbonate 22 mM/L|264
blood urea nitrogen 17 mg/dL|264
creatinine 0.94 mg/dL|264
glomerular filtration rate >60 mL/min/1.73 sq m|264
blood glucose 470 mg/dL|264
hemoglobin A1c not checked|264
serum calcium 9.6 mg/dL|264
ionized calcium not checked|264
albumin 5.1 g/dL|264
total protein 7.4 g/dL|264
AST 15 U/L|264
ALT 17 U/L|264
alkaline phosphatase 147 U/L|264
total bilirubin 0.6 mg/dL|264
follow-up visit with primary care physician|264
mammography of bilateral breast|264
nuclear bone imaging of whole body|264
computed tomography scan of chest abdomen and pelvis|264
follow-up workup unremarkable|264
calcium level within reference range|264