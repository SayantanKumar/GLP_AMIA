66-year-old gentleman|0  
presented for cardiovascular evaluation|0  
chest discomfort|0  
right knee pain|0  
intractable hiccups|0  
type 2 diabetes mellitus|0  
hypercholesterolemia|0  
aortic atherosclerosis|0  
ascending aortic aneurysm|0  
family history of premature coronary artery disease in the father|0  
compliant with his medical therapy|0  
subcutaneous 200 units/mL insulin degludec|0  
18 mg/3 mL subcutaneous liraglutide|0  
daily oral 500 mg metformin hydrochloride|0  
daily oral 100 mg sitagliptin|0  
daily oral 12.5 mg zolpidem|0  
daily oral 5 mg tadalafil|0  
20 mg tablet rosuvastatin daily|0  
initially referred for an upper gastrointestinal endoscopy|24  
no gastrointestinal etiology found for his persistent hiccups|24  
cardiac stress test conducted|2160  
no significant evidence of ischemia on stress test|2160  
patient complained of dyspnea (unstable angina)|2160  
transthoracic echocardiogram|2160  
preserved ejection fraction|2160  
noninvasive cardiovascular workup inconclusive|2160  
coronary calcium score study|2160  
Agatson calcium score of 1185|2160  
categorized as high risk for future cardiovascular events|2160  
cardiac catheterization|2880  
left main artery 10% stenosis|2880  
left anterior descending artery (LAD) 99% stenosis|2880  
circumflex artery 20% stenosis|2880  
right coronary artery (RCA) 30% stenosis|2880  
drug eluting stent placed in the mid-segment of the LAD|2880  
hiccups immediately resolved|2880  
patient discharged the same day|2904  
compliant with 81 mg aspirin|2904  
compliant with 90 mg ticagrelor twice a day|2904  
followed up in the office in the same week|3072  
post-interventional follow-up after 30 days|3600  
post-interventional follow-up after 6 months|7200  
post-interventional follow-up after 1 year|11640  
neither reported nor displayed the return of intractable hiccups|11640