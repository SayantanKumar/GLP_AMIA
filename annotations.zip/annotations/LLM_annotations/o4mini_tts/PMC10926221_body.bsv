32 years old|0  
male|0  
routine follow-up appointment|0  
diagnosed with mild form of MADD|-271560  
hypoglycemia|-271560  
hyperammonemia|-271560  
metabolic acidosis|-271560  
loss of consciousness|-271560  
hypoketotic, dicarboxylic aciduria|-271560  
increased excretion of ethylmalonic acid|-271560  
increased excretion of 2-hydroxyglutaric acid|-271560  
increased excretion of isovaleric glycine|-271560  
genetic analysis of ETFA gene|-271560  
dietary therapy|-271560  
riboflavin supplementation|-271560  
levocarnitine supplementation|-271560  
avoidance of prolonged fasting|-271560  
frequent meals high in carbohydrate low in fat and protein|-271560  
episodes of hypoglycemia due to fasting during infancy|-271560  
free of hypoglycemic events since age 2.5 years|-258420  
long-standing habit of consuming 500–1000 mL soft drinks daily|-166440  
weight 90.9 kg|-1440  
BMI 31 kg/m2|-1440  
AST 121 U/L|-1440  
ALT 224 U/L|-1440  
GGT 74 U/L|-1440  
cholinesterase 371 U/L|-1440  
C0 57.75 μmol/L|-2880  
C0 49.91 μmol/L|-1440  
C0 32.2 μmol/L|0  
C0 57.2 μmol/L|1440  
C0 73.15 μmol/L|2880  
C2 5.18 μmol/L|-2880  
C2 4.39 μmol/L|-1440  
C2 11.95 μmol/L|0  
C2 10.84 μmol/L|1440  
C2 7.83 μmol/L|2880  
C4 0.52 μmol/L|-2880  
C4 0.47 μmol/L|-1440  
C4 1.05 μmol/L|0  
C4 1.21 μmol/L|1440  
C4 1.1 μmol/L|2880  
C5 0.67 μmol/L|-2880  
C5 0.57 μmol/L|-1440  
C5 1.49 μmol/L|0  
C5 1.03 μmol/L|1440  
C5 2.35 μmol/L|2880  
C6 0.24 μmol/L|-2880  
C6 0.43 μmol/L|-1440  
C6 0.33 μmol/L|0  
C6 0.59 μmol/L|1440  
C6 0.52 μmol/L|2880  
C8 0.74 μmol/L|-2880  
C8 1.64 μmol/L|-1440  
C8 0.48 μmol/L|0  
C8 0.88 μmol/L|1440  
C8 0.76 μmol/L|2880  
C10 0.37 μmol/L|-2880  
C10 0.75 μmol/L|-1440  
C10 0.27 μmol/L|0  
C10 0.41 μmol/L|1440  
C10 0.33 μmol/L|2880  
C12 0.07 μmol/L|-2880  
C12 0.11 μmol/L|-1440  
C12 0.07 μmol/L|0  
C12 0.08 μmol/L|1440  
C12 0.09 μmol/L|2880  
C14:1 0.04 μmol/L|-2880  
C14:1 0.11 μmol/L|-1440  
C14:1 0.06 μmol/L|0  
C14:1 0.09 μmol/L|1440  
C14:1 0.04 μmol/L|2880  
C16 0.52 μmol/L|-2880  
C16 0.56 μmol/L|-1440  
C16 0.68 μmol/L|0  
C16 0.56 μmol/L|1440  
C16 0.61 μmol/L|2880  
axial CT scan 12 years prior showing liver steatosis|-105120  
axial CT scan near time of episode showing fatty liver|0  
polydipsia|0  
polyuria|0  
frequent muscle spasms|0  
fatigue|0  
decreased appetite|0  
HbA1c 8.5%|-720  
insulin 13.9 μU/mL|-720  
CPR 2.68 ng/mL|-720  
HOMA-R index 4.5|-720  
polydipsia|0  
polyuria|0  
frequent muscle spasms|0  
fatigue|0  
decreased appetite|0  
hba1c 13.9%|0  
postprandial blood glucose 382 mg/dL|0  
total ketone bodies 2.5 mmol/L|0  
3-hydroxybutyrate 1.4 mmol/L|0  
serum cholinesterase 293 U/L|0  
creatine kinase 176 U/L|0  
urea nitrogen 13 mg/dL|0  
creatinine 0.56 mg/dL|0  
venous blood gas pH 7.42|0  
venous blood gas HCO3− 26.5 mmol/L|0  
venous blood gas pCO2 42.5 mmHg|0  
anion gap 4.4 mmol/L|0  
urinalysis positive for glucose|0  
urinalysis positive for ketone bodies|0  
insulin level 3.9 μU/mL|0  
AST 26 U/L|0  
ALT 52 U/L|0  
GGT 41 U/L|0  
visceral fat area 103.90 cm2|0  
subcutaneous fat area 129.36 cm2|0  
managed with intravenous saline|0  
short-acting insulin infusion|0  
started intensive insulin therapy using insulin lispro glargine and liraglutide|0  
diagnosed with T2DM|0  
planned interventions|0  
engaged in physical labor|0  
energy intake over 2000 kcal/day|0  
macronutrient composition 14% protein 20% fat 66% carbohydrate|0  
consumption increased to 1500–2000 mL/day soft drinks|0  
blood glucose stabilized|264  
transitioned to once-daily liraglutide injection|264  
dietary management changed to 1700 kcal/day|264  
macronutrient composition 17% protein 27% fat 56% carbohydrate|264