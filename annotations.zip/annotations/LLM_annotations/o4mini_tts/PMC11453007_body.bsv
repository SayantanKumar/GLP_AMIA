45-year-old woman | 0  
presented to the ED | 0  
sudden onset of right flank pain | 0  
sweating | 0  
lightheadedness | 0  
fainting | 0  
syncope | 0  
recovered within a minute | 0  
brought to the ED by EMS | 0  
no history of fever | 0  
no vomiting | 0  
no falls | 0  
no urinary tract symptoms | 0  
family did not notice any jerky movements | 0  
no post-event confusion | 0  
type 2 diabetes | 0  
Semaglutide | 0  
pulse 88/min | 0  
blood pressure 115/75 mmHg | 0  
respiratory rate 18/min | 0  
temperature 36.4 C | 0  
abdomen soft | 0  
mild tenderness in the right flank | 0  
mild tenderness in costovertebral angle | 0  
rest of clinical examination unremarkable | 0  
hemoglobin of 13.3 gm/dl | 1  
raised total leukocyte count of 15.6×10^9/L with neutrophilic shift | 1  
urinalysis positive for red blood cells | 1  
urinalysis positive for hemoglobinuria | 1  
performed PoCUS | 2  
low-frequency curvilinear array transducer selected | 2  
transducer placed longitudinally at the right posterior-axillary line | 2  
hyperechoic heterogeneous mass visualized | 2  
mass arising from the upper region of the right kidney | 2  
identified anechoic region surrounding the right kidney suggestive of free fluid | 2  
ordered urgent CT abdomen | 3  
CT abdomen performed | 3  
large heterogeneous exophytic right renal mass | 3  
mass contained fat-density elements | 3  
mass contained soft tissue elements | 3  
mass contained prominent vessels | 3  
perinephric hematoma suggestive of tumor bleed | 3  
sought consultation from urology | 3  
sought consultation from interventional radiology | 3  
conducted angioembolization for ruptured AML | 4  
admitted under the urology service for monitoring of hemoglobin levels | 5  
hemoglobin levels remained stable | 5  
no blood product transfusion required | 5  
discharged | 77  
prescription for oral analgesics | 77  
uneventful recovery | 77