rapid weight gain the year prior|-8760  
outpatient evaluation by an endocrinologist|-8760  
HgbA1 4.8%|-8760  
testosterone 29.9|-8760  
LH 8.1|-8760  
FSH 4.1|-8760  
TSH 2.41|-8760  
CMP normal|-8760  
lipid panel normal|-8760  
trial of off-label metformin for weight loss|-8760  
self-discontinued metformin|-8760  
semaglutide injections|-8760  
abdominal striae|-8760  
no Cushing’s syndrome testing|-8760  
denied buffalo hump|-8760  
denied muscle wasting|-8760  
denied heat intolerance|-8760  
denied hypertension|-8760  
22-year-old woman|0  
presented to the emergency room|0  
worsening lower left pelvic pain|0  
nausea|0  
vomiting|0  
vaginal bleeding|0  
regular menses|0  
normal sleep habits|0  
denied hirsutism|0  
denied acne|0  
denied hair loss|0  
surgical history noncontributory|0  
family history noncontributory|0  
mild tenderness over her left lower quadrant|0  
no masses appreciated|0  
transvaginal ultrasound|0  
CT scan|0  
10.6 cm multi-septated left adnexal mass|0  
containing fat|0  
containing fluid|0  
containing calcifications|0  
suspected dermoid cyst|0  
pain improved|2  
arterial and venous blood flow to both ovaries|2  
decision for outpatient follow-up with a surgeon|2  
seen in the outpatient clinic|168  
scheduled for laparoscopic ovarian cystectomy|168  
laparoscopic entry|192  
left ovary torsed two times around its vascular pedicle|192  
large dermoid cyst|192  
dermoid removed laparoscopically|192  
ovarian parenchyma repaired|192  
final pathology mature cystic teratoma|240  
small focus of mature pituitary tissue|240  
positive pancytokeratin|240  
positive CAM 5.2|240  
positive S100|240  
positive synaptophysin|240  
positive growth hormone staining|240  
positive prolactin staining|240  
positive ACTH staining|240  
follow-up visit one month after surgery|912  
doing well|912  
modest weight loss since the operation|912  
advised repeat sonogram in 6 months|912  
not been back to see her endocrinologist to date|912