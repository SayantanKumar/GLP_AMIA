27-year-old woman|0  
female|0  
presented to the Howard University Hospital diabetes clinic|0  
family history of diabetes|0  
family history of high blood pressure|0  
family history of elevated cholesterol|0  
nonsmoker|0  
no children|0  
works at a fast-food chain|0  
taking NPH 20 units in the morning|0  
taking NPH 15 units in the evening|0  
taking regular insulin 25 units in the morning|0  
taking regular insulin 15 units in the evening|0  
taking atorvastatin 10 mg daily|0  
taking warfarin 7.5 mg daily|0  
taking ergocalciferol 50 000 units|0  
taking lisinopril/hydrochlorothiazide 20/25 mg|0  
poor compliance with medications and insulin regimen|0  
visual disturbances|0  
burning and tingling in her feet and legs|0  
alterations in appetite|0  
weight gain|0  
edema|0  
nausea|0  
irritability|0  
depression|0  
A1C 8.9%|0  
weight 265 lb|0  
rates personal health as poor|0  
given meal plan in the past but did not adhere|0  
stress causing overeating|0  
exercises regularly (walking)|0  
diagnosed with type 2 diabetes|−114000  
negative anti-islet antibody test|−114000  
not checking blood glucose because she had run out of test strips|−2160  
unplanned weight gain of 35 lb over the past 3 months|−2160  
recorded only 72 readings during Jan–June 2011|22320  
average blood glucose reading 295 mg/dL during Jan–June 2011|22320  
minimum blood glucose reading 58 mg/dL during Jan–June 2011|22320  
maximum blood glucose reading 601 mg/dL during Jan–June 2011|22320  
48 readings >200 mg/dL during Jan–June 2011|22320  
28% of readings within target range during Jan–June 2011|22320  
14 months before starting liraglutide: Insulin aspart 70/30 mix 40 units at breakfast and 30 units at dinner|15840  
13 months before starting liraglutide: Insulin aspart 70/30 mix 35 units twice daily|16560  
13 months before starting liraglutide: A1C climbed to 11.1%|16560  
13 months before starting liraglutide: developed albuminuria|16560  
13 months before starting liraglutide: insulin doses intensified|16560  
10 months before starting liraglutide: Insulin glargine 40 units at bedtime and Insulin aspart 15 units with meals|18720  
10 months before starting liraglutide: weight increased by 12 lb to 297 lb|18720  
6 months before starting liraglutide: Insulin glargine 45 units at bedtime and Insulin aspart 15 units with meals|21600  
1 month before starting liraglutide: Insulin aspart 70/30 mix 45 units twice daily|25200  
Date liraglutide was added: Insulin aspart 70/30 mix 45 units twice daily|25920  
Date liraglutide was added: Liraglutide 1.2 mg daily|25920  
started liraglutide 0.6 mg daily subcutaneously for 1 week|25920  
increased liraglutide to 1.2 mg daily after 1 week|26088  
tested blood glucose 193 times from 30 July to 30 December 2011|26640  
averaged 1.25 readings per day during that period|26640  
averaged 0.47 readings per day before starting liraglutide|26640  
results in target range increased to 44% during that period|26640  
mean blood glucose 166 mg/dL during that period|26640  
had more hypoglycemic readings on liraglutide|26640  
none of those readings resulted in a hospital visit|26640  
follow-up 1 month later: denied side effects or adverse reactions to liraglutide|26640  
follow-up 1 month later: lost 2 lb|26640  
follow-up 1 month later: reported checking blood glucose more often on liraglutide|26640  
follow-up 1 month later: having lower readings than on insulin alone|26640  
3 months after starting liraglutide: Insulin aspart 70/30 mix 35 units twice daily|28080  
3 months after starting liraglutide: Liraglutide 1.8 mg daily|28080  
3 months after starting liraglutide: A1C improved to 7.6%|28080  
3 months after starting liraglutide: admitted to some asymptomatic low readings|28080  
3 months after starting liraglutide: 34 hypoglycemic readings (<70 mg/dL)|28080  
3 months after starting liraglutide: some readings as low as 19 mg/dL|28080  
3 months after starting liraglutide: none required hospitalization|28080  
3 months after starting liraglutide: >95% of hypoglycemic readings were >50 mg/dL|28080  
3 months after starting liraglutide: treated hypoglycemia with three 5 mg glucose tablets|28080  
3 months after starting liraglutide: treated hypoglycemia with 4 oz fruit juice or nondiet soda|28080  
3 months after starting liraglutide: treated hypoglycemia with 8 oz skim milk|28080  
3 months after starting liraglutide: insulin dose decreased to 30 units twice daily|28080  
follow-up 2 months later: average glucose readings 133 mg/dL|29520  
follow-up 2 months later: lost 20 lb|29520  
follow-up 2 months later: BMI decreased by 3 kg/m2|29520  
6 months after starting liraglutide: Insulin aspart 70/30 mix 30 units twice daily|30240  
6 months after starting liraglutide: Liraglutide 1.8 mg daily|30240  
6 months after starting liraglutide: A1C 7.7%|30240  
6 months after starting liraglutide: none of her other diabetes medications were adjusted during this period|30240  
6 months after starting liraglutide: did not use over-the-counter medicines or dietary supplements|30240