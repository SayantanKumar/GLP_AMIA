62-year-old man|0  
body mass index: 18.5 kg/m2|0  
type 2 diabetes|0  
on vildagliptin (100 mg/day)|0  
referred to hospital for treatment of dilated cardiomyopathy with LVAD|0  
has left ventricular assist device (LVAD)|0  
good glycemic control (HbA1c 7.4%)|0  
no family history of diabetes|0  
no past medical history including collagenous diseases|0  
no history of Helicobacter pylori infection|0  
informed consent obtained|0  
after approximately 1 year transferred to hospital for cerebral hemorrhage|8760  
craniotomy performed to remove hematoma|8760  
left-side hemiparesis remained|8760  
administration of glargine (6 units)|8760  
administration of insulin aspart (6–6–4 units)|8760  
poor glycemic control (fasting plasma glucose ~120 mg/dL)|8760  
poor glycemic control (postprandial plasma glucose 180–230 mg/dL)|8760  
developed skin reaction: redness at injection site|8760  
developed skin reaction: itching at injection site|8760  
developed skin reaction: swelling at injection site|8760  
initiation of insulin aspart 30 mix (20–0–10 units)|8760  
initiation of insulin degludec (12–0–4 units)|8760  
skin reaction triggered by insulin aspart mix|8760  
skin reaction triggered by insulin degludec|8760  
suspected insulin allergy|8760  
anti-insulin antibodies detected (>50 U/mL)|8760  
anti-insulin-specific immunoglobulin E detected (27 UA/mL)|8760  
anti-insulin receptor antibodies detected (25.2%)|8760  
hyperinsulinemia detected: fasting plasma glucose 160 mg/dL|8760  
hyperinsulinemia detected: C-peptide 7.22 ng/mL|8760  
hyperinsulinemia detected: immunoreactive insulin 1150 μU/mL|8760  
diagnosed with type B insulin resistance syndrome|8760  
diagnosed with insulin allergy|8760  
acanthosis nigricans not found|8760  
no renal impairment|8760  
glutamic acid decarboxylase antibody negative|8760  
low complement level: serum C4 7 mg/dL|8760  
low complement level: CH50 27 U/mL|8760  
Scatchard analysis: affinity constant K1 0.0109 × 10^8/M|8760  
Scatchard analysis: binding capacity R1 47.4 × 10^−8 M|8760  
urinary tract infection considered|8760  
switched from insulin administration to liraglutide treatment|8760  
liraglutide initiated at 0.3 mg/day|8760  
liraglutide dose increased by 0.3 mg/day each week until 0.9 mg/day|8760  
no other drugs aside from liraglutide|8760  
improved glycemic control after liraglutide (fasting 90–110 mg/dL)|8760  
improved glycemic control after liraglutide (postprandial <160 mg/dL)|8760  
no allergic skin reactions during liraglutide treatment|8760  
no liraglutide-related side effects|8760  
no hypoglycemic event during liraglutide treatment|8760  
one month after initiation of liraglutide: fasting plasma glucose 101 mg/dL|9480  
one month after initiation of liraglutide: C-peptide 4.1 ng/mL|9480  
one month after initiation of liraglutide: immunoreactive insulin 732 μU/mL|9480  
one month after initiation of liraglutide: anti-insulin antibody level unchanged (>50 U/mL)|9480  
one month after initiation of liraglutide: anti-insulin receptor antibody level reduced (17.9%)|9480  
about 2 years after liraglutide initiation: fasting plasma glucose 100 mg/dL|26280  
about 2 years after liraglutide initiation: HbA1c 6.4%|26280  