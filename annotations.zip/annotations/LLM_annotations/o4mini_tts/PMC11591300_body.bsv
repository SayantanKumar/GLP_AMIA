weight 50 kg in her twenties| -245280  
gained weight after childbirth, reaching 80 kg| -245280  
developed hypothyroidism following radiotherapy for hyperthyroidism| -8760  
began thyroid hormone supplementation| -8760  
weight increased further, exceeding 100 kg| -1824  
experienced edema and additional weight gain leading to diagnosis of severe hypercapnic respiratory failure and hospitalization| -744  
edema did not improve| -24  
dyspnea developed| -24  
treated with NPPV at local hospital| -24  
treated with diuretics at local hospital| -24  
ventilatory failure worsened| -24  
admitted to our hospital| 0  
height 149 cm| 0  
weight 109 kg| 0  
BMI 49.0 kg/m2| 0  
blood pressure 108/69 mmHg| 0  
pulse rate 83 beats/min| 0  
SpO2 40–60% in room air| 0  
body temperature 38.0 °C| 0  
decreased bilateral breath sounds on auscultation| 0  
systemic edema| 0  
D-dimer level 5.1 μg/mL| 0  
brain natriuretic peptide level 108 pg/mL| 0  
arterial PaO2 31 mmHg| 0  
arterial PaCO2 75 mmHg| 0  
chest radiography overall decrease in permeability| 0  
echocardiography slightly decreased ejection fraction| 0  
echocardiography no pulmonary hypertension| 0  
chest CT bilateral lung congestion| 0  
chest CT no features of other lung diseases or remarkable cardiac enlargement| 0  
suspected obesity-hypoventilation syndrome with congestive heart failure triggered by upper airway infection| 0  
intubation| 0  
mechanical ventilation initiated| 0  
treated for right heart failure with diuretics| 0  
extubation| 96  
PaCO2 retention resolved| 96  
NPPV with IPAP/EPAP 14/7 all day started| 96  
switched to NPPV IPAP/EPAP 14/7 at night and oxygen therapy 3 L/min during day| 216  
pulmonary function test showing VC 1.59 L (58.6%) and FEV1 1.46 L (68.5%) indicating restricted ventilation failure| 504  
discharged with NPPV (IPAP/EPAP 12/7) at night and home oxygen therapy (2 L/min at rest; 3 L/min during sleep)| 504  
continued weight loss under guidance of Endocrinology and Metabolism| 504  
approximately 4 years after discharge weight had not dropped below 90 kg| 35544  
glucagon-like peptide 1 receptor agonist administered| 35544  
weight loss >30 kg achieved| 44304  
readmission for evaluation of NPPV and oxygen therapy withdrawal| 44304  
chest radiography and CT no findings of heart failure or lung abnormalities| 44304  
respiratory function test showing improvement in VC to 1.96 L (79.0%)| 44304  
arterial blood gas analysis on room air showing improved hypoxia and hypercarbia, A-aDO2 elevated| 44304  
evaluation under NPPV settings| 44304  
Setting 1: SpO2 acceptable; prolonged PtcCO2 duration| 44304  
Settings 2–4: SpO2 acceptable; PtcCO2 duration did not decrease| 44304  
Setting 4: difficulty falling asleep, nocturnal awakenings, prolonged PtcCO2 exposure| 44304  
Setting 5: PtcCO2 ≥55 mmHg <10 min, SpO2 acceptable but PtcCO2 ≥50 mmHg too long to shift to CPAP| 44304  
weaned off oxygen therapy| 44304  
discharged with NPPV (IPAP/EPAP 14/7) after second admission| 44328  
no worsening of respiratory condition on NPPV and planned to lose more weight| 44328