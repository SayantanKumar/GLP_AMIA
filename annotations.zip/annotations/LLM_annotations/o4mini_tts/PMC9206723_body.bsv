39 years old|0
female|0
Moroccan|0
presented to the emergency department|0
polyuria|0
polydipsia|0
weight 46 kg|0
BMI 24 kg/m²|0
blood glucose 340 mg/dL|0
HbA1c 12.4%|0
no ketosis|0
aunt had type 2 diabetes|0
parents no diabetes|0
siblings no diabetes|0
TSH 0.01 mU/L|0
AST 114 UI/L|0
ALT 117 UI/L|0
GGT 445 UI/L|0
ALP 420 UI/L|0
elevated FT3 8.8 pg/mL|0
elevated FT4 33 pg/mL|0
TRAb positive|0
anti-TPO positive|0
thyroid ultrasound heterogeneous hypervascular parenchyma|0
started carbimazole 60 mg/day|0
started propranolol 20 mg 3×/day|0
abdominal ultrasound normal|0
viral hepatitis ruled out|0
autoimmune hepatitis ruled out|0
Wilson’s disease ruled out|0
hemochromatosis ruled out|0
coeliac disease ruled out|0
liver elastography A0F0|0
biochemical liver abnormalities attributed to hyperthyroidism or seronegative autoimmune hepatitis|0
diagnosed type 1 diabetes|0
started basal-bolus insulin therapy|0
no microvascular complications|0
gastric ulcer disease|-720
four miscarriages|-720
daughter born prematurely|-720
daughter vesicoureteral reflux|-720
8-kg weight loss|-504
usual weight 54 kg|-504
weight regained|720
HbA1c decreased to 5.7%|4320
hypoglycemic episodes once daily grade 2|4320
insulin doses decreased to half|4320
antiglutamate decarboxylase antibodies negative|4320
anti-islet antigen 2 antibodies negative|4320
diagnosis of type 1 diabetes in doubt|12960
antiglutamate decarboxylase D antibody negative|12960
anti-islet antigen 2 antibody negative|12960
anti–Zinc transporter 8 antibody negative|12960
HLA DRB1*15-DQB1*0602 protective haplotype present|12960
diagnosed type 2 diabetes|12960
weaned off insulin|12960
started sulfonylurea|12960
hyperglycemia predominantly postprandial|12960
thyroid hormones normal|12960
TRAb negative|12960
stopped carbimazole|12960
diabetes well controlled (HbA1c 6.7–7.9%)|12960
frequent hypoglycemia 5/week mainly grade 2 with 1 grade 3|12960
autoimmune hepatitis ruled out|78840
coeliac disease ruled out|78840
biliary MRI unremarkable|78840
4-mm hemorrhagic cyst left kidney|78840
liver biopsy normal|78840
started ursodeoxycholic acid|78840
resumed insulin glargine|87600
HbA1c reached 12.4%|87600
HbA1c decreased to 7.7%|91920
HNF1B-MODY hypothesis raised|91920
hypomagnesemia 0.62 mmol/L|91920
HNF1B genetic testing performed|94080
genetic testing confirmed complete heterozygous deletion of HNF1B gene|94080
diagnosed HNF1B-MODY|94080
HbA1c 9.2%|115410
glargine 14 units|115410
glimepiride 4 mg|115410
dietary errors|115410
serum creatinine 54 µmol/L|115410
microalbuminuria physiological range|115410
renal ultrasound normal morphology|115410
test meal performed|115410
C peptide fasting 0.181 nmol/L|115410
C peptide 2 h 0.654 nmol/L|115410
fecal chymotrypsin normal|115410
fecal elastase normal|115410
pancreatic MRI unremarkable|115410
pelvic ultrasonography normal|115410
LFTs persistent cholestasis and cytolysis|115410
started liraglutide|115410
started repaglinide 4-1-2 mg|115410
weight 52 kg|115410
HbA1c 6.7%|116130
recurrent hypoglycemia|116130
repaglinide dose decreased|116130
HbA1c 6.6%|120450
liraglutide 1.2 mg|120450
repaglinide 1-0-1 mg|120450
weight 45 kg|120450