health check-up | -96  
dynamic contrast-enhanced CT scan of the lower abdomen | -96  
mass in the right adrenal gland | -96  
nodular low-density shadow with clear boundaries (37 mm) | -96  
no significant enhancement | -96  
possibility of a cyst | -96  
no abnormal density in left adrenal gland | -96  
35 years old | 0  
Han Chinese | 0  
male | 0  
admitted to the Department of Urology | 0  
admitted to the hospital with adrenal gland mass for surgical treatment | 0  
denied dizziness | 0  
denied fatigue | 0  
denied nausea | 0  
denied vomiting | 0  
denied blurred vision | 0  
denied general weakness | 0  
denied profuse sweating | 0  
good general condition | 0  
did not smoke | 0  
did not drink | 0  
denied any history of taking medications | 0  
blood pressure 132/85 mmHg | 0  
height 178 cm | 0  
weight 94 kg | 0  
BMI 29.7 kg/m2 | 0  
no thyroid enlargement | 0  
no cardiopulmonary signs | 0  
no abdominal signs | 0  
normal tendon reflexes | 0  
normal bowel sounds | 0  
ECG sinus rhythm | 0  
serum potassium 2.7 mmol/L | 0  
serum magnesium 0.58 mmol/L | 0  
serum chloride 94 mmol/L | 0  
potassium chloride 2000 mg tid initiated | 1  
transfer to Endocrinology Department | 2  
blood gas pH 7.44 | 2  
PCO2 41.2 mmHg | 2  
actual base excess 3.5 mmol/L | 2  
serum potassium 2.8 mmol/L | 2  
serum magnesium 0.58 mmol/L | 2  
serum chloride 96 mmol/L | 2  
ionized calcium 1.07 mmol/L | 2  
aldosterone 131.4 pg/ml | 2  
renin 8.99 ng/mL/hr | 2  
24-hour urine output 2900 mL | 2  
urine potassium 32.84 mmol/24 h | 2  
urine potassium 3.81 g/24 h | 2  
urine calcium 0.016 g/24 h | 2  
urine creatinine 1.84 g/24 h | 2  
urine phosphorus 0.59 g/24 h | 2  
fractional excretion of potassium 14.79% | 2  
urinary microalbumin/creatinine 38.75 mg/g | 2  
urinary microalbumin 34.6 mg/L | 2  
HbA1c 6.8% | 2  
anti-human insulin antibody 18.06 IU/mL | 2  
glutamic acid decarboxylase antibody 1 IU/mL | 2  
C-peptide 3.68 ng/mL | 2  
INS 16.58 uIU/mL | 2  
GS diagnosis | 96  
genetic testing on SLC12A3 gene | 96  
homozygous c.1456G>A p.(Asp486Asn) variant | 96  
right adrenal mass resection | 552  
postoperative pathology consistent with adrenal cyst | 552  
potassium chloride 500 mg bid initiated | 552  
magnesium chloride 1000 mg bid initiated | 552  
spironolactone 20 mg bid initiated | 552  
serum potassium maintained 3.63–3.71 mmol/L | 552  
serum magnesium maintained 0.46–0.6 mmol/L | 552  
spironolactone discontinued | 1464  
gynecomastia | 1464  
potassium chloride 2000 mg tid re-initiated | 1464  
magnesium chloride 1000 mg bid re-initiated | 1464  
serum potassium <3 mmol/L in repeated tests | 1464  
increased nocturia | 1464  
finerenone 10 mg bid initiated | 34752  
potassium chloride 1500 mg bid dose reduced | 34752  
magnesium chloride 1000 mg bid dose reduced | 34752  
blood potassium increased to 3.48–3.8 mmol/L | 34752  
blood magnesium maintained 0.47–0.7 mmol/L | 34752  
no obvious adverse reactions | 34752  
Semaglutide 1.0 mg qw initiated | 34752  
dapagliflozin 1 tablet qd initiated | 34752  
blood glucose levels well-controlled | 34752