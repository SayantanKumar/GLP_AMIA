presented for care of T1DM | 0  
40-year-old Caucasian female | 0  
denies other past medical history | 0  
nonspecific rash to sulfonamide antibiotic | 0  
not on any medications besides insulin | 0  
maternal grandmother with type-2 diabetes mellitus | 0  
no known dermatologic conditions | 0  
no known rheumatologic conditions | 0  
diagnosed with type-1 diabetes mellitus at age 37 | -26280  
presentation of diabetic ketoacidosis | -26280  
hemoglobin A1c of 9.3% | -26280  
C-peptide 0.8 ng/mL | -26280  
Glutamic Acid Decarboxylase antibodies positive at 10.4 U/mL | -26280  
body mass index of 28 kg/m2 | -26280  
initial treatment with multiple daily injections of insulin glargine | -26280  
initial treatment with multiple daily injections of insulin aspart | -26280  
switched to pod insulin pump therapy | -21960  
hemoglobin A1c range of 5.7% to 7.4% | -21960  
skin reactions at the pod insertion site | -4380  
pruritic erythema | -4380  
painful erythema | -4380  
wheals | -4380  
induration | -4380  
subcutaneous nodules | -4380  
surrounding lipodystrophy | -4380  
spontaneous resolution of skin reaction | -4272  
barrier adhesives | -4380  
topical antihistamines | -4380  
oral antihistamines | -4380  
topical glucocorticoids | -4380  
barrier adhesives ineffective | -4380  
topical antihistamines ineffective | -4380  
oral antihistamines ineffective | -4380  
topical glucocorticoids ineffective | -4380  
treated with insulin aspart | -4380  
treated with insulin lispro | -4380  
treated with insulin regular | -4380  
treated with insulin glulisine | -4380  
similar skin reactions | -4380  
using syringe injectors | -4380  
using pen injectors | -4380  
inhaled human insulin | -4380  
discontinued inhaled human insulin due to cough | -4380  
hemoglobin A1c range of 5.9% to 6.8% | -4380  
patient motivated and able to self-titrate insulin | -4380  
used a Do-It-Yourself automated insulin delivery system | -4380  
referred to a drug allergy clinic | 0  
positive immediate intradermal insulin lispro test | 0  
negative metacresol skin test | 0  
serum human insulin-specific IgG antibody testing positive at 156 mg/L | 0  
serum IgE antibody testing negative at <0.1 U/mL | 0  
skin punch biopsy revealing sublobular panniculitis | 0  
empirical treatment with metformin | 0  
empirical treatment with dapagliflozin | 0  
empirical treatment with liraglutide | 0  
minimal improvement in skin reaction | 0  
insulin requirement decreased from 60 units/d to 50 units/d | 0  
lost 12 pounds | 0  
hemoglobin A1c range of 5.8% to 6.8% | 0  
considered investigational approach with rituximab | 0  
treated with first round of rituximab infusion at 375 mg/m2 weekly for 4 weeks | 0  
premedicated with diphenhydramine | 0  
premedicated with acetaminophen | 0  
monitored during and after rituximab infusion | 0  
tolerated rituximab treatment well | 0  
skin reactions improved significantly | 696  
repeat serum human insulin-specific antibody testing | 840  
lower level of IgG at 122 mg/L | 840  
undetectable IgE antibodies | 840  
injection site reactions recurred | 12984  
deeper punch biopsy revealing sublobular panniculitis | 12984  
treated with second round of rituximab infusion | 12984  
drastic improvement of skin reactions | 13656  
no recurrent skin reactions up to 4 years afterward | 48024