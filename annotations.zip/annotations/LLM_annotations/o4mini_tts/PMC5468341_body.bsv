Non-alcoholic fatty liver disease|0  
Obesity|0  
Insulin resistance|0  
Liver accumulation of triglycerides|0  
Liver accumulation of free fatty acids|0  
Increased risk of liver-related mortality|0  
Increased risk of cardiovascular mortality|0  
NAFLD rapidly becoming leading indication for liver transplantation|0  
No effective treatment yet|0  
Non-alcoholic fatty liver (steatosis > 5% of parenchyma)|0  
Non-alcoholic steatohepatitis (necroinflammatory process)|0  
Risk of progression to cirrhosis|0  
Risk of progression to hepatocellular carcinoma|0  
NAFLD incidence 20%-30% in Western countries|0  
NAFLD incidence 5%-18% in Asia|0  
Prevalence of NAFLD increasing yearly|0  
Incidence of NAFLD 10% higher in overweight versus lean individuals|0  
NAFLD projected to become a major cause of liver morbidity and mortality and leading indication for transplant within next 20 years|175200  
NAFLD is the second most common reason for liver transplant listing|0  
34%-69% chance of dying over the next 15 years|131400  
Liver-related mortality accounts for 5% in NAFLD patients|0  
Liver fat content 80% higher in type 2 diabetes mellitus patients compared to non-diabetics|0  
T2DM patients have two-to-four-fold increased risk of fatty liver complications|0  
Highest rate of NAFLD development in Hispanic patients|0  
Increasing NAFLD prevalence in Asian individuals including those with normal BMI|0  
Hispanic population has higher occurrence of steatohepatitis and cirrhosis|0  
African American population has decreased chance of developing liver failure|0  
PNPLA3 rs738409 mutation associated with increased hepatic fat content and inflammation|0  
NAFLD more common in men and in younger to middle aged individuals|0  
Prevalence of NAFLD increases with age to >40% in those older than 60 years|0  
Approximately one-third of obese children have NAFLD|0  
Fatty liver is the most common liver abnormality in children aged 2-19 years|0  
Incidence of hepatocellular carcinoma in NASH cirrhosis 2.4% at 3.2 years|28032  
Incidence of hepatocellular carcinoma in NASH cirrhosis 12.8% at 7.2 years|63072  
Portal hypertension complications in cirrhosis: 17% at 1 year|8760  
Portal hypertension complications: 23% at 3 years|26280  
Portal hypertension complications: 52% at 10 years|87600  
Median survival of 2 years after decompensation in NASH cirrhosis|17520