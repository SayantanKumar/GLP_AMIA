birth by cesarean section at 40 weeks | -157788  
typical hypotonia | -153405  
poor oral intake | -153405  
rapid weight gain during childhood | -113958  
intellectual disability during childhood | -113958  
diagnosis of Prader-Willi syndrome | -35064  
paternal deletion identified through methylation test and fluorescence in situ hybridization | -35064  
growth hormone therapy could not be applied due to advanced bone age | -35064  
intelligence quotient measured as 30 | -35064  
type 2 diabetes mellitus diagnosed | -17532  
hypertension diagnosed | -17532  
metformin started | -17532  
amlodipine started | -17532  
reduced physical activity | -336  
ampicillin/sulbactam administered | -168  
calorie intake restricted to 800 kcal/day | -168  
presented with dyspnea | 0  
diffuse cellulitis in the abdomen | 0  
diffuse cellulitis in both legs | 0  
height 143 cm | 0  
weight 145 kg | 0  
BMI 71 kg/m2 | 0  
blood pressure 190/100 mmHg | 0  
heart rate 115 beats/min | 0  
respiratory rate 24 breaths/min | 0  
body temperature 36℃ | 0  
unable to walk unaided | 0  
unable to sit unaided | 0  
joint pain noted | 0  
high flow nasal cannula oxygen supply started | 0  
daily calorie intake approximately 1,600 kcal/day | 0  
weight increased to 164 kg | 336  
dyspnea aggravated | 336  
start intensive care unit care | 336  
mechanical ventilation (pressure-control ventilation) | 336  
calorie intake restricted to 200 kcal/day | 336  
furosemide 40 mg every 8 hours started | 336  
fluid restriction 1,000 mL/day started | 336  
close monitoring of electrolytes | 336  
extubation | 816  
pituitary function test performed | 816  
hypopituitarism revealed | 816  
growth hormone administered 1.33 IU/day | 840  
estrogen administered 0.125 mg/day | 840  
GLP-1 receptor agonist (liraglutide) added | 840  
serum glycosylated hemoglobin 7.3% observed | 840  
GLP-1 agonist dosage initiated at 0.6 mg/day | 840  
physical therapy implemented | 840  
GLP-1 agonist dosage increased to 1.2 mg/day | 1008  
able to walk independently | 2160  
weight decreased to 104 kg | 2160  
BMI decreased to 50.8 kg/m2 | 2160  
serum glycosylated hemoglobin reduced to 4.8% | 2160  
discharge | 2160  
BMI maintained at 48.5 kg/m2 at 1 year | 8760  
diet of 1,000 kcal/day (100 g carbs, 48 g proteins, 42 g fat) | 8760  
regular mealtimes maintained | 8760  
continued to exercise daily for 1 hour | 8760  
waist circumference reduction 7 cm | 8760  
weight loss 62.7 kg | 8760  
BMI reduction 31.7 kg/m2 | 8760