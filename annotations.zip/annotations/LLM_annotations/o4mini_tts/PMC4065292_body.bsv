59 years old|0  
female|0  
admitted to the hospital for obesity and glucose management|0  
body weight 153 kg|0  
BMI 62.7 kg/m2|0  
HbA1c 8.8%|0  
hormonal examinations revealed unlikely to have Cushing’s disease|0  
hormonal examinations revealed unlikely to have hypothyroidism|0  
15 weeks in hospital|0  
dietary intake of 1200 kcal per day|0  
began experiencing weight gain|–96360  
retired from work because of a disc herniation|–8760  
decreased physical activity|–8760  
gained additional weight|–8760  
weight reduced to 131.2 kg|2520  
BMI 53.9 kg/m2|2520  
HbA1c decreased to 6.5%|2520  
discharged|2520  
regained weight to 163.0 kg|26280  
HbA1c increased to 9.3%|26280  
repeatedly gained and lost weight|27540  
required ongoing weight management support|27540  
weight 144.1 kg|52560  
BMI 59.1 kg/m2|52560  
required a total dosage of 36 units of insulin by injection|52560  
glycemic control was poor (HbA1c 10.5%)|52560  
gradually reduced weight to 121 kg|53100  
BMI 49.6 kg/m2|53100  
insulin dosage decreased to 28 units|53100  
body weight 114 kg|53500  
BMI 46.7 kg/m2|53500  
maintained HbA1c 6.6% without medication|53500  
use of mazindol|54000  
very low calorie diet (800 kcal/day)|54000  
counseling by a psychotherapist|54000  
exercise therapy restricted to upper part of the body|54000  
renal dysfunction (eGFR 21.8 mL/min·1.73 m2)|54000  
gastric surgery considered but not performed|54000  
weight reduction to 112.1 kg|61320  
BMI 45.9 kg/m2|61320  
CGMS measurement (March 2011)|61320  
caloric intake maintained at 1600 kcal per day|61320  
resting metabolic rate measured|61320  
HOMA-IR calculated|61320  
HOMA-β calculated|61320  
QUICKI calculated|61320  
regained weight to 133.8 kg|75913  
BMI 54.8 kg/m2|75913  
HbA1c 8.2%|75913  
CGMS measurement (August 2012)|75913  
blood samples drawn for active GLP-1 measurement (Aug 2012)|75913  
blood samples drawn for total GIP measurement (Aug 2012)|75913  
exenatide therapy commenced (5 µg twice a day)|75913  
experienced nausea|75913  
experienced appetite loss|75913  
CGMS measurement (August 2013)|81030  
weight 96.3 kg|81030  
BMI 39.5 kg/m2|81030  
HbA1c 5.1%|81030  
RMR 1618 kcal/day|81030  
HOMA-IR 1.29|81030  
HOMA-β 57.2%|81030  
QUICKI 0.195|81030  
washout period (5 days without exenatide) commenced|80910  
blood samples drawn for active GLP-1 measurement (Aug 2013)|81030  
blood samples drawn for total GIP measurement (Aug 2013)|81030  
improved glycemic control|81030  
decreased glucagon levels observed|81030  
decreased active GLP-1 levels observed|81030  
decreased total GIP levels observed|81030  