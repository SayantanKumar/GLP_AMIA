vaginal bleeding | -4320  
55-year-old | 0  
nulliparous | 0  
uterine fibroids | 0  
hypertension | 0  
insulin resistance | 0  
presented to a specialist Gynae-oncology clinic | 0  
BMI of 80 kg/m2 | 0  
weight 230 kg | 0  
height 170 cm | 0  
trans-vaginal pelvic ultrasound | 0  
endometrial thickness of 44 mm | 0  
hysteroscopy | 0  
endometrial biopsy | 0  
levonorgestrel IUD insertion | 0  
atypical endometrial hyperplasia | 0  
delayed total hysterectomy and BSO via MIS | 0  
target weight of 160 kg (BMI 55 kg/m2) | 0  
declined bariatric surgery | 0  
initial weight loss with dietician and exercise programs | 0  
weight plateaued at 195 kg (BMI 68 kg/m2) | 4320  
repeat endometrial biopsy | 8640  
progression to grade 1 EAC | 8640  
CT scan of chest, abdomen and pelvis | 8640  
no metastatic disease | 8640  
medroxyprogesterone 100 mg oral twice daily commenced | 8640  
addition of Liraglutide and Metformin | 8640  
weight decreased to 180 kg | 17280  
continued to decline bariatric surgery | 17280  
repeat curettage | 17280  
regression to atypical endometrial hyperplasia | 17280  
medroxyprogesterone increased to 200 mg oral twice daily | 17280  
further weight loss recommended | 17280  
blood-stained fluid discharge from umbilicus | 21600  
CT scan of abdomen and pelvis | 21600  
umbilical soft tissue mass 32×33×39 mm suspicious for a metastasis | 21600  
core biopsy of umbilical lesion | 21600  
FIGO grade 1 EAC | 21600  
ER and PR strongly positive | 21600  
loss of MLH1 and PMS2 | 21600  
PET scan | 21600  
increased uptake in uterus, umbilicus, left parametrial lymph node and right inguinal node suspicious for metastatic disease | 21600  
CA-125 raised at 420 U/mL | 21600  
diagnostic laparoscopy | 21600  
no widespread peritoneal disease | 21600  
letrozole commenced | 21600  
disease progression | 23760  
changed to Carboplatin-Paclitaxel combination chemotherapy | 23760  
checkpoint inhibitor considered but not affordable | 23760  
after 3 cycles of neoadjuvant chemotherapy CA-125 reduced to 50 U/mL | 25272  
weight 157 kg | 25272  
repeat CT scan | 25272  
increase in umbilical soft tissue mass to 72×70×100 mm | 25272  
pulmonary embolism found | 25272  
treated with Apixaban for 12 weeks | 25272  
cyto-reductive surgery performed | 25920  
robotic total hysterectomy | 25920  
BSO | 25920  
right inguinal lymph node resection | 25920  
umbilical mass resection | 25920  
primary abdominal wall closure | 25920  
all tumor removed except a 1 cm deep nodule in the left pararectal peritoneum deemed unresectable | 25920  
infected abdominal wall seroma (Clavien Dindo grade 2 adverse event) | 25920  
seroma drainage | 25920  
systemic antibiotics | 25920  
oral antibiotics | 25920  
final histopathological assessment of surgical specimens | 25920  
final surgical stage IVB | 25920  
further 3 cycles of Carboplatin-Paclitaxel chemotherapy (total of 6 cycles) commenced | 25920  
external beam radiation to the right inguinal region | 25920  
germline testing negative for Lynch syndrome | 25920  
routine CT scan chest, abdomen and pelvis | 28080  
progressive disease in the peritoneum and retroperitoneal lymph nodes | 28080  
referred for consideration of a clinical trial with an immune check-point inhibitor | 28080  
alive | 31680