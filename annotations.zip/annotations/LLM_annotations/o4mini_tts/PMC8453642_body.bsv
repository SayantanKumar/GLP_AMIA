Hashimoto’s disease|-4380  
chronic urticaria|-4380  
mast cell activation disorder|-4380  
hypertension|-4380  
diabetes mellitus type 2|-4380  
metformin 1000 mg orally twice daily|-4380  
liraglutide 1.8 mg daily|-4380  
multiple chemical sensitivities including 76 food allergies, medication sensitivities, reactions to food dyes and additives|-4380  
multiple bilateral nodules previously biopsied and found benign|-4380  
tried and failed generic L-T4|-720  
discontinued metformin|-504  
presented to the clinic|0  
complaining of recurrent hives|0  
complaining of skin dryness|0  
complaining of fatigue|0  
complaining of weight gain|0  
complaining of intermittent constipation|0  
complaining of diarrhea|0  
complaining of cold intolerance|0  
complaining of brain fog|0  
complaining of difficulty with word finding|0  
complaining of swelling in lower extremities|0  
complaining of daytime somnolence|0  
temperature 36.6°C|0  
pulse 92 beats per minute|0  
blood pressure 136/88 mmHg|0  
respiratory rate 18 respirations per minute|0  
O2 saturation 98%|0  
height 1.57 m|0  
weight 92 kg|0  
body mass index 37.3 kg/m2|0  
in no acute distress|0  
no palpable thyroid nodules|0  
no visible urticaria|0  
hypoactive bowel sounds|0  
minimal tenderness to palpation in left lower quadrant|0  
family history of papillary thyroid cancer in a sister|0  
TSH 5.30 mIU/L|0  
free T4 16.60 pmol/L|0  
free T3 not evaluated|0  
treated with L-T4 sodium tablets (Synthroid®) 125 µg daily|0  
transitioned to compounded T4/T3 prescription without additives|1008  
TSH 4.65 mIU/L|1008  
free T4 16.60 pmol/L|1008  
free T3 4.47 pmol/L|1008  
T4/T3 compound at escalated dosing|2016  
TSH 6.50 mIU/L|2016  
free T4 18.53 pmol/L|2016  
free T3 5.24 pmol/L|2016  
T4/T3 compound at escalated dosing (second escalation)|3024  
TSH 2.60 mIU/L|3024  
free T4 24.07 pmol/L|3024  
free T3 4.93 pmol/L|3024  
started with worsening GI issues|4032  
projectile vomiting with undigested food and pill capsules|4032  
weight loss|4032  
10–20 bowel movements daily|4032  
TSH 7.42 mIU/L|4032  
free T4 19.82 pmol/L|4032  
free T3 5.24 pmol/L|4032  
metformin discontinued|4032  
liraglutide discontinued|4032  
upper endoscopy revealed gastritis|4032  
upper endoscopy revealed hiatal hernia|4032  
gastric emptying examination demonstrated 20% gastric retention at 4 hours|4032  
diagnosed with gastroparesis|4032  
placed on high-dose probiotics|4032  
placed on dicyclomine hydrochloride (Bentyl®)|4032  
initiated on gastroparesis diet|4032  
switched to L-T4 oral solution 150 µg|4032  
medication well tolerated|4032  
no side effects or reaction to the medication|4032  
treated with one cycle of rifaximin (Xifaxan®) for SIBO|5040  
diagnosed with SIBO|5040  
TSH 1.55 mIU/L|5040  
free T4 27.93 pmol/L|5040  
free T3 4.93 pmol/L|5040  
L-T4 oral solution down-titrated to 112 µg|6048  
resolution of thyroid symptoms|6048  
TSH control successfully sustained six weeks after down-titration|7056