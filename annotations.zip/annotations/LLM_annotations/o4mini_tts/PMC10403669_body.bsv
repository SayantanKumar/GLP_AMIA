53 years old|0  
White male|0  
presented for evaluation of nephrotic range proteinuria|0  
hypertension|0  
former tobacco use|0  
morbid obesity|0  
type 2 diabetes|0  
cystinuria|0  
nephrolithiasis requiring lithotripsy|0  
tiopronin initiation| -5040  
potassium citrate|0  
semaglutide|0  
amlodipine|0  
telmisartan|0  
chlorthalidone|0  
blood pressure 128/92 mm Hg|0  
BMI of 41.5 kg/m2|0  
no peripheral edema|0  
serum creatinine 1.1 mg/dl|0  
eGFR of 80 ml/min per 1.73 m2|0  
urinalysis 3+ protein|0  
urinalysis negative blood|0  
no leukocyturia|0  
24-hour urine protein of 4.6 g|0  
serum albumin 4.5 g/dl|0  
normal serum complement levels|0  
ANA negative|0  
dsDNA antibody negative|0  
hepatitis B surface antigen negative|0  
hepatitis C antibody negative|0  
MPO-ANCA negative|0  
PR3-ANCA negative|0  
anti-PLA2R antibody negative|0  
anti-GBM antibody negative|0  
HIV negative|0  
no M-spike on SPEP|0  
no M-spike on UPEP|0  
normal renal function (7 months prior)| -5040  
absence of proteinuria (7 months prior)| -5040  
kidney biopsy performed|0  
light microscopy: 23 glomeruli none sclerotic|0  
light microscopy: glomeruli normal to mildly enlarged|0  
light microscopy: mesangial areas unremarkable|0  
light microscopy: glomerular capillary lumina patent|0  
GBM normal thickness and contour|0  
silver stain: some capillary loops finely vacuolated|0  
no GBM spikes or chain-like thickening|0  
mild tubular atrophy and interstitial fibrosis 10–15%|0  
no significant interstitial inflammation|0  
nonatrophic proximal tubules intact brush borders|0  
arteries and arterioles unremarkable|0  
immunofluorescence: 2-3+ granular to semilinear segmental IgG|0  
immunofluorescence: trace C3|0  
immunofluorescence: 2+ kappa|0  
immunofluorescence: 2+ lambda|0  
involving <50% glomerular capillary surface area|0  
electron microscopy: small segmental subepithelial electron dense deposits|0  
electron microscopy: no mesangial, subendothelial, extraglomerular deposits|0  
electron microscopy: no endothelial tubuloreticular inclusions|0  
electron microscopy: podocyte foot process effacement 30–40%|0  
PLA2R negative on immunofluorescence staining|0  
NELL-1 positive on immunohistochemical staining|0  
diagnosis: segmental MN, NELL-1 positive (tiopronin-associated)|0  
tiopronin discontinued|1  
dapagliflozin started|1  
denied use of lipoic acid supplements|1  
no occupational or environmental heavy metal exposure risk factors|1  
cancer screening CT chest/abdomen/pelvis performed|1  
CT chest/abdomen/pelvis negative|1  
screening colonoscopy performed|1  
colonoscopy negative|1  
PSA testing performed|1  
PSA negative|1  
immunosuppressive therapies deferred|1  
anti-NELL-1 antibody testing not performed|1  
serum creatinine 1.0 mg/dl (6 months later)|4320  
urine protein-to-creatinine ratio 2.08 g/g (6 months later)|4320  
serum albumin 4 g/dl (6 months later)|4320