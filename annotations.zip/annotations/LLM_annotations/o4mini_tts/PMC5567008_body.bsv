immigrated to the United States|-70080  
began menstruation|-68640  
45-pound weight gain|-65760  
fever|-65040  
perianal pain|-65040  
surgery for large perianal abscess|-65040  
multiple skin lesions consistent with HS|-65040  
acne|-65040  
periods became irregular|-65040  
widespread disease with up to 20 lesions|-65040  
intermittent perianal disease|-65040  
widespread abdominal scarring resulting in contracture of the entire body|-65040  
oral and intravenous antibiotics therapy|-60660  
numerous surgeries|-60660  
isotretinoin for acne treatment|-60660  
periodic metformin|-60660  
oral birth control usage|-60660  
menstrual periods caused severe flare-ups|-60660  
increased pain medication required|-60660  
sleep severely impaired|-60660  
previous perianal abscess required 6 months of dressings and care|-26280  
19 years old|0  
female|0  
presented for evaluation and treatment|0  
obesity|0  
hidradenitis suppurativa|0  
polycystic ovary syndrome|0  
fatty liver|0  
no family history of HS|0  
no family history of colitis|0  
no family history of other autoimmune disease|0  
maternal grandparents had late-onset diabetes|0  
physical examination confirmed HS encompassing most of the truncal area anteriorly from the inframammary area to the groin|0  
HS extending to the right axilla|0  
HS incorporating nearly 40% body surface area|0  
extensive muscle wasting of the extremities|0  
facial acne without scarring|0  
absence of hirsutism|0  
weight 215 pounds|0  
BMI 37|0  
class II obesity|0  
WBC count 34×10^3/µL|0  
hemoglobin 6.2 g/dL|0  
platelet count 783×10^3/µL|0  
sedimentation rate >120 mm/h|0  
glucose 130 mg/dL|0  
AST 55 U/L|0  
ALT 112 U/L|0  
albumin 3.2 g/dL|0  
HbA1c 5.7%|0  
aggressive lifestyle modification program initiated (low-carbohydrate diet)|0  
oral contraception restarted|0  
G6PD test negative|0  
placed on dapsone 100 mg/day|0  
monthly follow-ups with complete laboratory testing undertaken|0  
initial minimal improvements noted|720  
no improvement in first 3 months|2160  
new lesions appeared|2160  
finasteride 5 mg/day started|2160  
metformin 2000 mg/day started|2160  
liraglutide 0.6 mg daily started|2160  
hypoglycemia symptoms absent|2160  
40-pound weight loss started|2160  
liraglutide increased to 1.8 mg daily|3600  
liver enzymes declined|4380  
WBC count 32×10^3/µL|4380  
hemoglobin 8.3 g/dL|4380  
platelet count 535×10^3/µL|4380  
sedimentation rate >120 mm/h|4380  
glucose 105 mg/dL|4380  
AST 27 U/L|4380  
ALT 72 U/L|4380  
albumin 3.2 g/dL|4380  
HbA1c 5.2%|4380  
patient felt better|4380  
less intense and frequent flares|4380  
perianal abscess developed|6480  
hospitalization required|6480  
surgery for perianal abscess|6480  
perianal lesion healed completely in 3 weeks|6480  
patient elected to avoid extensive debridement|6480  
weight regaining started|6540  
WBC count 18.8×10^3/µL|8760  
hemoglobin 8.5 g/dL|8760  
platelet count 523×10^3/µL|8760  
sedimentation rate 109 mm/h|8760  
glucose 87 mg/dL|8760  
AST 19 U/L|8760  
ALT 57 U/L|8760  
albumin 4.0 g/dL|8760  
HbA1c 5.2%|8760  
liver enzymes resolved|8760  
WBC count 9.7×10^3/µL|17520  
hemoglobin 11.8 g/dL|17520  
platelet count 376×10^3/µL|17520  
sedimentation rate 74 mm/h|17520  
glucose 98 mg/dL|17520  
AST 26 U/L|17520  
ALT 34 U/L|17520  
albumin 3.8 g/dL|17520  
HbA1c 5.0%|17520  
leukocytosis returned to normal|17520  
anemia returned to normal|17520  
hypoalbuminemia returned to normal|17520  
blood testing reduced to every 3 months|17520  
WBC count 9.2×10^3/µL|26280  
hemoglobin 12.5 g/dL|26280  
platelet count 391×10^3/µL|26280  
sedimentation rate 34 mm/h|26280  
glucose 89 mg/dL|26280  
AST 24 U/L|26280  
ALT 31 U/L|26280  
albumin 4.1 g/dL|26280  
HbA1c 4.9%|26280  
average estimated blood sugar 94 mg/dL|26280  
no adjunctive antibiotics required in past year|26280  
pregnancy risk not a concern|26280  
completed 3 years of regimen|26280  
remarkable tolerance of regimen|26280  
no new lesions for 6 months|26280  
axillary lesions healed completely|26280  
groin disease improved 90%|26280  
thigh disease improved 90%|26280  
perianal disease improved 90%|26280  
thoraco-abdominal lesions improved 60%|26280  
4–5 small areas persisting in thoraco-abdominal region|26280  
facial acne improved but persisted|26280  
adverse effects asked for routinely|26280  
weight regain noted|26280  
no physical or biochemical abnormality detected|26280  
consented to having photographs of the right axilla|26280