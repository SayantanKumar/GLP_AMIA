51 years old|0
male|0
Gulf War veteran|0
diabetes mellitus type II|0
alcohol use disorder|0
chronic pancreatitis|0
presented to the emergency department|0
abdominal pain|-336
abdominal distension|-336
nausea|-336
intermittent chills|-336
took acetaminophen|-336
quit alcohol use|-78840
smoking history|0
denied recent travel|0
has 2 dogs at home|0
denied exposure to livestock|0
semaglutide use|0
omeprazole use|0
acetaminophen use|0
last colonoscopy|-35040
tachycardia (HR 134 bpm)|0
fever (100.4 F)|0
blood pressure 130/96 mm Hg|0
oxygen saturation 100% on room air|0
firm and distended abdomen|0
tenderness right upper quadrant|0
tenderness right lower quadrant|0
hepatomegaly|0
white blood cell count 13,360 cells/mm3 with neutrophilic predominance|0
thrombocytosis (529 platelets per μL)|0
hemoglobin 8.0 g/dL|0
alanine aminotransferase 73 IU/L|0
aspartate transaminase 171 IU/L|0
alkaline phosphatase 625 IU/L|0
total bilirubin 1.9 mg/dL|0
direct bilirubin 1.3 mg/dL|0
blood urea nitrogen 50 mg/dL|0
creatinine 1.2 mg/dL|0
lactic acid 5.2 mmol/L|0
initial CT scan: multiple liver masses|0
initial CT scan: partial splenic vein thrombosis|0
initial CT scan: portal vein thrombosis|0
CT scan 6 months prior: no liver pathology|-4320
MRI abdomen: no biliary obstruction|0
MRI abdomen: hepatomegaly|0
MRI abdomen: multiseptated cystic hepatic masses|0
MRI abdomen: portal vein thrombosis|0
MRI abdomen: largest cystic lesion 9.0 cm × 5.4 cm|0
started IV cefepime|0
started oral metronidazole|0
started therapeutic IV heparin|0
blood cultures obtained|0
blood cultures negative|0
fungal blood cultures negative|0
hepatitis A IgM negative|0
hepatitis B core antibody IgM negative|0
hepatitis B surface antigen negative|0
hepatitis C antibody negative|0
HIV antibody 1 and 2 negative|0
Entamoeba histolytica IgG negative|0
Echinococcus IgG antibody negative|0
CT-guided liver biopsy with aspiration|0
H&E stain: inflamed and degenerating liver parenchyma with fibrinopurulent inflammation|0
abscess aspirate cultures showed no growth|0
switched to IV ampicillin-sulbactam|24
started oral trimethoprim-sulfamethoxazole|24
no clinical improvement|24
16S PCR positive for Fusobacterium nucleatum|48
death due to cardiac arrest|72