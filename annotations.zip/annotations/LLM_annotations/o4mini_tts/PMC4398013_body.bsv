saw primary care physician | -8760  
progressive ataxia | -8760  
MRI of brain normal | -8760  
nerve conduction velocity study suggest axonal type sensorimotor neuropathy | -8760  
diagnosis of hereditary sensory neuropathy considered | -8760  
osmotic symptoms | -720  
emesis | -48  
presented to us | 0  
disoriented state | 0  
confused state | 0  
no history of diarrhea | 0  
no history of abdominal pain | 0  
no history of convulsions | 0  
no history of loss of consciousness | 0  
no relevant drug/substance abuse | 0  
no family history of diabetes in any first- or second-degree relatives | 0  
poor socioeconomic background | 0  
respiratory frequency 30 breaths/min | 0  
heart rate 120 bpm | 0  
blood pressure 110/60 mmHg | 0  
temperature 101°F | 0  
blood glucose 609 mg/dL | 0  
arterial blood gas pH 7.1 | 0  
serum bicarbonate 9.5 mEq/L | 0  
serum ketones 6 mmol/L | 0  
urinary ketones strongly positive | 0  
Q waves in infero-lateral leads | 0  
working diagnosis of DKA | 0  
treatment with intravenous fluids | 0  
treatment with insulin | 0  
treatment with potassium | 0  
treatment with antibiotics | 0  
A1C 10.5% | 0  
anti-GAD65 antibodies negative | 0  
anti-IA2 antibodies negative | 0  
resolution of DKA | 24  
difficulties with walking | 24  
difficulties with standing | 24  
slurring of speech | 24  
ataxic gait | 24  
hypoactive knee jerks | 24  
hypoactive ankle jerks | 24  
bilateral extensor plantar responses | 24  
impairment of position sense | 24  
impairment of vibratory senses | 24  
dysmetria | 24  
intentional tremors | 24  
concentric symmetric hypertrophy of left ventricle | 24  
asymmetric septal hypertrophy | 24  
expanded allele in FRDA gene | 24  
homozygous alleles in FRDA gene | 24  
diagnosis of FA-associated insulin-dependent diabetes | 24  
diagnosis of cardiomyopathy | 24  
discharged with a split-mixed insulin regimen of NPH and rapid-acting insulins | 72  
postmeal serum C-peptide level 2.1 ng/mL | 1440