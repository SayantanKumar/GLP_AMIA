19 years old|0  
male|0  
new-onset diabetes after kidney transplantation (NODAT)|0  
marked hyperglycemia (up to 17.2 mmol/L)|0  
denied catabolic symptoms|0  
no evidence of ketoacidosis|0  
family history of diabetes in maternal grandmother and uncle|0  
fasting C-peptide 1.3 nmol/L|0  
GADA negative|0  
ICA negative|0  
IA-2A negative|0  
ZnT8A negative|0  
pancreatic ultrasound normal|0  
association raised possibility of MODY type 5 and HNF1B defects|0  
screening for HNF1B gene mutations undertaken|0  
heterozygous missense mutation p.S148L (c.443 C>T) in exon 2 found|0  
referred for genetic counseling|0  
no complaints suggestive of exocrine dysfunction|0  
liver enzymes normal|0  
no clinical evidence of genital tract malformations|0  
insulin therapy started with long-acting analog (0.16 UI/kg/day)|0  
routine fetal ultrasound at 20 weeks’ gestation showed bilateral hyperechogenic kidneys|-170136  
postnatal ultrasound demonstrated hyperechogenic kidneys with small cysts|-166776  
postnatal plasma creatinine abnormally elevated|-166776  
plasma creatinine 433.2 μmol/L (GFR 15.9 mL/min/1.73 m2) at age 18|-8760  
living kidney transplant from father received|−336  
routine blood analysis two weeks after transplant revealed marked hyperglycemia|-336 → 0 (defines NODAT)  
procedure complicated by partial graft necrosis|−168  
hospital discharge after transplant|−168  
plasma creatinine 185.6 μmol/L (GFR 44.3 mL/min/1.73 m2) at discharge|−168  
tacrolimus 15 mg/day at discharge|−168  
mycophenolate mofetil 2000 mg/day at discharge|−168  
prednisolone 15 mg/day at discharge|−168  
insulin switched to DPP-4 inhibitor five months after NODAT|3600  
tacrolimus 8 mg/day at that time|3600  
prednisolone 5 mg/day at that time|3600  
DPP-4 inhibitor stopped due to vomiting a few weeks later|4104  
no antidiabetic medication while HbA1c <6.5%|4104  
HbA1c increased to 6.9% sixteen months after NODAT|11520  
sitagliptin 25 mg/day resumed|11520  
HbA1c increased to 8% eight months later|17280  
renal function slowly deteriorated (creatinine 185.6–229.8 μmol/L; GFR 34–44 mL/min/1.73 m2)|17280  
tacrolimus 6 mg/day at that time|17280  
prednisolone 5 mg/day at that time|17280  
liraglutide therapy started, titrated to 1.8 mg/day|17280  
HbA1c dropped to 6.7% two months after liraglutide|18720  
glycemic control deteriorated, HbA1c increased to 10.9%|20160  
immunosuppressive therapy doses unchanged at that time|20160  
patient reported less physical activity|20160  
plasma creatinine 224.5 μmol/L (GFR 35.2 mL/min/1.73 m2)|20160  
liraglutide stopped|20160  
insulin with long-acting analog (0.14 UI/kg/day) resumed|20160  
glycemic control slightly improved two months later|21600  