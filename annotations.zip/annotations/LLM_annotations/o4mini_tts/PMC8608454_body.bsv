vaccination against seasonal influenza | -192720  
acute facial paralysis | -192216  
ascending upper and lower extremity weakness | -192216  
paresthesias | -192216  
flaccid paralysis of all 4 extremities | -192216  
generalized areflexia | -192216  
computed tomography scan of head | -192216  
lumbar puncture showed elevated cerebrospinal fluid protein | -192216  
GBS diagnosed based on clinical presentation and investigations | -192216  
prolonged mechanical ventilation | -192216  
tracheostomy | -192216  
treated with systemic corticosteroids | -192216  
treated with intravenous immune globulin (1999) | -192216  
received first dose of ChAdOx1 nCoV-19 vaccine | -288  
developed mild chills | -288  
resolved mild chills and fatigue | -216  
developed paresthesias of the lips and fingers on both hands | -24  
presented to the emergency department | 0  
progressive, ascending weakness of the upper and lower extremities | 0  
no preceding symptoms that suggested an infection | 0  
hypertension | 0  
dyslipidemia | 0  
insulin-dependent diabetes mellitus | 0  
nephrolithiasis | 0  
obesity | 0  
anxiety | 0  
Guillain–Barré syndrome after vaccination against influenza (history) | 0  
insulin glargine | 0  
metformin | 0  
semaglutide | 0  
gliclazide | 0  
amlodipine | 0  
valsartan | 0  
atorvastatin | 0  
potassium citrate | 0  
physical examination: mild weakness of both shoulder abductors | 0  
physical examination: mild weakness of knee flexors | 0  
physical examination: strength otherwise preserved | 0  
physical examination: areflexia | 0  
physical examination: bilateral loss of pinprick sensation up to mid-shin | 0  
physical examination: bilateral loss of vibration sensation up to mid-shin | 0  
physical examination: no sensory level | 0  
physical examination: loss of proprioception to the ankle joint | 0  
physical examination: gait was abnormally wide | 0  
computed tomography scan of head did not show any acute abnormality; observed background small vessel ischemic disease | 2  
Electrophysiologic studies showed sensorimotor peripheral neuropathy with demyelinating features and axonal features | 24  
analysis of CSF showed albinocytologic dissociation | 24  
CSF white blood cell count normal | 24  
CSF protein elevated | 24  
CSF glucose elevated | 24  
CSF lactate elevated | 24  
CSF bacterial cultures negative | 24  
CSF nucleic acid testing negative for enterovirus, parechovirus, varicella-zoster virus and herpes simplex virus type 1 and 2 | 24  
Serum investigations negative for hepatitis B, hepatitis C, HIV and syphilis | 24  
blood cultures sterile | 24  
Thyroid function normal | 24  
Adrenal function normal | 24  
Electrolytes normal | 24  
Magnetic resonance imaging of cervical spine normal | 24  
no evidence of an infectious cause | 24  
no evidence of a metabolic cause | 24  
no evidence of a structural cause | 24  
Antihuman neuronal ganglioside serology not done | 24  
initially treated with intravenous immune globulin | 24  
consult with Clinical Immunology and Allergy: no in vitro test available to identify any trigger for GBS | 24  
suggested avoiding future doses of the ChAdOx1 nCoV-19 vaccine | 24  
motor weakness deteriorated | 48  
vital capacity deteriorated | 48  
therapeutic plasma exchange performed | 48  
required noninvasive mechanical ventilation | 48  
never received invasive mechanical ventilation | 48  
Three months after presentation, motor function had improved substantially | 2160  
persistent mild weakness in hands and lower extremities | 2160  
persistent areflexia | 2160  
persistent abnormal light touch, pinprick and vibration sensation | 2160