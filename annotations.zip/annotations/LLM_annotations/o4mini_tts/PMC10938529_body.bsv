7-year-old Japanese boy|0  
male|0  
polyuria|0  
polydipsia|0  
diagnosed with DM|0  
blood glucose level 682 mg/dL|0  
hemoglobin A1c level 12.2%|0  
serum fasting C-peptide level 0.30 ng/mL|0  
serum immunoreactive insulin concentration 0.8 µU/mL|0  
anti-GAD antibody negative|0  
anti-insulin antibody negative|0  
anti-IA-2 antibody negative|0  
anti-zinc transporter 8 antibody negative|0  
diagnosed with T1BDM|0  
treated with subcutaneous insulin injection therapy|0  
insulin therapy twice daily initiated|0  
transitioned to basal-bolus insulin therapy|17520  
referred for initiation of insulin-pump therapy|26280  
total daily insulin dose 0.46 units/kg/day|26280  
hemoglobin A1c level 6.9%|26280  
serum fasting C-peptide level 0.24 ng/mL|26280  
anti-GAD antibody rechecked negative|26280  
anti-insulin antibody rechecked negative|26280  
anti-IA-2 antibody rechecked negative|26280  
ophthalmologic screening performed|26280  
uncorrected visual acuity right eye 0.15|26280  
uncorrected visual acuity left eye 0.2|26280  
fundus examination revealed optic disc pallor|26280  
critical flicker frequency right eye 23.1 Hz abnormal|26280  
critical flicker frequency left eye 20.8 Hz abnormal|26280  
magnetic resonance imaging no optic nerve atrophy|26280  
no hearing loss on screening|26280  
no urinary tract malformations on screening|26280  
no diabetes insipidus on screening|26280  
no psychiatric symptoms on screening|26280  
WFS1 gene analysis performed|26280  
INS gene analysis performed|26280  
KCNJ11 gene analysis performed|26280  
ABCC8 gene analysis performed|26280  
blood samples collected from patient and mother|26280  
father refused genetic analysis|26280  
direct sequencing of WFS1, INS, KCNJ11, and ABCC8|26280  
no variants in INS gene|26280  
no variants in KCNJ11 gene|26280  
no variants in ABCC8 gene|26280  
identified heterozygous WFS1 variant c.2483delinsGGA|26280  
identified heterozygous WFS1 variant c.1247T>A|26280  
compound heterozygous WFS1 variants confirmed|26280  
c.2483delinsGGA classified pathogenic|26280  
c.1247T>A classified likely pathogenic|26280  
mother carries c.2483delinsGGA WFS1 variant|26280