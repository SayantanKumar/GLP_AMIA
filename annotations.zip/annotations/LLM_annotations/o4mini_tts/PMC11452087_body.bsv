ethinyl estradiol 0.15 mg/levonorgestrel 30 mg for birth control| -87600  
tirzepatide initiated| -1800  
losing 30 pounds| -1800  
37 years old| 0  
female| 0  
obesity| 0  
hypertension| 0  
hypercholesterolemia| 0  
referred to clinic| 0  
elevated liver enzymes| 0  
denies nausea| 0  
denies vomiting| 0  
denies abdominal distension| 0  
denies jaundice| 0  
denies episodes of confusion| 0  
physical examination normal| 0  
denies supplement use| 0  
denies excessive alcohol use| 0  
denies family history of autoimmune disease| 0  
ALT level of 500 U/L| 0  
AST level of 261 U/L| 0  
hepatitis serologies unremarkable| 0  
antinuclear antibody level unremarkable| 0  
antimitochondrial antibody level unremarkable| 0  
ceruloplasmin level unremarkable| 0  
alpha-1 antitrypsin level unremarkable| 0  
anti-smooth muscle antibody level of 37| 0  
abdominal ultrasound normal hepatic echotexture| 0  
abdominal ultrasound no evidence of portal hypertension| 0  
discontinue tirzepatide| 0  
ALT decreased to 110 U/L| 504  
AST decreased to 57 U/L| 504  
resumed tirzepatide| 504  
ALT increased to 184 U/L| 1008  
AST increased to 104 U/L| 1008  
liver biopsy performed| 1008  
liver biopsy lymphocytic infiltration within lobules| 1008  
liver biopsy macrophage infiltration in portal tracts and sinusoidal spaces| 1008  
liver biopsy no evidence of steatosis| 1008  
liver biopsy no bile duct injury| 1008  
liver biopsy no bile duct proliferation| 1008  
liver biopsy no interface hepatitis| 1008  
liver biopsy no necrosis| 1008  
RUCAM score of 5| 1008  
diagnosis of drug-induced liver injury (DILI) from tirzepatide| 1008  
recommendation not to reinitiate tirzepatide| 1008  
ALT level of 36 U/L| 2448  
AST level of 24 U/L| 2448  
switched to semaglutide| 2448  
normal liver enzyme levels| 4608