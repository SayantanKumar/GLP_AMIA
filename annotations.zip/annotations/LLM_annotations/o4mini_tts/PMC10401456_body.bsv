42 years old | 0  
female | 0  
admission to hospital | 0  
no knowledge of diabetes in family history | 0  
cesarean section | -157680  
history of uterine fibroids | -105120  
xerostomia | -96  
polydipsia | -96  
polyuria | -96  
blurred vision | -96  
fatigue | -96  
consuming substantial amounts of beverages and fruits | -96  
admission to local hospital | -96  
FBG 18.15 mmol/L | -96  
HbA1c 10.3% | -96  
metformin prescribed | -96  
another oral glucose-lowering drug prescribed | -96  
symptoms not relieved | 0  
FBG 14.54 mmol/L | 0  
dry lips | 0  
body mass index 31.85 kg/m2 | 0  
blood pressure 133/96 mmHg | 0  
sane | 0  
conscious | 0  
general condition good | 0  
no other obvious abnormality detected | 0  
arterial pH 7.29 | 0  
PO2 93 mmHg | 0  
bicarbonate 14.6 mmol/L | 0  
islet cell antibody elevated | 0  
glutamic acid decarboxylase antibody elevated | 0  
insulin autoantibody elevated | 0  
urine ketone positive | 0  
liver function abnormal | 0  
blood lipids normal | 0  
albumin/creatinine ratio normal | 0  
thyroid function normal | 0  
next-generation sequencing performed | 0  
heterozygous PAX4 mutation (c.314G>A, p.R105H) identified | 0  
mother heterozygous PAX4 mutation | 0  
daughter normal PAX4 genotype | 0  
diabetic ketoacidosis | 0  
type 1 diabetes mellitus | 0  
fluid replacement therapy initiated | 0  
insulin treatment initiated | 0  
arterial pH normalized | 0  
urine ketone normalized | 0  
mixed protamine zinc recombinant human insulin injection (70/30) 8 IU before breakfast and dinner | 0  
lifestyle interventions (balanced diet and regular exercise 30 min/d) initiated | 0  
discharge | 48  
FBG 6-7 mmol/L at discharge | 48  
insulin injection regimen maintained at discharge | 48  
lifestyle interventions maintained at discharge | 48  
discontinued insulin therapy | 768  
blood glucose normal with lifestyle interventions | 768  
oral glucose tolerance test administered | 2208  
HbA1c 6.2% | 2208  
OGTT fasting 5.96 mmol/L | 2208  
OGTT 30 min 12.44 mmol/L | 2208  
OGTT 1 h 12.64 mmol/L | 2208  
OGTT 2 h 8.33 mmol/L | 2208  
oral glucose-insulin release test fasting 6.82 µU/mL | 2208  
oral glucose-insulin release test 30 min 35.97 µU/mL | 2208  
oral glucose-insulin release test 1 h 44.81 µU/mL | 2208  
oral glucose-insulin release test 2 h 56.74 µU/mL | 2208  
glutamic acid decarboxylase antibody still elevated | 2208  
capsular blood glucose ~7 mmol/L | 6528  
HbA1c and OGTT scheduled | 6528  
HbA1c 7.3% | 6528  
OGTT fasting 8.88 mmol/L | 6528  
OGTT 30 min 11.26 mmol/L | 6528  
OGTT 1 h 15.72 mmol/L | 6528  
OGTT 2 h 18.17 mmol/L | 6528  
oral glucose-insulin release test fasting 11.93 µU/mL | 6528  
oral glucose-insulin release test 30 min 18.26 µU/mL | 6528  
oral glucose-insulin release test 1 h 30.93 µU/mL | 6528  
oral glucose-insulin release test 2 h 33.13 µU/mL | 6528  
glutamic acid decarboxylase antibody still elevated | 6528  
liraglutide 1.8 mg once daily administered | 6528  
fasting blood glucose 5-6 mmol/L | 6528  
postprandial blood glucose 6-8 mmol/L | 6528