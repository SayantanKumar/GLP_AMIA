Diagnosed with asthma for over 30 years|-262800  
Controlled by PRN budesonide/formoterol for several years|-26280  
COVID infection|-6480  
Home management of COVID infection|-6480  
Room oxygen saturation 93%|-6480  
No antiviral therapy for COVID|-6480  
Weight gain of 40 pounds|-5760  
Non-COVID infectious exacerbation|-1440  
Prednisone treatment|-1440  
Macrolide antibiotic treatment|-1440  
Symptoms resolved after prednisone and antibiotic|-1430  
Symptoms recurred despite budesonide/formoterol increased to BID and PRN|-720  
53-year-old woman|0  
Mother has asthma|0  
Daughter has asthma|0  
No nasal symptoms|0  
Occasional heartburn a few times a week|0  
Excellent inhaler technique|0  
Medication adherence|0  
Normal chest radiograph|0  
Spirometry moderate obstruction|0  
FEV1 reversibility 21%|0  
Air-trapping with FVC improvement of 19% after bronchodilator|0  
Triple therapy indacaterol/mometasone/glycopyrronium started|0  
Proton pump inhibitor daily started|0  
Subcutaneous semaglutide started|0  
Semaglutide titrated to 1 mg weekly|0  
Weight loss started|0  
Underwent allergy testing|0  
Allergy testing positive for house dust mite|0  
Allergy testing positive for mold|0  
Allergy testing negative for dog|0  
Blood eosinophil count 100|0  
Fractional exhaled nitric oxide 11|0  
Lung function normalized|720  
Asthma symptoms resolved|720  
Repeat spirometry showing resolution of obstruction|2160  
Lost 40 pounds|4320  
Proton pump inhibitor discontinued|4320  
Asthma therapy reduced to moderate-dose ICS/LABA|4320  
Asthma therapy reduced to low-dose ICS/LABA|4320  
No recurrence of asthma symptoms|4320  
No recurrence of gastroesophageal reflux symptoms|4320