bigger than other children by age 8| -183960  
29-year-old woman| 0  
seeking medical weight loss options| 0  
seeking surgical weight loss options| 0  
unsuccessful attempts at weight loss through lifestyle modification| 0  
history of pediatric obesity| 0  
dyslipidemia| 0  
hypertension| 0  
obstructive sleep apnea| 0  
pre-diabetes| 0  
taking carvedilol| 0  
taking amlodipine| 0  
taking hydrochlorothiazide| 0  
taking torsemide| 0  
taking valsartan| 0  
taking atorvastatin| 0  
taking cholestyramine| 0  
weighed 185.3 kg| 0  
BMI 68.1| 0  
blood pressure 132/66 mmHg| 0  
excess abdominal adiposity| 0  
large dorsocervical fat pad| 0  
total cholesterol 182 mg/dL| 0  
LDL 129 mg/dL| 0  
triglyceride 189 mg/dL| 0  
A1c 5.6%| 0  
Binge Eating Severity Scale result 16| 0  
hypothyroidism workup normal| 0  
excess cortisol workup normal| 0  
phentermine 37.5 mg daily started| 0  
topiramate 50 mg daily started| 0  
semaglutide trialed| 0  
semaglutide discontinued| 504  
intractable nausea| 504  
topiramate dose increased to 50 mg twice daily| 3192  
weight loss 8 kg| 3192  
decision to defer surgical management| 3192  
blood pressure medications down-titrated| 5040  
weight loss 60 lbs| 5040  
CPAP discontinued| 5760  
hydrochlorothiazide discontinued| 6480  
valsartan discontinued| 8640  
amlodipine discontinued| 8640  
carvedilol discontinued| 8640  
Repeat Binge Eating Severity Scale result 1| 8640  
weight loss 67.3 kg| 9744  
BMI 43.4| 9744  
weight loss 36.3%| 10800  
BMI reduction of 24.7 kg/m2| 10800  
hyper-responder to phentermine/topiramate therapy| 10800  
genetic testing performed| 10800  
PLXNA4 variant noted| 10800  
atorvastatin discontinued| 10800  
cholestyramine discontinued| 10800  
decision to defer bariatric surgery in favor of continued medical and lifestyle intervention| 10800