60-year-old man|0
male|0
admission to hospital|0
asymptomatic on arrival|0
vital signs within normal limits|0
white blood cell count 7.6 K/μL|0
hemoglobin 14.6 g/dL|0
serum glucose 157 mg/dL|0
bicarbonate 24 mmol/L|0
anion gap 12 mmol/L|0
troponin 0.09 ng/mL|0
glycated hemoglobin 9.6%|0
urinalysis glucosuria >1000 mg/dL|0
urinalysis ketonuria 15 mg/dL|0
taking glimepiride|0
taking metformin|0
taking subcutaneous semaglutide|0
taking empagliflozin|0
oral antihyperglycemic medications withheld|0
placed on subcutaneous insulin regimen|0
coronary artery disease|0
hypercholesterolemia|0
type 2 DM diagnosed 15 years previously|-131400
switched to empagliflozin (Jardiance) about 1 year before admission|-8760
started subcutaneous semaglutide about 1 year before admission|-8760
cardiac catheterization revealing triple-vessel disease|-24
triple-vessel disease|-24
last dose of empagliflozin (Jardiance) 48 h before surgery (≈6 h before admission)|-6
third day of admission|42
CABG surgery|42
started intravenous norepinephrine for hypotension|42
developed elevated anion gap metabolic acidosis|46
arterial pH 7.275|46
reduced bicarbonate level 15 mmol/L|46
increased anion gap 25 mmol/L|46
serum glucose normal 138 mg/dL|46
β-hydroxybutyric acid level elevated 6.52 mmol/L|46
normal kidney function test results|46
normal lactic acid level|46
negative acetaminophen result|46
negative salicylate result|46
negative blood alcohol result|46
diagnosis of euglycemic DKA|46
initiated intravenous insulin drip with 5% dextrose in water|46
history of home SGLT2 inhibitor therapy obtained|46
discontinued intravenous norepinephrine infusion|66
ketoacidosis resolved|94
transitioned to subcutaneous basal and premeal insulin|94
discharge from hospital|120
educated on discontinuing SGLT2 inhibitors ≥72 h before surgery|120