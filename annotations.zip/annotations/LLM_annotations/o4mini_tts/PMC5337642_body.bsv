valproate reduced | -4320  
valproate stopped | -4320  
increased confusion | -48  
65 years old | 0  
male | 0  
prostate carcinoma | 0  
radical prostatectomy | 0  
adjuvant radiotherapy | 0  
type 2 diabetes mellitus | 0  
hypertension | 0  
hypercholesterolaemia | 0  
epilepsy of unknown origin during childhood | 0  
acetylsalicylic acid | 0  
olmesartan medoxomil | 0  
rosuvastatin | 0  
lixisenatide | 0  
metformin | 0  
gliclazide | 0  
previous imaging reports never mentioned intracranial anomalies | 0  
admission to hospital | 0  
generalised epileptic seizure at home | 0  
normal neurological examination | 0  
Glasgow Coma Scale 15/15 | 0  
blood tests unremarkable | 0  
slightly increased C reactive protein 5.9 mg/L | 0  
normal EEG | 0  
CT scan of the skull performed | 0  
hypodense contrast-enhanced lesion surrounded by oedema in right frontal lobe | 0  
no midline shift | 0  
no ventricular anomalies | 0  
initial oncologic screening advised | 0  
chest imaging performed | 0  
abdomen imaging performed | 0  
no primary malignancies or recurrence | 0  
neurosurgical consultation | 0  
MRI with diffusion-weighted imaging performed | 0  
brain abscess diagnosed | 0  
pachymeningitis diagnosed | 0  
transthoracic ultrasound performed | 0  
negative cardiac vegetations | 0  
no signs of cardiac infection | 0  
valproate 1.5 g/day | 0  
levetiracetam 1 g/day | 0  
vancomycin 2 g/day | 0  
ornidazole 1 g/day | 0  
ceftriaxone 2 g/day | 0  
stereotactic drainage performed | 0  
MALDI-TOF spectrometry of pus performed | 0  
P. gingivalis identified | 0  
intraoral inspection performed | 0  
partial dentition | 0  
parodontitis found | 0  
apical periodontitis around elements 16, 23 and 34 | 0  
sinus cavities normal | 0  
antibiotic regimen reduced to intravenous ornidazole 1 g/day | 0  
antibiotic regimen reduced to ceftriaxone 2 g/day | 0  
left hemiparesis developed | 456  
left hemineglect developed | 456  
increased epileptic seizures | 456  
tonic-clonic seizure | 456  
intubation | 456  
intravenous sedation started | 456  
imaging performed | 456  
intracerebral abscess extension to subdural space and subcutis | 456  
subdural empyema formed | 456  
abscess spread to occipital-parietal regions | 456  
incision and drainage performed | 456  
total extraction of remaining dentition performed | 456  
ceftriaxone 2 g/day continued | 456  
ornidazole 1 g/day continued | 456  
antibiotics continued for 43 days | 456  
clinical improvement | 1032  
biochemical improvement | 1032  
radiological improvement | 1032  
discharge from neurosurgical ward | 1416  
almost complete resolution of neurological deficit | 1416  
referral for inhospital physiotherapy | 1416