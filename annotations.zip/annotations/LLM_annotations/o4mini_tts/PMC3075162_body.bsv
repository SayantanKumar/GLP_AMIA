diagnosed with tropical chronic pancreatitis | -52560  
maintained on oral pancreatic enzyme therapy for exocrine pancreatic insufficiency | -52560  
diagnosed with non-insulin-dependent diabetes mellitus | -26280  
prescribed glucotrol (glipizide) 5 mg daily | -26280  
approximately 2 months prior presented to a medical center in India with similar pain | -1440  
approximately 2 months prior fever | -1440  
CT scan of the abdomen performed (India) | -1440  
chronic atrophic calcific pancreatitis (India CT finding) | -1440  
dilated pancreatic duct (7 mm) (India CT finding) | -1440  
intraductal calculi (India CT finding) | -1440  
ERCP performed (India) | -1440  
discharged from India center | -1440  
scheduled to return for removal of ductal stones | -1440  
discharged (previous pain-control admission) | -48  
CT scan of the abdomen performed (emergency department) | 0  
fatty atrophy of both pancreatic head and uncinate process | 0  
pancreatic duct filled with large calcifications | 0  
possible obstruction at the level of the neck | 0  
marked upstream ductal dilatation of 1.5 cm | 0  
admitted for management of pain secondary to chronic pancreatitis | 0  
no history of alcohol consumption | 0  
continuing epigastric pain | 0  
on the second day of the current admission developed fever (102°F) | 48  
developed chills | 48  
developed rigors | 48  
rapidly progressed to severe sepsis | 48  
developed septic shock | 48  
transferred to medical intensive care unit | 48  
intubated for hypoxemic respiratory failure | 48  
acute respiratory distress syndrome | 48  
multiorgan failure | 48  
administered broad-spectrum antibiotics | 48  
vasopressor support | 48  
activated recombinant human protein C | 48  
ultrasound of the abdomen performed | 48  
markedly dilated pancreatic duct (1.9 cm) with 8.7×7.6 mm calculus | 48  
pancreas diffusely echogenic | 48  
common bile duct prominent with no obvious obstructing calculi | 48  
bedside emergency ERCP performed | 50  
major papilla of Vater visualized expelling frank pus | 50  
no evidence of papillitis, tumor or previous sphincterotomy | 50  
evacuation of more than 5 ml of yellow pus | 50  
could not aspirate fluid through the cannula for culture | 50  
cholangiogram revealed normal biliary tree without stones | 50  
pancreatogram showed marked dilatation of main pancreatic duct with a single distal calculus | 50  
guide wire introduced into the pancreatic duct | 50  
evacuation of approximately 20 ml of pus | 50  
placed 5-cm-long 5 F stent into the pancreatic duct | 50  
stent removed | 50  
diagnosed with acute suppuration of the pancreatic duct (ASPD) | 50  
contrast enhanced CT scan of abdomen performed | 72  
inflammatory changes in fat surrounding body and tail of pancreas consistent with edema | 72  
dilatation of pancreatic duct diminished | 72  
calculus distal migration towards the sphincter of Oddi | 72  
no evidence of pancreatic necrosis or fluid collection | 72  
bilateral moderate pleural effusions present | 72  
dramatic clinical improvement with stabilization of hemodynamic parameters | 72  
blood cultures grew Klebsiella ornithinolytica sensitive to antibiotics | 72  
extubated | 72  
transferred from intensive care unit | 72  
completed antibiotic course | 264  
discharged home | 264  
follow-up examination at 1 month after discharge no further complications | 984  
follow-up examination at 3 months after discharge no further complications | 2424