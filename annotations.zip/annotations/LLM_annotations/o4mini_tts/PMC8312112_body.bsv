75-year-old woman|0  
Left atrial appendage closure with the Watchman device| -1440  
Microperforation of fixation anchors during Watchman placement| -1440  
Progressive shortness of breath| -1440  
Chest pressure| -1440  
Multiple emergency department visits| -720  
Prior hospitalization with two thoracenteses| -720  
Thoracenteses draining clear fluid from left pleural space| -720  
No NSAIDs or colchicine after prior thoracenteses and during prior hospitalizations| -720  
Chest radiograph on admission showing reaccumulation of left pleural effusion|0  
Referral to our hospital for evaluation|0  
Reaccumulation of left pleural effusion|0  
Placement of a chest tube|0  
Drainage of clear yellow exudative pleural fluid with lymphocyte predominance|0  
Pleural fluid WBC 425 cells/μl|0  
Pleural fluid RBC 7123 cells/μl|0  
Pleural fluid neutrophils 12%|0  
Pleural fluid lymphocytes 50%|0  
Pleural fluid eosinophils 1%|0  
Pleural fluid total protein 3.8 g/dl|0  
Pleural fluid glucose 176 mg/dl|0  
Pleural fluid cultures negative for any infection|0  
Pleural fluid cytology negative for malignant cells|0  
Subjective fevers|0  
20-pound weight loss|0  
Lack of appetite|0  
Chronic anemia|0  
Elevated hs-CRP 63.9 mg/l|0  
Chest CT showing multiple sub-centimeter lung nodules|0  
Small-size pericardial effusion unchanged from prior CT|0  
Preserved left ventricular ejection fraction|0  
No signs of restriction or constriction on echocardiography|0  
Transesophageal echocardiogram: Watchman device seated in LAA|0  
Transesophageal echocardiogram: small 1-mm leak through the device|0  
Cardiac CT with contrast: occlusive device in LAA with passage of contrast into distal LAA confirming small 1-mm peridevice leak|0  
No passage of contrast into the pericardial space|0  
No passage of contrast into the pleural space|0  
Chest pain|0  
Non-bloody pleural effusion|0  
Pericarditis|0  
Initiation of NSAIDs|0  
Initiation of colchicine|0  
Improvement in chest pain|72  
Improvement in shortness of breath|72  
Predischarge chest radiograph obtained 3 days after NSAIDs/colchicine|72  
Left basilar atelectasis|72  
Chest tube removal|72  
Discharge|96  
Discharge home on a 2-week course of NSAIDs and colchicine|96  
Follow-up phone call at 3 weeks post-discharge|600  
Resolution of symptoms while on anti-inflammatory therapy|600  
Completion of medical therapy (2-week NSAIDs/colchicine)|432  
Intermittent chest pain after completing medical therapy|432  
Repeat chest CT at 3 weeks showing unchanged small left pleural effusion|600  
Trace pericardial effusion at 3-week CT|600  
Advice to take NSAIDs as needed|768  
Repeat chest CT at 4 weeks showing unchanged small left pleural effusion|768  
Trace pericardial effusion at 4-week CT|768  
Symptom resolution at 8 weeks post-discharge|1440  
Resumed daily activities|1440  
Paroxysmal atrial fibrillation (history)|0  
Hypertension (history)|0  
Dyslipidemia (history)|0  
Diabetes mellitus type 2 well controlled (HbA1c 6.6%) (history)|0  
Chronic kidney disease (history)|0  
Aspirin (home medication)|0  
Bisoprolol (home medication)|0  
Evolocumab (home medication)|0  
Ferrous sulfate (home medication)|0  
Fluoxetine (home medication)|0  
Gabapentin (home medication)|0  
Rosuvastatin (home medication)|0  
Semaglutide (home medication)|0  
Furosemide (home medication)|0  
Chest nodules not FDG avid on PET scan|1  
Chest CT done 1 month prior to admission| -720  
Differential diagnosis: Watchman erosion to pericardial and pleural spaces|0  
Differential diagnosis: Watchman-related inflammatory process|0  
Differential diagnosis: pulmonary embolism|0  
Differential diagnosis: drug-induced pleural effusion|0  
Differential diagnosis: malignancy|0  
Differential diagnosis: connective tissue disease|0