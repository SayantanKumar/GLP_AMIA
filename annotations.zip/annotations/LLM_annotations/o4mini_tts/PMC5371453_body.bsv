no history of diabetes | -1  
no history of hypoglycemic symptoms before operation | -1  
52-year-old woman | 0  
moderately overweight (BMI 29 kg/m2) | 0  
severe reflux disease | 0  
underwent laparoscopic Toupet fundoplication | 0  
developed episodes of severe symptomatic late dumping syndrome | 8760  
palpitations | 8760  
nausea | 8760  
sweating | 8760  
weakness | 8760  
collapse | 8760  
blood tests | 8760  
functional X-ray examination | 8760  
upper endoscopy | 8760  
magnetic resonance imaging of the upper abdomen | 8760  
diagnosis of symptomatic hyperinsulinemic hypoglycemia | 8760  
Sigstad score questionnaire | 8760  
OGTT | 8760  
CGM | 8760  
treatment includes dietary changes | 8760  
administration of acarbose | 8760  
increased meal frequency to 5 to 6 per day | 8760  
meal composition shift toward more protein and fiber and less carbohydrates | 8760  
50 mg of acarbose given before each meal, 3 times a day | 8760  
acarbose treatment failure | 8760  
decision to give liraglutide as off-label drug | 8760  
patient consented and signed informed consent | 8760  
baseline OGTT | 8760  
fasting glucose level of 93 mg/dL | 8760  
fasting insulin level of 29 μU/mL | 8760  
initial liraglutide 0.6 mg per day subcutaneous injection | 8760  
glucose level of 206 mg/dL at 30 minutes | 8760.5  
glucose level of 180 mg/dL at 60 minutes | 8761  
glucose level of 146 mg/dL at 90 minutes | 8761.5  
insulin peak of 717 μU/mL at 90 minutes | 8761.5  
glucose level of 35 mg/dL at 150 minutes | 8762.5  
OGTT and CGM at week 2 of liraglutide treatment | 9096  
marginal improvement in subjective hypoglycemic symptoms | 9096  
OGTT fasting glucose level of 88 mg/dL | 9096  
fasting insulin level of 19.3 μU/mL | 9096  
insufficient treatment response | 9096  
liraglutide dosage boosted to 1.2 mg/day | 9096  
peak glucose level of 155 mg/dL at 30 minutes | 9096.5  
peak insulin level of 311 μU/mL at 60 minutes | 9097  
glucose level of 76 mg/dL at 120 minutes | 9098  
insulin level of 109 μU/mL at 120 minutes | 9098  
glucose concentration of 48 mg/dL at 180 minutes | 9099  
OGTT after 2 weeks of 1.2 mg/day liraglutide | 9432  
CGM after 2 weeks of 1.2 mg/day liraglutide | 9432  
fasting insulin level of 10.7 μU/mL | 9432  
fasting glucose level of 83 mg/dL | 9432  
glucose remained above 66 mg/dL | 9432  
84% of glucose values reached normoglycemia | 9432  
patient remains free of symptoms | 9432  
peak insulin level of 413 μU/mL at 60 minutes | 9433  