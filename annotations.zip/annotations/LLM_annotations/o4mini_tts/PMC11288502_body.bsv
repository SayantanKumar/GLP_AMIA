54 years old|0
male|0
history of type 2 diabetes mellitus|0
dyslipidemia|0
hypertension|0
recurrent ITP|0
coronary artery disease treated with percutaneous coronary intervention| -43800
presented to our clinic for evaluation|0
metformin 1000 mg twice daily|0
empagliflozin 12.5 mg twice daily|0
gliclazide 30 mg once daily|0
semaglutide 1 mg once weekly|0
atorvastatin 40 mg at bedtime|0
amlodipine 5 mg once daily|0
losartan 50 mg once daily|0
metoprolol 25 mg twice daily|0
aspirin 81 mg once daily|0
low ferritin levels|0
no anemia|0
started on ferrous gluconate 300 mg daily|0
baseline platelet count of 223 x10^9/L|0
decline in platelet count to 89 x10^9/L|840
remained asymptomatic|840
presented with recurrent gum bleeding| -289080
presented with petechiae| -289080
bone marrow biopsy confirming ITP diagnosis| -289080
treated with corticosteroids| -289080
advised to have annual follow-ups| -289080
presented with widespread petechiae| -131400
persistent epistaxis| -131400
recent upper respiratory tract infection| -131400
stable vital signs| -131400
critically low platelet count| -131400
treated with prednisone| -131400
intravenous immunoglobulin| -131400
tapering course of prednisone| -131400
ranitidine| -131400
Diagnosed with ITP| -289080
Bone marrow biopsy confirming ITP diagnosis| -289080
Corticosteroids| -289080
Admitted for diffuse petechial rash| -121236
gum bleeding| -121236
Platelet levels at 1 x10^9/L| -121236
Prednisone 1 mg/kg orally| -121236
IV immunoglobulins 50 g daily for 2 days| -121236
Iron deficiency anemia|0
Ferritin level at 20.7 ug/L|0
Prescribed ferrous gluconate|0
Platelet levels at 86 x10^9/L|1032
Cessation of ferrous gluconate|1032
discontinuing ferrous medication|1032
platelet count increased to 144 x10^9/L|1272
diagnosis of ferrous medication-induced ITP|1272