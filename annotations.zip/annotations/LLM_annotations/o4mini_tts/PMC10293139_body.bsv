62 years old|0  
male|0  
retired office worker|0  
presented for scheduled revision of transjugular intrahepatic portosystemic shunt|0  
portal hypertension|0  
non-alcoholic steatohepatitis|0  
liver cirrhosis|0  
esophageal varices|0  
known splenic vein thrombosis|0  
stent implantation| -30240  
initiation of anticoagulation therapy| -30240  
metabolic syndrome|0  
good general condition|0  
Spironolactone|0  
Hydrochlorothiazide|0  
Ornithine aspartate|0  
Lactulose|0  
Rifaximin|0  
Duloxetine|0  
Ramipril|0  
Ursodeoxycholic acid|0  
Apixaban|0  
Insulin glargine|0  
Insulin lispro|0  
Metformin|0  
Semaglutide|0  
angiographic intervention|0  
percutaneous transluminal balloon angioplasty of the TIPS|0  
balloon percutaneous transluminal balloon angioplasty of the splenic vein stent|0  
prilocaine 1% 10 mL administration|0  
iodine-based contrast medium 120 mL administration|0  
anticoagulation paused|0  
Metformin discontinued| -48  
post-interventional abdominal pain|8  
metamizole 1 g administration|8  
first intake of metamizole|8  
agranulocytosis|24  
neutrophil count <0.01/nL|24  
elevated indirect bilirubin|24  
no increase of liver enzymes|24  
manual differential blood count (no atypical cells)|24  
protective reverse isolation initiated|24  
antibiotic prophylaxis initiated|24  
filgrastim administration|24  
haptoglobin decreased|24  
free hemoglobin increased|24  
lactate dehydrogenase increased|24  
manual differential blood count (no schistocytes)|24  
no previous hematologic disease|0  
no evidence of microangiopathy|24  
no extracorporeal procedures|24  
glucose-6-phosphate dehydrogenase deficiency excluded|24  
paroxysmal nocturnal hemoglobinuria excluded|24  
hemoglobin electrophoresis (no other hemoglobin disorders)|24  
no evidence of corpuscular hemolysis|24  
no blood transfusion|24  
no infectious hemolysis|24  
no evidence of foreign travel in recent years|0  
reticulocytes elevated|24  
Coombs test negative|24  
hemoglobin decreased from 12.6 to 11.5 mg/dL|24  
no symptoms of anemia|24  
no pectanginal symptoms|24  
diagnosis of metamizole-induced agranulocytosis|24  
diagnosis of metamizole-induced hemolysis|24  
increase in granulocytes|48  
decrease in bilirubin to baseline levels|48  
C-reactive protein increased from 5.5 to 12.2 mg/L|48  
IVIG not administered|48  
steroids not administered|48  
computed tomography performed|48  
post-interventional imaging performed|48  
therapeutic success documented|48  
cardiac function stable|0  
pulmonary function stable|0  
no fever|0  
no symptoms of infection|0  
discharged after full recovery|120