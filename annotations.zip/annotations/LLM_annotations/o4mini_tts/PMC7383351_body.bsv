18-year-old Caucasian female|0  
admitted for diagnostic coronary angiography|0  
10-year history of type 2 diabetes mellitus| -87600  
10-year history of essential arterial hypertension| -87600  
10-year history of dyslipidemia| -87600  
pulmonary sarcoidosis diagnosed by mediastinal lymph node biopsy| -43800  
resected epidermoid carcinoma of the tongue| -43800  
coronary angiography showing 40%-50% mid-left anterior descending artery stenosis| -43800  
routine bisoprolol 2.5 mg/d| -24  
routine acetylsalicylic acid 80 mg/d| -24  
routine atorvastatin 10 mg/d| -24  
routine metformin 850 mg twice/d| -24  
routine gliquidone 15 mg/d| -24  
routine dulaglutide 1.5 mg/wk| -24  
dyspnea on moderate exertion (NYHA class II)| -336  
New York Heart Association class II| -24  
increased frequency of dyspnea| -48  
denies chest pain| -24  
denies palpitations| -24  
denies orthopnea| -24  
denies lower leg edema| -24  
denies paroxysmal nocturnal dyspnea| -24  
denies change in weight| -24  
denies syncope| -24  
no family history of sudden cardiac death| -24  
denies recent severe illness| -24  
denies respiratory symptoms| -24  
recent abdominal and thoracic CT scan revealing mediastinal and hilar lymph nodes| -72  
no signs of distress on physical examination| -24  
temperature 37.2 °C| -24  
blood pressure 130/70 mmHg| -24  
heart rate 50 beats/min| -24  
oxygen saturation 97% on room air| -24  
no jugular vein distention| -24  
no carotid bruit| -24  
peripheral pulses present and equal| -24  
no skin lesions| -24  
occasional premature beat| -24  
first and second heart sounds heard| -24  
no murmurs| -24  
no rubs| -24  
no gallops| -24  
lung examination unremarkable| -24  
abdomen examination unremarkable| -24  
laboratory: elevated glycated hemoglobin| -24  
laboratory: normal potassium| -24  
laboratory: normal cardiac ultrasensitive troponin| -24  
laboratory: normal thyroid findings| -24  
laboratory: angiotensin converting enzyme within normal range| -24  
electrocardiogram: regular sinus rhythm| -24  
electrocardiogram: prolonged PR interval| -24  
electrocardiogram: QTc at 450 ms| -24  
initial cardiac ultrasound: basal-septal akinesia| -24  
initial cardiac ultrasound: preserved left ventricular ejection fraction| -24  
initial cardiac ultrasound: normal left and right chamber sizes| -24  
initial cardiac ultrasound: normal tricuspid aortic valve with trace insufficiency| -24  
initial cardiac ultrasound: ascending aorta 41 mm| -24  
submaximal exercise stress test reaching 67% maximal predicted heart rate| -2  
exercise stress test: multifocal ventricular extrasystoles| -2  
exercise stress test: torsades de pointes| -2  
exercise stress test: no syncope| -2  
exercise stress test: no chest pain| -2  
exercise stress test: maximal blood pressure 152/70 mmHg| -2  
exercise stress test recovery: multifocal ventricular extrasystoles| -1.5  
increased bisoprolol from 2.5 mg to 5 mg| -1  
stopped dulaglutide| -1  
coronary angiography showing stable 40%-50% mid-LAD plaque|0  
cardiac continuous monitoring: ectopic supraventricular beats| 2  
cardiac continuous monitoring: polymorphic ventricular extrasystoles| 2  
cardiac continuous monitoring: intermittent type I second-degree atrioventricular block (Mobitz I)| 2  
electrophysiology study: induced sustained monomorphic ventricular tachycardia at 240 beats/min| 24  
electrophysiology study: termination of ventricular tachycardia by burst pacing| 24  
cardiac magnetic resonance imaging: nondilated left ventricle with basoseptal and mid-septal dyskinesis| 48  
cardiac magnetic resonance imaging: left ventricular ejection fraction 45%| 48  
cardiac magnetic resonance imaging: patchy transmural fibrosis and papillary muscle hyperenhancement| 48  
whole-body PET/CT scan showing no myocardial uptake| 48  
diagnosis of cardiac sarcoidosis with pulmonary sarcoidosis in remission| 48  
double-chamber implantable cardiac defibrillator implantation| 72  
methylprednisolone 12 mg/d started| 72  
methotrexate 12.5 mg/wk started| 72  
regular ICD interrogation: asymptomatic nonsustained ventricular tachycardia episodes| 168  
antitachycardia pacing run terminating nonsustained ventricular tachycardia| 168