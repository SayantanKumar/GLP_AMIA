27 years old|0  
male|0  
history of Crohn disease|0  
obesity|0  
body mass index 37.1|0  
depression|0  
sleep apnea|0  
continuous positive airway pressure|0  
low mood|0  
fatigue|0  
presented to the endocrine clinic for evaluation|0  
normal hair distribution|0  
normal muscle mass|0  
normal muscle strength|0  
soft 10 mL testicles|0  
absence of palpable testicular nodule|0  
intramuscular testosterone cypionate 120 mg weekly usage|0  
total testosterone level of 2.43 ng/mL|0  
testosterone replacement therapy discontinued|0  
low testosterone levels diagnosed| -6480  
repeat total testosterone 0.91 ng/mL|6480  
repeat bioavailable testosterone 0.69 ng/mL|6480  
sex hormone binding globulin 8 nmol/L|6480  
luteinizing hormone 3.1 mIU/mL|6480  
follicle stimulating hormone 2.7 mIU/mL|6480  
estradiol 23 pg/mL|6480  
insulin like growth factor 1 193 ng/mL|6480  
prolactin 10 ng/mL|6480  
thyroid stimulating hormone 1.03 mIU/L|6480  
free thyroxine 1.15 ng/dL|6480  
8 am cortisol 13.5 μg/dL|6480  
adrenocorticotropic hormone 37 pg/mL|6480  
semen analysis unremarkable|6480  
iron studies normal|6480  
pituitary magnetic resonance imaging performed|6480  
symmetric ectatic cavernous portions of the internal carotid arteries compressing and distorting the anterior pituitary gland|6480  
brain magnetic resonance angiography performed|6480  
no aneurysm or malformation of the cavernous internal carotid arteries|6480  
subcutaneous semaglutide 0.25 mg weekly started|6480  
semaglutide titrated to 1 mg weekly|6480  
30 lb weight loss|6480  
body mass index reduced to 33.05|6480  
testosterone levels did not improve with weight loss and sleep apnea treatment|6480  
testosterone replacement therapy not reinitiated|6480  
hypogonadotropic hypogonadism diagnosis|6480