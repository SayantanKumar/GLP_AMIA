56-year-old | 0  
Caucasian | 0  
male | 0  
presented to outpatient dermatology clinic | 0  
new-onset pruritic symptoms | -1176  
diffuse pruritic symptoms | -1176  
intense pruritic symptoms | -1176  
pruritic symptoms began at lower extremities | -1176  
pruritic symptoms advanced to upper extremities | -588  
inability to work due to itching | 0  
inability to sleep due to itching | 0  
exacerbated by stress | 0  
excoriations on lower extremities | 0  
excoriations on upper extremities | 0  
no specific nodules | 0  
post-inflammatory hyperpigmentation | 0  
pruritic nodules on lower extremities | 0  
pruritic nodules on upper extremities | 0  
attempted relief with over-the-counter anti-itch creams | -840  
no improvement with over-the-counter anti-itch creams | -840  
attempted relief with low-dose steroids | -840  
no improvement with low-dose steroids | -840  
prediabetes | 0  
joint pain | 0  
takes Ozempic | 0  
non-adherent to Ozempic | 0  
allergic symptoms to environment | 0  
symptoms exacerbated by sun exposure | 0  
well-controlled with over-the-counter first-generation antihistamines | 0  
elevations in AST | 0  
elevations in ALT | 0  
abdominal ultrasound negative for biliary tree involvement | 0  
CT abdomen and pelvis negative for biliary tree involvement | 0  
P-ANCA normal | 0  
differential diagnosis of atopic dermatitis | 0  
started topical steroids | 1  
no relief with topical steroids | 1  
started oral steroids | 1  
no relief with oral steroids | 1  
given trial of gabapentin 1000 mg | 168  
new differential of chronic pain presenting as pruritus | 168  
gabapentin dose titrated down to 500 mg steady state | 336  
complete resolution of symptomatology | 336