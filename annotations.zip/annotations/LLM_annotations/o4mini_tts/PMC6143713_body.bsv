60 years old|0  
male|0  
presented to the dermatology clinic|0  
6 large, persistent nodules|0  
nodules persisted|0  
pruritus|0  
mild discomfort|0  
induration|0  
5.5-cm × 4-cm subcutaneous nodule on the left side of the abdomen|0  
5 other 2.0- to 4.0-cm deep nodules palpated from the right and left sides of the abdomen as well as the left thigh|0  
slight erythema from the overlying skin of each nodule|0  
warmth from the overlying skin of each nodule|0  
denied fevers|0  
denied chills|0  
denied lymphadenopathy|0  
denied systemic allergic symptoms|0  
diabetes mellitus type II|0  
hypertension|0  
dyslipidemia|0  
nonalcoholic steatohepatitis|0  
exenatide discontinued|0  
nodules treated with betamethasone 0.5% cream|0  
nodules treated with Zyrtec|0  
metformin| -1344  
liraglutide| -1344  
dulaglutide| -1344  
starting exenatide| -1344  
first nodule| -1344  
nodules no improvement|168  
patient requested excision of each of these large nodules|168  
excisional biopsy taken from a nodule on the right side of the abdomen|168  
intralesional triamcinolone injection (10 mg/mL, 1 mL) to a separate superior right abdominal nodule|168  
lobular and septal panniculitis|168  
mononuclear cells|168  
prominent admixed eosinophils|168  
dermal hypersensitivity reaction|168  
moderate predominantly perivascular lymphohistiocytic infiltrate|168  
occasional plasma cells|168  
periodic acid–Schiff stain negative|168  
acid-fast bacilli stain negative|168  
telephone call|504  
worsening erythema surrounding the biopsy site|504  
yellow, thickened drainage|504  
doxycycline 100 mg twice daily started|504  
prednisone course started (50 mg)|672  
dapsone 50 mg started|672  
prednisone discontinued|840  
dapsone discontinued|840  
worsening lower extremity edema|840  
follow up in the dermatology clinic|1008  
great improvement within the nodule on the right side of the abdomen treated with intralesional triamcinolone|1008  
nodule now measured 0.8 cm|1008  
greater than 50% improvement in size|1008  
remaining nodules similar in size|1008  
overlying erythema no longer appreciated|1008  
intralesional triamcinolone injection (10 mg/mL, 1 mL) to each involved nodule|1008  
return visit|2016  
significant improvement of all nodules|2016  
2 subtle, less than 0.5 cm persistent nodules on the right and left sides of the abdomen|2016  
intralesional triamcinolone injection (10 mg/mL, 0.5 mL) to these nodules|2016  
pruritus resolved|2016  
discomfort resolved|2016  
no skin atrophy developed|2016  
triamcinolone injections well tolerated|2016