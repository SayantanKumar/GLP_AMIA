66 years old|0  
male|0  
referred for evaluation for cataract surgery on his right eye|0  
bilateral severe myopia|0  
right-eye cataract|0  
pseudophakic status in the left eye|0  
phacoemulsification|–113880  
intraocular lens (IOL) implantation in his left eye|–113880  
hypertension|0  
type 2 diabetes mellitus|0  
hyperlipidemia|0  
chronic obstructive pulmonary disease|0  
prostate cancer|0  
total prostatectomy|0  
morbid obesity|0  
glipizide|0  
metformin|0  
liraglutide|0  
carvedilol|0  
simvastatin|0  
levothyroxine|0  
tiotropium|0  
no known allergies|0  
denies tobacco use|0  
denies alcohol use|0  
poor vision at all distances|0  
without recent worsening of vision|0  
BCVA 20/70 in right eye|0  
BCVA 20/200 in left eye|0  
pinhole-corrected to 20/50 in right eye|0  
pinhole-corrected to 20/70 in left eye|0  
near visual acuity J3 bilaterally|0  
manifest refraction −14.00 D + 1.75 × 075 in right eye|0  
manifest refraction −16.00 D + 1.00 × 075 in left eye|0  
intraocular pressure 15 in right eye|0  
intraocular pressure 18 in left eye|0  
slit-lamp examination 2+ nuclear sclerotic cataract in right eye|0  
slit-lamp examination posterior chamber IOL with mild capsular fibrosis in left eye|0  
posterior segment examination pathologic myopia bilaterally|0  
posterior segment examination scleral thinning bilaterally|0  
refractive analysis compound myopic astigmatism bilaterally|0  
biometric analysis axial length 30.5 mm right eye|0  
biometric analysis axial length 33.5 mm left eye|0  
corneal tomography normal corneal thickness bilaterally|0  
corneal tomography normal architecture bilaterally|0  
patient elected off-label placement of a phakic IOL in his left eye with a piggyback technique|0  
uncomplicated surgery with placement of a sulcus-located pIOL (−16.00 D, 13.2 mm) in left eye|2  
postoperative day 1 follow-up monitoring|24  
denies new symptoms|24  
uncorrected best visual acuity 20/50 in left eye|24  
pinhole visual acuity 20/40 in left eye|24  
postoperative IOP constant in right eye|24  
postoperative IOP decreased to 16 in left eye|24  
slit-lamp exam left eye sutured wound on temporal limbus|24  
slit-lamp exam left eye pharmacologically dilated pupil|24  
slit-lamp exam left eye deep and quiet anterior chamber|24  
slit-lamp exam left eye visualization of pIOL in correct position anterior to prior IOL with space|24  
BCVA right eye remained stable|24  
IOP right eye remained stable|24  
slit-lamp exam right eye remained stable|24  
patient returned for monitoring at 1 week|168  
subjective improvement in vision|168  
ongoing mild blurriness|168  
uncorrected best visual acuity 20/25 in left eye|168  
intraocular pressure 13 in left eye|168  
slit-lamp exam left eye intact sutured wound on temporal limbus|168  
slit-lamp exam left eye deep and quiet anterior chamber|168  
slit-lamp exam left eye visualization of pIOL correct position anterior to prior IOL with space|168  
BCVA right eye remained stable|168  
IOP right eye remained stable|168  
slit-lamp exam right eye remained stable|168  
referred to primary ophthalmologist for treatment of nuclear sclerotic cataract in right eye aimed at emmetropia|168  
+4.0 D AMO SensAr Lens implant in right eye|240  
uncomplicated right eye surgery|240  
uncorrected best visual acuity 20/20 in right eye|240  