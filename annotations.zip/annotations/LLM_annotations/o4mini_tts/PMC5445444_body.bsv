15-year history of type 2 diabetes mellitus| -131400  
evaluated for vertigo| 0  
MRI revealed a 1.2-cm pituitary macroadenoma with remodeling of the sella floor| 0  
no suprasellar extension| 0  
hypertension| 0  
obstructive sleep apnea| 0  
obesity| 0  
hyperlipidemia| 0  
bilateral carpal tunnel syndrome| 0  
arthralgia| 0  
uncontrolled IGF-1 level 551.0 ng/mL| 0  
elevated GH level (2-hour 5-point mean 1.7 ng/mL)| 0  
acromegaly diagnosis| 0  
elevated baseline fasting plasma glucose 140 mg/dL| 0  
elevated baseline HbA1c 7.5%| 0  
metformin 1000 mg b.i.d.| 0  
pioglitazone 45 mg q.d.| 0  
glipizide extended release 10 mg q.d.| 0  
insulin detemir 30 units q.d.| 0  
refused surgical removal of the pituitary adenoma| 0  
enrolled in C2305 trial| 0  
initiation of octreotide long-acting 20 mg IM q28d| 0  
baseline IGF-1 487.4 ng/mL| 0  
baseline GH 1.7 ng/mL| 0  
after 3 months of octreotide: IGF-1 344.1 ng/mL| 2160  
after 3 months of octreotide: GH 1.6 ng/mL| 2160  
after 3 months of octreotide: HbA1c 8.5%| 2160  
dose of octreotide increased to 30 mg IM q28d| 2160  
insulin aspart 10 units at dinner added| 2160  
after 12 months of octreotide: IGF-1 383.9 ng/mL| 8640  
after 12 months of octreotide: GH 1.0 ng/mL| 8640  
after 12 months of octreotide: fasting plasma glucose 147 mg/dL| 8640  
after 12 months of octreotide: HbA1c 7.3%| 8640  
did not achieve biochemical control on octreotide| 8640  
entered extension phase and crossed over to pasireotide 40 mg IM q28d| 8640  
start of weight decrease from 282 to 258 pounds over pasireotide treatment| 8640  
pasireotide-associated FPG variability due to noncompliance with diet and exercise| 8640  
pasireotide-associated HbA1c stability (range 6.7%–7.8%)| 8640  
continued metformin 1000 mg b.i.d. during pasireotide treatment| 8640  
varied insulin dosing during pasireotide treatment| 8640  
after 1 month of pasireotide: fasting plasma glucose 162 mg/dL| 9360  
after 3 months of pasireotide (month 15): IGF-1 246.7 ng/mL| 10800  
after 3 months of pasireotide (month 15): GH 0.6 ng/mL| 10800  
after 3 months of pasireotide (month 15): fasting plasma glucose 146 mg/dL| 10800  
dose of pasireotide increased to 60 mg IM q28d (month 16)| 11520  
after 6 months of pasireotide (month 18): IGF-1 normalized to 193.0 ng/mL| 12960  
after 6 months of pasireotide (month 18): GH 0.2 ng/mL| 12960  
after 6 months of pasireotide (month 18): fasting plasma glucose 131 mg/dL| 12960  
after 6 months of pasireotide (month 18): HbA1c 7.1%| 12960  
biochemical control achieved with pasireotide| 12960  
IGF-1 remained within reference range from month 18 to month 80| 12960  
GH remained ≤0.6 ng/mL from month 18 to month 80| 12960  
sitagliptin 50–100 mg q.d. added to antidiabetic regimen (month 28)| 20160  
IGF-1 226.8 ng/mL (month 33)| 23760  
IGF-1 283.5 ng/mL (month 36)| 25920  
IGF-1 288.4 ng/mL (month 39)| 28080  
IGF-1 231.8 ng/mL (month 60)| 43200  
liraglutide 0.6 mg q.d. initiated (month 63)| 45360  
liraglutide dose increased to 1.2–1.8 mg q.d. (month 66)| 47520