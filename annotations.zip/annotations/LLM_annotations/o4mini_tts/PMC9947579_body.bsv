45 years old|0  
female|0  
overweight|0  
Parkinson's disease diagnosed|−1  
refractory dyskinesia treated with clozapine|−1  
history of gestational diabetes|−1  
acute onset of glycaemic dysfunction|0  
blood glucose 505 mg/dl|0  
HbA1c 12.4%|0  
metformin initiated|1  
clozapine discontinued|1  
insulin added|2  
exenatide added|2  
empagliflozin added|2