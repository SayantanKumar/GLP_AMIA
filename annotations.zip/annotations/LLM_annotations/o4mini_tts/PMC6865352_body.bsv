57 years old|0  
female|0  
Caucasian|0  
incidentally found to have bilateral adrenal enlargement|0  
abdominal imaging performed for elevated liver enzymes|0  
elevated liver enzymes|0  
10-year history of type 2 diabetes mellitus|0  
metformin|0  
insulin glargine|0  
glycemic control progressively worsened|0  
significant weight gain|0  
without overt cushingoid features|0  
elevated 8:00 h cortisol|0  
non-suppressible after 1 mg of dexamethasone|0  
low DHEAS|0  
low ACTH|0  
normal 24-h urinary free cortisol|0  
normal midnight salivary cortisol|0  
elevated bilateral cortisol production|0  
cortisol level in the left adrenal vein significantly higher than the right|0  
AIMAH|0  
subclinical Cushing’s syndrome|0  
nodule on the left side measured 4 cm in diameter|0  
left adrenalectomy|24  
insulin requirement came down significantly|504  
HbA1C decreased from 8.2 to 6.3%|504  
serum cortisol normalized|504  
DHEAS normalized|504  
ACTH normalized|504  
she started gaining weight|2160  
rise in HbA1C|2160  
non-suppressible cortisol following low-dose dexamethasone|2160  
Mifepristone was started at 300 mg|2160  
Mifepristone was escalated to 600 mg daily|3240  
Mifepristone was escalated to 900 mg daily|4320  
patient did not comply with scheduled follow-up|4320  
intensive care unit admission|4656  
severe refractory hypokalemia|4656  
fluid overload|4656  
Mifepristone toxicity was diagnosed|4656  
mifepristone was held|4656  
dexamethasone was started|4656  
potassium was adequately repleted|4656  
IV diuresis|4656  
WBC 9.0|4656  
Hemoglobin 11.9|4656  
Hematocrit 35.3|4656  
Platelets 161|4656  
Sodium 142|4656  
Potassium 2.6|4656  
Chloride 97|4656  
Bicarbonate 30|4656  
Blood urea nitrogen 9|4656  
Creatinine 0.75|4656  
Blood glucose 153|4656  
Calcium 9.1|4656  
Magnesium 1.3|4656  
Phosphorus 2.1|4656  
Cortisol 190.4|4656  
TSH 8.62|4656  
Free T4 0.89|4656  
Creatine kinase 224|4656  
CKMB 1.6|4656  
Troponin <0.030|4656  
Pro-BNP 2067|4656  
chest x-ray|4656  
question of flash pulmonary edema|4656  
multifocal pneumonia|4656  
trace effusions bilaterally|4656  
chest CT with pulmonary embolism protocol|4656  
no evidence of pulmonary embolism|4656  
bilateral predominantly perihilar airspace disease|4656  
small bilateral pleural effusions|4656  
echocardiogram|4656  
ejection fraction of 60–65%|4656  
mild concentric left ventricular hypertrophy|4656  
transmitral spectral Doppler flow pattern normal for her age|4656  
normal left ventricle filling pressures suggestive|4656  
left ventricular wall motion was normal|4656  
cardiac catheterization|4656  
no angiographically evident coronary artery disease|4656  
improved|4728  
discharge|4728  
followed up as an outpatient 2 weeks after discharge|5064  
Mifepristone was discontinued|5064  
repeat potassium level was normal|5064  
managed for diabetes with dulaglutide|5064  
managed for diabetes with insulin degludec|5064  
managed for diabetes with metformin|5064  
monitored with periodic follow-up visits to look for specific signs of Cushing’s syndrome|5064