35 years old|0  
male|0  
presented to hospital|0  
significant weight loss of 30 kg|-4320  
newly diagnosed diabetes|0  
uncontrolled skin itching|0  
erythema|0  
numerous patches of erythematous areas|0  
vesicles|0  
crust formation|0  
complete blood count normal|0  
blood chemistry normal|0  
renal function normal|0  
liver function normal|0  
serum glucose 6.4 mmol/L|0  
CT scan performed|0  
hypervascular mass replacing most of the pancreas|0  
severe diffuse pancreatic enlargement|0  
multiple liver lesions in right lobe|0  
left para-aortic lymph node lesions|0  
FDG PET/CT performed|0  
mild to moderate heterogeneous activity in pancreatic mass|0  
mild FDG uptake in 2 liver lesions|0  
biopsy of a liver lesion|0  
metastatic grade 2 neuroendocrine tumor|0  
mitotic index = 1|0  
Ki-67 index = 10%|0  
serum glucagon level elevated to 2500 pg/ml|0  
chromogranin level elevated to 4600 ng/ml|0  
68Ga-DOTATATE scan performed|0  
intense Ga-avid pancreatic mass|0  
multiple Ga-avid liver lesions|0  
peripancreatic Ga-avid foci|0  
no additional distant metastases|0  
prescribed short-acting subcutaneous octreotide|0  
shifted to long-acting intramuscular octreotide|72  
prescribed liraglutide|0  
prescribed gliclazide|0  
prescribed metformin|0  
good control of blood glucose|24  
erythematous skin changes resolved|672  
weight gain of 3 kg|672  
surgical consultation recommended locoregional PRRT|672