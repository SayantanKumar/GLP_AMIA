58-year-old|0  
woman|0  
referred to hospital|0  
chest pain|0  
VSD diagnosis in infancy| -507840  
VSD followed but never treated| -507840  
DCRV with spontaneously closed VSD detected on TTE| -131400  
regular follow-up with TTE| -131400  
pressure gradient 21 mmHg| -26280  
pressure gradient 57 mmHg| -13140  
pressure gradient 32 mmHg| -4380  
mild dyspnea on exertion| -131400  
hypertension diagnosed| -175200  
diabetes diagnosed| -149160  
dyslipidemia diagnosed| -17520  
candesartan 8 mg/day|0  
nifedipine 40 mg/day|0  
atenolol 50 mg/day|0  
doxazosin mesylate 3 mg/day|0  
atorvastatin 5 mg/day|0  
metformin 2 g/day|0  
ipragliflozin L-proline 50 mg/day|0  
glimepiride 0.5 mg/day|0  
semaglutide 0.5 mg/week|0  
blood pressure 94/55 mmHg|0  
heart rate 88 bpm|0  
oxygen saturation 98% on room air|0  
chest X-ray cardiac enlargement|0  
chest X-ray no lung congestion|0  
ECG at admission|0  
ST elevation in leads II, III, and aVF|0  
previous ECG| -2160  
TTE at admission|0  
akinesis of basal inferior LV myocardium|0  
DCRV present|0  
VSD not detected|0  
troponin I 30681.6 pg/mL|0  
CK 1070 U/L|0  
CK-MB 85.1 ng/mL|0  
acute myocardial infarction suspected|0  
percutaneous coronary angiography performed|0  
coronary angiography significant LAD stenosis|0  
coronary angiography RCA total occlusion|0  
percutaneous coronary intervention on RCA|0  
ST elevation in right precordial leads after intervention|0  
vital signs stable post-intervention|0  
RV infarction not clinically obvious|0  
CK 1259 U/L on second day|48  
CK-MB 85 ng/mL on second day|48  
TTE mid-RV stenosis|96  
pressure gradient 31 mmHg|96  
CT mid-ventricular RV stenosis|96  
CT RV hypertrophy|96  
CT no other anomalies|96  
right heart catheterization performed|168  
peak pressure gradient 58 mmHg|168  
heart failure not experienced|0  
atrioventricular block not experienced|0  
cardiac rehabilitation commenced|168  
discharged after one week of rehabilitation|336  
cardiac MRI performed almost two months after discharge|1776  
late gadolinium enhancement of inferior LVM|1776  
late gadolinium enhancement of RV myocardium|1776  
DCRV repair performed|1780  
CABG of LAD performed|1780  
TTE successful repair of RV|1948  
mid-RV pressure gradient 5.7 mmHg|1948