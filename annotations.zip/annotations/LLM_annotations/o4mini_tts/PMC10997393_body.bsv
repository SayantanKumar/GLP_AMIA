twenty-one-year-old woman|0  
not known to have diabetes mellitus|0  
not known to have hypertension|0  
no significant past medical history|0  
admitted to the ICU from the ER|0  
abdominal pain|-48  
vomiting|-48  
diarrhoea|-48  
no history of fever|0  
no history of cough|0  
no history of dysuria|0  
no history of headache|0  
no history of chest pain|0  
tirzepatide (5 mg) subcutaneously administered once weekly|-504  
diarrhoea (3–4 times/day)|-504  
loss of 5 kg weight|-504  
denied having a ketogenic diet|0  
pantoprazole use|0  
dehydration|0  
tachypnea|0  
air hunger|0  
heart rate 110 beats per minute|0  
blood pressure 130/80 mmHg|0  
oxygen saturation 99% on room air|0  
BMI 28.2 kg/m2|0  
white blood count 8.5 ×10^9/l|0  
haemoglobin 13.7 g/dl|0  
platelet count 351 ×10^9/l|0  
sodium 137 mmol/l|0  
serum potassium 4.0 mmol/l|0  
blood urea nitrogen 1.6 mmol/l|0  
corrected calcium 2.28 mmol/l|0  
phosphorus 1.1 mmol/l|0  
magnesium 0.75 mmol/l|0  
total bilirubin 8 mmol/l|0  
gamma glutamyl Transpeptidase 13 U/l|0  
aspartate amino transferase 18 U/l|0  
creatinine 54 μmol/l|0  
glucose 4.9 mmol/l|0  
HbA1c 5.1|0  
amylase 44 U/l|0  
lipase 35 U/l|0  
C-reactive protein 14 mg/l|0  
lactate 0.9 mmol/l|0  
paracetamol undetectable|0  
salicylates undetectable|0  
no osmolar difference|0  
pH 7.22|0  
partial pressure of carbon dioxide 33 mmHg|0  
partial pressure of oxygen 70 mmHg|0  
bicarbonate concentration 13.8 mmol/l|0  
anion gap 25|0  
blood ketone concentration 5.2 mmol/l|0  
admitted for management of high anion gap metabolic ketoacidosis|0  
normal lactate|0  
blood glucose not elevated|0  
ketosis thought to be caused by vomiting and starvation|0  
treated with 0.9% saline 1 l over 30 min|0  
treated with dextrose 10% infusion 125 ml/hour|0  
treated with 0.9% saline infusion 125 ml/hour|0  
blood glucose 7–8 mmol/l during infusion|0  
did not require insulin|0  
ondansetron orally every six hours|0  
pantoprazole intravenously|0  
anion gap closed|24  
acidosis corrected|24  
advised against taking tirzepatide|24  
Naranjo adverse drug reaction probability scale score 6|24  
follow-up|672  
resolution of all symptoms|672  
weight gain of 1 kg|672