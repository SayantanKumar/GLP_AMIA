obesity diagnosed | -96360  
lifestyle modification started | -96360  
psoriasis onset | -140160  
consulted dermatologists | -26280  
ixekizumab 80 mg treatment started | -26640  
ixekizumab treatment interrupted | -25200  
secukinumab 75 mg treatment started | -25200  
guselkumab 100 mg treatment started | -18000  
guselkumab treatment discontinued | -10800  
first clinical observation (baseline T0) | 0  
never smoked | 0  
lifestyle modification continued | 0  
diagnosed type-2 diabetes | 0  
waist circumference 98 cm measured | 0  
body mass index 30.4 kg/m2 measured | 0  
height 1.6 m measured | 0  
weight 77.8 kg measured | 0  
HbA1c 6.5% measured | 0  
fasting glucose 120 mg/dL measured | 0  
insulin 11.2 μU/mL measured | 0  
HOMA-IR 3.32 measured | 0  
total cholesterol 222 mg/dL measured | 0  
HDL cholesterol 42 mg/dL measured | 0  
LDL cholesterol 158 mg/dL measured | 0  
triglycerides 112 mg/dL measured | 0  
C-reactive protein 4.3 mg/dL measured | 0  
interleukin-6 4.9 pg/mL measured | 0  
leukocytes 4.95 10^9/L measured | 0  
erythrocyte sedimentation rate 21 mm/h measured | 0  
coronary CT angiography performed | 0  
coronary plaques absent | 0  
coronary calcium (CAC) score 0 | 0  
epicardial adipose tissue (EAT) attenuation −80 HU measured | 0  
pericoronary adipose tissue (PCAT) attenuation LAD −65 HU measured | 0  
PCAT attenuation Cx −77 HU measured | 0  
PCAT attenuation RCA −68 HU measured | 0  
subcutaneous adipose tissue (SAT) attenuation −94 HU measured | 0  
EAT volume 198 cm3 measured | 0  
psoriasis area severity index (PASI) 12.0 measured | 0  
dermatology life quality index (DLQI) 20 measured | 0  
disease activity index for psoriatic arthritis (DAPSA) 31.0 measured | 0  
semaglutide 0.25 mg/week therapy initiated | 0  
semaglutide dose increased to 0.50 mg/week | 672  
semaglutide maintenance dose 1 mg/week reached | 2688  
follow-up visit (T4) | 2880  
weight 66.9 kg measured | 2880  
body mass index 27.3 kg/m2 measured | 2880  
waist circumference 87 cm measured | 2880  
HbA1c 6.1% measured | 2880  
fasting glucose 101 mg/dL measured | 2880  
insulin 10.3 μU/mL measured | 2880  
HOMA-IR 2.57 measured | 2880  
total cholesterol 215 mg/dL measured | 2880  
HDL cholesterol 46 mg/dL measured | 2880  
LDL cholesterol 149 mg/dL measured | 2880  
triglycerides 97 mg/dL measured | 2880  
C-reactive protein 2.4 mg/dL measured | 2880  
interleukin-6 4.1 pg/mL measured | 2880  
leukocytes 6.16 10^9/L measured | 2880  
erythrocyte sedimentation rate 13 mm/h measured | 2880  
PASI 4.0 measured | 2880  
DLQI 5 measured | 2880  
DAPSA 8.0 measured | 2880  
follow-up coronary CT angiography (T10) | 7200  
weight 57.8 kg measured | 7200  
body mass index 22.6 kg/m2 measured | 7200  
waist circumference 72 cm measured | 7200  
HbA1c 5.1% measured | 7200  
fasting glucose 91 mg/dL measured | 7200  
insulin 3.8 μU/mL measured | 7200  
HOMA-IR 0.84 measured | 7200  
total cholesterol 196 mg/dL measured | 7200  
HDL cholesterol 58 mg/dL measured | 7200  
LDL cholesterol 137 mg/dL measured | 7200  
triglycerides 39 mg/dL measured | 7200  
C-reactive protein <0.5 mg/dL measured | 7200  
interleukin-6 3.4 pg/mL measured | 7200  
leukocytes 4.56 10^9/L measured | 7200  
erythrocyte sedimentation rate 12 mm/h measured | 7200  
coronary plaques still absent | 7200  
CAC score still 0 | 7200  
EAT attenuation −94 HU measured | 7200  
PCAT attenuation LAD −70 HU measured | 7200  
PCAT attenuation Cx −82 HU measured | 7200  
PCAT attenuation RCA −72 HU measured | 7200  
SAT attenuation −95 HU measured | 7200  
EAT volume 190 cm3 measured | 7200  
PASI 0.2 measured | 7200  
DLQI 1 measured | 7200  
DAPSA 4.0 measured | 7200