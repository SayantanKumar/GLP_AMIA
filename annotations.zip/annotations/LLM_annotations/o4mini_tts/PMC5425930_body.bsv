arrival in UK at age 25 | -201480  
first known to UK psychiatric services | -201480  
paranoid delusions | -201480  
grandiose delusions | -201480  
auditory hallucinations | -201480  
flupentixol depot 40 mg three times a week for approximately 10 years | -87600  
risperidone up to 9 mg daily for approximately 5 years | -43800  
olanzapine 15 mg daily for approximately 4 years | -35040  
paliperidone palmitate 150 mg monthly for approximately 2 years | -17520  
clozapine up to 400 mg a day for 2 non-consecutive years | -17520  
48-year-old male | 0  
African origin | 0  
treatment-resistant paranoid schizophrenia | 0  
admission to National Psychosis Unit | 0  
baseline fasting blood glucose 4–6 mmol/L | 0  
baseline HbA1c 7.3% | 0  
metformin 1 g twice daily | 0  
hypertension (average BP 165/101 mmHg) | 0  
hypercholesterolemia (LDL 270 mg/dL) | 0  
one-pack-per-day smoking | 0  
BMI 28.7 | 0  
irritability | 0  
shouting | 0  
intimidating behaviour | 0  
paranoid delusions | 0  
grandiose delusions | 0  
thought disorder | 0  
perceptual abnormalities suspected | 0  
risperidone treatment on admission | 0  
not taking any other hyperglycaemia-causing medication | 0  
fasting blood glucose started to increase linearly | 144  
commenced insulin therapy (4 units fast-acting once daily) | 144  
clozapine 100 mg daily | 144  
commenced exenatide 2 mg weekly | 144  
dose of medium-acting insulin increased to 52 units twice daily | 720  
HbA1c increased to 12.1% | 1440  
mental state improved considerably | 336  
amelioration of thought and speech disorders | 336  
perceptual abnormalities no longer noted | 336  
continued paranoid delusions to a lower degree | 336  
engaged in art activities | 336  
calm demeanour increased | 336  
partial insight | 336  
psychotic symptoms significantly reduced | 3600  
glycaemic control stable | 3600  
discharge from hospital | 3600