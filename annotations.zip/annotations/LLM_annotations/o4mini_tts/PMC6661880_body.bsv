52 years old|0
female|0
BMI of 29|0
referred by local practitioner to regional hospital|0
follow-up because of mushroom poisoning|0
alcoholic LC|0
portal hypertension|0
ascites|0
diabetes mellitus|0
30 years of alcohol dependence|-262800
10 years of smoking addiction|-87600
decompensated stage of LC initial diagnosis|-157680
decompensated stage of LC|0
first symptoms of chronic pancreatitis|-210240
mushroom intoxication|-210240
external secretory insufficiency of pancreas|-210240
pancreatogenic diabetes developed|-210240
diabetes mellitus onset|-192720
axial hiatal hernia|0
polyarthritis|0
cyclical period of upper abdominal pain radiating to the back after eating or drinking|-4380
nausea|0
excessive thirst|0
fatigue|0
weight loss|0
diarrhea|0
clay-colored stools|0
chronic pancreatitis diagnosed|-210240
withdrawing of smoking|-210240
withdrawing of alcohol|-210240
dietary changes (low-fat, high-protein, high-calorie diet with fat-soluble vitamin supplements and drinking plenty of liquids)|-210240
pancreatic enzyme supplements|-210240
insulin therapy|-210240
glucagon-like peptide 1 (GLP-1)|-210240
nonsteroidal anti-inflammatory drug (NSAIDs)|-210240
proton pump inhibitor (PPI)|-210240
corticosteroids|-210240
IV fluids|-210240
cavernous transformation of the portal vein|0
hepatosplenomegaly|0
chronic toxic hepatitis|0
chronic calculous cholecystitis|0
adhesive disease|0
intestinal obstruction|0
colon segment resection (2007)|-70080
duodenal ulcer surgery (2007)|-70080
erosive gastritis surgery (2007)|-70080
duodeno-gastric reflux surgery (2007)|-70080
cyst on the right kidney|0
right-sided nephrectomy|0
deterioration of health condition| -720
diarrhea up to 5 times per day|-720
tenderness of liver|0
chronic fatigue|0
general moodiness|0
feelings of despair|0
loss of appetite|0
bloating exacerbated after eating and exercise|0
liquid stools|0
tarry stools|0
vomiting|0
fever|0
abdominal pain|0
stomach upset|0
jaundice|0
altered personality|0
hyperreflexia|0
insomnia|0
drowsiness|0
bruises|0
pedal edema|0
shortness of breath|0
caput medusa|0
blotchy palms|0
nosebleeds|0
muscle cramps|0
abnormal complete blood count values|0
abnormal blood chemistry values|0
abnormal liver enzyme values|0
fasting HDL level <45 mg/dL|0
fasting triglyceride level >140 mg/dL|0
waist circumference >92 cm|0
fasting plasma glucose >5.6 mmol/L|0
hypertension >140/95 mmHg|0
viral hepatitis screening negative|0
esophageal varices presence|0
ultrasound hepatosplenomegaly|0
spleen size 16.3×6 cm|0
vena porta diameter 19 mm|0
splenic vein diameter 12 mm|0
recanalization of umbilical vein 14 mm|0
regimen palatine|0
diet N* (5 and 9)|0
monthly dispensary visits|0
insulin short-acting|0
insulin long-acting|0
aetropidi|0
protafan|0
berlitioni|0
solution natrium 0.9%|0
enterogel|0
creonu|0
enterogermina|0
lacium|0
calcemin|0
thiotriazolini|0
reosirbilact|0
calcii|0
vitruni|0
lactovit|0
aevit|0
pimafucini|0
furamag|0
thiogamma|0
rheosorbilact|0
furosemide 1%|0
dibazol 1%|0
papaverine|0