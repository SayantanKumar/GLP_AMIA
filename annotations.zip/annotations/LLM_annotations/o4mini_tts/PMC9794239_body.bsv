51 years old|0  
Asian man|0  
hypertension|0  
hyperlipidemia|0  
type 2 diabetes mellitus|0  
nonalcoholic fatty liver disease|0  
chronic kidney disease stage 3a|0  
started oral semaglutide 3 mg daily|−4320  
increased semaglutide to 7 mg once daily|−3600  
liver tests before starting semaglutide normal or minimally elevated|−4320  
increase in alkaline phosphatase|−3672  
increase in alanine aminotransferase|−3672  
increase in aspartate aminotransferase|−3672  
normal total bilirubin|−3672  
asymptomatic|−3672  
taking ibuprofen 400 mg twice daily|−1440  
presented to the hospital|0  
abdominal discomfort|0  
new-onset jaundice|0  
nausea|0  
vomiting|0  
diarrhea|0  
weakness|0  
afebrile|0  
tachycardic|0  
blood pressure 90s/60s mm Hg|0  
scleral icterus|0  
dry oral mucosa|0  
blood urea nitrogen 58 mg/dL|0  
creatinine 2.89 mg/dL|0  
worsening liver tests|0  
coagulation tests normal|0  
alpha-fetoprotein normal|0  
magnetic resonance cholangiogram normal|0  
antinuclear antibody negative|0  
smooth muscle antibody negative|0  
anti-mitochondrial antibody negative|0  
liver-kidney microsome-1 antibody negative|0  
soluble liver antigen antibody negative|0  
hepatitis A serology negative|0  
hepatitis B serology negative|0  
hepatitis C serology negative|0  
COVID-19 negative|0  
discharged home|72  
repeat imaging|336  
endoscopic retrograde cholangiopancreatogram|336  
liver biopsy 1|2496  
renal biopsy|2500  
liver biopsy 2|4656  
required hemodialysis|5000  
enrolled in DILIN prospective study|48  
protocol-specific workup for competing etiologies|48  
DILIN causality score probable (3)|72  
DILIN severity score transplantation (5)|72  
treated with ursodiol|72  
treated with budesonide|72  
treated with mycophenolate mofetil|72  
treated with rapamycin|72  
simultaneous liver and kidney transplantation|8760  
successful recovery|8800