received four doses of COVID-19 vaccinations|-720
tested positive for SARS-CoV-2|-24
staying at home|-24
syncope (first) at home|-1
weak limbs|-1
drooling|-1
ambulance called by family|-1
regained consciousness spontaneously|-1
74 years old|0
female|0
hypertension|0
diabetes|0
dyslipidemia|0
cerebral infarction|0
ischemic heart disease|0
amlodipine 5 mg|0
atorvastatin 5 mg|0
aspirin 100 mg|0
liraglutide 1.2 mg/day|0
insulin glargine 10 units/day|0
admitted to hospital|0
quarantined|0
body temperature 37.4°C|0
blood pressure 128/70 mmHg|0
heart rate 82 bpm|0
peripheral oxygen saturation 94%|0
lungs clear (on auscultation)|0
no abnormal heart murmur|0
electrocardiogram sinus rhythm with heart rate 78 bpm|0
C-reactive protein 0.35 mg/dL|0
white blood cell count 3,800 /μL|0
chest CT no signs of pneumonia or heart failure|0
remdesivir 200 mg administered|0
syncope (second) while walking back to bed after urinating|3
sinus arrest accompanied by 8 second pause|3
regained consciousness|3
blood pressure 119/69 mmHg|3
temporary transvenous pacemaker inserted|4
myocardial scintigraphy performed|100
myocardial scintigraphy no myocardial ischemia|100
remdesivir 100 mg administered|24
remdesivir 100 mg administered|48
no syncope or bradycardia|172
temporary pacemaker removed|172
urge to defecate and staggering (third syncope prodrome)|244
syncope (third) standing blankly in bathroom|244
bed blood pressure 115/79 mmHg|244
heart rate dropped from 80 to 36 bpm|244
2.4 second pause recorded|244
dual-chamber pacemaker implanted|245
dizziness while walking to bathroom (fourth syncope prodrome)|269
syncope (fourth) passed out and head injury|269
continued sitting and yawning|269
face pale and sweaty|269
blood pressure too low to measure|269
telemetry monitor disconnected|269
pacemaker records no bradycardia and sinus rhythm 70-80 bpm|269
returned to bed|269
blood pressure 107/62 mmHg|269
heart rate 98 bpm|269
head-up tilt test performed|270
supine blood pressure 140/76 mmHg|270
supine heart rate 80 bpm|270
tilt blood pressure 67/52 mmHg|270
tilt heart rate 81 bpm|270
cold sensations experienced|270
consecutive yawns experienced|270
syncope during tilt test|270
diagnosed vasodepressor reflex syncope|270
metoprolol 60 mg/day prescribed|271
discharged from hospital|267
six months post-discharge follow-up period|4587
no fainting episodes|4587
no bradycardia episodes|4587
maintain normal pulse without pacemaker|4587