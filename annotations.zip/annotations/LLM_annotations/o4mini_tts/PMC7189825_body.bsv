28 years old|0  
female|0  
presented to the emergency department|0  
accidental injection of liraglutide 18 mg subcutaneously|0  
epigastric abdominal pain|0  
radiating to her back|0  
nausea|0  
vomiting|0  
sweating|0  
diabetes mellitus type II|0  
obesity|0  
weight: 109 kg|0  
body mass index 40.5 kg/m2|0  
prescribed metformin 500 mg twice daily|0  
prescribed daily multivitamin|0  
vital signs all within normal limits|0  
blood glucose on arrival 4.6 mmol/L|0  
normal conscious level|0  
soft and lax abdomen|0  
no focal tenderness|0  
venous blood gas pH 7.40|0  
venous blood gas PCO2 42 mmHg|0  
venous blood gas HCO3 25.2 mEq/L|0  
venous blood gas lactate 0.6 mmol/L|0  
mild hypokalemia 3.2 mmol/L|0  
rest of electrolyte panel within normal limits|0  
renal panel within normal limits|0  
normal lipase level|0  
normal amylase level|0  
normal C-peptide level|0  
kept under observation for 16 h|0  
hourly blood glucose monitoring|0  
persistent vomiting|0  
received three boluses of dextrose D50%|2.5  
started dextrose 5% infusion|7  
started dextrose 10% infusion|7  
supplemented with octreotide|0  
became asymptomatic|16  
abdominal pain improved|16  
blood glucose normalized at 7.8 mmol/L|16  
did not continue liraglutide after discharge|16  
patient in good health at 15 months|10800  
no further episodes of hypoglycemia at 15 months|10800  
no further episodes of pancreatitis at 15 months|10800