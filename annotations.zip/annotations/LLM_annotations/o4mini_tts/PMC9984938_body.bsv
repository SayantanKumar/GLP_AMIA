67-year-old woman|0  
Chinese origin|0  
history of type 2 diabetes for 15 years|0  
recent HbA1c of 11.1%|0  
hypertension|0  
dyslipidemia|0  
liver fibrosis|0  
hemorrhoids|0  
taking irbesartan|0  
taking simvastatin|0  
taking empagliflozin|0  
taking semaglutide|0  
new-onset left-eye ptosis|−168  
new-onset double vision|−168  
mild pain around left eye|−168  
presented to emergency room|0  
CTA of head normal|0  
referred to neurology|0  
MRI of brain and orbits with contrast|0  
abnormal enhancement of cisternal segment of left third cranial nerve|0  
slight thickening of cisternal segment of left third cranial nerve|0  
increased T2 signal in cisternal portion of third nerve|0  
increased T2 signal in cavernous portion of third nerve|0  
referred to neuro-ophthalmology|0  
visual acuity 20/25 OD|0  
visual acuity 20/50 OS due to cataract|0  
left complete ptosis|0  
complete limitation of elevation|0  
complete limitation of depression|0  
complete limitation of adduction|0  
right ocular ductions full|0  
cranial nerve function otherwise normal|0  
pupils equal sizes|0  
pupils reactive to light|0  
diagnosed with complete, pupil-sparing third nerve palsy|0  
steroid therapy not initiated|0  
inflammatory bloodwork normal|24  
lumbar puncture normal cell count, glucose, protein|24  
repeat MRI performed 1 month after onset|552  
persistent thickening of third nerve|552  
persistent enhancement of third nerve|552  
third nerve palsy spontaneously resolved after 2 months|1272  
no new diabetes medications started within this time|1272  
no new hypertension medications started within this time|1272  
started on insulin|4152  
repeat MRI at 10 months after presentation showing significant improvement|7200  
minimal enhancement on repeat MRI|7200  
increased T2 signal in cisternal portion of third nerve persisted|7200  
increased T2 signal in cavernous portion of third nerve persisted|7200  
increased T2 signal in superior portion of third nerve persisted|7200  
increased T2 signal in inferior portion of third nerve persisted|7200  
no recurrence|8592  
remained clinically well|8592