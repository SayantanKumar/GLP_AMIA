36 years old|0  
male|0  
admitted for pneumonia|0  
admitted for heart failure|0  
pneumonia|0  
heart failure|0  
type 2 diabetes| -183960  
obesity|0  
CKD stage 4|0  
nephrotic syndrome|0  
diabetic nephropathy|0  
liraglutide (0.9 mg/day)|0  
pioglitazone (15 mg/day)|0  
insulin aspart (40, 20 and 24 U before breakfast, lunch and dinner)|0  
insulin glargine (65 U at bedtime)|0  
stopped pioglitazone|0  
plasma glucose 254 mg/dL| -504  
HbA1c 8.3%| -504  
plasma B-type natriuretic peptide 7.9 pg/mL| -504  
plasma B-type natriuretic peptide 38.6 pg/mL|0  
body height 158.6 cm|0  
body weight 137.9 kg|0  
body mass index 54.8 kg/m2|0  
fever|0  
tachycardia (heart rate 118/min)|0  
hypoxemia (SpO2 94% with 4 L oxygen)|0  
tachypnea (respiratory rate over 20/min)|0  
cardiomegaly|0  
pleural effusion|0  
consolidation|0  
systolic blood pressure 168 mm Hg|0  
diastolic blood pressure 95 mm Hg|0  
eGFR 14 mL/min/1.73 m2|0  
serum creatinine 4.7 mg/dL|0  
daily urinary protein 15.5 g/day|0  
dapagliflozin (5 mg/day) started|96  
body weight promptly decreased|96  
body weight loss of over 20 kg|96  
transient increase of serum creatinine|96  
transient decrease of eGFR|96  
serum creatinine gradually decreased|96  
eGFR gradually increased|96  
urinary protein promptly decreased|96  
significant reduction in urinary protein (-10.8 g/day)|96  
serum ketone bodies 557 µmol/L|192  
serum ketone bodies 407 µmol/L|1032  
plasma B-type natriuretic peptide decreased to 5.3 pg/mL|1944  
discharged from hospital|1056  
treatment changed to liraglutide (0.9 mg/day)|1056  
treatment changed to dapagliflozin (5 mg/day)|1056  
treatment changed to insulin aspart (46, 10 and 16 U before breakfast, lunch and dinner)|1056  
treatment changed to insulin glargine (41 U at bedtime)|1056  
daily insulin dose decreased from 149 to 113 U|1056