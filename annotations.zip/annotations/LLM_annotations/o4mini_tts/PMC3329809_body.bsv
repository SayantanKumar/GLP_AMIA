57 years old|0  
male|0  
off-label liraglutide initiated at 0.6 mg/day|0  
weight 116 kg|0  
A1C 8.1%|0  
consulted a dietitian|0  
consulted a diabetes educator|0  
advised to lower insulin dose by 10 U when self-monitored blood glucose <5 mmol/L|0  
HIV infection diagnosed|−140160  
initial treatment with zidovudine initiated|−140160  
dual-therapy with zidovudine and zalcitabine initiated|−131400  
started zidovudine and lamivudine|−122640  
started triple-therapy with efavirenz, didanosine, and lamivudine|−70080  
dizziness|−70080  
rash|−70080  
depression|−70080  
started atazanavir, tenofovir, and lamivudine|−70080  
progressive abdominal distention|−52560  
replaced atazanavir by raltegravir|−52560  
weight 105 kg|−52560  
15-kg weight gain over 2 years|−70080  
type 2 diabetes diagnosed|−52560  
lifestyle consultation|−52560  
metformin (1,000 mg b.i.d.) initiated|−52560  
severe insulin resistance|−52560  
A1C rose to 8.8%|−30660  
NPH insulin started|−30660  
body weight increased by 5 kg in 6 months|−30660  
glimepiride (up to 6 mg q.i.d.) initiated|−26280  
A1C remained 8.3%|−26280  
insulin glargine started|−24840  
insulin glargine titrated to 60 U/day|−24840  
glimepiride discontinued|−24840  
body weight increased by 7 kg in 6 months|−24840  
no glycemic improvement|−24840  
after 3 weeks of liraglutide therapy|504  
body weight dropped to 110 kg|504  
insulin dose reduced to 30 U/day|504  
insulin discontinued|1008  
fasting glucose decreased from 12.3 to 7.0 mmol/L|1008  
no side-effects|1008  
no hypoglycemia|1008  
less fatigue|1008  
improved quality of life|1008  
self-monitored blood glucose 5.6–8.3 mmol/L|1008  
HIV-RNA remained undetectable|2880  
A1C decreased to 6.8%|2880  
body weight 102 kg|2880  
liver enzymes normalized|2880  
lipid profile improved|2880  
total cholesterol decreased from 5.6 to 4.9 mmol/L|2880  
HDL cholesterol increased from 0.79 to 1.0 mmol/L|2880  
triglycerides decreased from 6.6 to 3.1 mmol/L|2880  
body weight rose to 108 kg|5040  
A1C remained 6.8%|5040  
regularly visited outpatient clinic|−70080