Zinc tablets ingestion|-336
Zinc solution ingestion|-336
Calcium supplementation|-336
Phosphorus supplementation|-336
Visited naturalist|-24
Admission to John H Stroger Hospital|0
42 years old|0
Male|0
Hispanic|0
HIV-positive|0
Diabetes mellitus type II|0
Hypertension|0
Hyperlipidemia|0
Right foot pain|0
Right foot swelling|0
Atorvastatin 80 mg daily|0
Amlodipine/benazepril 5 mg/40 mg daily|0
Bictegravir/emtricitabine/tenofovir alafenamide 50 mg/200 mg/25 mg daily|0
Fenofibrate 160 mg daily|0
Dulaglutide 0.75 mg subcutaneous weekly|0
Linagliptin 5 mg daily|0
Metformin 1000 mg twice a day|0
Insulin 70/30 35 units twice a day|0
HIV viral load 56,477 copies/ml|0
CD4+ T-lymphocyte count 537 cells/ml|0
Excellent adherence to bictegravir/emtricitabine/tenofovir alafenamide|0
Continuation of bictegravir/emtricitabine/tenofovir alafenamide|0
Patient informed team of zinc consumption|1
Discontinuation of zinc supplements|1
HIV viral load < 40 copies/ml on reassessment|720