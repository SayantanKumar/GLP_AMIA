70-year-old | 0
male | 0
COPD GOLD grade 2 | 0
obstructive sleep apnea syndrome | 0
insulin-dependent type 2 diabetes | 0
diabetic retinopathy | 0
diabetic nephropathy (CKD 3b) | 0
diabetic polyneuropathy | 0
arterial hypertension | 0
coronary heart disease | 0
obesity (BMI: 38 kg/m2) | 0
long-acting beta agonist/long-acting muscarinic antagonist therapy | 0
inhaled glucocorticoid (400 μg budesonide per day) therapy | 0
valsartan therapy | 0
spironolactone therapy | 0
ivabradine therapy | 0
atorvastatin therapy | 0
metformin therapy | 0
liraglutide therapy | 0
insulin glargine therapy | 0
enoxaparin therapy | 0
proximal deep vein thrombosis | -2880
productive cough | -336
dyspnea | -336
intermittent fever (>38.5°C) | -336
presented to emergency department | -168
arterial pO2 67 mmHg breathing ambient air | -168
white blood cell count within normal limits | -168
C-reactive protein 33 mg/dl | -168
D-dimer within normal range | -168
creatinine 1.85 mg/dl | -168
chest X-ray bilateral basal coarse reticular opacities | -168
real-time PCR positive for SARS-CoV-2 | -168
diagnosed with COVID-19 | -168
refused hospitalization | -168
discharged home | -168
started oral doxycycline 200 mg once daily | -168
returned to emergency department | 0
clinical deterioration | 0
hypoxemia (arterial pO2 46 mmHg breathing ambient air) | 0
admitted to ICU | 0
moderate ARDS (oxygenation index 154) | 0
chest CT-scan performed | 0
chest CT multiple bilateral ground-glass opacities with crazy paving appearance | 0
reversed halo sign | 0
white blood cell count 11.65×10^9 per L | 0
neutrophils 9.7×10^9 per L | 0
C-reactive protein 144 mg/dl | 0
interleukin-6 396 pg/ml | 0
ferritin 465 ng/ml | 0
creatinine increased from 1.85 to 3.26 mg/dl | 0
lymphocytes within normal range | 0
meropenem 1 g twice daily | 0
azithromycin 500 mg once daily | 0
hydroxychloroquine 200 mg twice daily | 0
intubation | 0
mechanical ventilation | 0
chest X-ray progression of bilateral infiltrates | 48
pulmonary deterioration (oxygenation index <100) | 48
endotracheal aspiration obtained | 72
culture Aspergillus fumigatus growth | 72
Aspergillus lateral-flow device positive | 72
galactomannan not performed | 72
serum galactomannan negative | 72
serum 1,3-β-D-glucan negative | 72
diagnosed with putative invasive pulmonary aspergillosis | 96
started intravenous voriconazole (6 mg/kg b.i.d. then 4 mg/kg b.i.d.) | 96
death due to multiorgan failure | 168
autopsy not performed | 168