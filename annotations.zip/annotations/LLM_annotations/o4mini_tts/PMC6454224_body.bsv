45 years old|0  
male|0  
referred by GP to bariatric clinic|0  
severe obesity|0  
poorly controlled T2DM of 10-year duration|0  
onset of T2DM|-87600  
well-controlled hypertension|0  
dyslipidaemia|0  
stable non-alcoholic steatohepatitis|0  
insulin aspart 20, 18 and 22 units with meals|0  
insulin glargine 40 units nocte|0  
metformin 500 mg three times daily|0  
ramipril 2.5 mg once daily|0  
simvastatin 30 mg once daily|0  
aspirin 75 mg once daily|0  
no alcohol|0  
stopped smoking|-4320  
smoking history 26 pack year|0  
mother had T2DM|0  
sister had T2DM|0  
single|0  
living with two siblings|0  
persistently elevated glucometer readings|-2160  
thirst|-2160  
polydipsia|-2160  
polyuria|-2160  
nocturia|-2160  
weight 113.8 kg|0  
height 168.2 cm|0  
BMI 40.2 kg/m2|0  
waist 117 cm|0  
hip 120 cm|0  
waist-to-hip ratio 0.98|0  
BP 105/62 mmHg|0  
no retinopathy|0  
no neuropathy|0  
no cutaneous markers of insulin resistance|0  
HbA1c 72 mmol/mol (8.7%)|0  
total cholesterol 3.3 mmol/L|0  
LDL 0.8 mmol/L|0  
HDL 1.0 mmol/L|0  
triglycerides 1.9 mmol/L|0  
normal liver profile|0  
normal iron studies|0  
normal renal function|0  
normal thyroid function|0  
ECG right bundle branch block|0  
declined laparoscopic sleeve gastrectomy|0  
declined GLP‐1 agonist therapy|0  
no evidence of psychiatric disorder|0  
assessed by bariatric dietician|0  
advice on healthy eating provided|0  
large intake of sugary snacks|0  
large intake of starchy carbohydrates|0  
agreed to trial of milk-based LELD|0  
concomitant multivitamin and mineral supplement|0  
fiber (ispaghula husk 3.5 g twice daily)|0  
stock cube for sodium replacement|0  
commenced milk-based liquid diet|0  
weight 101.2 kg|1344  
weight 94.6 kg|4032  
insulin titrated down to zero|168  
glucose readings normalised|168  
bloods drawn|336  
start of weight stabilisation phase|1512  
start of weight maintenance phase|2856  
diet and glycaemic control improved|3600  
weight gained 1.6 kg|3600  
regained 2.2 kg|15120  
HbA1c 48 mmol/mol|15120  
off insulin therapy|15120  
weight 92.6 kg|19440  
HbA1c 104 mmol/mol|19440  
increased metformin to 1 g twice daily|19440  
linagliptin 5 mg once daily|19440  
canagliflozin 100 mg once daily|19440  
HbA1c 50 mmol/mol|39600  
weight 100.4 kg|39600  
BMI 35.5 kg/m2|39600  
felt well|39600