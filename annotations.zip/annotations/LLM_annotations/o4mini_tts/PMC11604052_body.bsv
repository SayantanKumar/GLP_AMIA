47 years old|0  
male|0  
admission to emergency department|0  
type 2 diabetes|0  
heart failure with preserved ejection fraction|0  
chronic obstructive pulmonary disease|0  
treated with insulin lispro|0  
treated with insulin glargine|0  
treated with dulaglutide|0  
not on any statins|0  
on evolocumab 140 mg/mL every 2 weeks|0  
history of statin-induced rhabdomyolysis requiring hospitalization|0  
hemoglobin A1c 8.42%|−168  
started on empagliflozin 25 mg once daily|−168  
significant pain in bilateral lower extremities|−96  
constant aching in legs|−96  
constant aching in thighs|−96  
denied recent trauma|0  
denied fall|0  
denied new medications|0  
denied herbal supplements|0  
no common causes of myopathy on medication list review|0  
home medication gabapentin|0  
home medication atenolol|0  
home medication bupropion|0  
home medication ziprasidone|0  
home medication rimegepant|0  
home medication galcanezumab|0  
home medication albuterol inhaler|0  
no weight loss|0  
no change in urination|0  
no feeling thirsty|0  
vital signs within normal limits|0  
no skin erythema|0  
no subcutaneous edema|0  
no lesions|0  
no evidence of dehydration|0  
no joint effusions|0  
range of motion normal|0  
intact strength upper extremities|0  
intact strength lower extremities|0  
discomfort on light palpation|0  
discomfort on deep palpation|0  
tenderness in bilateral thighs|0  
tenderness in bilateral legs|0  
deep tendon reflexes normal|0  
sensation intact|0  
CK elevated (958 U/L)|0  
glucose elevated (206 mg/dL)|0  
creatinine 0.93 mg/dL|0  
eGFR >60 mL/min/1.73 m2|0  
magnesium 2.4 mg/dL|0  
urinalysis negative for blood|0  
urinalysis negative for red blood cells|0  
AST elevated (64 U/L)|0  
ALT elevated (117 U/L)|0  
ALP elevated (138 U/L)|0  
ultrasound showing hepatomegaly with hepatic steatosis|0  
ANA negative|0  
ESR normal (21 mm/hr)|0  
discontinued empagliflozin|0  
given intravenous fluids|0  
discharged home|6  
follow-up at resident clinic|336  
improvement in muscle pain|336  
improvement in muscle weakness|336  
complete resolution of symptoms|336  
CK downtrending (215 U/L)|336  
pain returned to normal|336  
strength returned to normal|336  
deferred further lab testing for autoimmune causes|336