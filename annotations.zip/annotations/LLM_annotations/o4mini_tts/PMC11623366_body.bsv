weight gain began in childhood | -438000  
laparoscopic gastric band | -78840  
laparoscopic gastric sleeve | -52560  
previous laparoscopic cholecystectomy | -17520  
60-year-old | 0  
Caucasian female | 0  
long–standing metabolic syndrome | 0  
BMI of 43 kg/m2 | 0  
presented for elective revision bariatric surgery | 0  
increasing immobility due to chronic back pain | 0  
chronic back pain | 0  
significant weight regain | 0  
dyslipidaemia persistent due to statin intolerance | 0  
blood pressure well treated | 0  
occasional intermittent abdominal pain | 0  
revision bariatric surgery elected | 0  
family history negative for MP | 0  
family history negative for FD | 0  
hs-CRP elevated | 0  
ESR increased | 0  
surgery abandoned | 2  
biopsy of abnormal mesenteric tissue done | 3  
reactive epithelial changes of the mesentery | 48  
diffuse intraepithelial lymphocytes | 48  
diagnosis of MP | 48  
abdominal CT scan confirmed MP | 72  
previous work up for rheumatological diseases negative | 96  
worsening intermittent left-sided facial pain | 8760  
ocular symptoms | 8760  
progressive facial disfigurement | 8760  
difficulty with wearing her glasses | 8760  
CT scan of the head revealed left orbital enlargement | 26280  
possible multiple apparent osteochondromas | 26280  
MRI confirmed left FD of the zygoma | 35040  
abdominal CT scan in 2021 showed persistent MP | 35040  
hepatic steatosis | 35040  
diagnosis of diabetes type 2 | 43800  
semaglutide initiation | 43800  
tirzepatide initiation | 44000  
initial weight loss | 44200  
current abdominal pain | 61320  
current facial pain with trigeminal distribution | 61320  
pain severity 6 out of 10 at rest | 61320  
occasional abdominal swelling | 61320  
chronic back pain with radiculopathy | 61320  
constipation | 61320  
depression | 61320  
poor quality of life | 61320  
treatment for sleep apnoea | 61320  
new onset hearing loss | 61320  
no leucocytosis | 61320  
no anaemia | 61320  
HDL cholesterol not greater than 40 mg/dl | 61320  
slightly increased triglycerides | 61320  
normal LDL cholesterol | 61320