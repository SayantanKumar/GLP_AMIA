70 years old|0  
male|0  
admitted to hospital for treatment of T2DM and bilateral leg swelling|0  
type 2 diabetes mellitus|0  
hypertension|0  
dermatosclerosis|0  
height 167.5 cm|0  
body weight 78.7 kg|0  
body mass index 28.1 kg/m2|0  
blood pressure 134/90 mmHg|0  
pulse rate irregular 95 beats per minute|0  
atrial fibrillation|0  
enlarged heart|0  
right pleural effusion|0  
serum BNP 390.7 pg/mL|0  
serum creatinine 0.78 mg/dL|0  
eGFR 75.2 mL/min/1.73 m2|0  
24-h urinary protein 3.8 g|0  
serum albumin 3.0 g/dL|0  
fasting plasma glucose 141 mg/dL|0  
hemoglobin A1c 7.8%|0  
urinary C-peptide 49 μg/day|0  
treated with glimepiride 1 mg/day|0  
treated with dapagliflozin 5 mg/day|0  
three months prior aware of bilateral leg swelling|-2160  
diagnosed with T2DM at age 50|-175200  
started oral hypoglycemic agents|-175200  
start 1,800-kcal diet therapy|1  
start salt restriction NaCl 6 g/day|1  
change nifedipine CR 60 mg/day to sacubitril/valsartan 200 mg/day|216  
change azilsartan 40 mg/day to sacubitril/valsartan 200 mg/day|216  
start multiple insulin injection therapy|96  
discontinue glimepiride 1 mg/day|96  
increase dapagliflozin to 10 mg/day|120  
add oral semaglutide 3 mg/day|336  
reduce sacubitril/valsartan dose to 100 mg/day|480  
peak insulin requirement 51 units/day|432  
add mitiglinide 30 mg/day|504  
add voglibose 0.9 mg/day|528  
urinary C-peptide increased to 307 μg/day|312  
discontinue sacubitril/valsartan and change to azilsartan 20 mg/day|576  
serum C-peptide 2.03 ng/mL|48  
urinary C-peptide decreased to 99 μg/day|840  
serum BNP decreased to 151.2 pg/mL|384  
serum C-peptide increased to 2.71 ng/mL|384  
serum C-peptide increased to 3.16 ng/mL|648  
serum BNP decreased to 128.1 pg/mL|840  
change azilsartan to olmesartan 20 mg/day|696  
good glycemic control with insulin requirement 22 units/day|840