32 years old | 0  
female | 0  
referred to unit for refractory diarrhea | 0  
first admission to our unit | 0  
planned diagnostic workup | 0  
height 170 cm | 0  
weight 52 kg | 0  
severe electrolyte deficiency with low plasma potassium and magnesium | 0  
normal plasma sodium but urinary sodium below detection | 0  
fecal cultures negative for Campylobacter, Salmonella, Yersinia, Shigella | 0  
Clostridium difficile PCR positive | 0  
10-day vancomycin trial started | 0  
MRI of small bowel normal | 0  
pan-enteric double balloon endoscopy normal | 0  
duodenal, jejunal, ileal, colonic biopsies normal | 0  
laxative screen negative | 0  
markers of systemic infection or metabolic disease normal | 0  
trial of spironolactone | 0  
trial of octreotide | 0  
trial of liraglutide | 0  
thiopurine metabolite measurement | 0  
normal TPMT genotype and phenotype | 0  
E-TGN level 247 nmol/mmol HGB | 0  
E-MeMP level 2354 nmol/mmol HGB | 0  
potassium normalized with 100 mmol/day infusion | 0  
urinary sodium measurable after hypertonic 3% NaCl 2000 mL/day | 0  
classified as type III intestinal failure subtype A3 | 0  
scheduled twice weekly IV fluids and electrolytes | 0  
patient remained underweight and watery diarrhea persisted | 0  
Crohn’s disease remission verified via colonoscopy | 0  
fecal calprotectin < 30 mg/kg | 0  
no bowel surgery | 0  
low-dose 6-mercaptopurine for Crohn’s disease | 0  
colesevelam 625 mg t.i.d. | 0  
loperamide 2–8 mg/day | 0  
levetiracetam 1500 mg/day | 0  
lamotrigine 400 mg/day | 0  
escitalopram 40 mg/day discontinued | 0  
venlafaxine 225 mg/day discontinued | 0  
infliximab therapy | 0  
adalimumab therapy | 0  
natalizumab therapy | 0  
vedolizumab therapy | 0  
repeat fecal C. difficile tests negative after vancomycin taper | 240  
fecal microbiota transplantation | 240  
mean bowel passages decreased from 17 to 13 | 240  
obeticholic acid started 10 mg/day | 240  
obeticholic acid dose increased to 25 mg/day | 336  
mean bowel movements decreased from 13 to 7 | 336  
mean nightly bowel openings decreased from 3 to 2 | 336  
occasional nights without bowel opening | 336  
weight increased by 2 kg to 54 kg | 336  
weaned off IV fluid support | 336  
resumed running | 336  
running-induced increase in bowel movements | 336  
ibuprofen 400 mg single dose induced liquid stools | 336  
plasma total cholesterol decreased from 7.5 to 5.9 mmol/L | 336  
LDL-cholesterol decreased from 4.5 to 3.1 mmol/L | 336  
HDL-cholesterol increased from 2.0 to 2.1 mmol/L | 336  
mean FGF19 during obeticholic acid increased from 35.7 to 167.0 pg/mL | 336  
FGF19 fluctuation range 21 to 728 pg/mL | 336  
EuroQol EQ-5D-3L wellbeing increased from 35 to 85 | 384  
maintained wellbeing at 85 for 6 months | 4320  
treatment pause started | 1440  
bowel movements increased from 7 to 16 | 1440  
profound hypokalemia during pause | 1440  
obeticholic acid restarted | 1512  
bowel control reestablished | 1512  
no adverse effects during 6-month follow-up | 4320  
stable control of Crohn’s disease | 4320  
stable control of epilepsy | 4320  
stable control of depression | 4320  
single episode serum pancreatic amylase increased to 266 U/L | 2000  
ultrasound normal pancreas and bile ducts | 2000  
p-amylase normalized | 2000  
acute pancreatitis not confirmed | 2000  
6-mercaptopurine resumed after pause | 2000  
chronic refractory diarrhea lasting 10 years | -87600  
history of recurrent depression (15-year duration) | -131400  
history of primary tonic-myoclonic epilepsy (15-year duration) | -131400  
diagnosed with colonic Crohn’s disease following diarrhea onset | -87600  
SeHCAT scintigraphy performed | -52560  
0 retention indicating severe bile acid malabsorption | -52560  
treatment with colestyramine | -52560  
treatment with colesevelam (prior) | -52560  
loperamide unresponsive (prior) | -52560  
codeine phosphate unresponsive (prior) | -52560