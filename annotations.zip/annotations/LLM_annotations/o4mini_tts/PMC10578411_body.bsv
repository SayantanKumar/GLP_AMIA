23 years old|0  
male|0  
presented to weight management program|0  
weight of 643 pounds (292 kg)|0  
BMI of 84.3 kg/m2|0  
mixed central and peripheral obesity|0  
genetic predisposition (family history of obesity in mother and sister)|0  
strong degrees of hunger|0  
food cravings|0  
binge-eating tendencies|0  
depression|0  
prediabetes|0  
hemoglobin A1c of 6.4%|0  
concern for obstructive sleep apnea|0  
presented to pediatric weight management clinic at 17 years old| -52560  
weight of 364 pounds (165 kg)| -52560  
BMI of 48.5 kg/m2| -52560  
started topiramate 75 mg daily| -52560  
phentermine 15 mg daily added| -52536  
lost approximately 25 pounds (11.3 kg)| -48240  
lost to follow-up several times| -26280  
inconsistent AOM use| -26280  
briefly restarted on phentermine| -25000  
briefly restarted on topiramate| -25000  
phentermine and topiramate for only a few weeks| -25000  
weight increased approximately 50 to 75 pounds (23–34 kg)| -25000  
re-established care in adult weight management clinic|0  
started phentermine 15 mg daily|0  
started topiramate 75 mg daily|0  
started metformin 500 mg daily|0  
seen virtually via telemedicine over the next year|0  
weight and BMI not obtained|0  
phentermine increased to 18.75 mg daily|4320  
topiramate increased to 50 mg twice a day|4320  
metformin increased to 500 mg twice a day|4320  
started bupropion extended release 150 mg daily|4320  
bupropion increased to 300 mg daily|8760  
returned to weight management clinic in person|8760  
weight and BMI remained largely unchanged|8760  
started semaglutide 0.25 mg weekly|8760  
started lower calorie diet|8760  
regularly scheduled registered dietician visits started|8760  
reported significant reduction in hunger|8800  
BMI began to decrease|8800  
semaglutide increased to 0.5 mg weekly|9480  
lost 209 pounds (95 kg)|17520  
BMI decreased to 66.5 kg/m2|17520  
hemoglobin A1c normalized to 5.0%|17520  
snoring improved|17520  
semaglutide increased to 1.0 mg weekly|19560  
lost additional 6 pounds (2.7 kg)|20280  
gained additional 11 pounds (5 kg)|21720  
overall stability on AOM regimen suggested|21720