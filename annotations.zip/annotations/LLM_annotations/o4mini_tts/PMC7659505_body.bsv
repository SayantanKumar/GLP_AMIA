51 years old | 0
woman | 0
type 2 diabetes diagnosed | -183960
hypertension diagnosed | -17520
hypercholesterolemia | 0
rheumatic disease treated with prednisolone 10 mg once daily | 0
depression | 0
borderline personality disorder | 0
normal birth weight (3,500 g) | -446760
experienced extreme hunger from early childhood | -402960
weighed 140 kg at age of 20 | -271560
highest weight 186 kg | -122640
gastric bypass operation (RYGB) underwent | -122640
obesity runs in family (paternal side) | 0
obesity runs in family (maternal side) | 0
no other known inherited diseases in the family | 0
screened for MC4R mutations | 0
volunteered to enter biobank project | 0
homozygous carrier of T allele of rs747681609 variant | 0
liraglutide administration started | 0
liraglutide dose increased to 1.2 mg daily | 168
liraglutide dose increased to 1.8 mg daily | 336
liraglutide dose increased to 2.4 mg daily | 504
liraglutide dose increased to 3.0 mg daily | 672
treatment continued until 16 weeks | 2688
weight 152.2 kg | 0
height 1.64 m | 0
BMI 56.6 kg/m2 | 0
systolic blood pressure 122 mmHg | 0
diastolic blood pressure 78 mmHg | 0
pulse 83 beats/min | 0
fasting plasma glucose 6.3 mmol/L | 0
fasting HbA1C 54 mmol/mol | 0
fasting serum insulin 66 pmol/L | 0
fasting C-peptide 1152 pmol/L | 0
triglycerides 2.41 mmol/L | 0
total fat mass 75.5 kg | 0
total lean mass 76.9 kg | 0
total fat 49.6 % | 0
iAUC glucose 439 mmol/L×min | 0
iAUC insulin 6217 pmol/L×min | 0
iAUC C-peptide 103623 mmol/mol×min | 0
impaired glucose tolerance (2-h OGTT) | 0
postprandial glucose 8.7 mmol/L at 2 h OGTT | 2
nausea | 0
stomach pain | 0
no side effects during remaining 12 weeks | 672
fell less hungry | 0
more satiated | 0
effect reduced in last 8 weeks | 1344
no additional weight loss between weeks 8 and 16 | 1344
weight 142.5 kg | 2688
BMI 53.0 kg/m2 | 2688
systolic blood pressure 112 mmHg | 2688
diastolic blood pressure 76 mmHg | 2688
pulse 67 beats/min | 2688
fasting plasma glucose 5.0 mmol/L | 2688
fasting HbA1C 49 mmol/mol | 2688
fasting serum insulin 48 pmol/L | 2688
C-peptide 1099 pmol/L | 2688
triglycerides 1.78 mmol/L | 2688
total fat mass 71.2 kg | 2688
total lean mass 71.3 kg | 2688
total fat 49.9 % | 2688
iAUC glucose 428 mmol/L×min | 2688
iAUC insulin 12027 pmol/L×min | 2688
iAUC C-peptide 130277 mmol/mol×min | 2688
postprandial glucose 6.4 mmol/L at 2 h OGTT | 2690
normalized to glucose tolerant | 2690