36-year-old|0  
woman|0  
poorly controlled type 1 diabetes mellitus|0  
on closed-loop insulin infusion therapy (t:slim CIQ)|0  
prescribed tirzepatide|−2160  
weight 192 lbs|−2160  
BMI 32.2 kg/m2|−2160  
HbA1c 9.4%|−2160  
three months later lost 50 lbs|0  
weight 142 lbs|0  
BMI 25.3 kg/m2|0  
severe nausea|0  
heartburn|0  
elected to continue tirzepatide|0  
last tirzepatide injection|−96  
acute worsening of nausea|−72  
acute worsening of heartburn|−72  
vomiting|−72  
inability to keep anything down|−72  
home urine ketone positive|0  
t:slim CIQ hypoglycemia report leading to suspension|0  
not checked capillary glucose|0  
treated hypoglycemia with glucose tablets|0  
alert on examination|0  
mild distress|0  
appropriate attachment of CLS|0  
appropriate attachment of CGM|0  
tachycardia (137 beats/min)|0  
tachypnea (35 breaths/min)|0  
elevated blood pressure (155/100 mm Hg)|0  
normal body temperature (98.6 °F)|0  
Kussmaul breathing|0  
dry oral mucosa|0  
CGM readings 40–180 mg/dL|0  
intermittent hypoglycemia|0  
total daily insulin dose 30 units|0  
prior total daily insulin dose ~70 units|−2160  
inaccurate Dexcom G6 CGM sensor readings|−72  
POC glucose 289 mg/dL|0  
serum glucose 322 mg/dL|0  
interstitial glucose 40 mg/dL|0  
hemoglobin 16.2 g/dL|0  
hematocrit 45.3%|0  
HbA1c 7.4%|0  
bicarbonate 12 mmol/L|0  
sodium 131 mmol/L|0  
potassium 5 mmol/L|0  
serum creatinine 1.00 mg/dL|0  
GFR 75 mL/min/1.73 m2|0  
anion gap 21 mmol/L|0  
urine hCG negative|0  
betahydroxybutyrate level ordered but not drawn|0  
no source of infection|0  
volume depletion|0  
diabetic ketoacidosis diagnosis|0  
removed CLS and CGM devices|0  
treated with continuous regular insulin|0  
initiated intravenous normal saline infusion|0  
serum glucose improved to 143 mg/dL|8  
anion gap closed to 8 mmol/L|8  
bicarbonate improved to 24 mmol/L|72  
transitioned to subcutaneous basal glargine and prandial lispro (TDD 24 units)|72  
transitioned back to t:slim CIQ and Dexcom G6 CGM at preadmission settings|72  
glycemic control within optimal range (TDD 37 units)|96  
outpatient follow-up|240  
glycemic control within optimal range at follow-up|240  
tirzepatide discontinued|240