54-year-old female | 0  
previously diagnosed with type 2 diabetes | 0  
morbid obesity (BMI 42 kg/m2) | 0  
laparoscopic gastric bypass with a 200 cm biliopancreatic limb | 0  
type 2 diabetes in clinical remission | 4320  
post-prandial episodes of sweating | 17520  
post-prandial episodes of fainting | 17520  
documented hypoglycemia (capillary blood glucose <50 mg/dl) | 17520  
appropriate nutrition | 17520  
not actively losing weight | 17520  
stabilized BMI of 30 kg/m2 | 17520  
abdominal ultrasound revealed a 1.8-cm solid mass in the pancreatic head | 17520  
abdominal CT scan confirmed a 1.8-cm solid mass in the pancreatic head | 17520  
octreotide scan showed a focus of abnormal uptake of the radiotracer in the topography of the pancreatic lesion | 17520  
lowest laboratory glucose recorded (65 mg/dl) | 17520  
parallel insulin recorded (3.3 μUI/ml) | 17520  
plasma chromogranin A level (4.1 ng/ml) | 17520  
72-h fast test was negative for hypoglycemia | 17520  
laparoscopic enucleation of the pancreatic nodule | 17600  
intraoperative pancreatic ultrasound revealed that the pancreatic nodule was more than 1 cm away from the pancreatic duct and there was no evidence of other nodules | 17600  
postoperative period was uneventful | 17600  
complete remission of the hypoglycemic episodes | 17600  
histology of the surgical specimen showed a pseudoglandular neuroendocrine neoplasia staining positive for CAM 5.2, chromogranin A, synaptophysin, glucagon and GLP1, and negative for insulin | 17600  
low Ki-67 (<2 %) and mitotic index (<1 mitosis/10c) | 17600  
PET-68Ga-SRP (DOTANOC) performed postoperatively excluded the existence of any residual disease | 17600  
frozen tumor sample was homogenized in 1 % (v/v) trifluoroacetic acid, extracts were purified and eluted with 70 % ethanol | 17600  
peptide hormone levels were measured by in-house developed RIAs | 17600  
tumor showed a high concentration of glucagon (26 707 pmol/g tissue) and traces of GLP1 (471 pmol/g), insulin (139 pmol/g) and somatostatin (23 pmol/g) | 17600