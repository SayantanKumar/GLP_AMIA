diagnosed with diabetes mellitus | -113880  
intravitreal anti-VEGF injections of aflibercept | -26280  
cataract surgery (right eye) | -26280  
referred to Hokkaido University Hospital | 0  
69 years old | 0  
male | 0  
residual diabetic CME | 0  
dyslipidemia | 0  
hypertension | 0  
subcutaneous dulaglutide injection | 0  
insulin lispro injection | 0  
serum HbA1c 6.0% | 0  
best-corrected visual acuity right eye 1.2 | 0  
best-corrected visual acuity left eye 0.5 | 0  
intraocular pressure normal | 0  
intraocular lens present (right eye) | 0  
mild cataract (left eye) | 0  
dot hemorrhages | 0  
hard exudates | 0  
pan-retinal photocoagulation scars | 0  
macular edema | 0  
foveal cystoid lesions | 0  
pars plana vitrectomy (left eye) | 2160  
cataract surgery (left eye) | 2160  
internal limiting membrane peeling | 2160  
removal of cystoid lesion component | 2160  
cystoid lesion component translucent soft solid | 2160  
tissue fixed in formalin overnight | 2160  
embedded in paraffin | 2160  
hematoxylin-eosin staining | 2160  
fluorescence immunohistochemical staining | 2160  
best-corrected visual acuity left eye 0.3 | 720  
CME subsided | 720  
CME recurred | 800  
sub-Tenon injection of triamcinolone acetonide | 1000  
direct photocoagulation for microaneurysms | 1000  
intravitreal aflibercept injection | 1000  
best-corrected visual acuity left eye 0.2 | 10920  
microscopic examination elliptical shape 0.7x0.4 mm | 2160  
homogeneous eosinophilic material without cellular components | 2160  
no membranous structure | 2160  
erythrocyte aggregates at margin | 2160  
immunohistochemistry positive for fibrin/fibrinogen | 2160  
immunohistochemistry weakly positive for AGEs | 2160  
immunohistochemistry negative for GFAP | 2160  
immunohistochemistry negative for RAGE | 2160  
immunohistochemistry negative for type 1 collagen | 2160  
immunohistochemistry negative control normal rabbit IgG | 2160