51 years old|0
male|0
referred to hospital|0
HbA1c high|0
height 162.8 cm|0
weight 63 kg|0
BMI 24.6 kg/m2|0
abdominal circumference 83.5 cm|0
diagnosed type 2 diabetes|0
SBP 106 mm Hg|0
DBP 66 mm Hg|0
triglyceride 231 mg/dL|0
HDL-C 48 mg/dL|0
LDL-C 141 mg/dL|0
creatinine 0.8 mg/dL|0
eGFR 80.1 mL/min/1.73 m2|0
no proteinuria|0
Albuminuria not detected|0
Sitagliptin started|0
metformin started|1440
TG 139 mg/dL improved|1440
HDL-C 40 mg/dL improved|1440
LDL-C 124 mg/dL improved|1440
eGFR gradual decrease|8640
eGFR 34.5 mL/min/1.73 m2|18000
metformin discontinued|18000
SBP 120 mm Hg|18000
DBP 74 mm Hg|18000
no microalbuminuria|18000
no auto-antibodies detected|18000
no drugs inducing renal injury detected|18000
continued home BP and weight monitoring|20160
masked hypertension|20160
diagnosed hypertensive nephrosclerosis|20160
ARB telmisartan started|20160
empagliflozin started|20160
reduction in HbA1c|20160
reduction in body weight|20160
eGFR 30.1 mL/min/1.73 m2|21600
eGFR 32.2 mL/min/1.73 m2|22320
eGFR 31.7 mL/min/1.73 m2|23760
empagliflozin dose increased|23760
eGFR 29.6 mL/min/1.73 m2|24480
eGFR 31.7 mL/min/1.73 m2|25920
empagliflozin stopped|25920
teneligliptin started|25920
eGFR 38.3 mL/min/1.73 m2|35280
eGFR 27.7 mL/min/1.73 m2|60480
oral semaglutide 3 mg started|60480
HbA1c 7.7%|60480
eGFR 33.6 mL/min/1.73 m2|60480
semaglutide dose increased to 14 mg|61200
HbA1c 6.8%|61200
eGFR 37 mL/min/1.73 m2|61200
body weight decreased|61200
SBP decreased|61200
postprandial glucose decreased|61200
peak daily glucose decreased|61200
average daily glucose decreased|61200
stable body weight|67680
stable glucose control|67680
stable eGFR ~35 mL/min/1.73 m2|67680