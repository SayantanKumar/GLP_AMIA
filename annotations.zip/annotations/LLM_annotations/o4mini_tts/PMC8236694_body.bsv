relapsing‐remitting multiple sclerosis|‐87600  
fasting blood glucose 8.0 mmol/L|‐17520  
fasting blood glucose 13.0 mmol/L|‐1440  
HbA1c 12.4%|‐1440  
diagnosed with steroid‐induced diabetes mellitus|‐1440  
fasting blood glucose values 9.5–12.7 mmol/L|‐1440  
postprandial blood glucose values 18.4–22.6 mmol/L|‐1440  
55 years old|0  
male|0  
admitted to hospital due to poor glycemic control|0  
without history of diabetes mellitus|0  
oral methylprednisolone dose reduction from 24 to 6 mg/day|0  
methotrexate 7.5 mg/week|0  
Tripterygium wilfordii 60 mg/day|0  
BMI 30.1 kg/m2|0  
height 168 cm|0  
weight 85 kg|0  
body temperature 36.5 °C|0  
blood pressure 124/75 mmHg|0  
pulse 75 beats/minute, regular|0  
hyperinsulinemia|0  
severe insulin resistance|0  
abnormal liver function tests (ALT 178 U/L, AST 198 U/L, γ-GTP 265 U/L)|0  
prescribed diammonium glycyrrhizinate enteric-coated capsules|0  
started insulin aspart 60 U/day|0  
started insulin glargine 26 U/day|0  
developed insulin allergy|72  
wheals with redness and itching at injection sites|72  
hypereosinophilia|72  
high total IgE|72  
biopsy showing eosinophilic infiltration|72  
changed insulin aspart to insulin lispro (glargine continued)|72  
total daily insulin dose >90 U/day|72  
poorly controlled fasting (~10 mmol/L) and postprandial (~18 mmol/L) hyperglycemia|72  
hepatic enzyme concentrations normalized|168  
added metformin 1.5 g/day|168  
started liraglutide 0.6 mg/day|336  
fasting and postprandial hyperglycemia significantly decreased|504  
blood glucose near normal (7.1 mmol/L)|504  
satiety without nausea or diarrhea|504  
induration at insulin injection sites diminished|504  
began reduction of insulin lispro dose|504  
began reduction of insulin glargine dose|504  
increased liraglutide dose to 0.9 mg/day then 1.2 mg/day|504  
discontinued insulin lispro|1776  
fasting blood glucose 5.2–6.7 mmol/L|1776  
HbA1c 8.6%|1776  
improvements in serum insulin and eosinophil levels|1776  
no further allergic symptoms at injection sites|1776  
body weight decreased by 6.8 kg|3216