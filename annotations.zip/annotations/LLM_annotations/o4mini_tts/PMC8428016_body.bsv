73-year-old|0
male|0
obese|0
Caucasian|0
diagnosed with T2DM| -35040
lifestyle modifications| -35040
metformin 1000 mg twice daily| -35040
chronic obstructive pulmonary disease|0
inhaled long-acting beta-adrenoceptor agonists daily|0
inhaled steroids daily|0
severe psoriasis| -52560
consulted many dermatologists| -26280
treated with adalimumab| -8760
adalimumab discontinued| -1440
came to our observation|0
HbA1c 7.9%|0
fasting glucose level 162 mg/dL|0
self-monitoring blood glucose showed poor control|0
height 158 cm|0
weight 106.7 kg|0
BMI 42.7|0
dermatology consultant photo-documented skin lesions|0
PASI 33.2|0
DLQI 26.0|0
semaglutide 0.25 mg/week started|0
semaglutide dose increased to 0.50 mg/week|672
semaglutide maintenance dose 1 mg once weekly reached|2688
dermatologist visit after 4 months|2688
PASI 8.0|2688
HbA1c 6.4%|2688
fasting glucose level 124 mg/dL|2688
BMI 40.3|2688
DLQI 3|2688
amelioration of quality of life|2688
patient refused reintroduction of adalimumab|2688
HbA1c 5.4%|7200
fasting glucose 98 mg/dL|7200
BMI 38.3|7200
PASI 2.6|7200
DLQI 0|7200