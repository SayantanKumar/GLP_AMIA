word “incretin” was coined by the Belgian physiologist La Barre|0  
infusion of exogenous GLP-1 agonists normalized fasting plasma glucose (Nauck et al 1993)|-271560  
GLP-1 inhibits secretion of pancreatic glucagon|0  
additional effects involving satiety slowed gastric emptying|0  
weight loss has made it a good option used by many doctors|0  
ADA treatment algorithm recommended GLP-1 receptor agonists for patients with ASCVD or CKD after uncontrolled metformin|0  
GLP-1 receptor agonists proposed to be associated with adverse effects including cancer, systemic complications, and hypoglycemia under combined treatments|0  
GLP-1 receptor agonists suggested to be associated with hypoglycemic symptoms in certain individuals (1998)|-227760  
subcutaneous GLP-1 injection after a 16-hour fast could cause hypoglycemia in healthy subjects|-16  
end of the 26-week randomized trial assessing addition of liraglutide to metformin (minor hypoglycemia comparable to placebo)|4368  
usage of incretin-mimetic therapies for 30 days to 2 years assessed for risk of acute pancreatitis|720  
26-week open-label trial comparing IDegLira, insulin degludec, or liraglutide (confirmed hypoglycemic events per patient-year)|4368