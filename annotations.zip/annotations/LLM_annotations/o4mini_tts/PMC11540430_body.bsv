started low-dose tirzepatide 2.5 mg subcutaneous once weekly | -672  
new-onset constipation | -672  
firm bowel movements once every 3 days | -672  
eating smaller, more frequent meals | -672  
lower abdominal cramping pain | -24  
urge to defecate | -24  
bloody stools | -24  
62 years old | 0  
female | 0  
obesity | 0  
body mass index 40 kg/m2 | 0  
prior venous thromboembolism | 0  
heart failure with preserved ejection fraction | 0  
up to date on colorectal cancer screening | 0  
previous colonoscopies had shown benign polyps | 0  
diverticulosis | 0  
did not take any over-the-counter supplements | 0  
did not take laxatives | 0  
medication: tirzepatide 2.5 mg subcutaneous once weekly | 0  
medication: apixaban 5 mg twice daily | 0  
medication: spironolactone 25 mg once daily | 0  
medication: furosemide 20 mg once daily | 0  
medication: atorvastatin 20 mg once daily | 0  
medication: fluoxetine 30 mg once daily | 0  
medication: lisinopril 2.5 mg once daily | 0  
medication: atenolol 37.5 mg once daily | 0  
presented to the hospital | 0  
hypertensive with blood pressure of 155/103 mm Hg | 0  
vital signs otherwise normal | 0  
soft, nondistended abdomen | 0  
mild diffuse lower tenderness | 0  
without guarding | 0  
white blood cell count of 12.0 ×10^9/L | 0  
normal hemoglobin | 0  
normal platelet count | 0  
international normalized ratio 1.6 | 0  
computed tomography scan of the abdomen and pelvis with contrast | 0  
bowel wall thickening | 0  
pericolonic fat stranding | 0  
mesenteric vasculature was patent | 0  
colonoscopy demonstrated inflammatory mucosal changes from the mid-sigmoid colon through the distal transverse colon | 0  
epithelial denudation and sloughing with necrosis | 0  
crypt withering | 0  
hyalinization of the lamina propria | 0  
lamina propria congestion and hemorrhage | 0  
diagnosis of colonic ischemia | 0  
admitted to the hospital | 0  
intravenous fluids | 0  
bowel rest | 0  
broad-spectrum antibiotics | 0  
intravenous ciprofloxacin | 0  
intravenous metronidazole | 0  
analgesics | 0  
apixaban held | 0  
furosemide held | 0  
spironolactone held | 0  
tirzepatide held | 0  
rapid spontaneous resolution of symptoms | 48  
weaned off opioid pain medications | 48  
discharged | 72  
apixaban resumed | 72  
diuretics held | 72  
oral ciprofloxacin | 72  
oral metronidazole | 72  
5-day antibiotic course started | 72  
clinic follow-up visit | 240  
no recurrence of rectal bleeding | 240  
intermittent recurrence of bloody bowel movements | 1512  
repeat colonoscopy | 1800  