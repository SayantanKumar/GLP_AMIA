79 years old|0  
male|0  
type 2 diabetes mellitus|0  
duration of diabetes mellitus 20 years|0  
hypertension|0  
metformin hydrochloride use|0  
glimepiride use|0  
dulaglutide use|0  
nifedipine CR use|0  
doxazosin mesylate use|0  
telmisartan use|0  
hydrochlorothiazide use|0  
miglitol 150 mg/day administration|-408  
hemoglobin A1c 8.6%|-408  
serum creatinine 1.50 mg/dL|-408  
leg edema|-336  
general malaise|-336  
acetaminophen administration|-240  
general fatigue|-240  
acetaminophen administration|-216  
appetite loss|0  
urgent hospital admission|0  
acute kidney injury|0  
serum creatinine 8.12 mg/dL|0  
white blood cell 8,200/µL|0  
eosinophil 100/µL|0  
hemoglobin 9.3 g/dL|0  
platelet 228,000/µL|0  
HbA1c 8.0%|0  
total protein 6.8 g/dL|0  
serum albumin 3.1 g/dL|0  
blood urea nitrogen 62 mg/dL|0  
serum sodium 136 mmol/L|0  
serum potassium 5.0 mmol/L|0  
serum chloride 100 mmol/L|0  
serum calcium 8.6 mg/dL|0  
serum phosphorus 5.2 mg/dL|0  
blood sugar 145 mg/dL|0  
eGFR 5.6 mL/min/1.73 m2|0  
CRP 10.87 mg/dL|0  
no post-renal AKI on computed tomography|0  
fractional excretion of sodium 9.43%|0  
fractional excretion of urea nitrogen 63.76%|0  
blood pressure 178/100 mmHg|0  
blood culture negative|0  
urine culture negative|0  
sputum culture negative|0  
low fever 37.5°C|0  
urinary β2-microglobulin 31,748 μg/L|0  
miglitol discontinued|0  
metformin hydrochloride discontinued|0  
glimepiride discontinued|0  
dulaglutide discontinued|0  
insulin therapy initiated|0  
drug-induced lymphocyte stimulation test for miglitol positive|0  
renal biopsy|264  
renal biopsy infiltration of lymphocytes, plasma cells, eosinophils|264  
diffuse mesangial expansion in glomeruli|264  
polar vasculosis in vascular poles|264  
hyalinosis of small arteries|264  
global sclerosis in 15/34 glomeruli (44.1%)|264  
urinary β2-microglobulin decreased to normal range|312  
serum creatinine gradually decreased|312  
gallium scintigraphy|384  
diffuse isotope uptake in both kidneys on gallium scintigraphy|384  
serum creatinine remained >4 mg/dL|528  
serum creatinine increased to 4.77 mg/dL|528  
oral prednisolone 30 mg initiated|528  
patient discharged|600  
serum creatinine remained >3 mg/dL|600