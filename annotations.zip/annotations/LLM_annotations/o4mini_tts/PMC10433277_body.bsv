39 years old|0  
male|0  
White|0  
obesity|0  
failure of nonpharmacologic strategies for weight reduction|0  
body mass index of 39.2 kg/m2|0  
no allergies|0  
no previous history of atopy|0  
no concomitant disease beyond obesity|0  
treatment with liraglutide administered subcutaneously|0  
initial dose of liraglutide 0.6 mg daily|0  
dose increase of liraglutide by 0.6 mg to 1.2 mg daily|168  
dose increase of liraglutide by 0.6 mg to 1.8 mg daily|336  
pruritic erythematous patches appeared on the injection sites|360  
the itch was negligible|360  
round erythematous plaques on the abdomen at the injection sites of liraglutide|360  
patch test with European baseline series conducted on back and abdomen|360  
patch test with propylene glycol (5% in petrolatum)|360  
patch test with liraglutide (6 mg/mL; aqueous solution)|360  
patch test with liraglutide (6 mg/mL; in petrolatum)|360  
skin prick test with liraglutide (6 mg/mL; aqueous solution) yielded a negative result|360  
intradermal test with liraglutide (6 mg/mL) diluted 1:10 in saline negative at 20th minute|360  
intradermal test with liraglutide (6 mg/mL) diluted 1:10 in saline in 5 healthy controls negative at 20th minute|360  
intradermal test with liraglutide (6 mg/mL) diluted 1:10 in saline positive at 24-hour reading|384  
intradermal test with liraglutide (6 mg/mL) diluted 1:10 in saline in 5 healthy controls negative at 24-hour reading|384  
patient refused skin biopsy|384  
patient refused histopathologic examination|384  
diagnosis of delayed hypersensitivity to liraglutide|384  
start symptomatic treatment with clobetasol propionate ointment 0.05% twice daily|384  
patch test reading day 2 no positive reaction|408  
patch test reading day 3 no positive reaction|432  
dose increase of liraglutide by 0.6 mg to 2.4 mg daily|504  
dose increase of liraglutide by 0.6 mg to 3 mg daily|672  
reached 3 mg daily|672  
continued treatment with liraglutide 3 mg daily|672  
end clobetasol propionate treatment|720  
start mometasone furoate ointment 0.1% once daily|720  
end mometasone furoate treatment|1440  
tolerate drug without any skin reaction at the end of treatment|1440  
tolerate drug without any skin reaction during 6-month follow-up|4320