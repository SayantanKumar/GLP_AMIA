84 years old|0  
woman|0  
presented to dermatology clinic|0  
diffuse bullous rash|0  
chronic kidney disease|0  
hyperthyroidism|0  
hypertension|0  
type II diabetes mellitus|0  
dulaglutide subcutaneous administration|−1344  
dulaglutide therapy|−1344  
mild erythematous rash|−672  
dulaglutide discontinued|−672  
tense bullous lesions with serous-hematic content spread over entire skin|0  
single blister on oral mucosa|0  
intense itching|0  
cutaneous biopsy taken|0  
eosinophilic papillitis with eosinophils along free border of dermal-papillary clefts|0  
IgG deposits on basement membrane|0  
C3 deposits on basement membrane|0  
neutrophilic leukocytosis|0  
elevation of inflammatory indices|0  
marked increase in total IgE|0  
BP180 positive >200 U/ml|0  
BP230 positive 31 U/ml|0  
diagnosis of bullous pemphigoid|0  
no recent infections|0  
no recent vaccinations|0  
tumor markers evaluated|0  
tumor markers negative|0  
dulaglutide was only newly introduced drug|0  
oral prednisone 25 mg/day prescribed|0  
oral doxycycline 100 mg twice/day prescribed|0  
topical drainage of bullous lesions|0  
topical eosin application|0  
restoration of previous diabetes therapy with addition of daily insulin glargine|0  
first follow-up visit (monthly)|720  
absence of new lesions|720  
gradual re-epithelialization of preexisting erosions|720