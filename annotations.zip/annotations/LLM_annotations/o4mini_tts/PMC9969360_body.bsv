motor vehicle accident | -17520  
enrolled in the Program of All-inclusive Care for the Elderly | 0  
left lower extremity pain | 0  
generalized weakness | 0  
major depressive disorder | 0  
Patient Health Questionnaire-9 evaluation suggested mild depression | 0  
HDL 47 mg/dL | 0  
LDL 97 mg/dL | 0  
total cholesterol 176 mg/dL | 0  
atherosclerotic cardiovascular disease risk of 20.3% indicated high-intensity statin therapy | 0  
atorvastatin 20 mg once daily | 0  
ezetimibe 10 mg once daily | 0  
carvedilol 12.5 mg twice daily | 0  
furosemide 20 mg once daily | 0  
diltiazem 120 mg twice daily | 0  
doxycycline hyclate 100 mg twice daily | 0  
fluoxetine 20 mg once daily | 0  
dulaglutide 0.75 mg once weekly | 0  
insulin glargine 10 units three times daily | 0  
insulin aspart 5 units once daily | 0  
lansoprazole 30 mg once daily | 0  
levothyroxine 200 mcg once daily | 0  
lorazepam 0.5 mg up to 3 times daily | 0  
warfarin 17.5 mg weekly | 0  
hypothyroidism | 0  
type II diabetes | 0  
atrial fibrillation | 0  
mechanical mitral valve | 0  
bacteremia/endocarditis antibiotic therapy | 0  
warfarin time in therapeutic range less than 50% | 0  
clinical pharmacist requested medication safety review | 24  
post-enrollment polypharmacy call | 24  
recommended change atorvastatin 20 mg to pravastatin 40 mg | 24  
recommended discontinue diltiazem 120 mg | 24  
recommended discontinue ezetimibe 10 mg | 24  
recommended change fluoxetine 20 mg to citalopram 10 mg | 24  
recommended change time of lansoprazole administration to bedtime | 24  
recommended discontinue lorazepam 0.5 mg | 24  
implemented change fluoxetine to citalopram 10 mg | 864  
implemented discontinue ezetimibe 10 mg | 864  
implemented change atorvastatin to pravastatin 40 mg | 864  
ordered pharmacogenomic test | 2088  
pharmacogenomic test results revealed decreased function of SLCO1B1 | 2088  
recommended monitor for signs of myopathy | 2088  
recommended decrease pravastatin to 20 mg | 2088  
recommended separate administration times of warfarin and citalopram | 2088  
reported minor left lower extremity pain primarily occurring at night | 2160  
reported improved well-being | 2160  
HDL 51 mg/dL | 5760  
LDL 70 mg/dL | 5760  
total cholesterol 134 mg/dL | 5760  
INR checked every 3 to 4 days | 5760  
INR more stable | 5760  
diet education provided to minimize future INR fluctuations | 5760  
MedWise Risk Score decreased from high risk to moderate risk | 5760  
reported improved mental health | 5760  
reported improved physical health | 5760