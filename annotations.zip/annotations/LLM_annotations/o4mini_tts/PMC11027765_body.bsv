38 years old|0
female|0
presented to the obesity clinic at primary care|0
no other medical illness|0
sister brought her to the clinic|0
aunt brought her to the clinic|0
partially willing to lose weight|0
no previous structured weight-loss trial|0
attempted to lose weight through dietary instructions sourced from different social media platforms|-720
modest efficacy and overall dissatisfactory outcomes|-720
first-degree family history of obesity|0
no one else in her family had super-super obesity|0
resides with aging parents and a housekeeper|0
height 146 cm|0
weight 193 kg|0
BMI 90.5 kg/m2|0
central obesity|0
blood pressure normal|0
regular pulse|0
prediabetes level of blood sugar|0
laboratory results normal|0
elevated risk of obstructive sleep apnea by STOP-BANG score|0
six pillars of lifestyle medicine assessed|0
no physical activity|0
no muscle-strengthening exercise engagement|0
spending most of daytime sitting or reclining at home|0
objective evidence of major mobility limitations on 400-m walk test|0
objective evidence of major mobility limitations on climbing one flight of stairs|0
daily diet mainly of sugary foods and drinks|0
daily diet mainly of ultra-processed foods|0
very little intake of fruits and vegetables|0
frequent sleep pattern interruption|0
unrefreshed 4-5 h of sleep|0
no smoking|0
no substance abuse|0
limited social connections|0
mental health generally stable|0
multidisciplinary team formed|0
preventive medicine physician lifestyle medicine training|0
family medicine physician lifestyle medicine training|0
health coach lifestyle medicine training|0
suggested starting a structured lifestyle intervention for 6 months|0
structured lifestyle intervention started|0
metformin prescribed|0
CPAP prescribed|0
plant-based diet implemented|0
reduced calorie consumption|0
gradually increasing physical activity|0
adheres to Harvard healthy eating plate|0
half plate non-starchy vegetables and fruits|0
one-quarter plate whole grains|0
one-quarter plate lean proteins|0
three balanced meals daily|0
stop eating snacks|0
discouraged sugar-sweetened beverages|0
discouraged high-fat foods|0
discouraged highly processed foods|0
drinking 2-3 L water and herbal teas|0
agreed on exercise plan based on fitness level and preference|0
walking 2 min three times daily at home|0
progressed to daily moderate-intensity walking for a non-continuous 15 min at home but sometimes outdoors|1440
resistance training for the upper limb using weightlifting with 10 repetitions three times daily|1440
progressed to resistance training sessions of 5-10 min, 2 days per week|2160
encouraged interrupt sitting with physical activity such as housecleaning, dishwashing, cooking, or moving|0
efforts to adjust bedtime and wake-up times|0
difficulty extending sleep duration|0
implement incremental approach advancing sleep schedule by 30 min each week|0
set wake-up time 30 min earlier|0
consistent use of CPAP therapy|0
increase nighttime sleep duration to 6 h|672
family support by sister influenced weight loss journey|0
spent 5 days a week at sister’s home for weight loss|0
sister ensured dietary recommendations were followed|0
purchased healthy food options together|0
prepared nutritious meals together|0
emphasized portion control and balanced diet|0
sister walked alongside patient|0
sister participated in resistance training|0
improved adherence to physical activity regimens|0
improved overall well-being|0
attending hybrid follow-up visits every 2 weeks for first 6 months|0
weight measurement monthly at clinic|0
lost 23 kg after 6 months lifestyle intervention|4320
percent weight loss 11.9% after 6 months|4320
patient came unaccompanied to clinic|4320
willing to continue weight management|4320
trust ability to lose weight|4320
liraglutide introduced|4320
lost additional 5 kg over 3 months of liraglutide|6480
total weight loss of 28 kg after 1 year of follow-up|8760
percent weight loss 14% after 1 year|8760
BMI decreased to 77.4 kg/m2 after 1 year|8760
regained ability to perform daily activities|8760
regained ability to take care of herself and others|8760
patient consent for publication obtained|0
no conflict of interest|0