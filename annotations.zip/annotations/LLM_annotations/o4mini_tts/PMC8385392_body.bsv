61 years old|0  
female|0  
presented|0  
type II diabetes mellitus|0  
glimepiride|0  
hypertension|0  
hyperlipidemia|0  
lichen sclerosus|0  
fibromyalgia|0  
chronic gingivitis|0  
rheumatoid arthritis|0  
cyclobenzaprine|0  
amitriptyline|0  
hydroxychloroquine|0  
oxycodone/paracetamol|0  
atorvastatin|0  
losartan|0  
chlorhexidine oral rinse|0  
clobetasol 0.05% cream|0  
erythematous lesion on breast|0  
crusted lesion on breast|0  
semaglutide|-720  
patient returned|720  
crusted erosion on breast|720  
crusted erosion on lower back|720  
erythema of gingivae|720  
edema of gingivae|720  
applied 2% ketoconazole cream|720  
applied 2.5% hydrocortisone cream|720  
skin biopsies obtained|720  
no mucosal biopsies taken|720  
subepidermal vesiculation|720  
mixed dermal infiltrate with many eosinophils|720  
linear IgG reactivity in n-serrated pattern|720  
linear C3 staining along basement membrane|720  
positive indirect immunofluorescence with IgG4 epidermal localization|720  
elevated anti-BP180 antibodies at 86 units|720  
non-elevated anti-BP230 antibodies at 1 unit|720  
diagnosis of BP|720  
no additional topical treatments used|720  
discontinued semaglutide|744  
marked improvement in cutaneous erosions|744  
reduced inflammation of gingivae|744  
follow up|3600  
mild gingival irritation consistent with baseline gingivitis|3600  
IIF titers repeated|3600  
IIF demonstrated IgG4 epidermal localization|3600  
elevated anti-BP180 antibodies at 69 units|3600  
non-elevated anti-BP230 antibody at 1 unit|3600