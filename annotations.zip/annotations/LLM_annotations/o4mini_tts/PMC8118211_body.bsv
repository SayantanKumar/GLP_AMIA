49-year-old|0  
female|0  
overweight|0  
hypertensive|0  
urban environment|0  
desensitization to insulin glulisine initiated|0  
skin prick test negative to insulin glulisine|-1  
skin prick test negative to latex|-1  
skin prick test negative to atopic panel|-1  
intradermal test positive to 1 U/ml insulin glulisine within an hour|-1  
patch test negative to insulin glulisine|-1  
patch test negative to latex|-1  
patch test negative to zinc|-1  
insulin specific-IgE negative|-1  
basophil degranulation test not performed|-1  
local reaction with pruritus|2.17  
erythema|2.17  
12 mm diameter edema|2.17  
reached 4 UI dose (cumulative 7.231111 U)|5.5  
local wheal reaction|6  
local flare reaction|6  
extensive induration|12  
erythema of injection sites|12  
resolution of induration and erythema|36  
premedication with 10 mg Desloratadine|24  
premedication with 10 mg Montelukast|24  
change of administration site|24  
8 UI maintenance daily dose reached|72  
1 month check-up appointment|720  
tolerating insulin glulisine injections|720  
palmar eczema|720  
emollient recommended|720  
re-epithelization creams recommended|720  
resolution of palmar eczema|744  
skin testing negative to insulin glargine|719  
desensitization to insulin glargine initiated|720  
12 units insulin glargine maintenance dose reached|792  