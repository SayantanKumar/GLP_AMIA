birth weight 7 pounds 1 ounces|-131400  
weight gain occurred during pre-kindergarten years|-87600  
weight gain worsened as he grew older|-43800  
non-responder to prior weight loss attempts|-720  
highest weight of 365 pounds based on outpatient records|-168  
15 years old|0  
Caucasian teenager|0  
male|0  
admitted to the hospital|0  
gasping for air|0  
emergency room visit|0  
vomiting|0  
diarrhea|0  
shortness of breath|0  
malaise|0  
bilateral lower extremity edema|0  
tachypnea in the 60s|0  
BNP level of 522 pg/mL|0  
elevated troponin level of 49 ng/mL|0  
sleep apnea diagnosed|0  
no drug allergies|0  
no mention of obesity on initial assessment notes|0  
bilateral atelectasis|0  
cardiomegaly|0  
congestion|0  
health insurance: Medicaid|0  
started on furosemide|1  
started on pressors|1  
started on continuous positive airway pressure therapy|1  
started on milrinone drip|1  
transferred to pediatric cardiac intensive care unit|1  
palliative care consultation requested|2  
taken to catheterization laboratory|3  
intubated briefly|3  
left ventricular ejection fraction 12–17%|3  
diagnosed with heart failure|3  
cardiac transplant consultation placed|4  
unable to be weaned off intravenous cardiac support|5  
diagnosed with prediabetes (Hgb A1c 6.1%)|6  
started on metformin XR 1000 mg once daily|6  
initial obesity medicine consultation requested|336  
extubated|336  
acetaminophen as needed|336  
carvedilol|336  
enoxaparin|336  
lisinopril|336  
melatonin|336  
metformin XR in current medications|336  
milrinone infusion|336  
spironolactone|336  
BP 116/85|336  
pulse 95|336  
weight 400 pounds|336  
BMI 71.6 kg/m2|336  
3L oxygen via nasal cannula|336  
oxygen saturation 92–93%|336  
electrolytes normal|336  
kidney function normal|336  
liver function normal|336  
thyroid function normal|336  
complete blood count significant for anemia with hemoglobin 9.7 g/dL|336  
HgbA1c 6.1%|336  
total cholesterol 103 mg/dL|336  
triglycerides 67 mg/dL|336  
HDL 19 mg/dL|336  
LDL 71 mg/dL|336  
physical exam: almost blind child with glasses|336  
physical exam: round-shaped facies|336  
physical exam: stubby hands|336  
physical exam: stubby feet|336  
no other dietary, lifestyle, exercise, sleep history found on inpatient record|336  
genetic testing for obesity: buccal swab sent|336  
telemedicine video call with caregiver|337  
no known family history of obesity|337  
hyperphagia behaviors and distress around food|337  
foraging behaviors|337  
exercise restriction due to shortness of breath|337  
encouraged to walk laps in ICU|337  
psychosocial: caregiver worried about heart condition|337  
no previous depression and anxiety history prior to hospitalization|337  
small group of friends and playing video games|337  
bullied in school|337  
attacked resulting in concussions|337  
transitioned to homeschooling|337  
24-h dietary recall|337  
urgent zoom meeting request from senior leadership, directors, and pharmacy team|338  
start liraglutide 3.0 mg|338  
start empagliflozin 5 mg once daily|338  
start pramlintide 15 mcg pre-meals|338  
discontinue metformin XR|338  
discontinue pramlintide|339  
lost 30 lbs|672  
weaned off milrinone infusion|672  
weaned off diuretics|672  
transferred from PCICU to step-down unit|672  
discharged home|2880  
lost 101 pounds|2880  
weight 299 pounds|2880  
BMI 49.9 kg/m2|2880  
left ventricular ejection fraction improved to 39%|2880  
continued on liraglutide 3.0 mg daily as outpatient|2880  
continued on empagliflozin as outpatient|2880