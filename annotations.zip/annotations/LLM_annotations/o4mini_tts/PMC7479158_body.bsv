30 years old | 0
female | 0
morbid obesity | 0
weight 95 kg | 0
BMI 36 kg/m2 | 0
newly diagnosed with type II diabetes | 0
treated with oral medication | 0
laparoscopic sleeve gastrectomy performed | 0
preoperative complete blood count normal | 0
preoperative coagulation profile normal | 0
preoperative renal profile with electrolyte normal | 0
preoperative liver profile normal | 0
preoperative lipid profile normal | 0
preoperative hormones normal | 0
preoperative chemistry normal | 0
preoperative vitamins normal | 0
electrocardiography extreme axis deviation with upright P waves in AVR and inverted P waves in I and II | 0
echocardiography revealed dextrocardia | 0
chest X-ray revealed dextrocardia | 0
barium meal test revealed right-sided stomach with no contrast obstruction | 0
ultrasound of abdomen revealed normal gall bladder | 0
preoperative evaluation by cardiology agreed fit | 0
preoperative evaluation by endocrinology agreed fit | 0
preoperative evaluation by anesthesia agreed fit | 0
preoperative evaluation by respirology agreed fit | 0
induction of general anesthesia | 0
intubation | 0
patient positioned in reverse Trendelenburg French method | 0
skin preparation and draping performed | 0
carbon dioxide insufflation at 12 mmHg started | 0
11 mm bladeless trocar inserted supra-umbilical region | 0
10 mm 30° scope examined peritoneal cavity | 0
peritoneal cavity revealed right-sided stomach and spleen and left-sided liver and gallbladder | 0
monitor positioned at patient’s right shoulder | 0
surgeon stood between patient’s legs | 0
nursing assistant on patient’s left side | 0
15 mm bladeless trocar inserted left upper quadrant | 0
12 mm bladeless trocar inserted right upper quadrant | 0
laparoscopic liver retractor used to lift hepatic lobe | 0
dissection of gastrocolic ligament started | 0
dissection of gastrosplenic ligament performed | 0
first stapling with Endo GIA black 60 mm reload 2 cm proximal to pylorus | 0
36 Fr calibrating tube inserted orally up to pylorus | 0
remainder stapled with Endo GIA purple 60 mm reload ending 2 cm lateral to GEJ | 0
staple line reinforced with 10 mm Endo clips | 0
calibrating tube pulled to GEJ | 0
methylene blue leak test with 150 ml performed revealing no leak | 0
calibrating tube removed completely | 0
interrupted 2.0 vicryl gastropexy stitches placed | 0
5 mm free gravity drain inserted at RUQ near GEJ | 0
resected stomach removed from 15 mm port | 0
port sites closed with 1 vicryl and Endo closure | 0
skin closed with 3.0 monocryl subcuticular | 0
surgical duration 28 min | 0
no surgical complications | 0
no anesthesia complications | 0
patient extubated without problems | 0
transferred to recovery room in good condition | 0
oral fluid intake started | 6
gastrografin leak test performed | 24
gastrografin leak test revealed no leak | 24
drain removed | 24
meeting with dietitian before discharge | 24
patient discharged | 24
follow-up outpatient clinic visit at 1 week | 168
early postoperative complications excluded | 168
wound care performed | 168
follow-up at 3 months | 2160
weight 83 kg | 2160
follow-up at 6 months | 4320
weight 75 kg | 4320
follow-up at 12 months | 8640
weight 63 kg | 8640
good glycemic control observed | 8640
taken off medications | 8640
cesarean section | -17520
SIT diagnosed | -17520
dieting | -720
exercise | -720
medical treatment | -720
liraglutide injection | -720