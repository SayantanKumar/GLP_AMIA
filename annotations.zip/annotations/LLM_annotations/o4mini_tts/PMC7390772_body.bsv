LASIK| -87600
penetrating keratoplasty (PKP)| -35040
Baerveldt glaucoma drainage implant implantation| -30660
consistent wearing of scleral contact lens without issues| -5040
follow-up visit in October 2016: lens uncomfortable (“wants to pop out”)| -5040
37-year-old man| 0
male| 0
initial pain presentation| 0
pronounced left eye pain characterized as a dull ache without associated redness, light sensitivity, or vision changes| 0
ocular pain refractory to office treatment with topical proparacaine| 0
using dorzolamide/timolol| 0
using loteprednol| 0
using artificial tears in the left eye| 0
no prior history of headache syndrome| 0
no prior history of anxiety| 0
no prior history of depression| 0
type 2 diabetes mellitus| 0
obesity| 0
obstructive sleep apnea| 0
taking liraglutide| 0
taking lorcaserin| 0
left-sided headaches localized to the left temple region| 0
visual acuity of 20/20 with contact lens correction| 0
intraocular pressure of 20 mm Hg| 0
equal, reactive pupils without an afferent pupillary defect| 0
extraocular motility full| 0
confrontational visual fields full| 0
mild ptosis| 0
well-covered glaucoma drainage implant plate and tube| 0
trace injection of the conjunctiva| 0
clear penetrating keratoplasty (PKP)| 0
deep and quiet anterior chamber| 0
0.3 cup-to-disc ratio| 0
sharp foveal light reflex| 0
normal retinal vasculature and periphery| 0
pain severity increasing and limiting work functions and interfering with sleep| 1008
associated burning sensation as the most intense feature of pain| 1008
evaluated by cornea subspecialist| 1008
evaluated by uveitis subspecialist| 1008
evaluated by oculoplastics subspecialist| 1008
evaluated by optometric subspecialist| 1008
magnetic resonance imaging of the brain and orbit showed enlarged left lacrimal gland| 1008
no signs or symptoms of inflammation on history and physical examination| 1008
MRI finding incompatible with dacryoadenitis| 1008
uveitis work-up noted tenderness over aqueous shunt bleb| 1008
negative for posterior scleritis with normal B-scan ultrasonography| 1008
started trial of ibuprofen 800 mg three times daily| 1008
use of fluorometholone twice daily OS temporarily alleviated pain| 1008
use of oral prednisone 60 mg daily temporarily alleviated pain| 1008
intermittent 1+ Meibomian gland dysfunction and blepharitis without corneal epithelial disruption| 2160
intermittent 1+ flare in the anterior chamber| 2160
slit-lamp examination of the right eye entirely within normal limits| 2160
discontinued ibuprofen 800 mg three times daily| 3168
pain characterized as a waxing and waning retrobulbar ache| 3600
endorsed redness and swelling of the left eye| 3600
started gabapentin 300 mg twice daily| 5760
reported pain as 0 out of 10| 6264
able to tolerate normal wear of scleral contact lens| 6264