72-year-old | 0  
male | 0  
obese | 0  
body mass index: 34.2 kg/m2 | 0  
diabetic patient | 0  
poor glucose control | 0  
HbA1c: 10.8% | 0  
overt proteinuria | 0  
diabetes duration over 20 years | 0  
started basal insulin | 0  
started dipeptidyl peptidase 4 inhibitor | 0  
hypertension | 0  
dyslipidemia | 0  
beta-blocker | 0  
carvedilol (5 mg/day) | 0  
ARB | 0  
azilsartan (40 mg/day) | 0  
Ca2+ channel blocker | 0  
nifedipine (40 mg/day) | 0  
alpha-blocker | 0  
doxazosin (8 mg/day) | 0  
rosuvastatin (2.5 mg/day) | 0  
HbA1c below 7% | 24  
serum creatinine 1.25 mg/dL | 26280  
started empagliflozin (25 mg/day) | 37230  
started liraglutide | 43800  
renal function deterioration | 74460  
serum BUN 40 mg/dL | 74460  
creatinine 2.43 mg/dL | 74460  
eGFR 22 mL/min/1.73 m2 | 74460  
blood pH 7.33 | 74460  
metabolic acidosis | 74460  
CKD stage G4 | 74460  
started sodium bicarbonate | 74460  
started spherical carbonaceous adsorbent | 74460  
started finerenone | 74460  
hyperuricemia | 74460  
serum uric acid 7.9 mg/dL | 74460  
started dotinurad | 74460  