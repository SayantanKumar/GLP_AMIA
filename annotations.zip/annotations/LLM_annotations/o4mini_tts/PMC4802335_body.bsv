37 years old|0  
male|0  
bradycardia|0  
asthma|0  
gout|0  
no diabetes|0  
laparoscopic RYGB|−13140  
lost 88 kg|−4380  
BMI reduced to 27.7 kg/m2|−4380  
admitted to hospital|0  
neuroglycopenic symptoms|0  
relieved by consumption of carbohydrates|0  
plasma–glucose 1.6 mmol/l|0  
used standard nutritional supplements|0  
no drugs|0  
rarely alcohol|0  
serum–cortisol normal|0  
thyroid function tests normal|0  
cerebral CT scan normal|0  
abdominal CT scan normal|0  
cardiac evaluation normal|0  
72 h fast|0  
plasma–glucose after a 72 h fast normal|0  
dietary modifications|0  
self-monitoring of blood–glucose|0  
hypoglycaemic episodes increased in frequency|336  
hospital admissions increased in frequency|336  
acarbose attempted|336  
gastrointestinal side effects|336  
diazoxide 600 mg daily|336  
dyspnea|336  
diazoxide discontinued|336  
verapamil not considered|336  
octreotide 50 mcg three times daily|336  
less severe PHH|336  
alanine transaminase increased|336  
aspartate transaminase increased|336  
PHH effect of octreotide attenuated|336  
severe symptomatic hypoglycaemia occurred daily|336  
hospital admission for glucose infusions|336  
mixed meal test PO|168  
gastrostomy tube feeding started|336  
laparoscopic positioning of the gastrostomy tube|336  
subileus|336  
reoperation|336  
mixed meal test GT1|504  
mixed meal test GT2|1008  
recurrent abdominal pain|1680  
dependence on continuous parenteral glucose infusions|1680  
hypoglycaemia unawareness|1680  
reduced oral feeding did not prevent hypoglycaemia|1680  
increased nutrition through gastric tube|1680  
partial reversal of RYGB|2016  
gastrostomy tube removed|2016  
alimentary limb transected 6 cm below gastro–jejunostomy|2016  
remnant stomach to small bowel anastomosis created|2016  
biliopancreatic limb divided|2016  
side-to-side entero–entero anastomosis created|2016  
mixed meal test POr|2688  
no hypoglycaemic symptoms postoperatively|2688  
constipation|2688  
constipation corrected by barium enema|2688  
returned to work|3024  
reviewed|3456  
no hypoglycaemic symptoms at 2 months|3456  
body weight 87.3 kg|3456  
continuous glucose monitoring plasma–glucose around 5 mmol/l|4176  
no hypoglycaemic symptoms at 3 months|4176  
provocations with high glycaemic meals|4176  
body weight 94 kg|9216  
dyspepsia|9216  
upper endoscopy normal|9216  
infrequent low blood glucose levels|9216  
lowest blood glucose 2.7 mmol/l|9216  
no hypoglycaemic symptoms at 10 months|9216