26 years old|0
male|0
presented to hospital emergency department|0
agitation|-4
shortness of breath|-4
abdominal pain|-4
fatigue|-96
malaise|-96
fever|-96
sore throat|-96
T2DM diagnosis|-61320
metformin treatment|-61320
multiple oral hypoglycemic agents|0
poorly controlled diabetes|0
no history of recent travel|0
dry oral mucosa|0
distress|0
febrile (38.5 °C)|0
tachycardia (110 beats per minute)|0
tachypnea (28 breaths per minute)|0
low blood pressure (110/50 mmHg)|0
2 L normal saline infusion|-2
BMI of 41.52 kg/m2|0
morbid obesity|0
non-exudative pharyngitis|0
shallow breathing|0
bilateral vesicular breathing without added sounds|0
sinus tachycardia|0
mild epigastric tenderness|0
hyperglycemia (13.6 mmol/L)|0
metabolic acidosis|0
bicarbonate level 4 mmol/L|0
venous blood pH 6.84|0
high anion gap 34|0
urine ketone level 15 mmol/L|0
lactic acid normal (2 mmol/L)|0
leukocytosis (WBC 29×10^9/L)|0
hemoglobin 16.4 g/L|0
platelet count 350×10^9/L|0
C-reactive protein 64 g/L|0
procalcitonin 2.3 ng/mL|0
toxicology screen negative|0
sodium 135 mmol/L|0
potassium 3.8 mmol/L|0
creatinine 85 μmol/L|0
urea 4 mmol/L|0
no rhabdomyolysis (CK 223 IU/L)|0
serum osmolality 315 mOsm/kg|0
liver function tests normal|0
thyroid tests normal|0
broad-spectrum antibiotic therapy started|0
DKA protocol initiated (insulin bolus 10 units and infusion)|0
insulin infusion rate 1 unit/hour|0
chest x-ray normal|0
HbA1c 13.3%|0
C-peptide 0.11 nmol/L|0
anti-IA2 antibodies negative|0
GAD antibodies negative|0
insulin antibodies negative|0
additional crystalloid 5 L|1
sodium bicarbonate infusion (250 mL of 8.4%)|2
respiratory distress developed|3
assisted ventilation required|3
renal replacement therapy initiated|4
intermittent hemodialysis sessions (3 sessions)|4
continuous veno-venous hemodiafiltration at 30 mL/kg/hour|4
additional sodium bicarbonate boluses|5
metabolic team consulted|12
urine organic acid profile peaks (ketosis markers)|13
home medications brought by family|18
gliclazide 120 mg daily|18
canagliflozin 300 mg daily (home med)|18
pioglitazone 30 mg daily|18
liraglutide 1.8 mg injection|18
metformin/sitagliptin 1000/50 mg twice daily|18
serial capillary ketone measurement started|38
dextrose escalation started|38
intravenous potassium replacement started|38
significant diuresis noted (first 24 hours)|24
blood cultures negative|48
sputum cultures negative|48
urine cultures negative|48
influenza screen negative|48
Strep A negative|48
HIV test negative|48
hepatitis B and C negative|48
respiratory viral panel positive for adenovirus|48
resolution of metabolic acidosis (anion gap closed)|62
extubation|96
ketonemia persistent (>0.6 mmol/L)|96
shifted to basal–bolus insulin regimen|120
provoked femoral line site deep venous thrombosis|192
pulmonary embolism|192
anticoagulant therapy started|192
ketonemia resolved|288
discharge|384