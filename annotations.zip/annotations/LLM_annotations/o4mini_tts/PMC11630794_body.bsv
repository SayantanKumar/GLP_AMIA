atorvastatin 40 mg use started | -46800  
discontinuation of atorvastatin | -12240  
rosuvastatin 5 mg use started | -7200  
progressive proximal muscle weakness | -2160  
extreme muscle pain | -2160  
difficulty climbing stairs | -2160  
difficulty rising from a chair | -2160  
64 years old | 0  
Caucasian | 0  
male | 0  
presented to the clinic | 0  
history of type 2 diabetes mellitus | 0  
hypertension | 0  
hyperlipidemia | 0  
metabolic dysfunction-associated steatotic liver disease | 0  
Gilbert syndrome | 0  
coronary artery disease | 0  
reduced muscle strength | 0  
moderate to significant weakness in biceps, triceps, and shoulder girdles | 0  
good strength in wrists and hands | 0  
significant weakness in hip muscles | 0  
good strength at the knee and ankles | 0  
total CK elevated at 232.48 µkat/L | 0  
rhabdomyolysis | 0  
no history of autoimmune disease | 0  
no fevers | 0  
no chills | 0  
no joint pain | 0  
no dysphagia | 0  
AST elevated at 3.88 µkat/L | 0  
ALT elevated at 9.73 µkat/L | 0  
potassium 5.5 mmol/L | 0  
renal function tests normal | 0  
statin discontinued | 0  
dulaglutide discontinued | 0  
syncopal episode | 504  
no evidence of a neurological event | 504  
no ischemia | 504  
CK increased to 275.0167 µkat/L | 504  
ALT 9.71 µkat/L | 504  
AST 5.35 µkat/L | 504  
aldolase elevated at 1.0717 µkat/L | 504  
aggressive intravenous hydration | 504  
CK improved to 153.333 µkat/L | 504  
right upper quadrant ultrasound normal | 504  
renal function tests normal | 504  
thyroid function tests normal | 504  
electromyography demonstrating diffuse myopathy | 520  
myotonic discharges | 520  
fibrillation potentials | 520  
complex repetitive discharges | 520  
sharp waves | 520  
mild decrease in FEV and FVC consistent with neuromuscular weakness | 520  
left vastus lateralis muscle biopsy showing scattered necrotic and regenerating fibers | 520  
IMNM diagnosis | 520  
anti-HMGCR antibody levels > 200 CU | 520  
anti-SRP IFA negative | 520  
colonoscopy unremarkable | 520  
whole-body FDG PET/CT not completed due to hyperglycemia | 520  
prednisone 40 mg daily started | 530  
intravenous immunoglobulin 2 g/kg over 5 days monthly for 3 months started | 540  
ezetimibe 10 mg started | 540  
evolocumab 140 mg subcutaneous started | 540  
recommendation to re-evaluate lipid panel in 2 to 3 months | 540  
CK lowered to 94.73 µkat/L | 1250  
CK normalized to 1.05 µkat/L | 2700  
plan continue IVIG 2 g/kg monthly for 3 more months | 2700  
plan decrease IVIG to 1 g/kg monthly | 2700  
prednisone taper planned | 2700  
methotrexate replacement planned | 2700