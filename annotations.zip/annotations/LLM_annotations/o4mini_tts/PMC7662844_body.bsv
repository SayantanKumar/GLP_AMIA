73-year-old man | 0  
male | 0  
admission to hospital | 0  
imbalance of type 2 diabetes | 0  
anorexia | 0  
weight loss of 8 kg | -1460  
diarrhea | 0  
tetany attacks | 0  
initial DPP4 inhibitor therapy | 0  
Metformin therapy | 0  
Glimipiride therapy | 0  
adjustment to Abasaglar | -2160  
initiation of Liraglutide | -2160  
abdominal pain | 0  
conscious | 0  
normocardial | 0  
normotensive | 0  
eupneic | 0  
apyretic | 0  
body temperature 36.7 °C | 0  
weight 84 kg | 0  
height 1.69 m | 0  
BMI 29.13 | 0  
negative Chvostek sign | 0  
negative Trousseau sign | 0  
ECG without signs of hypocalcemia | 0  
normal PTH plasma concentration (21.51 ng/l) | 0  
low vitamin D level (53.7 nmol/l) | 0  
initial sodium 139 mmol/l | 0  
initial potassium 3.2 mmol/l | 0  
initial chloride 98 mmol/l | 0  
initial CO₂ 24 mmol/l | 0  
initial glycemia 6.80 mmol/l | 0  
initial urea 5.20 mmol/l | 0  
initial creatinine 73 µmol/l | 0  
initial CKD-EPI clearance 88 ml/min/1.73 m² | 0  
initial calcium 1.52 mmol/l | 0  
initial albumin 37 g/l | 0  
initial prealbumin 0.17 g/l | 0  
initial corrected calcium 1.60 mmol/l | 0  
initial phosphorus 1.22 mmol/l | 0  
initial magnesium < 0.1 mmol/l | 0  
initiation of IV electrolyte supplementation | 0  
initiation of ECG monitoring | 0  
administration of calcium gluconate 8 g over 24 h | 0  
administration of magnesium sulfate 4 g over 24 h | 0  
administration of potassium chloride 2 g over 24 h | 0  
normalization of serum electrolytes (Ca, Mg, K) | 48  
elevation of PTH concentration | 48  
improvement of glycemic control | 48  
oral Magnesium Pidolate intake maintained | 48  
urinary magnesium excretion 7.53 mEq/24 h | 72  
discontinuation of Liraglutide therapy | 48  
improvement of digestive disorders | 48  
absence of hypoparathyroidism | 48  
suspected causal link to Liraglutide | 48  