32 years old|0  
woman|0  
Prader–Willi syndrome|0  
diagnosed with diabetes|−192720  
recommended strict low-carbohydrate diet|−96360  
bodyweight was 54 kg|−96360  
bodyweight increased up to 67 kg|−312  
received glimepiride (2 mg/day)|−312  
received metformin (2 250 mg/day)|−312  
received linagliptin (5 mg/day)|−312  
discontinued glimepiride|−312  
discontinued metformin|−312  
discontinued linagliptin|−312  
started ipragliflozin (50 mg/day)|−312  
polyuria|−312  
bodyweight decreased by approximately 3 kg|−312  
epigastralgia|−48  
water intake decreased|−48  
dietary intake decreased|−48  
tachypnea|−24  
visited emergency room|0  
severe acidosis|0  
ketonuria|0  
ketonemia|0  
normal lactate level|0  
no abnormalities on chest X-ray|0  
no abnormalities on electrocardiogram|0  
no abnormalities on abdominal computed tomography|0  
no abnormalities on urinary sediments|0  
no infectious diseases|0  
diagnosed with ketoacidosis|0  
initiated continuous intravenous insulin|0  
initiated Ringer’s solution infusion|0  
initiated glucose infusion|0  
antiglutamic acid decarboxylase antibody negative|0  
islet antigen-2 antibody negative|0  
insulin autoantibody negative|0  
serum C-peptide 0.4 ng/mL|0  
urinary C-peptide undetectable|0  
plasma glucose 191 mg/dL|0  
HbA1c 9.3%|0  
glycated albumin 19.6%|0  
no alcohol consumption|0  
no excessive soft drink consumption|0  
ketoacidosis improved|48  
bodyweight increased by approximately 2 kg|48  
continued basal–bolus insulin therapy|48  
urinary C-peptide increased up to 40.2 μg/day|144  
treated with insulin glargine (24 units/day)|168  
treated with lixisenatide (20 μg/day)|168  
treated with metformin (2 250 mg/day)|168  
nutritionist instructed 1 500-kcal diet|168  
diet containing 210 g carbohydrate/day|168  
one month later HbA1c 6.8%|720  
one month later glycated albumin 13.7%|720