36-year-old woman|0  
presented in January 2024|0  
2-month history of waxing and waning rash affecting her axillae and inframammary area|0  
minimally pruritic|0  
denied systemic symptoms|0  
denied oral lesions|0  
obesity (BMI 36.5 kg/m2)|0  
nephrolithiasis|0  
multivitamins|0  
fish oil|0  
levonorgestrel IUD|0  
initial evaluation in our clinic|0  
ill-defined erythematous patches with minimal fine scale lacking vesicles, pustules, or satellite lesions in the axillary and inframammary folds|0  
no lymphadenopathy|0  
no mucosal lesions|0  
potassium hydroxide examination deferred|0  
differential diagnosis of contact dermatitis|0  
differential diagnosis of symmetrical drug-related intertriginous and flexural exanthema|0  
differential diagnosis of erythema annulare centrifugum|0  
started hydrocortisone 2.5% ointment twice daily|0  
started 21-day taper of prednisone 40 mg|0  
initiation of weekly injections of compounded semaglutide (0.25-0.75 mg; Olympia Pharmaceuticals)|-1800  
rash onset|-1440  
associated burning pain|-1440  
visited urgent care on several occasions for the rash|-720  
prescribed clotrimazole-betamethasone 1%/0.05% cream|-720  
prescribed ketoconazole 2% cream|-720  
prescribed hydrocortisone 2.5% cream|-720  
prescribed fluconazole 150 mg|-720  
rash spread down the abdomen|240  
ongoing burning pain|240  
instructed to stop treatment|240  
rash began resolving after skipping semaglutide doses|336  
rash reappeared rapidly 3 days after most recent injection|432  
returned for biopsy three weeks after initial evaluation|504  
reported missing 2 consecutive doses of semaglutide in the past 3 weeks|504  
exam revealed annular erythematous patches with prominent trailing scale in the axillary and inframammary folds|504  
punch biopsy from the left axilla performed|504  
subcorneal pustular dermatosis with parakeratosis, mild acanthosis, mild spongiosis, and a lymphocytic and neutrophilic infiltrate in the superficial dermis|504  
periodic acid–Schiff stain negative|504  
differential diagnosis of AGEP|504  
differential diagnosis of Sneddon–Wilkinson disease|504  
differential diagnosis of early evolving pustular psoriasis|504  
diagnosis of AGEP sine pustules|504  
Naranjo adverse drug reaction probability score of 9|504  
AGEP validation score of 6|504  
semaglutide discontinued|504  
eruption cleared within 2 weeks|840  
consideration of patch testing|840  
patch testing deferred|840