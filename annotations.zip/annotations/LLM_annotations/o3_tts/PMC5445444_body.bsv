53-year-old man | 0  
male | 0  
type 2 diabetes mellitus (15-year history) | -131400  
vertigo | -720  
MRI: 1.2-cm pituitary macroadenoma | -720  
hypertension | -720  
obstructive sleep apnea | -720  
obesity | -720  
hyperlipidemia | -720  
bilateral carpal tunnel syndrome | -720  
arthralgia | -720  
screening IGF-1 551 ng/mL (uncontrolled) | -168  
screening GH 1.7 ng/mL (elevated) | -168  
fasting plasma glucose 140 mg/dL | -168  
HbA1c 7.5 % | -168  
metformin 1000 mg b.i.d. | -168  
pioglitazone 45 mg q.d. | -168  
glipizide ER 10 mg q.d. | -168  
refused pituitary surgery | 0  
enrolled in C2305 study | 0  
octreotide 20 mg IM q28d started | 0  
baseline IGF-1 487.4 ng/mL (elevated) | 0  
baseline GH 1.7 ng/mL (elevated) | 0  
baseline HbA1c 8.5 % | 0  
baseline FPG 147 mg/dL | 0  
after 3 months: IGF-1 344.1 ng/mL elevated | 2160  
after 3 months: GH 1.6 ng/mL elevated | 2160  
octreotide dose increased to 30 mg q28d | 2160  
HbA1c 8.5 % persists | 2160  
insulin aspart 10 units at dinner added | 2160  
after 12 months: IGF-1 383.9 ng/mL elevated | 8640  
after 12 months: GH 1.0 ng/mL | 8640  
HbA1c 7.3 % | 8640  
FPG 147 mg/dL | 8640  
cross-over to pasireotide 40 mg IM q28d | 8640  
first month pasireotide: FPG 162 mg/dL | 9360  
after 3 months pasireotide: IGF-1 246.7 ng/mL | 10800  
after 3 months pasireotide: GH 0.6 ng/mL | 10800  
pasireotide dose increased to 60 mg q28d | 10800  
FPG 146 mg/dL | 10800  
after 6 months pasireotide: IGF-1 193.0 ng/mL (normalized) | 12960  
after 6 months pasireotide: GH 0.2 ng/mL | 12960  
FPG 131 mg/dL | 12960  
HbA1c 7.1 % | 12960  
insulin detemir 85 units b.i.d. (dose increase) | 15120  
sitagliptin 50–100 mg q.d. added | 20160  
IGF-1 226.8 ng/mL (slightly high) | 23760  
IGF-1 283.5 ng/mL (slightly high) | 25920  
IGF-1 288.4 ng/mL (slightly high) | 28080  
IGF-1 231.8 ng/mL (slightly high) | 43200  
liraglutide 0.6 mg q.d. started (replacing sitagliptin) | 45360  
liraglutide dose increased to 1.2–1.8 mg q.d. | 47520  
weight decreased from 282 lb to 258 lb | 48960  
GH ≤0.6 ng/mL maintained | 48960  
HbA1c stable (6.7–7.8 %) | 48960