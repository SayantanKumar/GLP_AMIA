28-year-old | 0
female | 0
accidental injection of liraglutide 18 mg subcutaneously | -1
presented to emergency department | 0
epigastric abdominal pain | -0.5
abdominal pain radiating to back | -0.5
nausea | -0.5
vomiting | -0.5
sweating | -0.5
diabetes mellitus type II | -1000
obesity | -1000
weight 109 kg | -1000
body mass index 40.5 kg/m2 | -1000
metformin 500 mg twice daily | -1000
multivitamin daily | -1000
vital signs within normal | 0
blood glucose 4.6 mmol/L | 0
normal conscious level | 0
soft and lax abdomen | 0
no focal tenderness | 0
venous blood gas pH 7.40 | 0
PCO2 42 mmHg | 0
HCO3 25.2 mEq/L | 0
lactate 0.6 mmol/L | 0
mild hypokalemia 3.2 mmol/L | 0
electrolyte panel within normal | 0
renal panel within normal | 0
normal lipase level | 0
normal amylase level | 0
normal C-peptide level | 0
observation for 16 h | 0
persistent epigastric abdominal pain | 0
persistent vomiting | 0
first bolus dextrose 50% (50 ml) | 2
dextrose 5% infusion | 6
dextrose 10% infusion | 6
octreotide supplementation | 6
became asymptomatic | 16
abdominal pain improved | 16
blood glucose 7.8 mmol/L | 16
good health follow-up | 10958
did not continue liraglutide | 10958
no further hypoglycemia | 10958
no pancreatitis | 10958