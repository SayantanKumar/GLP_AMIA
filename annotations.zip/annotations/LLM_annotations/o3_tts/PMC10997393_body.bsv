tirzepatide started 5 mg weekly | -504  
diarrhoea 3–4 times/day | -504  
loss of 5 kg | -504  
tirzepatide last dose | -168  
pantoprazole (home use) | -72  
abdominal pain | -48  
vomiting | -48  
diarrhoea | -48  
admitted to ICU | 0  
admitted from ER | 0  
21 years old | 0  
woman | 0  
not known to have diabetes mellitus | 0  
no hypertension | 0  
no significant past medical history | 0  
no fever | 0  
no cough | 0  
no dysuria | 0  
no headache | 0  
no chest pain | 0  
dehydrated | 0  
tachypnoea | 0  
air hunger | 0  
heart rate 110 beats per minute | 0  
blood pressure 130/80 mmHg | 0  
oxygen saturation 99% on room air | 0  
BMI 28.2 kg/m2 | 0  
pH 7.22 | 0  
pCO2 33 mmHg | 0  
pO2 70 mmHg | 0  
bicarbonate 13.8 mmol/l | 0  
anion gap 25 | 0  
blood ketone concentration 5.2 mmol/l | 0  
blood glucose 4.9 mmol/l | 0  
no osmolar difference | 0  
paracetamol levels undetectable | 0  
salicylate levels undetectable | 0  
high anion gap metabolic ketoacidosis | 0  
normal lactate | 0  
0.9% saline 1 l over 30 min | 1  
dextrose 10% 125 ml/hour | 1  
0.9% saline 125 ml/hour | 1  
ondansetron orally every six hours | 1  
pantoprazole IV | 1  
blood glucose 7–8 mmol/l | 2  
no insulin required | 2  
anion gap closed | 12  
acidosis corrected | 12  
advised against taking tirzepatide | 12  
Naranjo scale 6 indicating probable adverse events | 12  
resolution of all symptoms | 672  
gained 1 kg | 672