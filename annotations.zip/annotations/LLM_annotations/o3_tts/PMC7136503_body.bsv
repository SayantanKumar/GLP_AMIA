born at 40 weeks by cesarean section | -157680  
birth weight 1.9 kg | -157680  
infantile hypotonia | -150000  
poor oral intake during infancy | -150000  
rapid weight gain during childhood | -113880  
intellectual disability during childhood | -113880  
Prader-Willi syndrome diagnosed | -35040  
paternal 15q11-q13 deletion identified | -35040  
advanced bone age over 14 years | -35040  
growth hormone therapy not applied due to advanced bone age | -35040  
type 2 diabetes mellitus diagnosed | -17520  
hypertension diagnosed | -17520  
metformin started | -17520  
calcium channel blocker (amlodipine) started | -17520  
reduced physical activity | -336  
body weight increased by 20 kg | -336  
18-year-old | 0  
girl | 0  
presented with dyspnea | 0  
diffuse cellulitis abdomen | 0  
diffuse cellulitis legs | 0  
height 143 cm | 0  
weight 145 kg | 0  
BMI 71 kg/m2 | 0  
blood pressure 190/100 mmHg | 0  
heart rate 115 beats/min | 0  
respiratory rate 24 breaths/min | 0  
body temperature 36 ℃ | 0  
unable to walk unaided | 0  
unable to sit unaided | 0  
joint pain | 0  
high-flow nasal cannula oxygen supply | 0  
ampicillin/sulbactam administered | 0  
daily calorie intake restricted to 800 kcal/day | 0  
metformin 1.5 g/day continued | 0  
insulin detemir 28 IU/day | 0  
amlodipine 10 mg/day | 0  
hydralazine 60 mg/day | 0  
body weight increased to 164 kg | 168  
dyspnea aggravated | 168  
intensive-care-unit care started | 168  
mechanical ventilation initiated | 168  
calorie intake restricted to 200 kcal/day | 168  
furosemide 120 mg/day started | 168  
fluid restriction 1,000 mL/day started | 168  
5 % dextrose with Na/K 600 mL/day started | 168  
amlodipine increased to 20 mg/day | 336  
losartan 50 mg/day started | 336  
iron 80 mg/day started | 336  
calcium carbonate/cholecalciferol started | 336  
mechanical ventilation SIMV–CPAP mode | 336  
normal saline 600 mL/day substituted for dextrose solution | 600  
hydrochlorothiazide 50 mg/day started | 600  
amlodipine increased to 40 mg/day | 600  
losartan increased to 100 mg/day | 600  
loss of 26 kg | 648  
extubation performed | 648  
high-flow nasal cannula oxygen resumed | 648  
sedatives discontinued | 648  
pituitary function test performed | 700  
hypopituitarism diagnosed | 700  
growth-hormone deficiency diagnosed | 700  
gonadotropin deficiency diagnosed | 700  
growth hormone 1.33 IU/day started | 700  
estrogen 0.125 mg/day started | 700  
HbA1c 7.3 % | 700  
liraglutide 0.6 mg/day started | 700  
liraglutide increased to 1.2 mg/day | 720  
physical therapy started | 750  
pulmonary rehabilitation started | 750  
transfer to general ward | 1008  
oxygen therapy discontinued | 1008  
aquatic rehabilitation started | 1008  
diuretics discontinued | 1680  
losartan discontinued | 1680  
transfer to rehabilitation center | 1800  
previous regimen continued | 2016  
discharged | 2160  
able to walk independently | 2160  
weight decreased to 104 kg | 2160  
BMI decreased to 50.8 kg/m2 | 2160  
HbA1c decreased to 4.8 % | 2160  
BMI maintained at 48.5 kg/m2 | 10944  
diet 1,000 kcal/day maintained | 10944  
regular mealtimes maintained | 10944  
exercise 1 hour daily | 10944  
weight loss 62.7 kg | 10944  
waist circumference reduced by 7 cm | 10944  
BMI reduction of 31.7 kg/m2 | 10944  
patient satisfied with diet | 10944