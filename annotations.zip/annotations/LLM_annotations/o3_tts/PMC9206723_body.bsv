gastric ulcer disease | -87600
4 miscarriages | -87600
aunt had type 2 diabetes | -43800
daughter born prematurely with birth weight 1.9 kg | -35064
daughter treated for vesicoureteral reflux | -35064
8-kg weight loss | -504
39 years old | 0
female | 0
Moroccan origin | 0
polyuria | 0
polydipsia | 0
blood glucose 340 mg/dL | 0
hemoglobin A1c 12.4 % | 0
no ketosis | 0
thyroid-stimulating hormone 0.01 mU/L | 0
aspartate aminotransferase 114 U/L | 0
alanine aminotransferase 117 U/L | 0
gamma-glutamyl transferase 445 U/L | 0
alkaline phosphatase 420 U/L | 0
elevated free triiodothyronine 8.8 pg/mL | 0
elevated free thyroxine 33 pg/mL | 0
positive thyrotropin receptor autoantibodies | 0
positive anti-thyroid peroxidase antibodies | 0
heterogeneous hypervascular thyroid ultrasound | 0
Graves’ disease | 0
considered type 1 diabetes | 0
no microvascular complications of diabetes | 0
basal–bolus insulin therapy started | 1
carbimazole 60 mg/day started | 2
propranolol 20 mg three times/day started | 2
abdominal ultrasound unremarkable | 24
viral hepatitis ruled out | 24
autoimmune hepatitis ruled out | 24
Wilson’s disease ruled out | 24
hemochromatosis ruled out | 24
coeliac disease ruled out | 24
liver elastography A0F0 | 24
weight regained to usual | 2190
hemoglobin A1c decreased to 5.7 % | 2190
daily grade 2 hypoglycemic episodes | 2190
insulin doses decreased by 50 % | 2190
antiglutamate decarboxylase antibodies negative | 2190
anti-islet antigen 2 antibodies negative | 2190
tight glycemic control on 0.15 U/kg/day insulin | 12960
diagnosis of type 1 diabetes in doubt | 12960
antiglutamate decarboxylase antibodies negative (repeat) | 12960
anti-islet antigen 2 antibodies negative (repeat) | 12960
anti-zinc transporter 8 antibodies negative | 12960
protective HLA DRB1*15-DQB1*0602 haplotype | 12960
considered atypical type 2 diabetes | 12960
weaned off insulin | 12960
sulfonylurea started | 12960
postprandial hyperglycemia | 12960
thyroid hormone levels normal | 12960
thyrotropin receptor antibodies negative | 12960
carbimazole stopped | 12960
hemoglobin A1c 7.3 % | 45984
weight 51 kg | 45984
glimepiride 1 mg daily | 45984
AST 38 U/L | 45984
ALT 37 U/L | 45984
GGT 174 U/L | 45984
ALP 191 U/L | 45984
TSH 3.16 mU/L | 45984
frequent hypoglycemia 5/week | 45984
hemoglobin A1c 7.1 % | 64272
weight 52 kg | 64272
glimepiride 1 mg daily maintained | 64272
AST 54 U/L | 64272
ALT 55 U/L | 64272
GGT 215 U/L | 64272
TSH 3 mU/L | 64272
thyrotropin receptor antibodies 1.446 U/L | 64272
autoimmune hepatitis work-up negative (repeat) | 78840
coeliac disease work-up negative (repeat) | 78840
biliary MRI unremarkable liver and biliary tree | 78840
4-mm hemorrhagic renal cyst detected | 78840
liver biopsy normal | 78840
fatty liver ruled out | 78840
ursodeoxycholic acid started empirically | 78840
acute worsening of glycemic control | 87288
hemoglobin A1c 12.4 % | 87288
insulin glargine resumed | 87288
dietary errors documented | 87288
TSH 1.1 mU/L | 87288
anti-thyroid peroxidase antibodies >600 U/mL | 87288
hemoglobin A1c 7.7 % | 90480
glimepiride 3 mg/day | 90480
glargine 12 units/day | 90480
AST 44 U/L | 90480
ALT 44 U/L | 90480
GGT 283 U/L | 90480
ALP 362 U/L | 90480
persistent abnormal liver function tests | 95000
hypomagnesemia 0.62 mmol/L | 95000
HNF1B-MODY suspected | 95000
complete heterozygous deletion of HNF1B confirmed | 96000
poor glycemic control | 115440
hemoglobin A1c 9.2 % | 115440
weight 52 kg | 115440
glimepiride 4 mg/day | 115440
glargine 14 units/day | 115440
AST 90 U/L | 115440
ALT 88 U/L | 115440
GGT 297 U/L | 115440
ALP 278 U/L | 115440
TSH 1.6 mU/L | 115440
anti-TPO >600 U/mL | 115440
TRAb negative | 115440
serum creatinine 54 µmol/L | 115440
microalbuminuria normal | 115440
renal ultrasound normal morphology | 115440
fasting C-peptide 0.181 nmol/L | 115440
C-peptide 2 h 0.654 nmol/L | 115440
normal fecal chymotrypsin | 115440
normal fecal elastase | 115440
pancreatic MRI unremarkable | 115440
pelvic ultrasonography normal | 115440
persistent cholestasis and cytolysis | 115440
liraglutide started | 115440
repaglinide 4-1-2 mg started | 115440
hemoglobin A1c 6.7 % | 116160
recurrent hypoglycemia | 116160
repaglinide dose reduced by half | 116160
hemoglobin A1c 6.6 % | 120696
weight 45 kg | 120696
repaglinide 1-0-1 mg | 120696
liraglutide 1.2 mg/day | 120696
AST 37 U/L | 120696
ALT 38 U/L | 120696
GGT 250 U/L | 120696
ALP 242 U/L | 120696
TSH 4.07 mU/L | 120696