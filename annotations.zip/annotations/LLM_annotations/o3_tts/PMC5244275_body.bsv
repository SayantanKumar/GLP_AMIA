59 years old | 0
African American | 0
male | 0
presented to emergency department | 0
unilateral left-sided tongue swelling | -1
difficulty swallowing | -1
throat tightness | -1
no dyspnea | 0
no abdominal pain | 0
no nausea | 0
no vomiting | 0
no syncope | 0
no rash | 0
no hives | 0
no history of angioedema | 0
no food allergies | 0
no latex allergies | 0
no recent insect stings | 0
no family history of angioedema | 0
hydrocodone (current medication) | 0
metformin (current medication) | 0
exenatide (current medication) | 0
insulin glargine (current medication) | 0
daily aspirin | 0
Lotrel (amlodipine / benazepril) daily | -43800
IV access obtained | 0
methylprednisolone 125 mg IV | 0
diphenhydramine 25 mg IV | 0
epinephrine 1 µg IV | 0
no improvement in symptoms | 0
epinephrine 9 µg IV | 0.25
no response | 0.25
condition continued to decline | 0.583
airway collapse imminent | 0.583
ranitidine 150 mg IV | 0.583
C1-esterase inhibitor 3000 U IV | 0.583
response noted | 0.833
reduction of swelling | 0.833
resolution of dysphagia | 0.833
admitted to medical intensive care unit | 1
complement levels drawn | 2
normal C4 level | 2
normal C1-INH functionality | 2
diagnosis of ACEI-associated angioedema | 2
discontinue ACE inhibitors | 2
discharged | 24
scheduled follow-up with allergy department | 24
valsartan / hydrochlorothiazide 160 mg / 25 mg started | 24
no recurrence of angioedema | 8760
blood pressure well controlled on combination medication | 8760