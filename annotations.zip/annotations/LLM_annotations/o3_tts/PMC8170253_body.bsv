21 years old | 0
male | 0
Japanese | 0
severe abdominal pain | 0
total colonoscopy | 0
diagnosed with ulcerative colitis | 0
body weight not altered | 0
no family history of diabetes | 0
started prednisolone 60 mg | 24
started tacrolimus 10 mg | 24
started mesalazine 4,000 mg | 24
hyperglycemia 300-400 mg/dL | 72
HbA1c 5.2 % | 72
glycated albumin 16.8 % | 72
emergency sub-total colectomy | 720
symptoms resolved | 744
medications tapered | 800
hyperglycemia persisted | 800
intensive insulin therapy initiated | 840
BMI 18.6 kg/m2 | 840
anti-GAD antibody <5.0 U/mL | 840
anti-IA-2 antibody negative | 840
anti-ZnT8 antibody negative | 840
urinary C-peptide 52.3 µg/day | 840
C-peptide index 0.7 | 840
ΔC-peptide on glucagon load 0.4 ng/mL | 840
HLA-DRB1 1503 | 840
rectumectomy | 1704
total colectomy completed | 1704
ulcerative colitis resolved | 1704
prednisolone discontinued | 1800
tacrolimus discontinued | 1800
mesalazine discontinued | 1800
insulin therapy switched to vildagliptin | 6600
HbA1c 9.5 % | 6600
added metformin 1,000 mg | 6700
added glimepiride 1 mg | 6700
HbA1c 8.2 % | 7000
started dulaglutide 0.75 mg weekly | 7000
vildagliptin suspended | 7000
glimepiride suspended | 7000
HbA1c 5.9 % | 8344
HbA1c 5.4 % | 10360
HbA1c 11.3 % | 14920
GLP-1RA (dulaglutide) failure | 14920
intensive insulin therapy reintroduced | 14920
HbA1c 5.3 % | 15200
urinary C-peptide 26.8 µg/day | 15200
C-peptide index 0.36 | 15200
ΔC-peptide on glucagon load 0.1 ng/mL | 15200
sparse duodenal GLP-1-positive cells | 15200
few GIP-positive cells | 15200
fasted serum active GLP-1 5.80 pmol/L | 15200
fasted serum active GIP 2.52 pmol/L | 15200