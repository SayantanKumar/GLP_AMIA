36-year-old woman | 0  
presented to clinic | 0  
obesity (BMI 36.5 kg/m2) | 0  
nephrolithiasis | 0  
denied systemic symptoms | 0  
denied oral lesions | 0  
no lymphadenopathy | 0  
no mucosal lesions | 0  
potassium hydroxide examination deferred | 0  
hydrocortisone 2.5 % ointment twice daily started | 0  
prednisone 40 mg 21-day taper started | 0  
ill-defined erythematous patches with minimal fine scale (axillary and inframammary folds) | 0  

waxing and waning rash | -1344  
rash affecting axillae and inframammary area | -1344  
burning pain | -1344  
minimal pruritus | -1344  

initiation of weekly compounded semaglutide 0.25-0.75 mg injections | -1680  

clotrimazole-betamethasone 1 %/0.05 % cream prescribed | -336  
ketoconazole 2 % cream prescribed | -336  
hydrocortisone 2.5 % cream (urgent care) prescribed | -336  
fluconazole 150 mg prescribed | -336  
minimal benefit from urgent-care treatments | -336  

multivitamins use | -8760  
fish-oil use | -8760  
levonorgestrel IUD in place | -8760  

rash continued to spread | 240  
ongoing burning pain | 240  
hydrocortisone ointment discontinued | 240  
prednisone discontinued | 240  

missed two consecutive doses of semaglutide | 336  
rash began resolving | 336  

semaglutide injection (most recent) | 432  
rash reappeared | 432  

annular erythematous patches with prominent trailing scale | 504  
punch biopsy performed (left axilla) | 504  
subcorneal pustular dermatosis on biopsy | 504  
parakeratosis | 504  
mild acanthosis | 504  
mild spongiosis | 504  
lymphocytic and neutrophilic infiltrate in superficial dermis | 504  
Periodic acid–Schiff stain negative | 504  
AGEP sine pustules diagnosis | 504  
Naranjo score 9 (definite adverse drug reaction) | 504  
AGEP validation score 6 (probable AGEP) | 504  
compounded semaglutide discontinued | 504  

eruption cleared | 840  
patch testing deferred | 840