cesarean section | -17520
diagnosed with situs inversus totalis | -17520
failed to lose weight with dieting | -720
failed to lose weight with exercise | -720
liraglutide injection treatment | -720
failed to lose weight with liraglutide | -720
weight 95 kg | -24
body mass index 36 kg/m2 | -24
obesity | -24
type II diabetes | -24
oral medication for diabetes | -24
multidisciplinary preoperative evaluation | -24
normal complete blood count | -24
normal coagulation profile | -24
normal renal profile with electrolyte | -24
normal liver profile | -24
normal lipid profile | -24
normal hormone tests | -24
normal chemistry panel | -24
normal vitamin levels | -24
ECG extreme axis deviation | -24
upright P waves in AVR | -24
inverted P waves in leads I and II | -24
dextrocardia on echocardiography | -24
dextrocardia on chest X-ray | -24
right-sided stomach on barium study | -24
no contrast obstruction on barium study | -24
normal gall bladder on ultrasound | -24
fit for surgery | -24
no associated organic abnormalities | -24
induction of general anesthesia | 0
intubation | 0
laparoscopic sleeve gastrectomy | 0
right-sided stomach observed intraoperatively | 0
right-sided spleen observed intraoperatively | 0
left-sided liver observed intraoperatively | 0
left-sided gallbladder observed intraoperatively | 0
methylene blue leak test | 0
no leak on methylene blue test | 0
no surgical complications | 0
no anesthesia complications | 0
surgical duration 28 min | 0
extubated without problems | 1
transferred to recovery room in good condition | 1
started oral fluid intake | 6
gastrografin leak test | 24
no leak on gastrografin test | 24
surgical drain removed | 24
discharged from hospital | 24
dietitian instructions provided | 24
outpatient follow-up visit | 168
early postoperative complications excluded | 168
wound care performed | 168
weight 83 kg | 2160
satisfied at 3 months | 2160
no complaints at 3 months | 2160
weight 75 kg | 4320
satisfied at 6 months | 4320
no complaints at 6 months | 4320
weight 63 kg | 8640
good glycemic control | 8640
off diabetes medications | 8640
no late postoperative complications | 8640
satisfied at 12 months | 8640
no complaints at 12 months | 8640