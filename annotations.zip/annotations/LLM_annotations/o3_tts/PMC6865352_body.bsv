57-year-old | 0  
Caucasian woman | 0  
admitted to intensive care unit | 0  
volume overload | 0  
hypokalemia | 0  
severe refractory hypokalemia | 0  
metabolic alkalosis | 0  
elevated thyrotropin levels | 0  
serum cortisol 190.4 µg/dL | 0  
serum potassium 2.6 mEq/L | 0  
serum magnesium 1.3 mg/dL | 0  
WBC 9.0 × 1000/µL | 0  
Pro-BNP 2067 pg/mL | 0  
chest x-ray question of flash pulmonary edema | 0  
chest x-ray multifocal pneumonia | 0  
chest x-ray trace bilateral pleural effusions | 0  
chest CT no pulmonary embolism | 0  
chest CT bilateral perihilar airspace disease | 0  
chest CT small bilateral pleural effusions | 0  
echocardiogram ejection fraction 60–65 % | 0  
echocardiogram mild concentric left ventricular hypertrophy | 0  
echocardiogram normal transmitral flow pattern | 0  
echocardiogram normal left ventricular wall motion | 0  
cardiac catheterization no coronary artery disease | 0  
mifepristone toxicity diagnosed | 0  
mifepristone held | 0  
dexamethasone started | 0  
IV diuresis started | 0  
potassium repleted | 0  
improved | 72  
discharged | 96  
mifepristone discontinued | 96  
outpatient follow-up | 432  
repeat potassium level normal | 432  
dulaglutide therapy | 432  
insulin degludec therapy | 432  
metformin (continued) | 432  
periodic follow-up to look for signs of Cushing’s syndrome | 432  
mifepristone 900 mg daily | -720  
non-compliance with scheduled follow-up | -720  
mifepristone 600 mg daily | -1440  
mifepristone 300 mg daily | -2160  
mifepristone therapy started | -2160  
weight gain | -2880  
rise in HbA1C | -2880  
non-suppressible cortisol after low-dose dexamethasone | -2880  
left adrenalectomy | -5040  
insulin requirement came down significantly | -4560  
HbA1C decreased from 8.2 % to 6.3 % | -4560  
serum cortisol normalized | -4560  
DHEAS normalized | -4560  
ACTH normalized | -4560  
elevated 8:00 h cortisol | -5500  
cortisol non-suppressible after 1 mg dexamethasone | -5500  
low DHEAS | -5500  
low ACTH | -5500  
24-h urinary free cortisol normal | -5500  
midnight salivary cortisol normal | -5500  
adrenal venous sampling elevated bilateral cortisol production | -5460  
left adrenal vein cortisol greater than right | -5460  
diagnosed with AIMAH | -5280  
diagnosed with subclinical Cushing’s syndrome | -5280  
left adrenal nodule 4 cm | -5280  
bilateral adrenal enlargement on abdominal imaging | -8760  
elevated liver enzymes | -8760  
glycemic control progressively worsened | -9504  
type 2 diabetes mellitus (10-year history) | -87600  
metformin therapy | -87600  
insulin glargine therapy | -8760