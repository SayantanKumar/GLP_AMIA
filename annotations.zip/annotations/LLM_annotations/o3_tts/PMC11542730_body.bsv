35-year-old Han Chinese man | 0  
admitted to Department of Urology | 0  
dynamic contrast-enhanced CT scan of lower abdomen | -96  
mass in right adrenal gland detected | -96  
no dizziness | 0  
no fatigue | 0  
no nausea | 0  
no vomiting | 0  
no blurred vision | 0  
no general weakness | 0  
no profuse sweating | 0  
does not smoke | 0  
does not drink | 0  
denied history of taking medications | 0  
blood pressure 132/85 mmHg | 0  
height 178 cm | 0  
weight 94 kg | 0  
BMI 29.7 kg/m² | 0  
no thyroid enlargement | 0  
no cardiopulmonary positive signs | 0  
no abdominal positive signs | 0  
tendon reflexes normal | 0  
bowel sounds normal | 0  
electrocardiogram sinus rhythm | 0  
serum potassium 2.7 mmol/L | 0  
serum chloride 94 mmol/L | 0  
transferred to Endocrinology Department | 12  
blood gas pH 7.44 | 24  
PCO₂ 41.2 mmHg | 24  
actual base excess 3.5 mmol/L | 24  
serum potassium 2.8 mmol/L | 24  
serum magnesium 0.58 mmol/L | 24  
serum chloride 96 mmol/L | 24  
ionized calcium 1.07 mmol/L | 24  
aldosterone 131.4 pg/ml | 24  
renin 8.99 ng/mL/hr | 24  
metabolic alkalosis | 24  
hypokalemia | 24  
hypomagnesemia | 24  
increased plasma renin level | 24  
24-h urine collection started | 24  
24-h urine output 2900 mL | 48  
urine potassium 32.84 mmol/24 h | 48  
urine calcium 0.016 g/24 h | 48  
hypocalciuria | 48  
fractional excretion of potassium 14.79 % | 48  
HbA₁c 6.8 % | 24  
urinary microalbumin/creatinine 38.75 mg/g | 24  
urinary microalbumin 34.6 mg/L | 24  
anti-insulin antibody 18.06 IU/mL | 24  
glutamic acid decarboxylase antibody 1 IU/mL | 24  
C-peptide 3.68 ng/mL | 24  
insulin 16.58 uIU/mL | 24  
SLC12A3 gene testing performed | 96  
c.1456G>A homozygous variant in SLC12A3 | 96  
Gitelman syndrome diagnosed | 120  
potassium chloride 2000 mg tid started | 48  
right adrenal mass resection | 552  
postoperative pathology: adrenal cyst | 552  
potassium chloride 500 mg bid started | 552  
magnesium chloride 1000 mg bid started | 552  
spironolactone 20 mg bid started | 552  
serum potassium 3.63–3.71 mmol/L | 600  
gynecomastia | 2208  
spironolactone stopped | 2208  
serum potassium <3 mmol/L | 2250  
potassium chloride 2000 mg tid restarted | 2250  
magnesium chloride 1000 mg bid continued | 2250  
increased nocturia | 2250  
finerenone 10 mg bid started | 36480  
potassium chloride dose reduced to 1500 mg bid | 36480  
magnesium chloride 1000 mg bid continued | 36480  
semaglutide 1 mg weekly started | 36480  
dapagliflozin daily started | 36480  
serum potassium 3.48–3.8 mmol/L | 36504  
serum magnesium 0.47–0.7 mmol/L | 36504  
no adverse reactions to finerenone | 36504  
blood glucose well-controlled | 36504