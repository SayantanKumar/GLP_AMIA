type 2 diabetes diagnosed | -140160
negative anti-islet antibody test results | -140160
27 years old | -26280
first presentation to diabetes clinic | -26280
visual disturbances | -26280
burning in feet | -26280
tingling in feet | -26280
tingling in legs | -26280
alterations in appetite | -26280
weight gain | -26280
edema | -26280
nausea | -26280
irritability | -26280
depressed mood | -26280
A1C 8.9 % | -26280
weight 265 lb | -26280
unplanned 35 lb weight gain | -26280
poor medication compliance | -26280
had not been checking blood glucose for 3 months | -26280
given meal plan but nonadherent | -26280
personal health rated poor | -26280
family history of diabetes | -26280
family history of high blood pressure | -26280
family history of elevated cholesterol | -26280
nonsmoker | -26280
no children | -26280
works at fast-food chain | -26280
NPH 20 units morning | -26280
NPH 15 units evening | -26280
regular insulin 25 units morning | -26280
regular insulin 15 units evening | -26280
atorvastatin 10 mg daily | -26280
warfarin 7.5 mg daily | -26280
ergocalciferol 50 000 units | -26280
lisinopril/hydrochlorothiazide 20/25 mg daily | -26280
hypercholesterolemia | -26280
deep venous thrombosis | -26280
vitamin D deficiency | -26280
high blood pressure | -26280
blood pressure and cholesterol cycling uncontrolled | -26280
noncompliance with appointments | -26280
noncompliance with blood glucose monitoring | -26280
insulin aspart 70/30 mix 40 units breakfast | -10080
insulin aspart 70/30 mix 30 units dinner | -10080
A1C 9.7 % | -10080
insulin aspart 70/30 mix 35 units twice daily | -9360
A1C 11.1 % | -9360
albuminuria | -9360
insulin glargine 40 units bedtime | -7200
insulin aspart 15 units with meals | -7200
A1C 10.8 % | -7200
weight 297 lb | -7200
weight gain 12 lb | -7200
insulin glargine 45 units bedtime | -4320
insulin aspart 15 units with meals | -4320
A1C 12.2 % | -4320
insulin aspart 70/30 mix 45 units twice daily | -720
A1C 11.4 % (pre-liraglutide) | -720
liraglutide 1.2 mg daily started | 0
insulin aspart 70/30 mix 45 units twice daily | 0
A1C 11.4 % | 0
morbid obesity | 0
denied side effects of liraglutide | 720
denied adverse reactions | 720
weight loss 2 lb | 720
increased self-monitoring of blood glucose | 720
lower blood glucose readings | 720
insulin aspart 70/30 mix decreased to 35 units twice daily | 2160
liraglutide increased to 1.8 mg daily | 2160
A1C 7.6 % | 2160
hypoglycemia episodes (<70 mg/dL) | 2160
asymptomatic hypoglycemia | 2160
no hospitalization for hypoglycemia | 2160
hypoglycemia treated with oral carbohydrates | 2160
insulin aspart 70/30 mix decreased to 30 units twice daily | 4320
liraglutide 1.8 mg continued | 4320
A1C 7.7 % | 4320
average blood glucose 133 mg/dL | 5760
weight loss 20 lb | 5760
BMI decreased by 3 kg/m2 | 5760
blood pressure controlled <140/90 mmHg | 5760
no use of over-the-counter medicines or supplements | 5760
increased frequency of blood glucose testing (121 % rise) | 5760
44 % of readings in target range | 5760
more hypoglycemic readings but no hospitalization | 5760