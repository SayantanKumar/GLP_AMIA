51-year-old | 0
male | 0
presented to the emergency department | 0
abdominal pain | -336
abdominal distension | -336
nausea | -336
intermittent chills | -336
pain described as constant pressure | 0
pain rated 10 out of 10 | 0
pain improved by leaning forward or crouching | 0
pain worsened by eating meals | 0
acetaminophen did not help pain | 0
quit alcohol use | -78840
alcohol use disorder | 0
diabetes mellitus type II | 0
chronic pancreatitis | 0
former smoker | 0
denied recent travel | 0
has 2 dogs at home | 0
denied exposure to livestock | 0
semaglutide | 0
omeprazole | 0
acetaminophen | 0
tachycardia heart rate 134 beats per minute | 0
temperature 100.4 F | 0
blood pressure 130/96 mm Hg | 0
100% oxygen saturation on room air | 0
firm and distended abdomen | 0
tenderness to palpation over right upper quadrant | 0
tenderness to palpation over right lower quadrant | 0
palpable hepatomegaly | 0
white blood cell count 13,360 cells/mm3 | 0
neutrophilic predominance | 0
thrombocytosis 529 platelets per μL | 0
hemoglobin 8.0 g/dL | 0
alanine aminotransferase 73 IU/L | 0
aspartate transaminase 171 IU/L | 0
alkaline phosphatase 625 IU/L | 0
total bilirubin 1.9 mg/dL | 0
direct bilirubin 1.3 mg/dL | 0
blood urea nitrogen 50 mg/dL | 0
creatinine 1.2 mg/dL | 0
lactic acid 5.2 mmol/L | 0
CT scan abdomen pelvis showed multiple masses throughout the liver | 0
CT scan abdomen pelvis showed partial splenic vein thrombosis | 0
CT scan abdomen pelvis showed portal vein thrombosis | 0
CT scan 6 months prior showed no liver pathology | -4320
magnetic resonance imaging revealed hepatomegaly | 0
magnetic resonance imaging revealed multiseptated cystic hepatic masses | 0
magnetic resonance imaging revealed portal vein thrombosis | 0
largest cystic lesion 9.0 cm × 5.4 cm | 0
started intravenous cefepime | 0
started oral metronidazole | 0
started therapeutic intravenous heparin | 0
bacterial blood cultures no growth | 48
fungal blood cultures no growth | 48
hepatitis A IgM negative | 48
hepatitis B core antibody IgM negative | 48
hepatitis B surface antigen negative | 48
hepatitis C antibody negative | 48
HIV antibody 1 and 2 negative | 48
Entamoeba histolytica IgG negative | 48
Echinococcus IgG antibody negative | 48
CT-guided liver biopsy with aspiration of abscess material | 72
H&E stain showed inflamed and degenerating liver parenchyma | 72
cultures from aspirate showed no growth | 96
changed antibiotics to intravenous ampicillin-sulbactam | 96
changed antibiotics to oral trimethoprim-sulfamethoxazole | 96
16S PCR from aspirate positive for Fusobacterium nucleatum | 120
cardiac arrest | 132
patient death | 132