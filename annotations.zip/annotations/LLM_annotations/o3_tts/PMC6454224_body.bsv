type 2 diabetes mellitus diagnosed | -87600
smoking cessation | -4320
26 pack year smoking history | -4320
persistently elevated glucometer readings | -2160
45 years old | 0
male | 0
carpenter | 0
referred to bariatric clinic | 0
severe obesity | 0
poorly controlled type 2 diabetes mellitus | 0
well-controlled hypertension | 0
dyslipidaemia | 0
stable non-alcoholic steatohepatitis | 0
insulin aspart 20 units with breakfast | 0
insulin aspart 18 units with lunch | 0
insulin aspart 22 units with dinner | 0
insulin glargine 40 units nocte | 0
metformin 500 mg three times daily | 0
ramipril 2.5 mg once daily | 0
simvastatin 30 mg once daily | 0
aspirin 75 mg once daily | 0
no alcohol intake | 0
family history of type 2 diabetes mellitus in mother | 0
family history of type 2 diabetes mellitus in sister | 0
single | 0
lives with two siblings | 0
thirst | 0
polydipsia | 0
polyuria | 0
nocturia | 0
weight 113.8 kg | 0
height 168.2 cm | 0
BMI 40.2 kg/m2 | 0
waist circumference 117 cm | 0
hip circumference 120 cm | 0
waist-to-hip ratio 0.98 | 0
blood pressure 105/62 mmHg | 0
no retinopathy | 0
no neuropathy | 0
no cutaneous markers of insulin resistance | 0
HbA1c 72 mmol/mol | 0
total cholesterol 3.3 mmol/L | 0
LDL cholesterol 0.8 mmol/L | 0
HDL cholesterol 1.0 mmol/L | 0
triglycerides 1.9 mmol/L | 0
liver profile normal | 0
iron studies normal | 0
renal function normal | 0
thyroid function normal | 0
ECG normal | 0
right bundle branch block | 0
healthy eating advice provided | 0
large intake of sugary snacks | 0
large intake of starchy carbohydrates | 0
declined laparoscopic sleeve gastrectomy | 0
declined GLP1 agonist therapy | 0
no psychiatric disorder | 0
diet improved | 3600
glycaemic control improved | 3600
weight gain 1.6 kg | 3600
weight 115.2 kg | 3600
BMI 40.7 kg/m2 | 3600
milk-based low-energy liquid diet started | 3600
basal metabolic rate 1983 kcal | 3600
multivitamin and mineral supplement started | 3600
fibre supplementation (ispaghula husk) started | 3600
sodium replacement with stock cube started | 3600
insulin dose reduced to zero | 3768
insulin therapy discontinued | 3768
HbA1c normalised | 3768
weight 101.2 kg | 4944
BMI 35.8 kg/m2 | 4944
weight 94.6 kg | 7632
BMI 33.4 kg/m2 | 7632
milk-based component of diet stopped | 7632
balanced 1000 kcal diet resumed | 7632
weight gain 2.2 kg | 14400
HbA1c 48 mmol/mol | 14400
off insulin therapy | 14400
weight 92.6 kg | 18720
BMI 32.7 kg/m2 | 18720
HbA1c 104 mmol/mol | 18720
poor glycaemic control | 18720
metformin increased to 1 g twice daily | 18720
linagliptin 5 mg once daily started | 18720
canagliflozin 100 mg once daily started | 18720
oral therapy well tolerated | 18720
HbA1c 50 mmol/mol | 39600
weight 100.4 kg | 39600
BMI 35.5 kg/m2 | 39600
felt well | 39600