35 years old | 0
male | 0
presented | 0
weight loss 30 kg | -4320
newly diagnosed diabetes | -168
uncontrolled skin itching | 0
uncontrolled erythema | 0
patches of erythematous areas | 0
irregular borders | 0
vesicles | 0
crust formation | 0
normal complete blood count | 0
normal blood chemistry | 0
normal renal function | 0
normal liver function | 0
serum glucose 6.4 mmol/L | 0
CT scan chest abdomen pelvis | 4
hypervascular mass replacing most of pancreas | 4
severe diffuse pancreatic enlargement | 4
multiple liver lesions in right lobe | 4
left para-aortic lymph nodes | 4
FDG PET/CT performed | 24
mild-to-moderate heterogeneous activity in pancreatic mass | 24
mild FDG uptake in 2 liver lesions | 24
pattern suggestive of metastasis | 24
biopsy of liver lesion | 48
metastatic grade 2 neuroendocrine tumor | 48
mitotic index 1 | 48
Ki-67 index 10% | 48
markedly elevated serum glucagon 2500 pg/ml | 48
elevated chromogranin 4600 ng/ml | 48
68Ga-DOTATATE scan performed | 72
intense Ga-avid large pancreatic mass | 72
multiple Ga-avid lesions in liver | 72
Ga-avid per-pancreatic foci | 72
no additional distant metastases | 72
short-acting subcutaneous octreotide prescribed | 96
shifted to long-acting intramuscular octreotide | 120
liraglutide initiated | 120
gliclazide initiated | 120
metformin initiated | 120
good control of blood glucose | 168
erythematous skin changes mostly resolved | 768
weight gain 3 kg | 768
surgical consultation | 800
recommended tumor-shrinking therapy with PRRT | 800