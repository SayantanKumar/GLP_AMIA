26 years old | 0
female | 0
referred for evaluation | 0
persistent fatigue | 0
poor exertional tolerance | 0
fatigue started in early adolescence | -122640
onset of unintentional weight gain | -61320
70 pound weight gain | -61320
possible hypothyroidism | 0
right thyroid lobectomy | -52560
uninodular goiter | -52560
benign thyroid nodule on histopathology | -52560
TSH 0.4-2.5 mIU/L (within reference range) | -52560
abdominal pain | -72
diarrhea | -72
computed tomography of abdomen | -72
mild hepatic steatosis | -72
body mass index 38 kg/m² | 0
well-healed low neck incision | 0
right thyroid lobe and isthmus absent to palpation | 0
denies sustained or current dietary restrictions such as veganism | 0
remainder of history and physical examination unremarkable | 0
low total carnitine level | 0
low acyl carnitine level | 0
pattern consistent with primary carnitine deficiency | 0
genetic testing arranged | 120
two SLC22A5 mutations identified | 168
c.34G>A (p.Gly12Ser) mutation | 168
c.41G>A (p.Trp14Ter) mutation | 168
diagnosis of primary carnitine deficiency | 168
compound heterozygosity confirmed | 336
mother source of c.34G>A mutation | 336
father source of c.41G>A mutation | 336
no conduction abnormalities on electrocardiogram | 192
echocardiogram normal | 192
left ventricular ejection fraction 60-65 % | 192
carnitine supplementation started 20 mg/kg/d | 216
carnitine dose increased to 50 mg/kg/d | 720
serum total carnitine improved to 40 µM | 720
patient reported improved sense of well-being | 300
patient reported improved exertional tolerance | 300
saw dietitian | 720
began regular aerobic exercise | 720
started liraglutide (Saxenda) | 720
intentional 15 pound weight loss | 2880