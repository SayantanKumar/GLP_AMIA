61‐year‐old | 0
woman | 0
presented | 0
single erythematous, crusted lesion on breast | 0
type II diabetes mellitus | 0
hypertension | 0
hyperlipidemia | 0
lichen sclerosus | 0
fibromyalgia | 0
chronic gingivitis | 0
rheumatoid arthritis | 0
semaglutide (current use) | 0
glimepiride | 0
cyclobenzaprine | 0
amitriptyline | 0
hydroxychloroquine | 0
oxycodone/paracetamol | 0
atorvastatin | 0
losartan (current use) | 0
chlorhexidine oral rinse | 0
clobetasol 0.05 % cream | 0
semaglutide initiation | -720
losartan use for > 1 year | -8760
returned | 720
new crusted erosions of breast | 720
new crusted erosions of lower back | 720
worsening erythema of gingivae | 720
worsening edema of gingivae | 720
applied 2 % ketoconazole cream | 700
applied 2.5 % hydrocortisone cream | 700
no benefit from ketoconazole cream | 700
no benefit from hydrocortisone cream | 700
skin biopsies obtained | 720
subepidermal vesiculation on biopsy | 720
brisk mixed dermal infiltrate with many eosinophils | 720
direct immunofluorescence: linear IgG reactivity n-serrated pattern | 720
direct immunofluorescence: linear C3 staining along basement membrane | 720
indirect immunofluorescence: IgG4 epidermal localization | 720
ELISA elevated anti-BP180 antibodies 86 units | 720
anti-BP230 antibodies not elevated | 720
bullous pemphigoid diagnosis | 720
semaglutide discontinued | 730
no additional topical treatments used | 730
marked improvement in cutaneous erosions | 800
reduced gingival inflammation | 800
follow-up visit | 3600
mild gingival irritation | 3600
IIF IgG4 epidermal localization persists | 3600
ELISA anti-BP180 antibodies 69 units | 3600
anti-BP230 antibody remains negative | 3600