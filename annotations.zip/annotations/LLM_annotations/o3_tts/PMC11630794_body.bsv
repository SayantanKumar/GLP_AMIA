atorvastatin 40 mg | -47280
type 2 diabetes mellitus | -8760
hypertension | -8760
hyperlipidemia | -8760
metabolic dysfunction-associated steatotic liver disease | -8760
Gilbert syndrome | -8760
coronary artery disease | -8760
elevated liver enzymes | -12240
discontinued atorvastatin | -12240
rosuvastatin 5 mg started | -7200
progressive proximal muscle weakness | -2160
64-year-old | 0
Caucasian male | 0
presented to the clinic | 0
extreme muscle pain | 0
difficulty climbing stairs | 0
difficulty rising from a chair | 0
on rosuvastatin 5 mg | 0
elevated CK 232.48 µkat/L | 0
elevated AST 3.88 µkat/L | 0
elevated ALT 9.73 µkat/L | 0
potassium 5.5 mmol/L | 0
normal renal function tests | 0
no history of autoimmune disease | 0
no preceding fevers | 0
no preceding chills | 0
no preceding joint pain | 0
no preceding dysphagia | 0
discontinued rosuvastatin | 0
discontinued dulaglutide | 0
presented to emergency room | 504
syncopal episode | 504
increased CK 275.0167 µkat/L | 504
elevated ALT 9.71 µkat/L | 504
elevated AST 5.35 µkat/L | 504
elevated aldolase 1.0717 µkat/L | 504
aggressive intravenous hydration | 504
CK improved to 153.333 µkat/L | 510
right upper quadrant ultrasound normal | 510
renal function tests normal | 510
thyroid function tests normal | 510
electromyography diffuse myopathy | 528
electromyography myotonic discharges | 528
electromyography fibrillation potentials | 528
electromyography complex repetitive discharges | 528
electromyography sharp waves | 528
pulmonary function test mild decrease FEV and FVC | 528
muscle biopsy necrotic and regenerating fibers | 600
anti-HMGCR antibody > 200 CU | 600
anti SRP IFA negative | 600
colonoscopy unremarkable | 624
prednisone 40 mg daily started | 650
intravenous immunoglobulin 2 g/kg over 5 days monthly started | 700
CK decreased to 94.73 µkat/L | 1370
ezetimibe 10 mg started | 800
evolocumab 140 mg subcutaneous injections started | 820
CK normalized to 1.05 µkat/L | 1500
plan to continue intravenous immunoglobulin monthly for 3 more months | 1500
plan to decrease intravenous immunoglobulin to 1 g/kg monthly | 1500
plan to taper prednisone | 1500
plan to replace prednisone with methotrexate | 1500