59-year-old Japanese woman | 0
female | 0
body weight 133.8 kg | 0
BMI 54.8 kg/m2 | 0
HbA1c 8.2% | 0
exenatide therapy commenced (5 μg injected twice a day within the 60 min before morning and evening meals) | 0
goals of therapy: glycemic control | 0
goals of therapy: weight loss | 0
continuous glucose monitoring performed | 0
baseline active GLP-1 level measured | 0
baseline total GIP level measured | 0
total caloric intake maintained at 1,600 kcal per day | 0
resting metabolic rate measured | 0

mild nausea | 4380
appetite loss | 4380
adverse effects not serious enough to cease exenatide | 4380

exenatide ceased for 5 days (wash-out) | 8640

body weight 96.3 kg | 8760
BMI 39.5 kg/m2 | 8760
HbA1c 5.1% | 8760
resting metabolic rate 1,618 kcal/day | 8760
HOMA-IR 1.29 | 8760
HOMA-β 57.2% | 8760
QUICKI 0.195 | 8760
decreased glucagon levels | 8760
decreased active GLP-1 levels | 8760
decreased total GIP levels | 8760
weight loss 37.5 kg | 8760

appetite recovered | 10200
regained 3 kg | 10200

body weight 112.1 kg | -12408
BMI 45.9 kg/m2 | -12408
HbA1c 6.0% | -12408
resting metabolic rate 1,732 kcal/day | -12408
HOMA-IR 1.08 | -12408
HOMA-β 95.4% | -12408
QUICKI 0.201 | -12408
continuous glucose monitoring performed | -12408

body weight 144.1 kg | -17520
BMI 59.1 kg/m2 | -17520
insulin 36 units injected daily | -17520
poor glycemic control | -17520
HbA1c 10.5% | -17520
renal dysfunction (eGFR 21.8 mL/(min·1.73 m2)) | -17520
gastric surgery considered | -17520
gastric surgery not performed | -17520

body weight 121 kg | -16000
BMI 49.6 kg/m2 | -16000
insulin dose decreased to 28 units | -16000

body weight 114 kg | -15000
BMI 46.7 kg/m2 | -15000
HbA1c 6.6% | -15000
medication including insulin discontinued | -15000

body weight 153 kg | -87600
BMI 62.7 kg/m2 | -87600
HbA1c 8.8% | -87600
admitted to hospital for obesity and glucose management | -87600
dietary intake 1,200 kcal per day | -87600

body weight 131.2 kg | -86580
BMI 53.9 kg/m2 | -86580
HbA1c 6.5% | -86580
discharged | -86580

weight regained to 163.0 kg | -22000
BMI 66.8 kg/m2 | -22000
HbA1c 9.3% | -22000

anti-obesity drug mazindol used | -20000
very low calorie diet (800 kcal/day) | -20000
psychotherapist counseling | -20000
exercise therapy restricted to upper body | -20000
knee pain due to osteoarthritis | -20000

retired from work | -96480
disc herniation | -96480
decreased physical activity | -96480
additional weight gain | -96480

overeating | -183960
mental stress | -183960
weight gain began | -183960