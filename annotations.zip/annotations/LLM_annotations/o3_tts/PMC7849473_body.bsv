19 years old | 0  
male | 0  
referred to clinic | 0  
new-onset diabetes after kidney transplantation (NODAT) | 0  
hyperglycemia 17.2 mmol/L | 0  
body weight 55 kg | 0  
BMI 21.5 kg/m2 | 0  
denies catabolic symptoms | 0  
no evidence of ketoacidosis | 0  
fasting C-peptide 1.3 nmol/L | 0  
GADA negative | 0  
ICA negative | 0  
IA-2A negative | 0  
ZnT8A negative | 0  
pancreatic ultrasound normal | 0  
no complaints suggestive of exocrine dysfunction | 0  
liver enzymes normal | 0  
no clinical evidence of genital tract malformations | 0  
insulin long-acting analog 0.16 UI/kg/day started | 0  

HNF1B p.S148L heterozygous mutation detected | 48  
family referred for genetic counselling | 48  

insulin switched to DPP-4 inhibitor | 3600  
tacrolimus reduced to 8 mg/day | 3600  
prednisolone reduced to 5 mg/day | 3600  

vomiting | 4104  
sitagliptin stopped | 4104  
kept without diabetes medication | 4104  
HbA1c < 6.5 % | 4104  

HbA1c 6.9 % | 15624  
sitagliptin 25 mg/day resumed | 15624  
tacrolimus 6 mg/day | 15624  
prednisolone 5 mg/day | 15624  
plasma creatinine 185.6–229.8 µmol/L | 15624  
GFR 34–44 mL/min/1.73 m2 | 15624  

HbA1c 8 % | 21384  
therapy switched to liraglutide | 21384  
liraglutide titrated to 1.8 mg/day | 21384  

HbA1c 6.7 % | 22824  

less physical activity reported | 25704  
HbA1c 10.9 % | 25704  
plasma creatinine 224.5 µmol/L | 25704  
GFR 35.2 mL/min/1.73 m2 | 25704  
liraglutide stopped | 25704  
insulin long-acting analog 0.14 UI/kg/day resumed | 25704  

glycemic control slightly improved | 27144  
insulin therapy to be maintained | 27144  

living kidney transplant from father | -336  
partial graft necrosis | -330  
plasma creatinine 185.6 µmol/L at discharge | -330  
GFR 44.3 mL/min/1.73 m2 at discharge | -330  
tacrolimus 15 mg/day | -330  
mycophenolate mofetil 2000 mg/day | -330  
prednisolone 15 mg/day | -330  

plasma creatinine 433.2 µmol/L | -8760  
GFR 15.9 mL/min/1.73 m2 | -8760  

fasting blood glucose 4.2–5.2 mmol/L during childhood | -87600  

hyperechogenic kidneys with small cysts after birth | -166440  
plasma creatinine elevated after birth | -166440  

bilateral hyperechogenic kidneys detected on fetal ultrasound | -169800