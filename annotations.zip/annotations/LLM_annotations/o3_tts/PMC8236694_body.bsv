Relapsing-remitting multiple sclerosis | -87600
Fasting blood glucose 8.0 mmol/L | -17520
High-dose intravenous methylprednisolone 500 mg/day | -1000
Frequent hiccups | -1000
Numbness in hands | -1000
Hiccups improved | -980
Oral methylprednisolone 24–6 mg/day | -960
Methotrexate 7.5 mg/week | -960
Tripterygium wilfordii 60 mg/day | -960
Numbness relieved | -600
Fasting blood glucose 13.0 mmol/L | -1440
HbA1c 12.4 % | -1440
Steroid-induced diabetes mellitus diagnosed | -1440
Admitted to hospital | 0
Poor glycemic control | 0
Evaluation of residual insulin secretion | 0
Height 168 cm | 0
Body weight 85 kg | 0
BMI 30.1 kg/m2 | 0
Body temperature 36.5 °C | 0
Blood pressure 124/75 mmHg | 0
Pulse 75 beats/min regular | 0
Hyperinsulinemia | 0
Severe insulin resistance | 0
ALT 178 U/L | 0
AST 198 U/L | 0
γ-GTP 265 U/L | 0
Diammonium glycyrrhizinate started | 0
Insulin aspart 60 U/day started | 0
Insulin glargine 26 U/day started | 0
Developed insulin allergy | 72
Wheals at injection sites | 72
Redness at injection sites | 72
Itching at injection sites | 72
Hypereosinophilia | 72
Total IgE 864 IU/mL | 72
Biopsy: eosinophilic infiltration | 72
Discontinued insulin aspart | 72
Insulin lispro started | 72
Induration at injection sites | 96
Persistent hypereosinophilia | 96
Liver enzymes normalized | 168
Metformin 1.5 g/day started | 168
Continued unsatisfactory glucose control | 168
Liraglutide 0.6 mg/day started | 336
Fasting hyperglycemia decreased | 504
Postprandial hyperglycemia decreased | 504
Blood glucose near normal 7.1 mmol/L | 504
Reduced insulin lispro dose | 504
Reduced insulin glargine dose | 504
Liraglutide increased to 1.2 mg/day | 504
Satiety without nausea and diarrhea | 504
Induration at injection sites diminished | 504
Discontinued insulin lispro | 1776
Regimen: liraglutide 1.2 mg/day + metformin + insulin glargine 10 U/day | 1776
HbA1c 8.6 % | 1776
Fasting blood glucose 5.2–6.7 mmol/L | 1776
Improved serum insulin level | 1776
Improved eosinophil level | 1776
No further allergic symptoms | 1776
Body weight decreased by 6.8 kg | 3216