49 years old | 0
female | 0
no pertinent past medical history | 0
pelvic pain | -72
abnormal uterine bleeding | -72
pelvic ultrasound 6.5 cm complex left adnexal mass | 0
TSH normal | 0
Free T4 normal | 0
CA-125 within normal limits | 0
CEA within normal limits | 0
CA 19-9 within normal limits | 0
β-HCG within normal limits | 0
inhibin A within normal limits | 0
inhibin B within normal limits | 0
endometrial biopsy normal proliferative endometrium | 6
pelvic MRI concern for malignancy | 24
robotic bilateral salpingectomy | 168
left oophorectomy | 168
left adnexal mass removed with contained rupture | 168
intra-operative frozen section reported struma ovarii | 168
contralateral oophorectomy not performed | 168
hysterectomy not performed | 168
final pathology struma ovarii with papillary thyroid carcinoma foci | 192
largest papillary thyroid carcinoma focus 1.6 mm | 192
no lymphovascular space invasion | 192
no ovarian capsule involvement | 192
pelvic washings negative for malignant cells | 192
referred to endocrinology | 240
thyroid ultrasound normal | 240
neck ultrasound normal | 240
thyroglobulin level normal | 240
thyroid function tests normal | 240
elected monitoring | 240
thyroglobulin levels normal for 2 years | 240
GLP-1 agonist started | 17400
thyroglobulin increase | 17520
thyroglobulin remained elevated off GLP-1 for two months | 17520
CT chest/abdomen/pelvis no evidence of disease | 17530
neck ultrasound no evidence of disease | 17530
pelvic ultrasound small hyperechoic right ovarian lesion 6.4 × 9 × 7.5 mm with increased vascularity | 17540
decision for removal of remaining ovary ± hysterectomy | 17550
thyroglobulin 227 ng/ml | 17600
TSH 1.26 | 17600
diagnostic laparoscopy revealed peritoneal carcinomatosis | 17600
diffuse red cystic nodular lesions on peritoneal surfaces | 17600
right ovary enlarged complex cystic appearance | 17600
intra-op frozen section of omentum thyroid neoplasm | 17600
robotic-assisted total laparoscopic hysterectomy | 17600
right salpingo-oophorectomy | 17600
extensive peritoneal resection | 17600
omentectomy | 17600
no gross residual disease | 17600
pathology strumosis in resected specimens | 17624
metastatic foci with papillary thyroid carcinoma features | 17624
PD-L1 positive (CPS 4) | 17624
NRAS Q61R mutation pathogenic | 17624
tumor mutational burden 4.2 m/MB moderate | 17624
microsatellite stable | 17624
thyroglobulin 127 ng/ml | 18608
TSH 1.97 | 18608
plan for total thyroidectomy | 18608
total thyroidectomy | 18700
final thyroid pathology benign | 18724
plan to start I-131 therapy | 19000
plan for post-treatment whole-body I-131 scan | 19000
plan follow-up in 3–4 months | 19000