60-year-old | 0
White man | 0
long-standing type 2 diabetes mellitus | -87600
stable glycemic control | -17520
A1C level consistently between 6.0% and 7.0% | -17520
diagnosed with heterozygous lipoprotein lipase deficiency with variant p.Asn291Ser | -720
fenofibrate 145 mg daily | -2880
icosapent ethyl 2 g twice daily | -2880
ezetimibe 10 mg daily | -2880
atorvastatin 40 mg daily | -2880
semaglutide 1.0 mg weekly | -2880
empagliflozin 10 mg/day | -2880
metformin 1000 mg twice daily | -2880
chief complaint of chylomicronemia | 0
hypertriglyceridemia (triglyceride levels 1100–4000 mg/dL) | 0
alcohol consumption <1 drink/week | 0
20% low fat diet | 0
exercise with 30 minutes of daily walking | 0
no history of pancreatitis | 0
moderate hepatomegaly | 0
no eruptive xanthomata | 0
semaglutide discontinued | 0
switched to tirzepatide | 0
tirzepatide titrated up to 15 mg weekly | 0
triglyceride level decreased from 1404 to 583 mg/dL | 1440
resolution of chylomicronemia | 1440
A1C level decreased from 6.9% to 6.3% | 1440
body weight decreased by 12 lbs (to 176 lbs) | 1440
triglyceride level continued to decrease to 202 mg/dL | 4320
near normalization of hypertriglyceridemia | 4320
A1C level 5.3% | 4320
body weight 168 lbs | 4320