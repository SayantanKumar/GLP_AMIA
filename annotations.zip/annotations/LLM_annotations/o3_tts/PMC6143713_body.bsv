60-year-old | 0  
man | 0  
presented to dermatology clinic | 0  
6 large persistent nodules of abdomen | 0  
6 large persistent nodules of left thigh | 0  
pruritus | 0  
mild discomfort | 0  
slight erythema | 0  
slight warmth | 0  
denied fevers | 0  
denied chills | 0  
denied lymphadenopathy | 0  
denied systemic allergic symptoms | 0  
diabetes mellitus type II | 0  
hypertension | 0  
dyslipidemia | 0  
nonalcoholic steatohepatitis | 0  
exenatide extended release weekly injections | 0  
exenatide discontinued | 0  
betamethasone 0.5 % cream started | 0  
Zyrtec started | 0  
patient requested excision of nodules | 0  
excisional biopsy of right abdominal nodule | 0  
intralesional triamcinolone 10 mg/mL 1 mL injected | 0  
lobular and septal panniculitis with mononuclear cells and eosinophils | 0  
dermal hypersensitivity reaction | 0  
Periodic acid–Schiff stain negative | 0  
acid-fast bacilli stain negative | 0  
first nodule occurred | -1344  
no improvement after betamethasone and Zyrtec | 168  
worsening erythema surrounding biopsy site | 336  
yellow thickened drainage | 336  
doxycycline 100 mg BID started | 336  
doxycycline course completed | 504  
prednisone 50 mg started | 504  
dapsone 50 mg started | 504  
lower extremity edema worsened | 672  
prednisone discontinued | 672  
dapsone discontinued | 672  
follow-up visit | 1008  
nodule measured 0.8 cm | 1008  
nodule size improved >50 % | 1008  
remaining nodules similar size | 1008  
overlying erythema resolved | 1008  
each nodule injected with triamcinolone 10 mg/mL 1 mL | 1008  
return visit | 2016  
significant improvement of all nodules | 2016  
two persistent nodules <0.5 cm | 2016  
injected triamcinolone 10 mg/mL 0.5 mL | 2016  
pruritus resolved | 2016  
discomfort resolved | 2016  
no skin atrophy | 2016  
triamcinolone injections well tolerated | 2016