type 2 diabetes mellitus | -61320  
HbA1c 9-13% during preceding 2 years | -17520  
liraglutide treatment | 0  
received a ball python as a pet | -5040  
received a Mexican black kingsnake as a pet | -2880  
Mexican black kingsnake died | -720  
low-grade fever | -336  
sore throat | -336  
no abdominal pain | -336  
no diarrhea | -336  
chest pain (visit to primary doctor) | -24  
respiratory distress | -24  
cardiomegaly on chest X-ray | -24  
admitted to our hospital | 0  
174 cm tall | 0  
88.0 kg weight | 0  
body mass index 29.1 kg/m2 | 0  
blood pressure 132/77 mmHg | 0  
pulse rate 131/min | 0  
body temperature 36.8 ℃ | 0  
respiratory rate 14/min | 0  
pulse oximetry 97% on room air | 0  
no heart murmur | 0  
no pericardial friction rub | 0  
no abnormal breath sound | 0  
bilateral pitting edema of the lower extremities | 0  
no rashes | 0  
no tattoos | 0  
no cutaneous ulcers | 0  
white-blood-cell count 13,900 /μL | 0  
neutrophils 75.1% | 0  
C-reactive protein 7.3 mg/dL | 0  
plasma glucose 422 mg/dL | 0  
HbA1c 12.2% | 0  
creatine phosphokinase 35 U/L | 0  
N-terminal pro-brain natriuretic peptide 1,939 pg/mL | 0  
liver function unimpaired | 0  
kidney function unimpaired | 0  
thyroid function unimpaired | 0  
electrocardiogram: sinus tachycardia 128/min | 0  
electrocardiogram: low voltage | 0  
electrocardiogram: normal ST segment | 0  
echocardiography: large pericardial effusion | 0  
pericardial thickening on imaging | 0  
bilateral pleural effusion | 0  
no pulmonary parenchymal involvement | 0  
acute pericarditis diagnosed | 0  
emergency pericardiocentesis | 2  
drainage of 750 mL brownish-red purulent fluid | 2  
purulent pericarditis considered | 2  
chest pain improved | 2  
dyspnea on exertion improved | 2  
fosfuluconazole started | 2  
daptomycin started | 2  
doripenem started | 2  
colchicine administered | 2  
bisoprolol fumarate initiated | 2  
pericardial fluid cultures grew Gram-negative bacilli | 24  
no other primary source of infection identified | 24  
pericardial fluid identified as Salmonella enterica subsp. arizona | 72  
blood cultures negative | 72  
chest pain gradually relieved | 120  
white-blood-cell count returned to reference interval | 120  
dyspnea on exertion persisted | 120  
cardiac catheterization performed | 120  
normal coronary artery | 120  
ejection fraction 46.4% | 120  
asynergy present | 120  
pulmonary capillary wedge pressure 24 mmHg | 120  
cardiac index 1.29 L/min/m2 | 120  
unstable hemodynamic status | 120  
transferred to cardiovascular surgery for pericardiotomy | 120  
constrictive pericarditis secondary to bacterial infection diagnosed | 120  
pericardiotomy performed | 120  
recovered well after procedure | 168  
discharged from the hospital | 336