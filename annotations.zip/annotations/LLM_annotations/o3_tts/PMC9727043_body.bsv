53-year-old | 0  
female | 0  
nondiabetic | 0  
asthma diagnosed | -262800  
controlled by PRN budesonide/formoterol | -26280  
budesonide | -26280  
formoterol | -26280  
non-COVID infectious exacerbation | -2160  
prednisone | -2160  
macrolide antibiotic | -2160  
symptoms resolved after prednisone and macrolide | -1680  
symptoms recurred | -720  
budesonide/formoterol increased to BID and PRN | -720  
budesonide (dose increased) | -720  
formoterol (dose increased) | -720  
COVID infection | -8640  
weight gain 40 lb | -336  
adherent to medication | 0  
no nasal symptoms | 0  
occasional heartburn | 0  
normal chest radiograph | 0  
spirometry moderate obstruction | 0  
FEV1 reversibility 21 % | 0  
air-trapping improved with bronchodilator | 0  
blood eosinophil count 100 | 0  
fractionated exhaled nitric oxide 11 | 0  
treated with indacaterol/mometasone/glycopyrronium | 0  
indacaterol | 0  
mometasone | 0  
glycopyrronium | 0  
proton pump inhibitor daily | 0  
semaglutide 1 mg weekly | 0  
weight loss (slow and consistent) | 720  
lung function normalized | 2160  
symptoms resolved | 2160  
allergy testing positive for house dust mite | 720  
allergy testing positive for mold | 720  
allergy testing negative for dog | 720  
repeat spirometry resolution of obstruction | 2160  
no reversibility demonstrated | 2160  
lost 40 lb | 4320  
proton pump inhibitor discontinued | 4320  
asthma therapy reduced to moderate-dose ICS/LABA | 4320  
asthma therapy reduced to low-dose ICS/LABA | 5040  
no recurrence of asthma symptoms | 5040