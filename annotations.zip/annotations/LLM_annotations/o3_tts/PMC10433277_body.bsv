39-year-old | 0
male | 0
obesity | 0
body mass index 39.2 kg/m2 | 0
failure of nonpharmacologic strategies for weight reduction | 0
no allergies | 0
no previous history of atopy | 0
no concomitant disease beyond obesity | 0
treated with liraglutide | 0
liraglutide 0.6 mg daily started | 0
liraglutide dose increased to 1.2 mg daily | 168
liraglutide dose increased to 1.8 mg daily | 336
pruritic erythematous patches on injection sites | 360
pruritus negligible | 360
patient continued drug administration | 360
round erythematous plaques on the abdomen | 360
skin prick test with liraglutide negative | 360
intradermal test negative at 20 minutes | 360
intradermal test negative in 5 healthy controls | 360
patch test with European baseline series negative day 2 | 408
patch test with liraglutide negative day 2 | 408
patch test with liraglutide negative day 3 | 432
intradermal test positive at 24 hours | 384
diagnosis of delayed hypersensitivity to liraglutide | 384
patient refused skin biopsy | 384
clobetasol propionate ointment 0.05% twice daily started | 384
liraglutide dose increased to 2.4 mg daily | 504
liraglutide dose increased to 3 mg daily | 672
mometasone furoate ointment 0.1% once daily started | 720
tolerated liraglutide without skin reaction at end of treatment | 1440
no skin reaction during 6-month follow-up | 4320