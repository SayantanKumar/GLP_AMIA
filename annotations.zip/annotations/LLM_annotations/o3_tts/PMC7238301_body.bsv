61-year-old | 0  
male | 0  
presented to the office for a regular follow-up | 0  
blood pressure 124/72 mm Hg | 0  
heart rate 78 bpm | 0  
respiratory rate 12 bpm | 0  
temperature 98.3 F | 0  
patient asymptomatic | 0  
no evidence of dehydration | 0  
type 2 diabetes mellitus | -8760  
hypertension | -8760  
hyperlipidemia | -8760  
denies smoking | 0  
denies alcohol abuse | 0  
denies illicit drug intake | 0  
amlodipine | 0  
valsartan | 0  
atorvastatin | 0  
pioglitazone | 0  
metformin | 0  
insulin detemir | 0  
liraglutide | 0  
dapagliflozin | 0  
no calcium supplementation | 0  
no vitamin D supplementation | 0  
no proton pump inhibitors | 0  
no histamine H2-receptor antagonists | 0  
no known allergies to medications | 0  
properly hydrating | 0  
denies palpitations | 0  
denies fatigue | 0  
denies abdominal pain | 0  
denies polyuria | 0  
denies impaired concentration | 0  
denies constipation | 0  
denies dysuria | 0  
denies flank pain | 0  
denies history of nephrolithiasis | 0  
denies weight loss | 0  
denies night sweats | 0  
denies dyspnea | 0  
denies cough | 0  
denies rash | 0  
blood draw | -24  
calcium 11.1 mg/dL | -24  
albumin 4.7 g/dL | -24  
blood urea nitrogen 21 mg/dL | -24  
creatinine 0.91 mg/dL | -24  
chloride 101 mmol/L | -24  
fasting glucose 139 mg/dL | -24  
sudden-onset epigastric burning | -36  
took six chewable tablets of Tums 200 mg calcium (500 mg) | -36  
denies regular Tums intake | -36  
asked to refrain from ingesting Tums | 1  
asked to increase oral hydration | 1  
electrocardiography not ordered | 1  
repeat blood work | 120  
calcium 9.3 mg/dL | 120  
ionized calcium 4.8 mg/dL | 120  
parathyroid hormone intact 54 pg/mL | 120  
urine protein electrophoresis negative for monoclonal proteins | 120  
serum protein electrophoresis negative for monoclonal proteins | 120