70 years old | 0
male | 0
chronic obstructive pulmonary disease GOLD 2 | 0
obstructive sleep apnea syndrome | 0
insulin-dependent type 2 diabetes with end-organ damage | 0
diabetic retinopathy | 0
diabetic nephropathy (CKD 3b) | 0
diabetic polyneuropathy | 0
arterial hypertension | 0
coronary heart disease | 0
obesity (body mass index 38 kg/m2) | 0
proximal deep vein thrombosis | -2880
long-acting beta agonist/long-acting muscarinic antagonist combination | 0
inhaled glucocorticoid (400 µg budesonide per day) | 0
valsartan | 0
spironolactone | 0
ivabradine | 0
atorvastatin | 0
metformin | 0
liraglutide | 0
insulin glargine | 0
enoxaparin | 0
productive cough | -336
dyspnea | -336
intermittent fever (>38.5 °C) | -336
arterial pO2 67 mmHg (ambient air) | -168
white blood cell count within normal limits | -168
C-reactive protein 33 mg/dl | -168
D-dimer within normal range | -168
bilateral basal coarse reticular opacities on chest X-ray | -192
no pleural effusions | -192
positive SARS-CoV-2 PCR from oropharyngeal swab | -168
diagnosed with COVID-19 | -168
refused hospitalization | -168
discharged home | -168
oral doxycycline 200 mg once daily started | -168
clinical deterioration | 0
arterial pO2 46 mmHg (ambient air) | 0
multiple bilateral ground-glass opacities on chest CT | 0
crazy paving appearance on CT | 0
reversed halo sign on CT | 0
white blood cell count 11.65 × 10^9/L | 0
neutrophils 9.7 × 10^9/L | 0
C-reactive protein 144 mg/dl | 0
interleukin-6 396 pg/ml | 0
ferritin 465 ng/ml | 0
creatinine 3.26 mg/dl | 0
lymphocytes within normal range | 0
admitted to ICU | 0
moderate ARDS (oxygenation index 154) | 0
meropenem 1 g twice daily started | 0
azithromycin 500 mg once daily started | 0
hydroxychloroquine 200 mg twice daily started | 0
intubated | 0
mechanical ventilation | 0
chest X-ray progression of bilateral infiltrates | 48
oxygenation index <100 | 48
endotracheal aspiration obtained | 72
culture grew Aspergillus fumigatus | 72
positive Aspergillus lateral-flow device | 72
serum galactomannan negative | 72
serum 1,3-β-D-glucan negative | 72
diagnosed with putative invasive pulmonary aspergillosis | 72
intravenous voriconazole initiated | 96
multiorgan failure | 168
deceased | 168
autopsy not performed | 168