72 years old|0
male|0
atrial fibrillation|-720
cataract surgery with intraocular lens implantation right eye|-12960
mild, not-visually-significant nuclear cataract left eye|0
started 3.0 mg oral semaglutide|0
oral semaglutide 3 mg daily|0
propranolol 20 mg twice a day|0
aspirin 81 mg daily|0
naproxen 220 mg as needed|0
ibuprofen 400 mg as needed|0
fall|216
knee pain|216
right eye round central scotoma|384
denies neurologic changes|384
denies autoimmune changes|384
denies psychiatric changes|384
denies other systemic changes|384
irregular square scotoma right eye|408
central scotoma enlargement right eye|408
left eye small round scotoma|456
discontinued semaglutide|480
round scotomas persist both eyes|504
enlarged scotoma right eye covering a door panel|528
residual scotomas remain|552
scotomas gone|576
uncorrected distance visual acuity 20/20 right eye|624
uncorrected distance visual acuity 20/25 left eye|624
benign anterior segment exam|624
well-centered intraocular lens right eye|624
clear posterior capsule right eye|624
mild nuclear sclerotic cataract left eye (on exam)|624
normal appearing optic nerves|624
scattered small drusen in each macula|624
vitreous opacities from posterior vitreous detachment left eye|624
posterior vitreous detachment left eye|624
Humphrey visual field normal|624
subretinal drusenoid deposits|624
poorly defined interdigitation zone in fovea|624
preserved interdigitation zone elsewhere in macula|624
retinal nerve fiber layer OCT normal|624