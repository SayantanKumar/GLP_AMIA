started tirzepatide 2.5 mg subcutaneous once weekly | -672  
new-onset constipation | -650  
firm bowel movements once every 3 days | -650  
eating smaller, more frequent meals | -650  
acute onset lower abdominal cramping pain | -24  
urge to defecate | -24  
bloody stools | -24  
62-year-old | 0  
female | 0  
presented to hospital | 0  
obesity (body mass index 40 kg/m²) | 0  
prior venous thromboembolism | 0  
heart failure with preserved ejection fraction | 0  
diverticulosis | 0  
benign polyps (previous colonoscopies) | 0  
on apixaban 5 mg twice daily | 0  
on spironolactone 25 mg once daily | 0  
on furosemide 20 mg once daily | 0  
on atorvastatin 20 mg once daily | 0  
on fluoxetine 30 mg once daily | 0  
on lisinopril 2.5 mg once daily | 0  
on atenolol 37.5 mg once daily | 0  
no over-the-counter supplements | 0  
no laxatives | 0  
hypertension 155/103 mm Hg | 0  
vital signs otherwise normal | 0  
soft, nondistended abdomen | 0  
mild diffuse lower tenderness | 0  
no guarding | 0  
white blood cell count 12.0 × 10⁹/L | 0  
normal hemoglobin | 0  
normal platelet count | 0  
international normalized ratio 1.6 | 0  
admitted to hospital | 0  
CT wall thickening splenic flexure & descending colon | 2  
pericolonic fat stranding | 2  
mesenteric vasculature patent | 2  
intravenous fluids started | 2  
bowel rest initiated | 2  
intravenous ciprofloxacin started | 2  
intravenous metronidazole started | 2  
analgesics started | 2  
apixaban held | 2  
furosemide held | 2  
spironolactone held | 2  
tirzepatide held | 2  
colonoscopy inflammatory mucosal changes mid-sigmoid to distal transverse colon | 12  
biopsy epithelial denudation | 36  
biopsy sloughing with necrosis | 36  
biopsy crypt withering | 36  
biopsy hyalinization of lamina propria | 36  
biopsy lamina propria congestion | 36  
biopsy lamina propria hemorrhage | 36  
colonic ischemia | 36  
rapid and spontaneous resolution of symptoms | 24  
opioid pain medications weaned off | 48  
discharged | 72  
apixaban resumed | 72  
diuretics held at discharge | 72  
oral ciprofloxacin prescribed | 72  
oral metronidazole prescribed | 72  
no recurrence of rectal bleeding | 240  
intermittent recurrence of bloody bowel movements | 336  
repeat colonoscopy performed | 1800  
2 subcentimeter benign polyps in transverse colon | 1800  
normal mucosa without ischemia or inflammation | 1800