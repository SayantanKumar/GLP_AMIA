65-year-old woman | 0
female | 0
obesity | 0
type 2 diabetes mellitus | 0
hypertension | 0
hyperlipidaemia | 0
transient ischaemic attack | 0
left-sided breast cancer in remission | 0
mastectomy | 0
adjuvant docetaxel | 0
adjuvant cyclophosphamide | 0
fever (initial onset) | -168
dry cough (initial onset) | -168
shortness of breath (initial onset) | -168
exertional dyspnoea | -168
progressively worsening fever | -72
progressively worsening dry cough | -72
progressively worsening exertional dyspnoea | -72
chest CT ground-glass opacities | -24
hypoxaemia with oxygen saturation 87 % on room air | -3
admitted to emergency room | 0
temperature 36.1 °C | 0
blood pressure 107/62 mmHg | 0
heart rate 83 b.p.m. | 0
diminished breath sounds at lung bases | 0
chest X-ray bilateral infiltrates suggestive of pneumonitis | 0
nasopharyngeal swab positive for SARS-CoV-2 | 0
admitted to specialized COVID-19 unit | 0
initiated empiric antibiotics for community-acquired pneumonia | 0
aspirin 81 mg daily (home medication) | 0
losartan-hydrochlorothiazide 50–12.5 mg daily | 0
simvastatin 80 mg nightly | 0
levothyroxine 100 µg daily | 0
omeprazole 40 mg daily | 0
metformin 500 mg twice daily | 0
liraglutide 1.8 mg daily injection | 0
enrolled in remdesivir clinical trial | 24
first dose of remdesivir | 24
ceftriaxone started | 24
azithromycin started | 24
decompensated with shock | 168
multiorgan system failure | 168
acute biventricular heart failure | 168
acute respiratory distress syndrome | 168
acute kidney injury (eGFR 26 mL/min/1.73 m²) | 168
ischaemic hepatitis | 168
markedly elevated inflammatory markers | 168
emergent rapid-sequence intubation | 168
transferred to medical ICU | 168
TTE left ventricular ejection fraction 25 % | 168
norepinephrine infusion initiated | 168
vasopressin infusion initiated | 168
dobutamine infusion initiated | 168
sodium bicarbonate infusion initiated | 168
inhaled epoprostenol initiated | 168
hydrocortisone initiated | 168
propofol started | 168
fentanyl started | 168
cisatracurium (neuromuscular blockade) started | 168
interleukin-6 846 pg/mL | 168
brain natriuretic peptide 401 pg/mL | 168
troponin-I 1.058 ng/mL | 168
D-dimer >20 µg/mL | 168
ferritin 35 461 ng/mL | 168
lactate 4.4 mmol/L | 168
administered 400 mg intravenous tocilizumab | 192
significant clinical improvement | 216
down-trending inflammatory markers | 216
titration off norepinephrine | 216
titration off vasopressin | 216
titration off dobutamine | 216
titration off sodium bicarbonate | 216
cessation of neuromuscular blockade | 216
no significant dysrhythmia on continuous monitoring | 216
repeat TTE left ventricular ejection fraction 64 % | 216
mild right ventricular dysfunction | 216
grade 2 diastolic dysfunction | 216
small circumferential pericardial effusion | 216
interleukin-6 106 pg/mL | 216
brain natriuretic peptide 166 pg/mL | 216
troponin-I 1.682 ng/mL | 216
tracheostomy performed | 336
discharged from ICU | 360
discharged from hospital | 360
undergoing prolonged ventilatory wean at long-term acute care facility | 480