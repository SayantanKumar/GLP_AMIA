diagnosed with multiple acyl-CoA dehydrogenase deficiency | -271560  
hypoglycemia 1.0 mmol/L | -271560  
hyperammonemia 434 μmol/L | -271560  
metabolic acidosis | -271560  
loss of consciousness | -271560  
hypoketotic, dicarboxylic aciduria | -271560  
increased excretion of ethylmalonic acid | -271560  
increased excretion of 2-hydroxyglutaric acid | -271560  
increased excretion of isovaleric glycine | -271560  
compound heterozygous ETFA variants c.[478del];[764G>T] | -271560  
treated with dietary therapy (high-carbohydrate, low-fat, low-protein) | -271560  
riboflavin started | -271560  
levocarnitine started | -271560  
avoidance of prolonged fasting | -271560  
frequent meals instituted | -271560  
episodes of hypoglycemia during infancy | -270000  
remained free of hypoglycemic events since 2.5 years of age | -258420  
consuming 500–1000 mL of soft drinks daily | -166440  
weight 90.9 kg | -1440  
BMI 31 kg/m2 | -1440  
AST 121 U/L | -1440  
ALT 224 U/L | -1440  
GGT 74 U/L | -1440  
cholinesterase 371 U/L | -1440  
non-alcoholic fatty liver disease | -1440  
HbA1c 8.5 % | -720  
insulin 13.9 μU/mL (fasting) | -720  
CPR 2.68 ng/mL | -720  
HOMA-R index 4.5 | -720  
existence of type 2 diabetes mellitus suggested | -720  
soft drink intake increased to 1500–2000 mL/day | -720  
32 years old | 0  
Japanese man | 0  
routine follow-up appointment | 0  
polydipsia | 0  
polyuria | 0  
frequent muscle spasms | 0  
fatigue | 0  
decreased appetite | 0  
weight 74.7 kg | 0  
BMI 25 kg/m2 | 0  
postprandial blood glucose 382 mg/dL | 0  
HbA1c 13.9 % | 0  
total ketone bodies 2.5 mmol/L | 0  
3-hydroxybutyrate 1.4 mmol/L | 0  
serum cholinesterase 293 U/L | 0  
creatine kinase 176 U/L | 0  
urea nitrogen 13 mg/dL | 0  
creatinine 0.56 mg/dL | 0  
venous blood pH 7.42 | 0  
HCO3⁻ 26.5 mmol/L | 0  
pCO2 42.5 mmHg | 0  
anion gap 4.4 mmol/L | 0  
urinalysis positive for glucose | 0  
urinalysis positive for ketone bodies | 0  
insulin 3.9 μU/mL | 0  
AST 26 U/L | 0  
ALT 52 U/L | 0  
GGT 41 U/L | 0  
CT scan showed fatty liver | 0  
visceral fat area 103.90 cm² | 0  
subcutaneous fat area 129.36 cm² | 0  
intravenous saline started | 0  
short-acting insulin infusion started | 0  
insulin lispro infusion | 0  
insulin glargine initiated | 0  
liraglutide initiated | 0  
blood acylcarnitine profile unchanged | 0  
no acidosis | 0  
blood glucose levels stabilized | 264  
transitioned to once-daily liraglutide injection | 264  
well-controlled glycemia | 264  
dietary management changed to 1700 kcal/day (17 % protein, 27 % fat, 56 % carbohydrate) | 264