37 years old | 0  
male | 0  
left eye pain | 0  
dull ache | 0  
no redness | 0  
no light sensitivity | 0  
no vision changes | 0  
using dorzolamide/timolol | 0  
using loteprednol | 0  
using artificial tears | 0  
left-sided headaches | 0  
type 2 diabetes mellitus without neuropathy | 0  
obesity | 0  
obstructive sleep apnea | 0  
taking liraglutide | 0  
taking lorcaserin | 0  
no prior history of headache syndrome | 0  
no anxiety | 0  
no depression | 0  
visual acuity 20/20 with contact lens correction | 0  
intraocular pressure 20 mm Hg | 0  
equal reactive pupils | 0  
no afferent pupillary defect | 0  
full extraocular motility | 0  
full confrontational visual fields | 0  
mild ptosis | 0  
well-covered glaucoma drainage implant plate and tube | 0  
trace injection of the conjunctiva | 0  
clear PKP | 0  
deep and quiet anterior chamber | 0  
0.3 cup-to-disc ratio | 0  
sharp foveal light reflex | 0  
normal retinal vasculature | 0  
normal retinal periphery | 0  
history of consistently wearing a scleral contact lens without issues | -5040  
scleral contact lens uncomfortable | -5040  
history of Baerveldt glaucoma drainage implant implantation | -30672  
acutely elevated intraocular pressure | -30672  
history of penetrating keratoplasty | -35040  
progressive ectasia | -35040  
history of LASIK | -87600  
intermittent 1+ Meibomian gland dysfunction | 2160  
blepharitis | 2160  
no corneal epithelial disruption | 2160  
intermittent 1+ flare in the anterior chamber | 2160  
right eye entirely within normal limits | 2160  
waxing and waning retrobulbar ache | 3600  
redness of the left eye | 3600  
swelling of the left eye | 3600  
ocular pain refractory to topical proparacaine | 3600  
pain severity increasing | 1008  
pain limiting normal work functions | 1008  
pain interfering with sleep | 1008  
burning sensation | 1008  
evaluated by cornea subspecialist | 1008  
evaluated by uveitis subspecialist | 1008  
evaluated by oculoplastics subspecialist | 1008  
evaluated by optometric subspecialist | 1008  
MRI brain and orbit enlarged left lacrimal gland | 1008  
no signs or symptoms of inflammation | 1008  
clinically incompatible with dacryoadenitis | 1008  
tenderness over the aqueous shunt bleb | 1008  
normal B-scan ultrasonography findings | 1008  
negative for posterior scleritis | 1008  
started ibuprofen 800 mg three times daily | 1008  
temporarily alleviated by fluorometholone twice daily OS | 1008  
temporarily alleviated by oral prednisone 60 mg daily | 1008  
pain refractory despite a three-month trial of ibuprofen | 3168  
discontinuation of ibuprofen | 3168  
started gabapentin 300 mg twice daily | 5760  
pain 0 out of 10 | 6264  
tolerated normal wear of scleral contact lens | 6264