polyuria | -26280
polydipsia | -26280
blood glucose level 682 mg/dL | -26280
hemoglobin A1c 12.2% | -26280
serum fasting C-peptide 0.30 ng/mL | -26280
serum immunoreactive insulin 0.8 µU/mL | -26280
anti-glutamic acid decarboxylase antibody negative | -26280
anti-insulin antibody negative | -26280
anti-insulinoma-associated protein-2 antibody negative | -26280
anti-zinc transporter 8 antibody negative | -26280
diagnosed with diabetes mellitus | -26280
diagnosed with autoantibody-negative type 1 DM (T1BDM) | -26280
subcutaneous insulin injection therapy initiated | -26280
insulin therapy twice daily initiated | -26280
insulin therapy transitioned to basal-bolus therapy | -8760
6 years old | 0
male | 0
referred to Asahikawa Medical University Hospital | 0
total daily insulin dose 0.46 units/kg/day | 0
hemoglobin A1c 6.9% | 0
serum fasting C-peptide 0.24 ng/mL | 0
anti-GAD antibody rechecked and negative | 0
anti-insulin antibody rechecked and negative | 0
anti-IA-2 antibody rechecked and negative | 0
ophthalmologic screening performed | 0
uncorrected visual acuity 0.15 right eye | 0
uncorrected visual acuity 0.2 left eye | 0
optic disc pallor right eye | 0
optic disc pallor left eye | 0
optic atrophy in both eyes | 0
critical flicker frequency 23.1 Hz right eye | 0
critical flicker frequency 20.8 Hz left eye | 0
magnetic resonance imaging showed no optic nerve atrophy | 0
no hearing loss | 0
no urinary tract malformations | 0
no diabetes insipidus | 0
no psychiatric symptoms | 0
Wolfram syndrome suspected | 0
WFS1 gene analysis performed | 0
INS gene analysis performed | 0
KCNJ11 gene analysis performed | 0
ABCC8 gene analysis performed | 0
WFS1 variant c.2483delinsGGA identified | 336
WFS1 variant c.1247T>A identified | 336
compound heterozygous WFS1 variants confirmed | 336
c.2483delinsGGA classified as pathogenic | 336
c.1247T>A classified as likely pathogenic | 336
no variants in INS gene | 336
no variants in KCNJ11 gene | 336
no variants in ABCC8 gene | 336
Wolfram syndrome diagnosed | 336
7 years old | 8760