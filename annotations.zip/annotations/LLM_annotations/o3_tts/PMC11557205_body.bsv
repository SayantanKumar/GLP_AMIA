79-year-old | 0  
Japanese male | 0  
type 2 diabetes mellitus for 20 years | -175200  
hypertension | -8760  
metformin hydrochloride therapy | -8760  
glimepiride therapy | -8760  
dulaglutide therapy | -8760  
nifedipine CR therapy | -8760  
doxazosin mesylate therapy | -8760  
telmisartan therapy | -8760  
hydrochlorothiazide therapy | -8760  
poor glycemic control (HbA1c 8.6%) | -408  
miglitol 150 mg/day started | -408  
acetaminophen taken | -240  
leg edema | -336  
general malaise | -336  
admitted to the hospital | 0  
appetite loss | 0  
acute kidney injury | 0  
serum creatinine 8.12 mg/dL | 0  
blood urea nitrogen 62 mg/dL | 0  
eGFR 5.6 mL/min/1.73 m² | 0  
urinary β2-microglobulin 31,748 µg/L | 0  
fractional excretion of sodium 9.43 % | 0  
fractional excretion of urea nitrogen 63.76 % | 0  
low fever 37.5 °C | 0  
elevated C-reactive protein 10.87 mg/dL | 0  
blood cultures negative | 0  
urine cultures negative | 0  
sputum cultures negative | 0  
computed tomography: no post-renal AKI | 0  
blood pressure 178/100 mmHg | 0  
miglitol discontinued | 0  
metformin hydrochloride discontinued | 0  
glimepiride discontinued | 0  
dulaglutide discontinued | 0  
insulin therapy initiated | 0  
drug-induced lymphocyte stimulation test positive for miglitol | 48  
renal biopsy performed | 264  
renal biopsy: acute interstitial nephritis | 264  
renal biopsy: diabetic nephropathy | 264  
renal biopsy: nephrosclerosis | 264  
urinary β2-microglobulin normalized | 312  
gallium scintigraphy: diffuse renal uptake | 384  
serum creatinine increased to 4.77 mg/dL | 528  
oral prednisolone 30 mg started | 528  
discharged from hospital | 600  
serum creatinine remained >3 mg/dL at discharge | 600