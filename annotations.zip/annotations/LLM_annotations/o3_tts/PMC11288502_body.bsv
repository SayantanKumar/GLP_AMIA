54-year-old | 0
male | 0
type 2 diabetes mellitus | -1
dyslipidemia | -1
hypertension | -1
coronary artery disease | -43830
percutaneous coronary intervention | -43830
recurrent ITP | -1
metformin 1,000 mg twice daily | 0
empagliflozin 12.5 mg twice daily | 0
gliclazide 30 mg once daily | 0
semaglutide 1 mg once weekly | 0
atorvastatin 40 mg at bedtime | 0
amlodipine 5 mg once daily | 0
losartan 50 mg once daily | 0
metoprolol 25 mg twice daily | 0
aspirin 81 mg once daily | 0
health care maintenance visit | 0
low ferritin | 0
ferritin level at 20.7 µg/L | 0
iron deficiency anemia | 0
started ferrous gluconate 300 mg daily | 0
platelet count 223 x 10^9/L | 0
remained asymptomatic | 840
platelet count 89 x 10^9/L | 840
thrombocytopenia | 840
cessation of ferrous gluconate | 840
platelet count increased to 144 x 10^9/L | 1080
recurrent gum bleeding | -277882
petechiae | -277882
bone marrow biopsy | -277882
ITP diagnosis | -277882
treated with corticosteroids | -277882
advised annual follow-ups | -277882
widespread petechiae | -121206
persistent epistaxis | -121206
recent upper respiratory tract infection | -121206
vital signs stable | -121206
critically low platelet count | -121206
platelet levels at 1 x 10^9/L | -121206
prednisone 1 mg/kg orally | -121206
intravenous immunoglobulins 50 g daily for 2 days | -121206
tapering course of prednisone | -121206
ranitidine | -121206