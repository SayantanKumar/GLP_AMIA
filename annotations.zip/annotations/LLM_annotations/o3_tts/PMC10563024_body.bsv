84-year-old | 0
woman | 0
presented to dermatology clinic | 0
type II diabetes mellitus | -175200
vildagliptin therapy | -175200
repaglinide therapy | -175200
acarbose therapy | -175200
dulaglutide started | -1440
vildagliptin discontinued | -1440
repaglinide discontinued | -1440
acarbose discontinued | -1440
mild erythematous rash | -768
dulaglutide discontinued | -720
vildagliptin restarted | -720
repaglinide restarted | -720
acarbose restarted | -720
insulin glargine started | -720
diffuse bullous lesions | 0
blister on oral mucosa | 0
intense itching | 0
cutaneous biopsy taken | 0
eosinophilic papillitis | 0
eosinophils along dermal-papillary clefts | 0
IgG deposits on basement membrane | 0
C3 deposits on basement membrane | 0
neutrophilic leukocytosis | 0
elevated inflammatory indices | 0
increased total IgE | 0
BP180 positive >200 U/mL | 0
BP230 positive 31 U/mL | 0
diagnosis bullous pemphigoid | 0
chronic kidney disease | 0
hyperthyroidism | 0
hypertension | 0
no recent infections | 0
no recent vaccinations | 0
tumor markers negative | 0
oral prednisone 25 mg/day started | 0
oral doxycycline 100 mg twice daily started | 0
topical drainage of bullous lesions | 0
topical eosin touching | 0
absence of new lesions | 720
gradual re-epithelialization | 720
prednisone tapered toward discontinuation | 2160
doxycycline tapered toward discontinuation | 2160
prednisone discontinued | 4320
doxycycline discontinued | 4320