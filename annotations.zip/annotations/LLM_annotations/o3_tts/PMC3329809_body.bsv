HIV infection diagnosed | -140160  
zidovudine started | -140160  
dual-therapy zidovudine | -131400  
dual-therapy zalcitabine | -131400  
zidovudine and lamivudine started | -122712  
efavirenz started | -70128  
didanosine started | -70128  
lamivudine (triple-therapy) started | -70128  
dizziness | -65736  
rash | -65736  
depression | -65736  
triple-therapy discontinued | -65736  
atazanavir started | -65600  
tenofovir started | -65600  
lamivudine (continued) | -65600  
progressive abdominal distention | -52584  
atazanavir discontinued | -52584  
raltegravir started | -52584  
weight 105 kg | -52584  
weight gain 15 kg in 2 years | -52584  
type 2 diabetes diagnosed | -52584  
lifestyle consultation | -52584  
metformin 1 000 mg b.i.d. started | -52584  
A1C 8.8 % | -30672  
NPH insulin started | -30672  
weight increased 5 kg | -26304  
little glycemic improvement | -26304  
insulin treatment discontinued | -26304  
glimepiride up to 6 mg q.i.d. started | -26304  
A1C 8.3 % | -26304  
glimepiride discontinued | -5832  
insulin glargine started | -5832  
insulin glargine titrated to 60 U/day | -5832  
weight increased 7 kg | -1440  
no glycemic improvement | -1440  
weight 116 kg | 0  
BMI 35.1 kg/m2 | 0  
A1C 8.1 % | 0  
liraglutide 0.6 mg/day initiated | 0  
liraglutide uptitrated to 1.8 mg/day | 0  
consulted dietitian | 0  
consulted diabetes educator | 0  
advised to lower insulin 10 U if blood glucose <5 mmol/L | 0  
body weight 110 kg | 504  
insulin dose reduced to 30 U/day | 504  
insulin discontinued | 1008  
fasting glucose 12.3 → 7.0 mmol/L | 1008  
no side-effects | 1008  
no hypoglycemia | 1008  
less fatigue | 1008  
improved quality of life | 1008  
self-monitored blood glucose 5.6–8.3 mmol/L | 1008  
HIV-RNA undetectable | 1008  
A1C decreased to 6.8 % | 2880  
body weight 102 kg | 2880  
body weight 108 kg | 5040  
A1C remained 6.8 % | 5040  
liver enzymes normalized | 5040  
total cholesterol 5.6 → 4.9 mmol/L | 5040  
HDL cholesterol 0.79 → 1.0 mmol/L | 5040  
triglycerides 6.6 → 3.1 mmol/L | 5040