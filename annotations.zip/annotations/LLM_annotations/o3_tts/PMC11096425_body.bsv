50-year-old woman | 0
atrial fibrillation | -168
atrial flutter | -168
weekly palpitations | -168
symptoms persisted despite rate control | -168
heart failure with preserved ejection fraction | 0
Corvia atrial shunt insertion | -5040
randomized to Corvia atrial shunt trial | -5040
severe asthma | 0
sotalol relatively contraindicated | -168
flecainide not preferred | -168
drinks 2 standard drinks once per week | 0
nonsmoker | 0
does not exercise | 0
family history of atrial fibrillation | 0
weight 108 kg | -720
weight 96 kg | 0
Ozempic therapy | -720
sinus rhythm | 0
general anesthesia | 1
two venous accesses obtained | 2
decapolar catheter placed in coronary sinus | 2
Farawave sheath for ablation inserted | 2
no intracardiac echocardiography used | 2
atrial burst pacing induced left-sided atrial ectopy | 3
atrial burst pacing induced self-terminating atrial fibrillation | 3
decision to proceed with pulmonary vein isolation | 3
decision for cavotricuspid isthmus line ablation | 3
16F Farawave sheath introduced into right atrium | 4
Farapulse catheter introduced into right atrium | 4
cavotricuspid isthmus line ablation performed | 4
200 mcg intravenous glyceryl trinitrate given | 5
two pulses delivered at four CTI locations | 5
cavotricuspid isthmus block confirmed | 6
Rosen wire advanced through Corvia shunt into left atrium | 7
Farawave sheath guided through Corvia shunt into left atrium | 8
sheath passage through Corvia device without resistance | 8
heparin given to maintain ACT 350–400 s | 9
Farapulse catheter advanced to pulmonary veins | 10
eight pulses per pulmonary vein delivered | 10
catheter retracted into sheath | 11
sheath pulled back through Corvia device into right atrium | 11
no complications | 12