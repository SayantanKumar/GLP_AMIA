72-year-old | 0
male | 0
participated as a control person in a clinical study | 0
exercised regularly | 0
low intake of alcohol | 0
no liver-related symptoms | 0
no symptoms suggesting liver disease | 0
central obesity | 0
waist circumference 100 cm | 0
raised triglycerides 1.8 mmol/L | 0
raised blood pressure 144 mm Hg | 0
BMI 26.1 kg/m2 | 0
mean sensor glucose 8.0 mmol/L | 0
glucose within target range 96 % | 0
semaglutide treatment ongoing | 0
atorvastatin treatment ongoing | 0
type 2 diabetes | -8760
ileocecal resection | -17520
post-operative bile acid malabsorption | -17520
CT abdomen showed no liver abnormalities | -17520
possible cirrhosis detected (initial FibroScan 16.1 kPa) | 0
Fib-4 score 1.56 | 0
referred to hepatologist | 0
no cirrhosis stigmata on physical examination | 24
alanine aminotransferase 78 U/L | 24
alkaline phosphatase 108 U/L | 24
gamma-glutamyl-transferase 159 U/L | 24
aspartate aminotransferase normal | 24
bilirubin normal | 24
platelets normal | 24
albumin normal | 24
fasting FibroScan 19.8 kPa | 48
percutaneous liver biopsy performed | 72
mild steatosis on biopsy | 72
inflammation on biopsy | 72
ballooning on biopsy | 72
fibrosis grade 4 | 72
NASH-cirrhosis diagnosed | 72
alcoholic cirrhosis ruled out | 96
Alcohol Use Disorder Identification Test score 3 (low risk) | 96
viral hepatitis ruled out | 96
hemochromatosis ruled out | 96
autoimmune liver diseases ruled out | 96
primary biliary cholangitis ruled out | 96
celiac disease ruled out | 96
thyroid disease ruled out | 96
lifestyle intervention advice given | 96
advice regarding diet | 96
advice regarding physical activity | 96
advice regarding alcohol intake | 96
does not smoke | 96
empagliflozin initiated | 96
decrease in BMI to 24.7 kg/m2 | 15120
HbA1c decreased by 1 mmol/mol | 15120
total cholesterol decreased by 0.2 mmol/L | 15120
LDL decreased by 0.3 mmol/L | 15120
triglycerides decreased by 0.35 mmol/L | 15120
alanine aminotransferase 61 U/L | 15120
aspartate aminotransferase 37 U/L | 15120
liver stiffness 12.2 kPa | 15120
no signs of hepatic decompensation | 15120