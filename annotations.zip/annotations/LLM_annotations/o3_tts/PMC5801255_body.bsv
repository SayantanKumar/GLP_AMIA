born at 36 weeks’ gestation | -245280
vaginal breech delivery | -245280
newborn asphyxia | -245280
Apgar score of 4 | -245280
hypotonia | -245280
height could not be measured | -245280
weight was 2150 g | -245280
diagnosed with Prader–Willi syndrome | -157680
floppy infant | -157680
almond shaped eyes | -157680
scoliosis | -157680
obesity (weight more than 20% of standard) | -157680
mental retardation (IQ of 61) | -157680
hypogonadism with bilateral cryptorchidism | -157680
referred to a pediatric endocrinologist | -140160
oral glucose tolerance test showed impaired glucose tolerance | -140160
insulin tolerance test showed little reaction of growth hormone | -140160
GH therapy was not done | -140160
severe obesity | -140160
diagnosed with diabetes | -105120
began to take several kinds of oral hypoglycemic agents | -105120
referred to our department of diabetes and endocrinology | 0
body weight of 90.6 kg | 0
height of 152.2 cm | 0
BMI of 39.1 kg/m2 | 0
no sign of diabetic retinopathy | 0
microalbuminuria (13.6 mg/gCr) | 0
treated with glibenclamide (1.25 mg/day) | 0
treated with metformin (1000 mg/day) | 0
treated with pioglitazone (15 mg/day) | 0
HbA1c was 11.2% (99 mmol/mol) | 0
never had a neuroleptic drug prescribed | 0
genetic testing was performed | 24
abnormal DNA methylation detected in DMR upstream of SNRPN | 24
SNP array analysis showed no copy number variants | 24
microsatellite analysis revealed maternal uniparental disomy | 24
metformin increased to 2.25 g/day | 24
NPH insulin at bedtime of 28 U started | 24
miglitol (150 mg/day) started | 24
diet of 1600 kcal/day initiated | 24
exercise therapy initiated | 24
lost 12 kg of fat | 5112
HbA1c deteriorated to 12.2% (110 mmol/mol) | 5112
body composition measured by bioimpedance analysis | 5112
NPH insulin discontinued | 5112
exenatide (20 μg/day) started | 5112
lost 15 kg body weight (6 kg fat and 9 kg muscle) | 17520
massive loss of muscle mass | 17520
body weight reached 62.5 kg | 43800
exenatide discontinued | 43800
insulin glargine (6 U/day) started | 43800
lixisenatide administered | 43800
body weight stabilized | 43800
HbA1c did not improve | 43800
tofogliflozin (20 mg/day) added | 61320
lixisenatide discontinued | 61320
dulaglutide (0.75 mg/week) started | 61320
HbA1c began to decrease | 61320
body weight maintained at 62.8 kg | 67890
HbA1c improved to 8.5% (69 mmol/mol) | 67890
total ketone body level 781 µM | 67890
C-peptide induced by glucagon unchanged | 67890
abdominal CT scan performed | 67890
subcutaneous fat area decreased from 263.6 to 116.0 cm2 | 67890
visceral fat area hardly changed | 67890
fatty infiltration of pancreas disappeared | 67890
P/S value improved from −0.857 to −0.043 | 67890
liver lipid deposition did not change significantly | 67890
effect has lasted at least 1 year | 70080