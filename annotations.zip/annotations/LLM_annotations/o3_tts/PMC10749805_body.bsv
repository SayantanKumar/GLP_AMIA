diagnosed with T2DM at 50 years old | -175200  
became aware of bilateral leg swelling | -2160  
70-year-old | 0  
male | 0  
Japanese | 0  
type 2 diabetes mellitus | 0  
hypertension | 0  
chronic heart failure | 0  
nephrotic syndrome | 0  
diabetic nephropathy | 0  
atrial fibrillation | 0  
bilateral leg swelling | 0  
dermatosclerosis | 0  
height 167.5 cm | 0  
body weight 78.7 kg | 0  
BMI 28.1 kg/m2 | 0  
blood pressure 134/90 mmHg | 0  
irregular pulse 95 beats per minute | 0  
electrocardiogram atrial fibrillation | 0  
chest X-ray enlarged heart cardiothoracic ratio 57% | 0  
small amount of right pleural effusion | 0  
White blood cells 5,100 /µL | 0  
Red blood cells 3.4 ×106/µL | 0  
Hemoglobin 11.6 g/dL | 0  
Platelets 18.0 ×104/µL | 0  
Total protein 6.4 g/dL | 0  
Albumin 3.0 g/dL | 0  
Total bilirubin 0.6 mg/dL | 0  
AST 20 U/L | 0  
ALT 13 U/L | 0  
BUN 16 mg/dL | 0  
Creatinine 0.78 mg/dL | 0  
eGFR 75.2 mL/min/1.73 m2 | 0  
Uric acid 5.1 mg/dL | 0  
Sodium 142 mEq/L | 0  
Potassium 4.0 mEq/L | 0  
Chloride 105 mEq/L | 0  
Calcium 8.6 mg/dL | 0  
LDL-C 80 mg/dL | 0  
HDL-C 55 mg/dL | 0  
Triglyceride 105 mg/dL | 0  
BNP 390.7 pg/mL | 0  
Glucose 141 mg/dL | 0  
Hemoglobin A1c 7.8 % | 0  
Urinary C-peptide 49 µg/day | 0  
Anti-GAD antibody <5.0 U/mL | 0  
Urinary pH 7.5 | 0  
Urinary protein 2+ | 0  
Urinary glucose 4+ | 0  
Urinary ketone body negative | 0  
Urinary protein 3.8 g/day | 0  
no apparent causative disease other than diabetic nephropathy | 0  
glimepiride 1 mg/day | 0  
dapagliflozin 5 mg/day | 0  
1,800-kcal diet therapy started | 12  
salt restriction NaCl 6 g/day started | 12  
Serum C-peptide 2.03 ng/mL | 24  
blood glucose approximately 200 mg/dL | 24  
salt restriction improved leg swelling | 48  
salt restriction improved blood pressure | 48  
multiple insulin injection therapy started | 72  
glimepiride discontinued | 72  
dapagliflozin dose increased to 10 mg/day | 96  
sacubitril/valsartan 200 mg/day started | 192  
nifedipine CR 60 mg/day discontinued | 192  
azilsartan 40 mg/day discontinued | 192  
Urinary C-peptide 307 µg/day | 288  
blood glucose approximately 200 mg/dL (day 13) | 288  
oral semaglutide 3 mg/day added | 312  
BNP 151.2 pg/mL | 360  
Serum C-peptide 2.71 ng/mL | 360  
insulin requirement 51 units/day | 408  
blood pressure 86/59 mmHg | 456  
sacubitril/valsartan dose reduced to 100 mg/day | 456  
mitiglinide 30 mg/day added | 480  
voglibose 0.9 mg/day added | 504  
blood pressure remained low | 552  
sacubitril/valsartan discontinued | 552  
azilsartan 20 mg/day started | 552  
Serum C-peptide 3.16 ng/mL | 624  
olmesartan 20 mg/day started | 672  
BNP 128.1 pg/mL | 816  
Urinary C-peptide 99 µg/day | 816  
insulin requirement decreased to 22 units/day | 816  
blood glucose normalized | 816  
eGFR decreased | 816  
urine protein decreased | 816  
urine volume decreased | 816  
discharged | 816