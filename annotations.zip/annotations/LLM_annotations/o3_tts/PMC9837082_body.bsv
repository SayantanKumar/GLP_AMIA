started low carbohydrate, calorie restricted diet | -7920
severe vomiting | -7752
stopped low carbohydrate diet | -7200
lost 20 lbs | -7200
fatigue | -3600
proximal muscle weakness | -3600
presented to neurology clinic | -3600
elevated thyroid stimulating hormone 5.45 μIU/mL | -3600
elevated thyroid peroxidase antibodies | -3600
elevated creatine kinase 588 units/L | -3600
started Levothyroxine 25 mcg daily | -3600
myositis antibody panel normal | -3600
necrotizing myopathy antibodies normal | -3600
myasthenia gravis antibodies normal | -3600
muscular dystrophy genetic panel normal | -3600
electromyography suggested inflammatory, genetic, or metabolic myopathy | -3600
vastus lateralis biopsy: vacuolated muscle fibers with lipid droplets | -3000
plasma acylcarnitine profile: elevated small-, medium-, and long-chain acylcarnitines | -3000
urine organic acid analysis: elevated orotic acid | -3000
urine organic acid analysis: elevated 2-hydroxy glutaric acid | -3000
genetic testing ordered (pending) | -3000
thyroid stimulating hormone 4.17 μIU/mL | -2160
symptoms continued to worsen | -2160
27-year-old woman | 0
class III obesity (BMI 40.0 kg/m2) | 0
admitted to the hospital | 0
severe fatigue | 0
generalized muscle weakness | 0
multiple falls | 0
decreased oral intake | 0
proximal greater than distal weakness of bilateral upper and lower extremities | 0
neck weakness | 0
trace to absent lower extremity reflexes | 0
pulmonary embolism | 0
severe ketoacidosis venous pH 7.00 | 0
beta hydroxybutyrate 5.67 nmol/L | 0
rhabdomyolysis creatine kinase 4656 units/L | 0
lactate 6.0 mmol/L | 0
admission to intensive care unit | 1
sodium bicarbonate infusion | 1
normal saline infusion | 1
thiamine infusion | 1
dextrose infusion | 1
heparin infusion | 1
carnitine supplementation started | 12
riboflavin supplementation started | 12
cyanocobalamin supplementation started | 12
coenzyme Q10 supplementation started | 12
venous pH normalized to 7.45 | 24
creatine kinase improved to 245 units/L | 24
lactate improved to 3.6 mmol/L | 24
continued proximal greater than distal weakness | 24
heterozygous frameshift mutation c.51dup in ETFDH identified | 48
discharged to inpatient rehabilitation | 72
maintained on carnitine supplementation | 72
maintained on riboflavin supplementation | 72
maintained on cyanocobalamin supplementation | 72
maintained on coenzyme Q10 supplementation | 72
maintained on thiamine supplementation | 72
high carbohydrate, low-fat diet started | 72
advised to avoid prolonged fasting | 72
discharged home | 240
intermittent nausea | 336
ondansetron required | 336
neuropathic pain | 336
pregabalin required | 336
strength improved | 336
energy improved | 336
creatine kinase normalized 36 units/L | 504
acylcarnitine profile shifted toward short- and medium-chain species | 504
urine organic acid analysis normal | 504
whole genome sequencing no reportable variants | 720
balanced translocation t(5;19)(p10;q10) identified | 720
weight gain 30 lbs | 2880
metformin initiated | 2880
liraglutide initiated | 3000
thyroid stimulating hormone 21.58 μIU/mL | 3000
levothyroxine increased to 100 mcg daily | 3000
improved strength and energy sustained | 8760