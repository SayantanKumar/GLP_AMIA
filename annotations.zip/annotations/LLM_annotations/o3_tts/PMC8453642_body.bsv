51-year-old | 0  
female | 0  
presented to clinic | 0  
long-standing Hashimoto’s disease | 0  
chronic urticaria | 0  
mast cell activation disorder | 0  
hypertension | 0  
diabetes mellitus type 2 | 0  
multiple chemical sensitivities | 0  
76 food allergies | 0  
medication sensitivities | 0  
recurrent hives | 0  
skin dryness | 0  
fatigue | 0  
weight gain | 0  
intermittent constipation | 0  
intermittent diarrhea | 0  
cold intolerance | 0  
brain fog | 0  
difficulty with word finding | 0  
swelling in lower extremities | 0  
daytime somnolence | 0  
temperature 36.6 °C | 0  
pulse 92 beats per minute | 0  
blood pressure 136/88 mmHg | 0  
respiratory rate 18 per minute | 0  
O2 saturation 98 % | 0  
height 1.57 m | 0  
weight 92 kg | 0  
body mass index 37.3 kg/m2 | 0  
no acute distress | 0  
no palpable thyroid nodules | 0  
no visible urticaria | 0  
hypoactive bowel sounds | 0  
minimal left lower quadrant tenderness | 0  
family history of papillary thyroid cancer in a sister | 0  
generic L-T4 therapy tried and failed | -720  
transitioned to L-T4 sodium tablets (Synthroid®) 125 µg daily | 0  
metformin 1000 mg orally twice daily | 0  
liraglutide 1.8 mg daily | 0  
metformin discontinued (initial trial) | -336  
switch to compounded T4/T3 medication | 1008  
T4/T3 compound dose escalated | 2016  
T4/T3 compound second escalation | 3024  
projectile vomiting with undigested food | 4032  
worsening gastrointestinal symptoms | 4032  
weight loss | 4032  
10–20 bowel movements daily | 4032  
metformin discontinued (final) | 4032  
liraglutide discontinued | 4032  
upper endoscopy revealed gastritis | 4032  
hiatal hernia | 4032  
gastric emptying study 20 % retention at 4 h | 4032  
diagnosed gastroparesis | 4032  
started high-dose probiotics | 4032  
started dicyclomine hydrochloride | 4032  
initiated gastroparesis diet | 4032  
diagnosed small intestinal bacterial overgrowth | 4032  
treated with rifaximin | 4032  
switched to L-T4 oral solution 150 µg | 4032  
TSH 1.55 mIU/L | 5040  
continuing L-T4 oral solution 150 µg | 5040  
completed rifaximin cycle | 5040  
TSH 0.56 mIU/L | 6048  
L-T4 oral solution 150 µg continued | 6048  
down-titrated L-T4 oral solution to 112 µg | 7056  
TSH 1.95 mIU/L | 7056  
resolution of thyroid symptoms | 7056  
no side effects or reaction to medication | 7056