uterine fibroids | -1  
hypertension | -1  
insulin resistance | -1  
55-year-old | 0  
nulliparous female | 0  
BMI 80 kg/m2 | 0  
presented to specialist Gynae-oncology clinic | 0  
vaginal bleeding | -4320  
trans-vaginal pelvic ultrasound: endometrial thickness 44 mm | 0  
hysteroscopy | 0  
endometrial biopsy | 0  
levonorgestrel IUD insertion | 0  
atypical endometrial hyperplasia | 0  
bariatric surgery declined | 0  
weight plateau at 195 kg (BMI 68 kg/m2) | 4320  
repeat endometrial biopsy | 8640  
grade 1 endometrioid adenocarcinoma of uterus | 8640  
ER strongly positive (uterus) | 8640  
PR strongly positive (uterus) | 8640  
loss of MLH1 and PMS2 (uterus) | 8640  
CT chest/abdomen/pelvis: no metastatic disease | 8640  
medroxyprogesterone 100 mg orally twice daily commenced | 8640  
Liraglutide commenced | 12960  
Metformin commenced | 12960  
weight 180 kg | 17280  
continued refusal of bariatric surgery | 17280  
repeat curettage | 17280  
regression to atypical endometrial hyperplasia | 17280  
medroxyprogesterone increased to 200 mg orally twice daily | 17280  
blood-stained fluid discharge from umbilicus | 21600  
CT abdomen/pelvis: umbilical soft-tissue mass 32 × 33 × 39 mm | 21600  
core biopsy: FIGO grade 1 EAC metastasis | 21600  
ER strongly positive (umbilical lesion) | 21600  
PR strongly positive (umbilical lesion) | 21600  
loss of MLH1 and PMS2 (umbilical lesion) | 21600  
PET: increased uptake in uterus | 21600  
PET: increased uptake in umbilicus | 21600  
PET: increased uptake in left parametrial lymph node | 21600  
PET: increased uptake in right inguinal node | 21600  
CA-125 420 U/mL | 21600  
diagnostic laparoscopy: no widespread peritoneal disease | 21600  
letrozole commenced | 21600  
disease progression on letrozole | 23760  
Carboplatin-Paclitaxel combination chemotherapy commenced | 23760  
CA-125 reduced to 50 U/mL | 25200  
weight 157 kg (BMI 54.3 kg/m2) | 25200  
repeat CT: umbilical mass increased to 72 × 70 × 100 mm | 25200  
no new sites of disease on CT | 25200  
asymptomatic pulmonary embolism | 25200  
Apixaban commenced | 25200  
robotic total hysterectomy performed | 25920  
bilateral salpingo-oophorectomy performed | 25920  
right inguinal lymph node resection | 25920  
resection of umbilical mass | 25920  
residual 1 cm left pararectal peritoneal nodule unresectable | 25920  
infected abdominal wall seroma | 26000  
drainage of seroma | 26000  
systemic then oral antibiotics for 10 days | 26000  
uterus histology: FIGO grade 1 endometrioid adenocarcinoma | 25920  
right inguinal node histology: FIGO grade 2 endometrioid adenocarcinoma | 25920  
umbilical lesion histology: dedifferentiated endometrial carcinoma | 25920  
SMARCA4 loss in umbilical lesion | 25920  
final surgical stage IVB | 25920  
further 3 cycles Carboplatin-Paclitaxel completed (total 6) | 26300  
external beam radiation to right inguinal region | 26300  
germline testing: negative for Lynch syndrome | 26300  
CT chest/abdomen/pelvis: progressive peritoneal and retroperitoneal disease | 28080  
referred for clinical-trial consideration with immune check-point inhibitor | 28080  
alive 14 months since umbilical metastatic diagnosis | 31680