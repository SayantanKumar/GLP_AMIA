53-year-old | 0
White | 0
male | 0
presented for evaluation of nephrotic range proteinuria | 0
nephrotic range proteinuria | 0
hypertension | -8760
former tobacco use | -8760
morbid obesity | -8760
type 2 diabetes | -8760
cystinuria | -8760
nephrolithiasis | -8760
lithotripsy | -8760
tiopronin initiated | -5040
tiopronin | 0
potassium citrate | 0
semaglutide | 0
amlodipine | 0
telmisartan | 0
chlorthalidone | 0
blood pressure 128/92 mmHg | 0
body mass index 41.5 kg/m2 | 0
no peripheral edema | 0
serum creatinine 1.1 mg/dl | 0
estimated glomerular filtration rate 80 ml/min per 1.73 m2 | 0
3+ protein on urinalysis | 0
urinalysis negative blood | 0
no leukocyturia | 0
24-hour urine protein 4.6 g | 0
serum albumin 4.5 g/dl | 0
normal serum complement levels | 0
negative ANA | 0
negative dsDNA antibody | 0
negative hepatitis B surface antigen | 0
negative hepatitis C antibody | 0
negative MPO-ANCA | 0
negative PR3-ANCA | 0
negative anti-PLA2R antibody | 0
negative anti-GBM antibody | 0
negative HIV | 0
no M-spike on SPEP | 0
no M-spike on UPEP | 0
kidney biopsy performed | 0
no globally sclerotic glomeruli | 0
no segmentally sclerotic glomeruli | 0
mild tubular atrophy | 0
interstitial fibrosis 10%–15% | 0
no significant interstitial inflammation | 0
intact proximal tubule brush borders | 0
IgG 2–3+ granular to semilinear segmental capillary wall staining | 0
trace C3 | 0
kappa 2+ | 0
lambda 2+ | 0
small segmental subepithelial electron-dense deposits | 0
no mesangial electron-dense deposits | 0
no subendothelial electron-dense deposits | 0
no extraglomerular electron-dense deposits | 0
no endothelial tubuloreticular inclusions | 0
podocyte foot process effacement 30%–40% | 0
PLA2R staining negative | 0
NELL-1 staining positive | 0
Segmental membranous nephropathy, NELL-1 positive (tiopronin-associated) | 0
tiopronin discontinued | 12
telmisartan started (therapy adjustment) | 12
dapagliflozin started | 12
denies lipoic acid supplementation | 0
no occupational or environmental heavy metal exposure risk factors | 0
computed tomography chest/abdomen/pelvis negative | 24
screening colonoscopy negative | 24
prostate-specific antigen testing negative | 24
immunosuppressive therapies deferred | 24
serum creatinine 1.0 mg/dl | 4320
urine protein-to-creatinine ratio 2.08 g/g | 4320
serum albumin 4 g/dl | 4320