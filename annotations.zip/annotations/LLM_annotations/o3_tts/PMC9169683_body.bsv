Calcium 8.1 mg/dL | -336
Glucose 379 mg/dL | -336
air conditioner stopped working | -168
home overheated | -168
standing close to freezer door | -168
eating pieces of ice | -168
feeling heated | -168
sweating profusely | -168
headache | -72
dizziness | -72
nausea | -72
weakness | -72
chronic obstructive pulmonary disease | 0
hypertension | 0
hyperlipidemia | 0
bipolar disorder | 0
autoimmune hepatitis with cirrhosis | 0
gastroesophageal reflux disease | 0
hypothyroidism | 0
type 2 diabetes mellitus | 0
history of nonadherence to prescription medication regimen | 0
history of nonadherence to diabetic diet | 0
denies antacids | 0
denies calcium supplements | 0
denies vitamin A supplements | 0
no recent changes in prescription medications | 0
albuterol inhaler | 0
clonidine 0.2 mg twice daily | 0
atorvastatin 40 mg nightly | 0
quetiapine 300 mg nightly | 0
fluoxetine 20 mg daily | 0
benztropine 1 mg twice daily | 0
prednisone 5 mg daily | 0
pantoprazole 40 mg daily | 0
furosemide 20 mg daily | 0
levothyroxine 50 mcg daily | 0
metformin 1000 mg twice daily | 0
insulin degludec 16 units every morning | 0
exenatide 2 mg weekly | 0
blood pressure 150/90 mmHg | 0
temperature 37.4 °C | 0
heart rate 105 beats/min | 0
respiratory rate 18 breaths/min | 0
oxygen saturation 99 % on room air | 0
lethargy | 0
dry mucus membranes | 0
physical examination unremarkable | 0
hyperglycemia 365 mg/dL | 0
calcium 17.3 mg/dL | 0
ionized calcium 1.95 mM/L | 0
hyperglycemia without diabetic ketoacidosis | 0
electrocardiogram normal sinus rhythm | 0
2-liter normal-saline bolus administered | 0
continuous infusion of normal saline 150 mL/h started | 0
admitted to medical floor | 0
parathyroid hormone 5 pg/mL | 12
parathyroid hormone-related peptide <0.4 pmol/L | 12
25-hydroxy vitamin D 23 ng/mL | 12
1,25-dihydroxy vitamin D 11.2 pg/mL | 12
thyroid-stimulating hormone 1.266 uIU/mL | 12
cortisol 11.5 µg/dL | 12
serum protein electrophoresis unremarkable | 12
kappa free light chain 23.9 mg/L | 12
lambda free light chain 20.3 mg/L | 12
kappa/lambda ratio 1.18 | 12
calcium level gradually improved | 24
bisphosphonate therapy not needed | 24
calcium normalized | 72
intravenous hydration stopped | 72
symptoms resolved | 72
discharged home | 96
atorvastatin continued after discharge | 96
follow-up visit with primary care physician | 264
mammography bilateral breast unremarkable | 264
nuclear bone imaging whole body unremarkable | 264
computed tomography chest abdomen pelvis unremarkable | 264
calcium within reference range | 264