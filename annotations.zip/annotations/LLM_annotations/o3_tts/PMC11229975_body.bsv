43 years old | 0
female | 0
600000 islet equivalents laparoscopically transplanted onto the omentum | 0
diabetes (25-year history) | -219000
discontinued insulin infusion | 1
insulin independence | 1
maintained insulin independence | 8760
stable glycemic control | 8760