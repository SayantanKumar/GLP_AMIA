27 years old | 0  
male | 0  
history of Crohn disease | 0  
history of obesity (body mass index 37.1) | 0  
history of depression | 0  
sleep apnea on continuous positive airway pressure | 0  
presented to the endocrine clinic | 0  
low mood | -6480  
fatigue | -6480  
low testosterone diagnosed | -6480  
intramuscular testosterone cypionate 120 mg weekly | 0  
total testosterone 2.43 ng/mL | 0  
normal hair distribution | 0  
normal muscle mass | 0  
normal muscle strength | 0  
soft 10 mL testicles | 0  
no palpable testicular nodule | 0  
testosterone replacement therapy discontinued | 0  
repeat morning labs obtained | 6480  
total testosterone 0.91 ng/mL | 6480  
bioavailable testosterone 0.69 ng/mL | 6480  
sex hormone binding globulin 8 nmol/L | 6480  
luteinizing hormone 3.1 mIU/mL | 6480  
follicle stimulating hormone 2.7 mIU/mL | 6480  
estradiol 23 pg/mL | 6480  
insulin-like growth factor 1 193 ng/mL | 6480  
prolactin 10 ng/mL | 6480  
thyroid stimulating hormone 1.03 mIU/L | 6480  
free thyroxine 1.15 ng/dL | 6480  
8 am cortisol 13.5 µg/dL | 6480  
adrenocorticotropic hormone 37 pg/mL | 6480  
semen analysis unremarkable | 6480  
iron studies normal | 6480  
pituitary MRI: kissing internal carotid arteries compressing pituitary gland | 6480  
brain MRA: no intracranial aneurysm | 6480  
brain MRA: no vascular malformation | 6480  
started subcutaneous semaglutide 0.25 mg weekly | 6480  
semaglutide titrated to 1 mg weekly | 6720  
30 lb weight loss | 8640  
body mass index 33.05 | 8640  
testosterone levels did not improve | 9000  
testosterone replacement therapy not reinitiated | 9000  
diagnosed with hypogonadotropic hypogonadism | 6480  
intracranial kissing carotid arteries (anatomic variant) | 6480