admitted to our hospital | 0
body weight 87 kg | 0
body mass index 31 kg/m2 | 0
history of hypertension | 0
history of dyslipidemia | 0
history of hyperuricemia | 0
history of non-alcoholic fatty liver disease | 0
insulin release test showed delayed insulin secretion | 0
insulin release test without insulin deficiency | 0
pancreatic islet autoantibodies negative | 0
laparoscopic sleeve gastrectomy | 0
short-acting recombinant human insulin used to control perioperative hyperglycaemia | 0
short-acting recombinant human insulin discontinued immediately after the surgery | 0
metformin discontinued the day before surgery | -24
history of metformin 1000 mg bid | -720
history of T2DM for 6 years | -52560
no diabetic ketoacidosis before admission | -720
liraglutide was once prescribed (less than 3 months) | -9600
no obvious adverse reactions to liraglutide | -9500
stopped taking liraglutide 1 year ago | -8760
father diagnosed with T2DM | -1
postoperative Day 1 blood glucose 13.4–16.8 mmol/L | 24
degludec insulin 20 IU qn prescribed | 24
metformin 500 mg tid prescribed | 24
dulaglutide 1.5 mg weekly prescribed | 24
started sipping water | 24
started enteral nutritional suspension | 24
felt bloated | 24
felt full | 24
total daily fluid intake 800–1000 mL | 24
total daily calorie intake <500 kcal | 24
abdominal CT showed no abnormal signs | 24
fasting blood glucose 7–8 mmol/L | 24
postprandial blood glucose 8–12 mmol/L | 24
lost 5 kg in 5 days | 120
fatigue | 144
sweating | 144
nausea | 144
vomiting 30 times | 144
metabolic acidosis | 144
blood sugar 16.1 mmol/L | 144
urine ketone over 4+ | 144
urine glucose over 4+ | 144
fluid resuscitation administered | 144
glucose administered | 144
insulin infusion initiated at 0.05 units/kg/h | 144
degludec insulin discontinued | 144
metformin discontinued (post-EKA) | 144
dulaglutide discontinued | 144
no infections | 144
no alcohol intake | 144
blood glucose 11.8 mmol/L | 168
urine ketone +++ | 168
no nausea | 192
no vomiting | 192
urine ketone negative | 192
random blood glucose less than 11.1 mmol/L | 192
insulin infusion discontinued | 192
fluid infusion discontinued | 192
advised to ensure fluid and energy intake | 192
discharged on postoperative Day 10 | 240