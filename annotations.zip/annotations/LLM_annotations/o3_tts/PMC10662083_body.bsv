bigger than other children by age 8 | -183960  
progressive weight gain | -87600  
29-year-old | 0  
woman | 0  
initial appointment | 0  
seeking medical and surgical weight loss options | 0  
unsuccessful attempts at weight loss through lifestyle modification | 0  
dyslipidemia | 0  
hypertension | 0  
obstructive sleep apnea | 0  
pre-diabetes | 0  
carvedilol (ongoing) | 0  
amlodipine (ongoing) | 0  
hydrochlorothiazide (ongoing) | 0  
torsemide (ongoing) | 0  
valsartan (ongoing) | 0  
atorvastatin (ongoing) | 0  
cholestyramine (ongoing) | 0  
weight 185.3 kg | 0  
BMI 68.1 | 0  
blood pressure 132/66 mmHg | 0  
excess abdominal adiposity | 0  
large dorsocervical fat pad | 0  
total cholesterol 182 mg/dL | 0  
LDL 129 mg/dL | 0  
triglyceride 189 mg/dL | 0  
A1c 5.6 % | 0  
Binge Eating Severity Scale 16 | 0  
none-to-minimal binge eating behaviors | 0  
workup for hypothyroidism normal | 0  
no excess cortisol | 0  
phentermine 37.5 mg daily started | 0  
topiramate 50 mg daily started | 0  
weight loss 8 kg | 3192  
topiramate increased to 50 mg twice daily | 3192  
phentermine dose maintained | 3192  
surgical management deferred | 3192  
semaglutide initiated | 3192  
intractable nausea | 3696  
semaglutide discontinued | 3696  
weight loss 60 lbs (15 % of initial weight) | 5040  
blood pressure medications down-titrated | 5040  
CPAP discontinued | 5760  
improvement in obstructive sleep apnea symptoms | 5760  
hydrochlorothiazide discontinued | 6480  
valsartan discontinued | 8640  
amlodipine discontinued | 8640  
carvedilol discontinued | 8640  
repeat Binge Eating Severity Scale 1 | 8640  
weight loss 67.3 kg | 9744  
BMI 43.4 | 9744  
classified as hyper-responder to phentermine/topiramate | 9744  
genetic testing performed | 10800  
PLXNA4 variant identified | 10800