presentation to emergency department | 0
agitation | -4
shortness of breath | -4
abdominal pain | -4
fatigue | -96
malaise | -96
fever (four days before presentation) | -96
sore throat | -96
type 2 diabetes mellitus diagnosed | -61320
canagliflozin started 300 mg daily | -26280
poorly controlled T2DM | 0
morbid obesity (BMI 41.52 kg/m2) | 0
dry oral mucosa | 0
fever 38.5 °C (on exam) | 0
tachycardia 110 beats/min | 0
tachypnea 28 breaths/min | 0
low blood pressure 110/50 mmHg | 0
non-exudative pharyngitis | 0
shallow breathing | 0
bilateral vesicular breathing without added sounds | 0
cardiac exam normal apart from sinus tachycardia | 0
mild epigastric tenderness | 0
other systemic examination unremarkable | 0
mild hyperglycemia 13.6 mmol/L | 0
bicarbonate 4 mmol/L | 0
venous blood pH 6.84 | 0
high anion gap 34 | 0
urine ketone 15 mmol/L | 0
lactic acid normal 2 mmol/L | 0
leukocytosis 29 × 10⁹/L | 0
hemoglobin 16.4 g/L | 0
platelet count 350 × 10⁹/L | 0
C-reactive protein 64 g/L | 0
procalcitonin 2.3 ng/mL | 0
toxicology screen negative | 0
sodium 135 mmol/L | 0
potassium 3.8 mmol/L | 0
creatinine 85 μmol/L | 0
urea 4 mmol/L | 0
no rhabdomyolysis (CK 223 IU/L) | 0
serum osmolality 315 mOsm/kg | 0
liver function tests normal | 0
thyroid tests normal | 0
chest X-ray normal | 0
HbA1C 13.3 % | 0
broad-spectrum antibiotic therapy started | 0
diabetic ketoacidosis protocol initiated | 0
insulin bolus 10 units given | 0
insulin infusion started | 0
received additional 2 L normal saline prior to arrival | -1
five liters crystalloid fluid administered | 1
sodium bicarbonate infusion started | 2
respiratory distress developed | 3
intubation and assisted ventilation | 3
renal replacement therapy initiated | 4
significant diuresis | 24
blood, sputum, and urine cultures negative | 12
influenza screen negative | 12
Strep A test negative | 12
HIV test negative | 12
hepatitis B test negative | 12
hepatitis C test negative | 12
respiratory viral panel positive for adenovirus | 12
family brought home medications | 18
home medication: gliclazide 120 mg daily | 18
home medication: canagliflozin 300 mg daily | 18
home medication: pioglitazone 30 mg daily | 18
home medication: liraglutide 1.8 mg injection | 18
home medication: metformin/sitagliptin 1000/50 mg twice daily | 18
capillary blood ketone monitoring initiated | 38
insulin infusion titrated to ketone levels | 38
dextrose escalation | 38
intravenous potassium replacement escalated | 38
basal insulin started | 48
C-peptide 0.11 nmol/L | 24
Anti-IA2 antibodies negative | 24
GAD antibodies negative | 24
insulin antibodies negative | 24
first intermittent hemodialysis session | 4
continuous veno-venous hemodiafiltration started | 4
total three hemodialysis sessions completed | 28
additional sodium bicarbonate boluses required | 28
metabolic acidosis corrected | 62
anion gap closed | 62
extubated | 96
shifted to basal-bolus insulin regimen | 120
provoked femoral line site deep venous thrombosis | 168
pulmonary embolism | 168
anticoagulants started | 168
ketonemia persisted | 240
ketonemia resolved | 288
discharged | 384