no history of diabetes | -8760
no hypoglycemic symptoms before the operation | -8760
severe reflux disease | -8760
laparoscopic Toupet fundoplication | -8760
52-year-old woman | 0
moderately overweight (BMI 29 kg/m2) | 0
episodes of severe symptomatic late dumping syndrome | 0
palpitations | 0
nausea | 0
sweating | 0
weakness | 0
collapse | 0
blood tests | 0
functional X-ray examination | 0
upper endoscopy | 0
magnetic resonance imaging of the upper abdomen | 0
symptomatic hyperinsulinemic hypoglycemia | 0
Sigstad score 15 | 0
OGTT (baseline) | 0
CGM (baseline) | 0
fasting glucose 93 mg/dL | 0
fasting insulin 29 μU/mL | 0
HOMA-Index 6.6 | 0
HbA1c 4.5 % | 0
normal postoperative findings | 0
no evidence of a neuroendocrine tumor | 0
glucose peak 206 mg/dL | 0.5
insulin peak 717 μU/mL | 1.5
hypoglycemia glucose 35 mg/dL | 2.5
dietary changes started | 24
meal frequency increased to 5–6 per day | 24
shift toward more protein and fiber | 24
reduced carbohydrates | 24
acarbose 50 mg before each meal 3 × daily started | 24
insufficient therapeutic effect of acarbose | 168
decision to give liraglutide | 168
patient informed consent signed | 168
liraglutide 0.6 mg/day started | 168
OGTT with liraglutide 0.6 mg/day | 336
CGM with liraglutide 0.6 mg/day | 336
fasting glucose 88 mg/dL | 336
fasting insulin 19.3 μU/mL | 336
glucose peak 155 mg/dL | 336.5
insulin peak 311 μU/mL | 337
hypoglycemia glucose 48 mg/dL | 339
symptoms milder | 339
liraglutide dose increased to 1.2 mg/day | 504
OGTT with liraglutide 1.2 mg/day | 672
CGM with liraglutide 1.2 mg/day | 672
fasting glucose 83 mg/dL | 672
fasting insulin 10.7 μU/mL | 672
glucose levels remained above 66 mg/dL | 672
84 % glucose values in normoglycemic range | 672
insulin peak 413 μU/mL | 673
patient free of symptoms | 672
continuing liraglutide treatment | 672