35-year-old | 0
male | 0
obesity | 0
no medical conditions | 0
no history of surgery | 0
weekly subcutaneous semaglutide | -336
intolerance to dose escalation | -336
failed to reach targeted body weight | -336
insertion of MedSil intragastric balloon | 0
balloon filled with 600 mL normal saline | 0
balloon filled with 10 mL methylene blue | 0
left-sided varicocele | 168
varicocele confirmed by scrotal ultrasound | 168
abdominal-pelvic CT scan | 168
balloon compression of the splenic vein | 168
splenic vein nonenhancement at distal end | 168
few splenic vein collaterals | 168
finding suggested acute obstruction | 168
radiologist could not exclude thrombosis | 168
dilatation of left gonadal vein | 168
no other abdominal abnormality detected | 168
gastric balloon removed endoscopically | 168
started on rivaroxaban | 168
no isolated gastric varices found | 168
significant improvement in varicocele | 168
abdominal CT repeated | 336
patent splenic vein | 336
complete recanalization of splenic vein | 336
significant reduction in gonadal vein caliber | 336
advised to continue rivaroxaban for 3 months | 336
symptoms completely resolved | 336
referred to bariatric surgeon | 336