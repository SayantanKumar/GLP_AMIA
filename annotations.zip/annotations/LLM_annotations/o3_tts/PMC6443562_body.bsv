35-year-old | 0  
woman | 0  
admitted for detailed examination before bariatric/metabolic surgery | 0  
morbid obesity | 0  
body weight 111.4 kg | 0  
BMI 49.8 kg/m2 | 0  
height 151.3 cm | 0  
diabetes diagnosed | -157680  
oral hypoglycemic agents started | -157680  
SPIDDM diagnosed | -87600  
insulin treatment introduced | -87600  
obesity since childhood | -262800  
weight 90 kg | -131400  
BMI 39.0 kg/m2 | -131400  
weight 120.8 kg | -168  
BMI 52.3 kg/m2 | -168  
HbA1c 6.8 % | -168  
strict lifestyle modifications | -48  
daily insulin dose 35 units | -24  
metformin 2,250 mg daily | 0  
pioglitazone 15 mg daily | 0  
miglitol 150 mg daily | 0  
dulaglutide 0.75 mg weekly | 0  
insulin 62 units daily | 0  
HbA1c 5.7 % | 0  
fasting blood sugar 86 mg/dL | 0  
anti-GAD antibody 623 U/mL | 0  
plasma C-peptide response to glucagon 1.21 ng/mL | 0  
ABCD score 4/10 | 0  
AST 15 IU/L | 0  
ALT 14 IU/L | 0  
γGTP 10 IU/L | 0  
total bilirubin 0.6 mg/dL | 0  
ALP 132 IU/L | 0  
LDH 208 IU/L | 0  
CPK 71 IU/L | 0  
urea nitrogen 8.2 mg/dL | 0  
creatinine 0.44 mg/dL | 0  
total protein 7 g/dL | 0  
albumin 4.2 g/dL | 0  
amylase 49 IU/L | 0  
sodium 140 mEq/L | 0  
potassium 4 mEq/L | 0  
chloride 102 mEq/L | 0  
calcium 9.1 mg/dL | 0  
CRP 0.75 mg/dL | 0  
triglyceride 65 mg/dL | 0  
HDL-cholesterol 47 mg/dL | 0  
LDL-cholesterol 96 mg/dL | 0  
WBC 6,100 /µL | 0  
RBC 4.75 × 10⁶ /µL | 0  
hemoglobin 12.4 g/dL | 0  
hematocrit 39.4 % | 0  
MCV 82.9 fL | 0  
MCH 26.1 pg | 0  
MCHC 31.5 % | 0  
platelets 3.49 × 10⁵ /µL | 0  
urine pH 7.5 | 0  
urine specific gravity 1.013 | 0  
urine protein ± | 0  
urine occult blood negative | 0  
urine urobilinogen negative | 0  
TSH 2.63 µIU/mL | 0  
free T4 1.3 ng/dL | 0  
ACTH 10.1 pg/mL | 0  
cortisol 7.89 µg/dL | 0  
LH 2.68 mIU/mL | 0  
FSH 5.60 mIU/mL | 0  
prolactin 10.9 ng/mL | 0  
estradiol 34 pg/mL | 0  
decision to perform sleeve gastrectomy | 0  
sleeve gastrectomy | 72  
blood glucose stabilized post-surgery | 96  
cessation of all medications except insulin glargine | 96  
insulin glargine 5 units daily | 96  
insulin discontinued | 1512  
HbA1c 5.8 % | 4392  
fasting blood glucose 85 mg/dL | 4392  
body weight 76.1 kg | 4392  
BMI 33.2 kg/m2 | 4392  
percentage excess weight loss 66.6 % | 4392  
abdominal fat area 233 cm2 | 4392  
visceral fat area 71 cm2 | 4392  
subcutaneous fat area 162 cm2 | 4392  
fat mass 24.9 kg | 4392  
muscle mass 48.1 kg | 4392  
protein mass 9.9 kg | 4392  
body-fat percentage 32.7 % | 4392  
plasma C-peptide response to glucagon 2.34 ng/mL | 4392  
no severe adverse events | 4392