49-year-old | 0
female | 0
overweight | 0
hypertensive | 0
urban environment | 0
type 2 diabetes | 0
diabetic sensory peripheral neuropathy | 0
non-proliferative diabetic retinopathy | 0
triple therapy of oral hypoglycemic agents | -20000
uncontrolled glycemia | -20000
insulin introduced | -18000
insulin aspart initiated | -17760
repeated local erythema after insulin aspart | -17760
repeated local edema after insulin aspart | -17760
insulin aspart discontinued | -17600
insulin glargine introduced | -9000
extensive local reaction to insulin glargine | -9000
GLP-1 analog exenatide 5 µg twice daily started | -8760
delayed extensive local reactions to exenatide | -8760
antihistamine premedication (for exenatide) started | -8760
exenatide changed to 2 mg once a week | -8500
insulin lispro introduced | -168
large local reaction to insulin lispro | -168
insulin glulisine introduced (pre-referral) | -168
large local reaction to insulin glulisine | -168
referred to Allergy clinic | -24
skin prick test negative to insulin glulisine | 0
skin prick test negative to latex | 0
skin prick test negative to atopic panel | 0
intradermal test positive to insulin glulisine | 0
insulin-specific IgE negative | 0
basophil degranulation test not performed | 0
desensitization to insulin glulisine initiated | 0
start dose 0.000001 U insulin glulisine | 0
local pruritus (after 0.01 U dose) | 2
erythema at injection site (after 0.01 U dose) | 2
12 mm edema at injection site | 2
local wheal and flare reaction | 6
no systemic reaction during glulisine desensitization | 6
induration of injection sites | 12
erythema of injection sites (late phase) | 12
Desloratadine 10 mg premedication started | 24
Montelukast 10 mg started | 24
injection site changed | 24
8 U maintenance dose of insulin glulisine reached | 72
no further adverse reactions on glulisine | 72
tolerating insulin glulisine injections | 720
palmar eczema | 720
emollient creams recommended | 720
re-epithelization creams recommended | 720
skin testing negative to insulin glargine | 720
desensitization to insulin glargine initiated | 720
2 U insulin glargine administered | 720
4 U insulin glargine administered (dose 2) | 720
4 U insulin glargine administered (day 2) | 744
6 U insulin glargine administered (day 2) | 744
10 U insulin glargine administered | 792
12 U insulin glargine introduced in regimen | 816
no systemic reaction during glargine desensitization | 816
patch test negative to insulin glulisine (48 h) | 48
patch test negative to latex (48 h) | 48
patch test negative to zinc (48 h) | 48
patch test negative to insulin glulisine (96 h) | 96