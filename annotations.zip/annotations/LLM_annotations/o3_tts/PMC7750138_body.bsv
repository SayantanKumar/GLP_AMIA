22 years old|0
woman|0
presented to emergency room|0
worsening lower left pelvic pain|0
nausea|0
vomiting|0
vaginal bleeding|0
mild tenderness over left lower quadrant|0
no masses appreciated|0
transvaginal ultrasound performed|0
CT scan performed|0
10.6 cm multi-septated left adnexal mass|0
fat within adnexal mass|0
fluid within adnexal mass|0
calcifications within adnexal mass|0
suspected dermoid cyst|0
arterial and venous blood flow to both ovaries preserved|0
pain improved|3
decision for outpatient follow-up with surgeon|3
outpatient clinic visit|72
scheduled for laparoscopic ovarian cystectomy|72
laparoscopic entry|96
left ovary torsed two times around vascular pedicle|96
large dermoid cyst removed laparoscopically|96
residual ovarian parenchyma repaired|96
mature cystic teratoma on final pathology|120
mature pituitary tissue identified in teratoma|120
pituitary tissue positive for pancytokeratin|120
pituitary tissue positive for CAM 5.2|120
pituitary tissue positive for S100|120
pituitary tissue positive for synaptophysin|120
pituitary tissue positive for growth hormone|120
pituitary tissue positive for prolactin|120
pituitary tissue positive for ACTH|120
patient doing well|720
modest weight loss|720
advised repeat sonogram in 6 months|720
rapid weight gain|-8760
outpatient evaluation by endocrinologist|-720
HgbA1 4.8 %|-720
testosterone 29.9 ng/dL|-720
LH 8.1 IU/L|-720
FSH 4.1 mIU/mL|-720
TSH 2.41 mIU/L|-720
CMP normal|-720
lipid panel normal|-720
regular menses|-720
regular sleep habits|-720
denies hirsutism|-720
denies acne|-720
denies hair loss|-720
metformin trial initiated|-600
metformin self-discontinued|-576
injections of semaglutide|-500
abdominal striae|-500
not tested for Cushing's syndrome|-500