73 years old | 0
male | 0
admitted to hospital | 0
imbalance of type 2 diabetes | 0
anorexia | -1440
weight loss 8 kg | -1440
diarrhea | -24
abdominal pain | -24
attacks of tetany | -24
DPP4 inhibitor therapy | -2160
Metformin therapy | -2160
Glimipiride therapy | -2160
Abasaglar initiation | -2160
Liraglutide initiation | -2160
conscious | 0
normocardial | 0
normotensive | 0
eupneic | 0
apyretic 36.7 °C | 0
weight 84 kg | 0
height 1.69 m | 0
BMI 29.13 | 0
Chvostek sign negative | 0
sign of keychain negative | 0
initial ECG without hypocalcemia signs | 0
hypokalemia 3.2 mmol/l | 1
hypocalcemia 1.52 mmol/l | 1
corrected hypocalcemia 1.60 mmol/l | 1
hypomagnesemia <0.1 mmol/l | 1
hyperglycemia 6.80 mmol/l | 1
low prealbumin 0.17 g/l | 1
normal PTH 21.51 ng/l | 2
low vitamin D 53.7 nmol/l | 2
IV electrolyte supplementation initiated | 2
ECG monitoring | 2
calcium gluconate 8 g IV | 2
magnesium sulfate 4 g IV | 2
potassium chloride 2 g IV | 2
normalization of serum calcium | 48
normalization of magnesemia | 48
normalization of kalemia | 48
elevation of PTH | 48
improvement of glycemic cycle | 48
oral magnesium pidolate continued | 48
Liraglutide discontinued | 48
improvement in digestive disorders | 48
absence of hypoparathyroidism confirmed | 48
urinary magnesium excretion 7.53 mEq/24 h | 72