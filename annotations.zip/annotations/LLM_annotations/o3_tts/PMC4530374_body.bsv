54-year-old | 0
female | 0
admitted for evaluation of post-prandial hypoglycemia | 0
post-prandial sweating | 0
fainting | 0
documented hypoglycemia (capillary blood glucose < 50 mg/dl) | 0
BMI 30 kg/m2 (weight stabilized) | 0
not actively losing weight | 0
abdominal ultrasound: 1.8-cm solid mass in pancreatic head | 0
abdominal CT scan: 1.8-cm solid mass in pancreatic head confirmed | 0
octreotide scan: focus of abnormal uptake in pancreatic head | 0
octreotide scan: no other foci of abnormal uptake | 0
lowest laboratory glucose 65 mg/dl | 0
parallel insulin 3.3 µU/ml | 0
plasma chromogranin A 4.1 ng/ml | 0
72-h fast test negative for hypoglycemia | 0
type 2 diabetes in clinical remission | -13140
subjected to laparoscopic gastric bypass with 200 cm biliopancreatic limb | -17520
morbid obesity (BMI 42 kg/m2) | -17520
type 2 diabetes mellitus | -17520
laparoscopic enucleation of pancreatic nodule | 72
small pancreatic nodule found at upper edge of pancreatic head | 72
intraoperative pancreatic ultrasound: nodule >1 cm from pancreatic duct | 72
no evidence of other pancreatic nodules | 72
postoperative period uneventful | 96
complete remission of hypoglycemic episodes | 96
histology: 18×15×14 mm pseudoglandular neuroendocrine neoplasia | 120
staining positive for CAM 5.2 | 120
staining positive for chromogranin A | 120
staining positive for synaptophysin | 120
staining positive for glucagon | 120
staining positive for GLP1 | 120
staining negative for insulin | 120
low Ki-67 (<2 %) | 120
mitotic index <1/10 HPF | 120
diagnosis: low-grade (G1) well-differentiated neuroendocrine tumor | 120
PET-68Ga-SRP (DOTANOC): no residual disease | 168
frozen tumor sample homogenized for peptide analysis | 168
tumor glucagon concentration 26 707 pmol/g | 168
tumor GLP1 concentration 471 pmol/g | 168
tumor insulin concentration 139 pmol/g | 168
tumor somatostatin concentration 23 pmol/g | 168