47-year-old | 0
male | 0
type 2 diabetes | -1000
heart failure with preserved ejection fraction | -1000
chronic obstructive pulmonary disease | -1000
hyperlipidemia | -1000
statin-induced rhabdomyolysis requiring hospitalization | -1000
insulin lispro | -1000
insulin glargine | -1000
dulaglutide | -1000
evolocumab | -1000
gabapentin | -1000
atenolol | -1000
bupropion | -1000
ziprasidone | -1000
rimegepant | -1000
galcanezumab | -1000
albuterol inhaler | -1000
started empagliflozin 25 mg daily | -200
bilateral lower extremity pain | -120
aching in legs | -120
aching in thighs | -120
no recent trauma | -120
no fall | -120
no new medications | -120
no herbal supplements | -120
pain worsened | -48
presented to emergency department | 0
drug-induced myopathy (empagliflozin-induced) | 0
vital signs within normal limits | 0
no erythema | 0
no subcutaneous edema | 0
no lesions | 0
no evidence of dehydration | 0
no joint effusions | 0
range of motion normal | 0
intact strength in extremities | 0
tenderness in bilateral thighs | 0
tenderness in bilateral legs | 0
deep tendon reflexes normal | 0
sensation intact | 0
elevated creatinine kinase 958 U/L | 0
glucose 206 mg/dL | 0
creatinine 0.93 mg/dL | 0
eGFR > 60 mL/min/1.73 m² | 0
magnesium 2.4 mg/dL | 0
urinalysis negative for blood | 0
mild elevation of liver enzymes | 0
aspartate aminotransferase 64 U/L | 0
alanine aminotransferase 117 U/L | 0
alkaline phosphatase 138 U/L | 0
negative antinuclear antibody | 0
erythrocyte sedimentation rate 21 mm/hr | 0
no weight loss | 0
no change in urination | 0
no thirst | 0
discontinued empagliflozin | 0
intravenous fluids administered | 0
hepatomegaly | -720
hepatic steatosis | -720
discharged home | 4
follow-up clinic visit | 336
significant improvement in muscle pain | 336
muscle weakness improved | 336
complete resolution of muscle pain | 336
creatine kinase 215 U/L | 336
strength returned to normal | 336