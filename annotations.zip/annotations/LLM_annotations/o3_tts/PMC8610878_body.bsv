semaglutide 0.5 mg weekly started | -288  
liraglutide discontinued | -288  
ketogenic diet started | -168  
manual labour precipitated symptoms | -120  
severe epigastric pain onset | -120  
dysphagia onset | -120  
odynophagia onset | -120  
anorexia onset | -120  
nausea onset | -120  
non-bloody non-bilious emesis onset | -120  
no overt gastrointestinal bleeding | -120  
bed rest | -120  
ceased oral intake | -120  
presentation to Emergency | 0  
admitted to hospital | 0  
63 years old | 0  
male | 0  
weight 94 kg | 0  
height 1.778 m | 0  
body mass index 31.14 kg/m² | 0  
tachycardia 125 bpm | 0  
tachypnea 40 breaths per min | 0  
blood pressure 136/81 mmHg | 0  
Kussmaul respirations | 0  
voluntary abdominal guarding | 0  
painful belching | 0  
distress | 0  
hemoglobin 165 g/L | 0  
leukocytes 17.9 × 10⁹/L | 0  
anion gap 25 | 0  
bicarbonate 5 mmol/L | 0  
pH 7.02 | 0  
B-hydroxybutyrate 10.2 mmol/L | 0  
glucose 17 mmol/L | 0  
glucose peaked 82 mmol/L | 0  
urinalysis negative for leukocytes | 0  
urinalysis negative for nitrites | 0  
abdominal CT distal esophagus wall thickening | 0  
first presentation diabetic ketoacidosis | 0  
metformin 500 mg twice daily | 0  
ramipril 5 mg daily | 0  
ezetimibe 10 mg daily | 0  
duloxetine 60 mg daily | 0  
pravastatin 40 mg daily | 0  
C-peptide 1087 pmol/L | 12  
resolution of diabetic ketoacidosis | 24  
continued epigastric pain | 24  
reflux symptoms | 24  
dysphagia persisted | 24  
esophagogastroduodenoscopy performed | 36  
severe class D esophagitis | 36  
circumferential black necrotic esophageal tissue | 36  
acute esophageal necrosis | 36  
erosions in stomach body and antrum | 36  
multiple clean-based duodenal ulcers | 36  
biopsies taken gastric and duodenal mucosa | 36  
chronic gastroduodenitis | 36  
no H. pylori | 36  
no infectious organisms | 36  
no evidence of neoplasia | 36  
pantoprazole 40 mg IV twice daily started | 38  
sucralfate 1 g PO four times daily started | 38  
diet advanced from nil per os to clear fluids | 38  
discharged home | 72  
liquid diet prescribed | 72  
sucralfate 2 g with meals and nightly prescribed | 72  
pantoprazole 40 mg twice daily prescribed | 72  
metformin discontinued | 72  
semaglutide discontinued | 72  
insulin aspart 5 units three times daily started | 72  
insulin glargine 15 units nightly started | 72  
repeat esophagogastroduodenoscopy | 1416  
healed esophagus | 1416  
esophageal polyp detected | 1416  
polyp biopsy mild inflammatory changes | 1416  
healed gastric mucosa | 1416  
healed duodenal mucosa | 1416  
follow-up HbA1c 7.2 % | 1416