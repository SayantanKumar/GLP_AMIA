had been taking phendimetrazine tartrate for weight loss | -43800  
58-year-old woman | 0  
presented to the emergency department | 0  
dyspnea | 0  
bilateral flank pain | 0  
pallor | 0  
clamminess | 0  
blood pressure of 170/120 mmHg | 0  
heart rate of 120 beats/min | 0  
body temperature of 38.2 °C | 0  
respiration rate of 30 breaths/min | 0  
oxygen saturation of 89 % on room air | 0  
body mass index of 25.1 kg/m2 | 0  
crackles heard in the right lung field | 0  
abdomen soft without tenderness | 0  
C-reactive protein 29.5 mg/dL | 0  
erythrocyte sedimentation rate 120 mm/hr | 0  
leukocytosis 14.82×103/μL | 0  
normocytic anemia (hemoglobin 9.9 g/dL) | 0  
mean corpuscular volume 90.7 fL | 0  
platelet count normal | 0  
blood urea nitrogen 25 mg/dL | 0  
creatinine 1.66 mg/dL | 0  
aspartate aminotransferase 179 IU/L | 0  
alanine aminotransferase 106 IU/L | 0  
mixed metabolic-respiratory acidosis | 0  
lactate 20 mmol/L | 0  
chest radiography bilateral diffuse infiltrations | 0  
chest and abdominal CT round 3.8 cm left paravertebral mass | 0  
no medical history | 0  
no significant family history | 0  
sedated | 1  
intubated | 1  
admitted to the intensive care unit | 1  
vancomycin started | 1  
meropenem started | 1  
azithromycin started | 1  
mechanical ventilation initiated | 1  
chest radiography resolution of lung infiltrations | 24  
high fever persisted | 24  
uncontrolled hypertension persisted | 24  
troponin-I 0.841 ng/mL | 24  
creatine kinase 5.3 ng/mL | 24  
NT-proBNP 35,000 pg/mL | 24  
hypokinetic mid inferior and apical segments on echocardiogram | 24  
left ventricular ejection fraction 38 % | 24  
referred to an endocrinologist | 30  
24-hour urinary metanephrine 2.12 mg/day | 30  
plasma norepinephrine 1,588 pg/mL | 30  
plasma normetanephrine 2.27 nmol/L | 30  
plasma epinephrine 18 pg/mL | 30  
plasma metanephrine 0.04 nmol/L | 30  
plasma interleukin-6 16.5 pg/mL | 30  
18F-fluorodeoxyglucose PET/CT increased uptake in left paravertebral mass | 54  
functional paraganglioma diagnosed | 54  
SDHB mutation c.541-3C>R detected | 54  
alpha-blocker doxazosin initiated | 54  
body temperature normalized to 36.5 °C | 60  
blood pressure well controlled | 60  
open excision of retroperitoneal mass | 462  
tumor measured 4.3 × 3.5 × 3.7 cm3 | 462  
histology showed zellballen pattern | 462  
chromogranin A diffuse positive staining | 462  
doxazosin discontinued | 462  
no postoperative complications | 462  
inflammatory biomarkers improved | 558  
cardiac biomarkers improved | 558  
renal biomarkers improved | 558  
hepatic biomarkers improved | 558  
24-hour urinary metanephrine 0.25 mg/day | 558  
diagnosed with diabetes | 600  
phendimetrazine tartrate replaced with glucagon-like peptide-1 receptor agonist | 600  
follow-up abdominal CT no recurrence | 9822  
no evidence of distant metastases | 9822  
patient asymptomatic | 9822