60-year-old woman | 0
presented to emergency department | 0
left flank pain | -48
pain radiating to the groin | -48
vomiting | -48
dizziness | -48
lightheadedness | -48
absence of urinary symptoms | 0
no fever | 0
coronary artery disease | -8760
prior angioplasty | -17520
type 2 diabetes mellitus | -8760
insulin glargine 30 units twice a day | -8760
insulin lispro 30 units thrice a day | -8760
dulaglutide 1.5 mg weekly | -8760
empagliflozin 25 mg once daily started | -2880
hypertension | -8760
losartan 50 mg daily | -8760
hypertriglyceridemia | -8760
icosapent ethyl 2 g twice a day | -8760
former smoker | -61320
quit smoking | -61320
body mass index 26 kg/m2 | 0
costovertebral tenderness | 0
tachycardia | 0
hypotension | 0
nonresponsive to crystalloids | 0
required vasopressors | 0
lactic acidosis 8.4 mmol/L | 0
leukocytosis 10900 | 0
left shift | 0
thrombocytopenia 76000 | 0
glycosylated hemoglobin A1C 14% | 0
acute kidney injury (creatinine 3.5 mg/dL, BUN 57 mg/dL) | 0
shock | 0
severe sepsis | 0
hypovolemia | 0
abnormal liver function tests | 0
serum glucose >500 mg/dL | 0
urinalysis: large amount of glucose | 0
urinalysis: rare bacteria | 0
urinalysis: white blood cells <1/HPF | 0
computed tomography: severe emphysematous pyelonephritis of left kidney | 0
computed tomography: 80% parenchyma involvement | 0
computed tomography: ischemic colitis signs | 0
portal venous gas | 0
air within branches of superior mesenteric vein | 0
initial antibiotic treatment with cefepime | 0
initial antibiotic treatment with vancomycin | 0
initial antibiotic treatment with metronidazole | 0
emergent nephrectomy | 6
bowel found viable | 6
postoperative intensive care unit stay | 6
pan-susceptible Escherichia coli isolated | 24
antibiotics de-escalated | 24
recovered after surgery | 168
discharged home | 336
cefpodoxime 200 mg twice daily for 7 days started | 336
empagliflozin discontinued | 336
near-syncope episode | 1439
abdominal pain | 1439
admitted to hospital (second admission) | 1440
small bowel obstruction | 1440
rapid decompensation | 1450
cardiopulmonary arrest | 1450
massive emesis | 1450
aspiration of gastric contents | 1450
full resuscitation | 1450
intensive care unit stay (second) | 1450
anoxic brain injury | 1500
surgery not performed | 1500
life support withdrawn | 1600
died | 1600