type 1 diabetes mellitus | -2160
poorly controlled type 1 diabetes mellitus | -2160
prescribed tirzepatide | -2160
weight 192 lbs | -2160
BMI 32.2 kg/m2 | -2160
HbA1c 9.4% | -2160
total daily insulin 70 units | -2160
last tirzepatide injection | -96
acute worsening of nausea | -72
acute worsening of heartburn | -72
vomiting | -72
inability to keep anything down | -72
CGM reported hypoglycemia | -48
intermittent insulin delivery suspension | -48
treated hypoglycemia with glucose tablets | -48
did not check capillary glucose | -48
positive home urine ketone | -2
36-year-old | 0
woman | 0
admitted to hospital | 0
weight 142 lbs | 0
BMI 25.3 kg/m2 | 0
weight loss 50 lbs | 0
severe nausea | 0
tachycardia 137 beats/min | 0
tachypnea 35 breaths/min | 0
elevated blood pressure 155/100 mm Hg | 0
normal body temperature 98.6 °F | 0
Kussmaul breathing | 0
dry oral mucosa | 0
CGM readings 40–180 mg/dL | 0
total daily insulin 30 units | 0
POC glucose 289 mg/dL | 0
serum glucose 322 mg/dL | 0
Dexcom CGM glucose 40 mg/dL | 0
hemoglobin 16.2 g/dL | 0
hematocrit 45.3% | 0
HbA1c 7.4% | 0
bicarbonate 12 mmol/L | 0
sodium 131 mmol/L | 0
potassium 5 mmol/L | 0
creatinine 1.00 mg/dL | 0
GFR 75 mL/min/1.73 m2 | 0
anion gap 21 mmol/L | 0
high-anion-gap metabolic acidosis | 0
volume depletion | 0
DKA diagnosed | 0
betahydroxybutyrate level ordered but not drawn | 0
no source of infection found | 0
CLS and CGM removed | 1
continuous regular insulin infusion started | 1
intravenous normal saline infusion started | 1
serum glucose 143 mg/dL | 8
anion gap closed to 8 mmol/L | 8
bicarbonate 24 mmol/L | 72
transitioned to basal glargine | 72
transitioned to prandial lispro | 72
total daily insulin 24 units | 72
transitioned back to t:slim CIQ and Dexcom G6 | 73
tirzepatide discontinued | 73
total daily insulin 37 units | 97
glycemic control within optimal range | 97
discharged from hospital | 96
optimal glycemic control at outpatient follow-up | 240