psoriasis | -140160
diagnosed with obesity | -96360
treated unsuccessfully with lifestyle modification | -96360
treated with ixekizumab 80 mg | -26280
allergic reaction to ixekizumab | -25200
treatment interrupted (ixekizumab discontinued) | -25200
treated with secukinumab 75 mg | -25200
lack of response to secukinumab | -18240
secukinumab replaced with guselkumab 100 mg | -18240
little effects of guselkumab | -10944
discontinued guselkumab | -10944
never smoked | 0
not a current smoker | 0
patient came to our observation | 0
diagnosed with previously unknown T2D | 0
HbA1c 6.5 % | 0
weight 77.8 kg | 0
height 1.6 m | 0
BMI 30.4 kg/m2 | 0
waist circumference 98 cm | 0
CT-EAT attenuation −80 HU | 0
CT-PCAT attenuation LAD −65 HU | 0
CT-PCAT attenuation Cx −77 HU | 0
CT-PCAT attenuation RCA −68 HU | 0
SAT attenuation −94 HU | 0
CT-EAT volume 198 cm3 | 0
CAC score 0 | 0
absence of coronary plaques | 0
PASI score 12.0 | 0
erythematous plaques involving the right hand | 0
erythematous plaques involving the scalp | 0
DLQI score 20 | 0
DAPSA score 31.0 | 0
fasting glucose 120 mg/dL | 0
insulin 11.2 uU/mL | 0
HOMA-IR 3.32 | 0
total cholesterol 222 mg/dL | 0
HDL 42 mg/dL | 0
LDL 158 mg/dL | 0
triglycerides 112 mg/dL | 0
CRP 4.3 mg/dL | 0
IL-6 4.9 pg/mL | 0
leukocytes 4.95 × 109/L | 0
ESR 21 mm/h | 0
Framingham risk score 4.6 | 0
semaglutide therapy 0.25 mg weekly initiated | 0
semaglutide dose increased to 0.50 mg weekly | 720
semaglutide maintenance dose 1 mg weekly reached | 2688
weight 66.9 kg | 2880
BMI 27.3 kg/m2 | 2880
waist circumference 87 cm | 2880
PASI score 4.0 | 2880
DLQI score 5 | 2880
DAPSA score 8.0 | 2880
HbA1c 6.1 % | 2880
fasting glucose 101 mg/dL | 2880
insulin 10.3 uU/mL | 2880
HOMA-IR 2.57 | 2880
total cholesterol 215 mg/dL | 2880
HDL 46 mg/dL | 2880
LDL 149 mg/dL | 2880
triglycerides 97 mg/dL | 2880
CRP 2.4 mg/dL | 2880
IL-6 4.1 pg/mL | 2880
leukocytes 6.16 × 109/L | 2880
ESR 13 mm/h | 2880
Framingham risk score 3.9 | 2880
CT-EAT attenuation −94 HU | 7296
CT-PCAT attenuation LAD −70 HU | 7296
CT-PCAT attenuation Cx −82 HU | 7296
CT-PCAT attenuation RCA −72 HU | 7296
SAT attenuation −95 HU | 7296
CT-EAT volume 190 cm3 | 7296
CAC score 0 (follow-up) | 7296
absence of coronary plaques (follow-up) | 7296
weight 57.8 kg | 7296
BMI 22.6 kg/m2 | 7296
waist circumference 72 cm | 7296
PASI score 0.2 | 7296
DLQI score 1 | 7296
DAPSA score 4.0 | 7296
HbA1c 5.1 % | 7296
fasting glucose 91 mg/dL | 7296
insulin 3.8 uU/mL | 7296
HOMA-IR 0.84 | 7296
total cholesterol 196 mg/dL | 7296
HDL 58 mg/dL | 7296
LDL 137 mg/dL | 7296
triglycerides 39 mg/dL | 7296
CRP <0.5 mg/dL | 7296
IL-6 3.4 pg/mL | 7296
leukocytes 4.56 × 109/L | 7296
ESR 12 mm/h | 7296
Framingham risk score 2.6 | 7296