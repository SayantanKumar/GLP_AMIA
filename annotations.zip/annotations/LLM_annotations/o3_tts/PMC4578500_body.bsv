diagnosed with diabetes mellitus | -192720  
strict low-carbohydrate diet started | -96360  
bodyweight 54 kg | -96360  
bodyweight gradually increased | -336  
bodyweight 67 kg | -336  
glimepiride therapy | -312  
metformin therapy | -312  
linagliptin therapy | -312  
glimepiride discontinued | -312  
metformin discontinued | -312  
linagliptin discontinued | -312  
ipragliflozin 50 mg/day started | -312  
polyuria | -300  
bodyweight decreased 3 kg | -72  
epigastralgia | -48  
water intake decreased | -48  
dietary intake decreased | -48  
tachypnea | -24  
32 years old | 0  
woman | 0  
Prader–Willi syndrome | 0  
visited emergency room | 0  
admitted to hospital | 0  
severe acidosis | 0  
ketonuria | 0  
ketonemia | 0  
normal lactate level | 0  
chest X-ray no abnormalities | 0  
electrocardiogram no abnormalities | 0  
abdominal computed tomography no abnormalities | 0  
urinary sediments none | 0  
ketoacidosis | 0  
continuous intravenous insulin initiated | 0  
Ringer's solution infusion initiated | 0  
glucose infusion initiated | 0  
admitted to intensive care unit | 0  
bodyweight 63.9 kg | 0  
BMI 28.4 kg/m2 | 0  
respiratory rate 32/min | 0  
heart rate 112/min | 0  
blood pressure 139/77 mmHg | 0  
alert consciousness | 0  
serum C-peptide 0.4 ng/mL | 0  
urinary C-peptide undetectable | 0  
plasma glucose 191 mg/dL | 0  
HbA1c 9.3% | 0  
glycated albumin 19.6% | 0  
antiglutamic acid decarboxylase antibody negative | 0  
islet antigen-2 antibody negative | 0  
insulin autoantibody negative | 0  
ketoacidosis improved | 24  
bodyweight increased 2 kg | 24  
basal–bolus insulin therapy continued | 24  
urinary C-peptide 40.2 µg/day | 144  
discharged | 240  
insulin glargine 24 units/day | 240  
lixisenatide 20 µg/day | 240  
metformin 2,250 mg/day restarted | 240  
nutritionist instructed 1,500-kcal diet | 240  
HbA1c 6.8% | 720  
glycated albumin 13.7% | 720