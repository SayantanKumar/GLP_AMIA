46-year-old Asian-Indian man | 0
male | 0
no history of alcohol consumption | 0
diagnosed with tropical chronic pancreatitis | -70080
maintained on oral pancreatic enzyme therapy | -70080
developed non-insulin-dependent diabetes mellitus | -43800
prescribed glucotrol (glipizide) 5 mg daily | -43800
presented to medical center in India with similar pain and fever | -1440
CT scan: chronic atrophic calcific pancreatitis | -1440
dilated pancreatic duct (7 mm) | -1440
intraductal calculi | -1440
ERCP performed (India) | -1440
medically managed and discharged | -1440
steady midepigastric pain (6 h duration) | -72
pain radiating through back | -72
pain exacerbated by food intake | -72
hospitalized for pain control with narcotics | -60
narcotics given | -60
discharged | -48
returned with continuing epigastric pain | 0
nausea | 0
vomiting | 0
no documented fever | 0
CT scan: fatty atrophy of pancreatic head and uncinate process | 0
pancreatic duct filled with large calcifications | 0
possible obstruction at neck with ductal dilatation 1.5 cm | 0
again admitted for pain management (current admission) | 0
developed fever 102 °F | +48
chills | +48
rigors | +48
severe sepsis | +50
septic shock | +50
transferred to ICU | +50
intubated for hypoxemic respiratory failure | +50
acute respiratory distress syndrome | +50
multiorgan failure | +50
broad-spectrum antibiotics started | +50
vasopressor support initiated | +50
activated recombinant human protein C given | +50
abdominal ultrasound: dilated pancreatic duct 1.9 cm | +50
calculus 8.7 × 7.6 mm within duct | +50
pancreas diffusely echogenic | +50
common bile duct prominent with no obstructing calculi | +50
bedside emergency ERCP performed | +52
major papilla expelling frank pus | +52
evacuation of >5 ml yellow pus | +52
cholangiogram: normal biliary tree | +52
pancreatogram: marked duct dilatation | +52
single distal calculus | +52
approximately 20 ml pus evacuated | +52
5-cm 5 F pancreatic duct stent placed | +52
no further pus draining, stent removed | +52
assumed acute suppuration of the pancreatic duct (ASPD) | +52
no evidence of papillitis, tumor, or previous sphincterotomy | +52
follow-up CT (next day) performed | +76
inflammatory changes in peripancreatic fat (edema) | +76
diminished pancreatic duct dilatation | +76
calculus distal migration toward sphincter of Oddi | +76
no pancreatic necrosis | +76
no fluid collection | +76
bilateral moderate pleural effusions | +76
clinical improvement | +76
hemodynamic stabilization | +76
blood cultures grew Klebsiella ornithinolytica (antibiotic-sensitive) | +76
extubated | +80
transferred from ICU | +80
completed antibiotic course | +240
discharged home | +264
follow-up at 1 month after discharge: no further complications | +984
follow-up at 3 months after discharge: no further complications | +2424