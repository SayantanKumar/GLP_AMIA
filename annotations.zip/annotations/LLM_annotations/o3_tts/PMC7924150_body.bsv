60-year-old man | 0
referred to our hospital for CABG surgery | 0
admitted to our hospital | 0
triple-vessel disease | -48
coronary artery disease | 0
hypercholesterolemia | 0
type 2 DM diagnosed 15 years previously | -131400
taking glimepiride 2 mg twice daily | 0
taking metformin 1000 mg twice daily | 0
taking subcutaneous semaglutide 0.25 mg weekly | 0
taking empagliflozin 10 mg daily | 0
canagliflozin therapy for many years | -26280
switched to empagliflozin about a year before admission | -8760
last dose of empagliflozin | -6
asymptomatic on arrival | 0
vital signs within normal limits | 0
white blood cell count 7.6 K/µL | 0
hemoglobin 14.6 g/dL | 0
serum glucose 157 mg/dL | 0
bicarbonate 24 mmol/L | 0
anion gap 12 mmol/L | 0
troponin 0.09 ng/mL | 0
glycated hemoglobin 9.6 % | 0
urinalysis glucosuria >1000 mg/dL | 0
urinalysis ketonuria 15 mg/dL | 0
oral antihyperglycemic medications withheld | 0
glimepiride withheld | 0
metformin withheld | 0
empagliflozin withheld | 0
started subcutaneous insulin regimen | 0
CABG surgery | 42
elevated anion gap metabolic acidosis | 45
arterial pH 7.275 | 45
bicarbonate 15 mmol/L | 45
anion gap 25 mmol/L | 45
serum glucose 138 mg/dL | 45
β-hydroxybutyric acid 6.52 mmol/L | 45
euglycemic DKA | 45
normal kidney function tests | 45
normal lactic acid level | 45
negative acetaminophen level | 45
negative salicylate level | 45
negative blood alcohol | 45
intravenous insulin drip started | 45
5 % dextrose in water infusion started | 45
hypotension | 45
intravenous norepinephrine started | 45
intravenous norepinephrine discontinued | 69
ketoacidosis resolved | 93
transitioned to subcutaneous insulin (basal and premeal) | 93
adequate glycemic control | 93
education to discontinue SGLT2 inhibitors ≥3 days before procedures | 93
discharged from hospital | 120