51-year-old | 0
Asian | 0
man | 0
hypertension | 0
hyperlipidemia | 0
type 2 diabetes mellitus | 0
nonalcoholic fatty liver disease | 0
chronic kidney disease stage 3a | 0
pitavastatin | 0
losartan | 0
insulin | 0
oral semaglutide 3 mg daily started | -4320
oral semaglutide increased to 7 mg daily | -3648
increase in alkaline phosphatase | -3744
increase in alanine aminotransferase | -3744
increase in aspartate aminotransferase | -3744
asymptomatic | -3744
oral semaglutide continued | -3744
ibuprofen 400 mg twice daily | -1440
presented to the hospital | 0
abdominal discomfort | 0
new-onset jaundice | 0
nausea | 0
vomiting | 0
diarrhea | 0
weakness | 0
afebrile | 0
tachycardic | 0
blood pressure 90s/60s mm Hg | 0
scleral icterus | 0
dry oral mucosa | 0
blood urea nitrogen 58 mg/dL | 0
creatinine 2.89 mg/dL | 0
worsening liver tests | 0
normal coagulation tests | 0
normal alpha-fetoprotein | 0
MRI with cholangiogram normal | 0
negative autoimmune serologies | 0
negative viral hepatitis serologies | 0
COVID-19 negative | 0
patient improved | 48
discharged home | 72
worsening liver tests (outpatient) | 720
repeat imaging unrevealing | 720
endoscopic retrograde cholangiopancreatogram unrevealing | 720
first liver biopsy | 800
marked and diffuse bile duct injury | 800
patchy ductular reaction | 800
mild cholestasis | 800
enrolled in DILIN study | 1000
second liver biopsy | 2880
portal tract edema | 2880
chronic inflammatory infiltrate with damage to interlobular bile ducts | 2880
no duct loss | 2880
no steatohepatitis | 2880
no interface hepatitis | 2880
progressive renal disease | 3000
renal biopsy | 3000
chronic active interstitial nephritis with eosinophils | 3000
patchy acute tubular damage | 3000
moderate tubular atrophy | 3000
interstitial fibrosis | 3000
ursodiol started | 3000
budesonide started | 3000
mycophenolate mofetil started | 3000
rapamycin started | 3000
no meaningful improvement in liver or kidney function | 3200
hemodialysis required | 3500
simultaneous liver and kidney transplantation | 8760
liver explant revealed cirrhosis | 8760
marked ductular reaction (on explant) | 8760
cholestasis (on explant) | 8760
bile infarcts | 8760
biliary cirrhosis | 8760
successful recovery | 9000