36-year-old | 0  
woman | 0  
admitted for observation | 0  
abrupt fall in insulin requirements to 720 IU/day | 0  
insulin requirements continued to fall | 0  
insulin 520 IU/day | 24  
insulin 480 IU/day | 48  
weight 155 kg | 72  
P-insulin 923 pmol/L | 72  
C-peptide 3294 pmol/L | 72  
proinsulin 102 pmol/L | 72  
HbA1c 59 mmol/mol (week 35 + 3) | 72  
no insulin requirements | 96  
stable blood glucose ~6 mmol/L | 96  
cesarean section | 192  
healthy baby delivered | 192  
Apgar scores normal at 1 min | 192  
Apgar scores normal at 5 min | 192  
Apgar scores normal at 10 min | 192  
birth-weight 3850 g (large for gestational age) | 192  
placental weight 920 g | 192  
baby blood glucose 2.8 mmol/L (1 h postpartum) | 193  
baby blood glucose 4.3 mmol/L (4 h postpartum) | 196  
mother and baby discharged | 312  
blood glucose, plasma insulin, C-peptide and IGF-1 normalized | 312  
no antidiabetic medication (breast-feeding) | 312  
insulin 258 pmol/L (7 months postpartum) | 5232  
C-peptide 1836 pmol/L (7 months postpartum) | 5232  
proinsulin 76 pmol/L (7 months postpartum) | 5232  
HbA1c 116 mmol/mol (7 months postpartum) | 5232  
treatment warranted (return of insulin resistance) | 5232  
reached insulin 1420 IU/day | -72  
additional blood samples taken | -72  
leptin 117.6 µg/L | -72  
MBL 2418 ng/mL | -72  
IGF-1 401 µg/L | -72  
Novorapid “200–400 IU/day pn” added | -72  
no signs of placental insufficiency | -72  
insulin 780 IU/day | -384  
insulin 580 IU/day | -528  
insulin 360 IU/day | -1104  
insulin 345 IU/day | -1440  
insulin 290 IU/day | -1776  
insulin 270 IU/day | -2112  
insulin 211 IU/day | -2448  
insulin 192 IU/day | -2880  
regimen changed to Insulatard + Novorapid | -2880  
insulin 66 IU/day | -3384  
insulin 54 IU/day | -3600  
insulin 28 IU/day | -3720  
referred to outpatient clinic | -3816  
HbA1c 59 mmol/mol (week 12 + 2) | -3816  
insulin treatment initiated | -3816  
Novomix 30 20 IU/day started | -3816  
blood pressure 136/71 mmHg | -3816  
no lipodystrophy | -3816  
no severe acanthosis nigricans | -3816  
no hirsutism | -3816  
no obstructive sleep apnea | -3816  
no Cushing’s syndrome | -3816  
no acromegaly | -3816  
no hyperthyroidism | -3816  
pre-pregnancy BMI 40 kg/m² | -6000  
weight 115 kg prior to pregnancy | -6000  
irregular periods | -9000  
weight loss 30 kg | -9000  
regular periods | -9000  
spontaneous pregnancy | -6000  
metformin discontinued | -3816  
liraglutide discontinued | -3816  
ACE inhibitor discontinued | -3816  
polycystic ovary syndrome diagnosed | -61320  
type 2 diabetes diagnosed | -61320