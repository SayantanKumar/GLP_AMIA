female patient | 0
53-year-old | 0
transferred to our hospital | 0
admitted to our hospital | 0
height 149 cm | 0
weight 109 kg | 0
BMI 49.0 kg/m2 | 0
blood pressure 108/69 mmHg | 0
pulse rate 83 beats/min | 0
peripheral blood oxygen saturation 40–60% in room air | 0
body temperature 38.0 °C | 0
decreased bilateral breath sounds | 0
systemic edema | 0
D-dimer 5.1 μg/mL | 0
brain natriuretic peptide 108 pg/mL | 0
arterial pressure of oxygen 31 mmHg | 0
arterial pressure of carbon dioxide 75 mmHg | 0
type-2 respiratory failure | 0
overall decrease in chest radiographic permeability | 0
slightly decreased ejection fraction | 0
no pulmonary hypertension | 0
bilateral lung congestion on CT | 0
no features suggestive of other lung diseases on CT | 0
no remarkable cardiac enlargement on CT | 0
suspected obesity-hypoventilation syndrome | 0
congestive heart failure | 0
upper airway infection | 0
intubation | 0
mechanical ventilation initiated | 0
treated with diuretics for right heart failure | 0
extubated | 96
PaCO2 retention resolved | 96
non-invasive positive-pressure ventilation started (IPAP/EPAP 14/7 cmH2O all day) | 96
non-invasive positive-pressure ventilation continued | 120
non-invasive positive-pressure ventilation continued | 144
non-invasive positive-pressure ventilation continued | 168
non-invasive positive-pressure ventilation continued | 192
switched to night-time NPPV (IPAP/EPAP 14/7 cmH2O) | 216
oxygen therapy 3 L/min in daytime started | 216
pulmonary function test: vital capacity 1.59 L (58.6 %) | 504
pulmonary function test: FEV1 1.46 L (68.5 %) | 504
restricted ventilation failure | 504
discharged with night-time NPPV (IPAP/EPAP 12/7 cmH2O) | 528
home oxygen therapy 2 L/min at rest | 528
home oxygen therapy 3 L/min during sleep | 528
weight decreased following first hospitalization due to diuresis | 600
weight remained stable for approximately 2 years after discharge | 17520
weight >90 kg 4 years after discharge | 35040
continuous glucagon-like peptide-1 receptor agonist administered | 35040
weight loss >30 kg achieved | 43800
readmitted for consideration of withdrawal of NPPV and oxygen therapy | 43800
BMI 33.3 kg/m2 | 43800
chest radiography: no findings suggestive of heart failure | 43800
chest CT: no abnormalities in both lung fields | 43800
vital capacity improved to 1.96 L (79 %) | 43800
arterial blood gases improved (hypoxia and hypercarbia improved) | 43800
A-aDO2 25.8 Torr | 43800
NPPV setting 1: SpO2 acceptable, prolonged high PtcCO2 | 43800
NPPV setting 2: SpO2 acceptable, prolonged high PtcCO2 | 43800
NPPV setting 3: SpO2 acceptable, prolonged high PtcCO2 | 43800
NPPV setting 4: difficulty falling asleep | 43800
NPPV setting 4: nocturnal awakenings | 43800
NPPV setting 4: prolonged high PtcCO2 | 43800
NPPV setting 5: PtcCO2 ≥55 mmHg <10 min | 43800
NPPV setting 5: PtcCO2 ≥50 mmHg prolonged | 43800
weaned off oxygen therapy | 43800
planned further weight loss | 43848
weight 50 kg in her twenties | -262800
gained weight after childbirth | -175200
weight 80 kg after childbirth | -175200
developed hyperthyroidism (treated with radiotherapy) | -8760
radiotherapy for hyperthyroidism | -8760
developed hypothyroidism | -8760
thyroid hormone supplementation started | -8760
weight exceeded 100 kg | -8760
edema developed | -720
additional weight gain | -720
severe hypercapnic respiratory failure diagnosed | -720
initial hospitalization for respiratory failure | -720
edema did not improve after a month of treatment | -24
dyspnea developed | -24
referred to a local hospital | -24
receiving NPPV | -18
receiving diuretics | -18
ventilatory failure worsened | -12