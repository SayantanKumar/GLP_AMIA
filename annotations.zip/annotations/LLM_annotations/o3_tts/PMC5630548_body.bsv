male | 0
62-year-old | 0
admitted to hospital | 0
cerebral hemorrhage | 0
no family history of diabetes | 0
no past medical history including collagenous diseases | 0
glargine 6 units administered | 0
type 2 diabetes | ‑8760
body mass index 18.5 kg/m2 | ‑8760
vildagliptin 100 mg/day | ‑8760
referred to hospital for dilated cardiomyopathy | ‑8760
dilated cardiomyopathy | ‑8760
left ventricular assist device implanted | ‑8760
glycated hemoglobin 7.4 % | ‑8760
craniotomy | 6
left-side hemiparesis | 6
insulin aspart 6-6-4 units administered | 2
poor glycemic control (fasting plasma glucose 120 mg/dL) | 12
poor glycemic control (postprandial plasma glucose 180–230 mg/dL) | 12
skin redness at injection site | 12
skin itching at injection site | 12
skin swelling at injection site | 12
insulin allergy suspected | 12
insulin aspart 30 mix 20-0-10 units initiated | 24
insulin degludec 12-0-4 units initiated | 24
local skin reaction to insulin aspart 30 mix | 26
local skin reaction to insulin degludec | 26
anti-insulin antibodies >50 U/mL detected | 48
anti-insulin-specific IgE 27 UA/mL detected | 48
anti-insulin receptor antibodies 25.2 % detected | 48
fasting plasma glucose 160 mg/dL | 48
C-peptide 7.22 ng/mL | 48
immunoreactive insulin 1150 μU/mL | 48
hyperinsulinemia detected | 48
type B insulin resistance syndrome diagnosed | 48
insulin allergy diagnosed | 48
acanthosis nigricans not found | 48
no history of Helicobacter pylori infection | 48
no renal impairment | 48
glutamic acid decarboxylase antibody negative | 48
low complement C4 7 mg/dL | 48
low complement CH50 27 U/mL | 48
Scatchard analysis: low affinity constant 0.0109×108/M | 60
Scatchard analysis: high binding capacity 47.4×10−8 M | 60
urinary tract infection | 48
switched from insulin to liraglutide therapy | 72
liraglutide 0.3 mg/day initiated | 72
no other drugs aside from liraglutide | 72
liraglutide dose increased weekly to 0.9 mg/day | 336
improved fasting plasma glucose 90–110 mg/dL | 168
improved postprandial glucose <160 mg/dL | 168
no allergic skin reactions after liraglutide | 168
no liraglutide-related side effects | 168
no hypoglycemic events on liraglutide | 168
fasting plasma glucose 101 mg/dL | 720
C-peptide 4.1 ng/mL | 720
immunoreactive insulin 732 μU/mL | 720
anti-insulin antibody level unchanged >50 U/mL | 720
anti-insulin receptor antibody level 17.9 % | 720
follow-up 2 years | 17520
good glycemic control (fasting plasma glucose 100 mg/dL) | 17520
HbA1c 6.4 % | 17520
no typical clinical features of type B insulin resistance syndrome | 17520