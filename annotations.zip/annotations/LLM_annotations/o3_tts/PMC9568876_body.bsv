48 years old | 0
female | 0
postmenopausal | 0
from Lalitpur | 0
presented to hospital | 0
admitted to ICU | 0
lateral neck pain | -240
no fever | 0
no throat pain | 0
no trauma | 0
diabetes mellitus | 0
skipped oral hypoglycemic medication | -96
hypothyroidism (well-controlled) | 0
hypertension (well-controlled) | 0
social alcohol use | 0
thyroxine 87.5 µg daily | 0
liraglutide 5 mg daily | 0
repaglinide 1 mg thrice daily | 0
aspirin 75 mg daily | 0
atorvastatin 10 mg daily | 0
normal BMI | 0
conscious, calm, cooperative, oriented | 0
vitals stable | 0
general and systemic examinations non-revealing | 0
localized ill-defined 3 × 2 cm lesion left neck | 0
tenderness of neck lesion | 0
local rise in temperature over neck lesion | 0
crepitations over neck lesion | 0
palpable draining lymph nodes | 0
distal neurovascular status intact | 0
total leukocyte count 30 330 | 0
neutrophils 87 % | 0
hemoglobin 12.5 g/dl | 0
platelet count 166 000/ml | 0
random blood sugar 502 mg/dl | 0
hyperglycemia | 0
serum urea 63 mg/dl | 0
serum creatinine 3.5 mg/dl | 0
urine sugar +++ | 0
urine protein + | 0
urine acetone positive | 0
serum protein 6.4 g/dl | 0
serum albumin 3.3 g/dl | 0
arterial pH 7.067 | 0
pCO2 8.7 mm Hg | 0
pO2 77 % (room air) | 0
serum bicarbonate 12.6 mmol/L | 0
metabolic acidosis | 0
diagnosis of diabetic ketoacidosis | 0
neck abscess diagnosis | 0
insulin therapy started | 0
intravenous fluids started | 0
piperacillin–tazobactam started | 0
ultrasonography: 3 × 6 cm ill-defined mass left neck | 0
neck exploration and debridement under general anesthesia | +12
daily neck dressing begun | +12
wound swab culture sent | +12
pseudomonas aeruginosa cultured | +24
pseudomonas sensitive to amikacin and ciprofloxacin | +24
intravenous ciprofloxacin 200 mg twice daily started | +24
intravenous amikacin 500 mg thrice daily started | +24
histopathology consistent with necrotizing fasciitis | +48
necrotizing fasciitis diagnosis | +48
good signs of recovery | +168
tolerated oral feeding | +168
normal hematological parameters | +168
normal renal function | +168
blood sugar 166 mg/dl | +168
wound showing good healing | +168
anti-hyperglycemic medications prescribed | +168
advised regular dressing and blood sugar monitoring | +168
discharged home | +168