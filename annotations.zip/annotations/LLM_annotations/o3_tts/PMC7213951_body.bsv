type 2 diabetes mellitus | 0
generalized anxiety disorder | 0
major depressive disorder | 0
hypertension | 0
hyperlipidemia | 0
heart murmur | 0
degenerative arthritis of the knee | 0
esophageal reflux disease | 0
iron deficiency anemia | 0
insomnia | 0
vitamin D deficiency | 0
tobacco use (5 cigarettes per day) | 0
denies alcohol use | 0
denies illicit drug use | 0
insulin glargine 8 units subcutaneously daily | 0
metformin extended release 2000 mg daily | 0
dulaglutide 1.5 mg subcutaneously once weekly | 0
venlafaxine ER 225 mg daily | 0
aspirin | 0
losartan | 0
ezetimibe | 0
polysaccharide iron complex | 0
multivitamin | 0
omeprazole-sodium bicarbonate | 0
HbA1c 7.5 % | -2160
average self-monitoring fasting blood glucose 96 mg/dL | -2160
average self-monitoring bedtime blood glucose 175 mg/dL | -2160
titrated to dulaglutide 1.5 mg | -2496
reducing snacks prior to bedtime | -2160
initiating carbohydrate counting (≈45 g dinner, 15 g snack) | -2160
fasting blood glucose 88 mg/dL | -720
2-hour postprandial blood glucose 165 mg/dL | -720
venlafaxine discontinued | 0
desvenlafaxine ER 50 mg daily initiated | 0
HbA1c 7.2 % | 0
average fasting blood glucose 106 mg/dL | 0
average postprandial blood glucose 129 mg/dL | 0
patient health questionnaire-9 score 8 | 0
average fasting blood glucose 136 mg/dL | 720
average postprandial blood glucose 207 mg/dL | 720
insulin glargine increased to 10 units daily | 720
self-reported no changes to diet or exercise | 720
average fasting blood glucose 129 mg/dL | 1440
average postprandial blood glucose 192 mg/dL | 1440
insulin glargine titrated to 12 units daily | 1440
average fasting blood glucose 118 mg/dL | 1680
average postprandial blood glucose 194 mg/dL | 1680
insulin lispro 2 units before dinner initiated | 1680
insulin lispro increased to 8 units prior to dinner | 2160
average fasting blood glucose 106 mg/dL | 2160
average postprandial blood glucose 146 mg/dL | 2160
HbA1c 7.3 % | 2160
HbA1c 6.9 % | 4320
weight stable 62.7–63.6 kg | 4320
patient health questionnaire-9 score unchanged at 8 | 4320
patient refused desvenlafaxine discontinuation | 4320