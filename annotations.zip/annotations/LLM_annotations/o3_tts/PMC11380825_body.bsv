83-year-old male | 0
Anxiety | -8760
Hyperlipidemia | -8760
Type 2 diabetes mellitus | -8760
Hypertension | -8760
Glaucoma | -8760
Semaglutide | -8760
Empagliflozin | -8760
Brimonidine | -8760
Latanoprost | -8760
Atorvastatin | -8760
Headache | -48
Decreased appetite | -48
Non-contrast CT head no acute process | -48
Serologic workup negative for acute infection, toxic, or metabolic derangements | -48
Analgesics administered | -48
Discharged in stable condition (outside hospital) | -46
Worsened mental status | -4
Worsening headache | -4
Nausea | -4
Worsening appetite | -4
Afebrile | -4
Blood pressure 131/99 | -4
Heart rate 81 | -4
Respiratory rate 18 | -4
Fingerstick glucose 260 mg/dL | -4
Insulin aspart 2 units given | -4
Fentanyl administered | -4
Ondansetron administered | -4
CT abdomen and pelvis negative for acute process | -4
Repeat CT head acute left occipital intraparenchymal hemorrhage | -4
Levetiracetam 2 g load | -4
Transferred to neurocritical care unit | -2
Arrival to neurocritical care unit | 0
Encephalopathic | 0
Not oriented to date | 0
Not oriented to place | 0
Right homonymous hemianopsia | 0
Trouble completing complex commands | 0
Intact strength | 0
Intact sensation | 0
NIH Stroke Scale 5 | 0
No increased skin turgor | 0
No dry skin | 0
No dry mucosal membranes | 0
No polydipsia | 0
No decreased urine output | 0
Electrocardiogram normal sinus rhythm | 0
Hemoglobin A1c 10.2 % | 0
Blood urea nitrogen 23 mg/dL | 0
Anion gap 17 mmol/L | 0
Bicarbonate 20 mmol/L | 0
β-hydroxybutyrate 3.65 mmol/L | 0
Serum glucose 120 mg/dL | 0
Urine glucose > 1000 mg/dL | 0
Urine ketones > 80 mg/dL | 0
Urinalysis negative for infection | 0
Urine toxicology screen negative | 0
Euglycemic diabetic ketoacidosis | 0
Dextrose 10 % 250 cc/h infusion started | 0
Potassium chloride infusion started | 0
Insulin drip 1 U/h started | 0
Diet allowed to eat | 0
Electrolytes monitored every 4 h | 0
β-hydroxybutyrate monitored every 4 h | 0
Blood pressure goal systolic < 160 mmHg | 0
6-hour repeat CT head stable | 6
Anion gap closed to 10 mmol/L | 12
β-hydroxybutyrate decreased to 0.93 mmol/L | 12
Transitioned to insulin sliding scale | 12
Correction of DKA | 12
Resolution of encephalopathy | 12
Resolution of nausea | 12
Persistent visual field cut | 12
CT angiogram head/neck: prominent arterial branches | 12
MRI brain suggests arteriovenous malformation | 18
Digital subtraction angiography no arteriovenous malformation | 24
Intraparenchymal hemorrhage attributed to uncontrolled hypertension | 24
Lisinopril started | 26
Hospital day 9 | 216
Discharged home with home health | 216
Semaglutide discontinued | 216
Empagliflozin discontinued | 216
Glargine started | 216
Lispro started | 216
Outpatient endocrinology follow-up arranged | 216
Outpatient vascular neurology follow-up arranged | 216
Lost to follow-up | 720