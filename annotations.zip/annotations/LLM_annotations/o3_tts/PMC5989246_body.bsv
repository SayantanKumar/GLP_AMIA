32-year-old | 0
Caucasian woman | 0
referred to our unit | 0
admission | 0
chronic diarrhea | -87600
recurrent depression | -131400
primary tonic-myoclonic epilepsy | -131400
colonic Crohn’s disease | -78840
SeHCAT scintigraphy 0 retention | -52560
severe bile acid malabsorption | -52560
colestyramine treatment | -50000
colesevelam treatment (initial) | -50000
loperamide treatment (initial) | -50000
codeine phosphate treatment | -50000
escitalopram treatment | -35040
venlafaxin treatment | -35040
infliximab treatment | -17520
adalimumab treatment | -17520
natalizumab treatment | -17520
vedolizumab treatment | -17520
Crohn’s disease remission | -24
colonoscopy normal | -24
fecal calprotectin < 30 mg/kg | -24
duodenal biopsies normal | -24
no bowel surgery | 0
height 170 cm | 0
weight 52 kg | 0
low plasma potassium | 0
low plasma magnesium | 0
plasma sodium normal | 0
urinary sodium undetectable | 0
fecal culture negative for Campylobacter | 0
fecal culture negative for Salmonella | 0
fecal culture negative for Yersinia | 0
fecal culture negative for Shigella | 0
Clostridium difficile PCR toxin positive | 0
vancomycin therapy started | 0
MRI small bowel normal | 0
double balloon endoscopy remission | 0
duodenal, jejunal, ileal, and colonic biopsies normal | 0
laxative screen normal | 0
markers of systemic infection normal | 0
markers of metabolic disease normal | 0
6-mercaptopurine treatment | 0
colesevelam 625 mg three times per day | 0
loperamide 2-8 mg per day | 0
levetiracetam 1500 mg per day | 0
lamotrigine 400 mg per day | 0
spironolactone trial | 24
octreotide trial | 24
liraglutide trial | 24
spironolactone no effect | 48
octreotide abdominal pain | 48
liraglutide no effect | 48
weight loss 2 kg to 52 kg | 72
potassium infusion up to 100 mmol per day | 48
hypertonic 3 % NaCl 2000 mL per day | 48
intestinal failure type III subtype A3 diagnosed | 48
twice-weekly infusions of fluids and electrolytes | 72
repeat Clostridium difficile test positive | 120
vancomycin taper started | 120
fecal microbiota transplant | 168
bowel movements decreased from 17 to 13 per day | 192
obeticholic acid started 10 mg per day | 288
obeticholic acid increased to 25 mg per day | 384
bowel movements decreased to 7 per day | 720
weight increased by 2 kg to 54 kg | 720
weaned off intravenous fluid support | 720
quality of life improved from 35 to 85 | 720
resumed social activities | 744
running induced increased bowel movements | 744
ibuprofen 400 mg induced liquid stools | 768
treatment pause of obeticholic acid | 1440
bowel movements increased to 16 per day | 1512
profound hypokalemia | 1512
obeticholic acid restarted | 1520
no adverse effects during 6 months follow-up | 4320
serum pancreatic amylase 266 U/L | 4320
6-mercaptopurine paused | 4320
ultrasound pancreas and bile ducts normal | 4320
total cholesterol decreased from 7.5 to 5.9 mmol/L | 4320
LDL-cholesterol decreased from 4.5 to 3.1 mmol/L | 4320
HDL-cholesterol increased from 2.0 to 2.1 mmol/L | 4320
mean serum FGF19 increased from 35.7 to 167 pg/mL | 4320
p-amylase normalized | 4560
6-mercaptopurine restarted | 4600