immigrated to United States | -70080
menarche begun | -68640
45-pound weight gain | -65760
fever | -65040
perianal pain | -65040
surgery for large perianal abscess | -65040
multiple skin lesions consistent with hidradenitis suppurativa | -65040
acne developed over face | -65040
periods became irregular | -65040
widespread disease with up to 20 lesions | -60720
intermittent perianal disease | -60720
widespread abdominal scarring | -60720
contracture of the entire body | -60720
oral antibiotics (episodic and continuous) | -65040
intravenous antibiotics | -65040
numerous surgeries | -65040
isotretinoin for acne treatment | -65040
periodic metformin | -65040
oral birth control usage | -65040
menstrual period flare-ups | -720
increased pain medication | -720
sleep severely impaired | 0
presented for evaluation and treatment | 0
19-year-old | 0
female | 0
South Indian origin | 0
polycystic ovary syndrome | 0
fatty liver | 0
obesity | 0
hidradenitis suppurativa | 0
no family history of hidradenitis suppurativa | 0
no family history of colitis | 0
no family history of autoimmune disease | 0
maternal grandparents late-onset diabetes | 0
truncal hidradenitis suppurativa involving 40% body surface | 0
extensive muscle wasting of extremities | 0
facial acne without scarring | 0
hirsutism absent | 0
weight 215 pounds | 0
BMI 37 class II obesity | 0
microcytic anemia hemoglobin 6.2 g/dL | 0
elevated AST 55 U/L | 0
elevated ALT 112 U/L | 0
blood sugar 117 mg/dL | 0
HbA1c 5.7 % | 0
pre-diabetes | 0
aggressive lifestyle modification low-carbohydrate diet initiated | 0
oral contraception restarted | 0
glucose-6-phosphate dehydrogenase test negative | 0
dapsone 100 mg daily started | 0
initial minimal improvements | 720
no clinical improvement first 3 months | 2160
finasteride 5 mg daily started | 2160
metformin 2000 mg daily started | 2160
liraglutide 0.6 mg daily started | 2160
liraglutide increased to 1.8 mg | 3600
40-pound weight loss | 4320
decline in liver enzymes | 4320
patient felt better | 4320
less intense and frequent flares | 4320
liver enzyme resolution | 8760
large perianal abscess | 10800
hospitalization | 10800
surgery for perianal abscess | 10800
perianal lesion healed completely | 11304
leukocytosis resolved | 17520
anemia resolved | 17520
hypoalbuminemia resolved | 17520
sedimentation rate reduced to 34 mm/h | 17520
HbA1c 5.2 % | 17520
blood testing interval reduced to every 3 months | 17520
no adjunctive antibiotics required for past year | 26280
no new lesion for 6 months | 26280
completed 3 years of regimen | 26280
axillary lesions healed completely | 26280
groin, thigh, perianal disease improved 90 % | 26280
thoraco-abdominal lesions improved 60 % | 26280
facial acne improved but persisted | 26280
weight regain noted | 26280
no physical abnormality detected | 26280
no biochemical abnormality detected except minimal elevated ESR | 26280
sedimentation rate minimally elevated | 26280
adverse effects absent | 26280