type 2 diabetes mellitus | -183960  
obesity | -183960  
CKD stage 4 | -1  
nephrotic syndrome | -1  
liraglutide 0.9 mg/day | -1  
pioglitazone 15 mg/day | -1  
insulin aspart 40 U before breakfast | -1  
insulin aspart 20 U before lunch | -1  
insulin aspart 24 U before dinner | -1  
insulin glargine 65 U at bedtime | -1  
plasma glucose 254 mg/dL | -504  
HbA1c 8.3% | -504  
BNP 7.9 pg/mL | -504  
BNP increased from 7.9 to 38.6 pg/mL | -504  
admitted to hospital | 0  
36 years old | 0  
male | 0  
pneumonia | 0  
heart failure | 0  
body height 158.6 cm | 0  
body weight 137.9 kg | 0  
body mass index 54.8 kg/m2 | 0  
fever | 0  
tachycardia | 0  
heart rate 118 /min | 0  
hypoxemia | 0  
SpO2 94% with 4 L oxygen | 0  
tachypnea | 0  
respiratory rate over 20 /min | 0  
cardiomegaly on chest X-ray | 0  
pleural effusion on chest X-ray | 0  
consolidation on chest X-ray | 0  
systolic blood pressure 168 mm Hg | 0  
diastolic blood pressure 95 mm Hg | 0  
eGFR 14 mL/min/1.73 m2 | 0  
serum creatinine 4.7 mg/dL | 0  
daily urinary protein 15.5 g/day | 0  
BNP 38.6 pg/mL | 0  
pioglitazone discontinued | 96  
dapagliflozin 5 mg/day started | 96  
body weight decreased | 96  
serum ketone bodies 557 µmol/L | 192  
high serum ketone bodies | 192  
high serum ketone bodies 407 µmol/L | 1032  
body weight loss over 20 kg | 1056  
serum creatinine decreased | 1056  
eGFR increased | 1056  
urinary protein decreased by 10.8 g/day | 1056  
daily insulin dose decreased to 113 U | 1056  
liraglutide 0.9 mg/day (discharge regimen) | 1056  
dapagliflozin 5 mg/day (continued) | 1056  
insulin aspart 46 U before breakfast | 1056  
insulin aspart 10 U before lunch | 1056  
insulin aspart 16 U before dinner | 1056  
insulin glargine 41 U at bedtime | 1056  
discharged from hospital | 1056  
BNP 5.3 pg/mL | 1944  
plasma BNP decreased | 1944