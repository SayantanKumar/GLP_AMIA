73-year-old | 0  
male | 0  
obese | 0  
Caucasian | 0  
patient came to our observation | 0  
diagnosed with T2DM | -35040  
lifestyle modifications initiated | -35040  
metformin 1000 mg twice daily started | -35040  
severe psoriasis | -52560  
chronic obstructive pulmonary disease | -87600  
inhaled long-acting beta-adrenoceptor agonists prescribed | -87600  
inhaled steroids prescribed | -87600  
adalimumab started | -8760  
little effect of adalimumab | -8000  
adalimumab discontinued | -1440  
topical medications for psoriasis (unsatisfactory results) | -1440  
height 158 cm | 0  
weight 106.7 kg | 0  
BMI 42.7 | 0  
HbA1c 7.9 % | 0  
fasting glucose 162 mg/dL | 0  
self-monitoring blood glucose poor control | 0  
PASI 33.2 | 0  
DLQI 26 | 0  
semaglutide 0.25 mg/week started | 0  
semaglutide dose increased to 0.50 mg/week | 672  
semaglutide dose increased to 1 mg/week | 2688  
dermatologist visit at 4 months | 2880  
PASI 8.0 | 2880  
HbA1c 6.4 % | 2880  
fasting glucose 124 mg/dL | 2880  
BMI 40.3 | 2880  
DLQI 3 | 2880  
significant amelioration of quality of life reported | 2880  
patient refused reintroduction of adalimumab | 2880  
HbA1c 5.4 % | 7200  
fasting glucose 98 mg/dL | 7200  
BMI 38.3 | 7200  
PASI 2.6 | 7200  
DLQI 0 | 7200  
no effect of psoriasis on the patient | 7200  
semaglutide treatment normalized HbA1c | 7200  
semaglutide induced weight loss | 7200  
no significant side effects observed | 7200